package com.att.oce.transformation

import org.apache.camel.Exchange;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory
import com.att.oce.bpm.common.TransformationService;
import com.att.oce.bpm.common.WirelineTransformationService;
import com.att.oce.bpm.common.WirelineConstants;
import com.att.oce.bpm.error.APIFailedException
import org.springframework.stereotype.Component;

@Component('ValidateCreditCardTransformation')
class ValidateCreditCardTransformation extends WirelineTransformationService {
	def creditCard
    String url;
   @Override String getApiName()
		{
			return 'validateCreditcard';
		}
	
		public boolean preCondition(order){
			
			println('CreateValidateCreditCardTransformation.preCondition')
			
			def creditCard = order.PaymentOptions.PaymentOption.PaymentMethod?.CreditCard
			println("CreditCard Details::"+creditCard)
			
			def ccTypeNull = creditCard.findAll { cc -> (cc.CreditCardNumber!=null 
				&& cc.CardBillingZipCode !=null && cc.ExpirationYearMonth != null && cc.CreditCardType == null)
			}.collect{it}
			
			def flag = false
			if(ccTypeNull && ccTypeNull.size()>0) {
				flag = true
			}
			return flag
		}
		
		public String getApiUrn() {
			return "urn:csi:services:lscrm:CreateUnifiedServiceAccount.jws";
		}
	
		public void transform(Exchange exchange)
		{
			println('CreateValidateCreditCardTransformation.transform')
			
			exchange.properties.order = exchange.in.body.order
			exchange.properties.executionContext  = exchange.in.body.executionContext
			
			def order = exchange.in.body.order
			println("ORDER IS::"+order)
			
			def msgHeader = createMessageHeader((Map<String,Object>)exchange.in.body.order)
			def vccRequest = prepareRequest(order,msgHeader)
			println(" VCC req ::"+vccRequest)
			
			
			exchange.out.body = vccRequest
			setCSIHttpHeaders(exchange)
			exchange.out.headers.put("CamelHttpUri",resolveURN(getApiUrn(), url))
			exchange.properties.put("OceCSIApiName",getApiName())
			println('CreateValidateCreditCardTransformation.transform done')
			
	   }
		
		def prepareRequest(order,msgHeader)
		{
			def str
			def replaceStr
			def creditCard = order.PaymentOptions.PaymentOption.PaymentMethod?.CreditCard
			println("CreditCard Details::"+creditCard)
			
			def Country=order.Addresses.Address?.ParsedAddress?.Country
			println("country is::"+Country)
			String  cc_ExpirationYearMonth =creditCard?.ExpirationYearMonth
			println(cc_ExpirationYearMonth)
			println('new expirationyearMonth'  +'   '+cc_ExpirationYearMonth.indexOf('-'))
			if(cc_ExpirationYearMonth!=null && cc_ExpirationYearMonth.indexOf("-") > 0)
			{
				println('under if condition')
				 str=cc_ExpirationYearMonth
				 str = str.replace('-','')
			}
			else
			{
				println('under else condition')
				str = cc_ExpirationYearMonth
			}
			
			def vccRequest = [ messageHeader : msgHeader,
							   validateCreditCardRequest : [
								   
								   zipcode:creditCard?.CardBillingZipCode,
								   ExpirationYearMonth :str,
								   country: Country,
								   CreditCardNumber:creditCard?.CreditCardNumber,
								   Source:
								   [
									   sourceSystem:WirelineConstants.PAYMENT_SOURCE_SYSTEM_HARDROCK,
									   sourceLocation:WirelineConstants.PAYMENT_SOURCE_LOCATION_CS,
									   sourceUser:WirelineConstants.PAYMENT_SOURCE_USER_HARDROCK
								   ]
								]
							   ]
			
		  return vccRequest
		}

		public void processResponse(Exchange exchange) {
			
			println('VCC Response :: ' + exchange.in.body)
			println('CreateValidateCreditCardTransformation.processResponse done')
	
			def order = exchange.properties.order
			def executionContext = exchange.properties.executionContext
	
			def vccResponseXml = new XmlSlurper().parseText(exchange.in.body)
			def vccResponse = exchange.in.body;
	
			executionContext.put("vccResponse", vccResponse)
			//println ("RESPONSE" + vccResponseXml)
	
			def cct= WirelineConstants.VCC_CONCAT_STR
			
			/*ArrayList<String> paymentOptionList=new ArrayList<String>()
			 paymentOptionList = order.PaymentOptions.PaymentOption
			def po
			for( po in paymentOptionList) 
			{
				def creditCard = po.paymentMethod.CreditCard
				if(creditCard != null) 
				{
					creditCard.put('CreditCardType',vccResponse.conact(cct))
				}
			}	*/
			
			
			def paymentOptionList = order.PaymentOptions.PaymentOption
			
					for(def i=0;i<paymentOptionList.size();i++)
					{
						def paymentOptionMap=paymentOptionList.get(i)
						def creditCard = paymentOptionMap.CreditCard
						if(creditCard!= null)
						{
							creditCard.put('CreditCardType',cct)
						}
						
						
						
						
			if (vccResponseXml.Body.Fault.toString().size()>0){
				def e = new APIFailedException();
				e.api = getApiName()
				e.code = vccResponseXml.Body.Fault.detail.CSIApplicationException.Response.code
				e.codeDescription = vccResponseXml.Body.Fault.detail.CSIApplicationException.Response.description
				e.subCode = vccResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code
				e.subCodeDescription = vccResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
				addTransactionHistory(exchange,e);
				throw e
			}
			else
			{
				addTransactionHistory(exchange,null);
			}
			
			
			
			//return exchange.in.body
		}
	
		}
		
		
		
//		public void printRequest(Exchange exchange)
//		{
//			println("**************** REQUEST is****************************"+exchange.in.body)
//		}
	
		
}	
		

