
package com.att.oce.transformation

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.common.WirelineTransformationService;
import com.att.oce.bpm.common.util.ErrorBean
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.error.OceErrorHandler
import com.att.oce.config.components.GlobalProperties
import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import groovy.json.JsonSlurper
import com.att.oce.bpm.utility.OrderUtility

/**
 *
 * @author PS00484310
 *
 */
@Component('cancelWirelinePayment')
class CancelWirelinePaymentTransformation extends WirelineTransformationService {

	static Logger log = LoggerFactory.getLogger(CancelWirelinePaymentTransformation.class)

	@Override String getApiName(){
		return 'CancelWirelinePayment';
	}
	
	public void pringBody(Exchange exchange) {
		println("CWP Body :: " + exchange.in.body)
	}
	
	public boolean preCondition(order,executionContext) {
		return (OrderUtility.isEligibleForCWP(order) || 
			(OrderUtility.checkPaymenteCollected(order) && OrderUtility.isWirelessProductExist(order)))
	}

	/**
	 * @param exchange
	 */
	public void transform(Exchange exchange){
		println ('CancelWirelinePaymentTransformation.transform')
		int index = 0
//	    def order = exchange.in.body.order
		exchange.properties.order = exchange.in.body.order
		def order = exchange.in.body.order
		exchange.properties.put("referenceId",order.CustomerOrderNumber)
//		exchange.properties.put('apiURN', 'urn:CancelWirelinePayment.jws')
		exchange.properties.put("fedIndicator",false);
		exchange.properties.put("executionContext", exchange.in.body.executionContext)

		def apiURN = getApiUrn()
		def apiUrl = super.resolveURN(apiURN, null)
		exchange.properties.apiURN = apiURN
		exchange.properties.apiUrl = apiUrl
		
		println('ORDER :: ' + order)

		def payment_Options =   OrderUtility.getPaymentOptionForAdvancePay(order);
		def PreAuthorization_code = OrderUtility.getPreAuthorizationCode(payment_Options);
		def Source_System =  OrderUtility.getPaymentSourceSystem(order);
		def Source_Location =  OrderUtility.getPaymentSourceLocation(order);
		def Source_User =  OrderUtility.getPaymentSourceUser(order);

		def cwpRequest = [ messageHeader : createMessageHeader(order),
			CancelWirelinePaymentRequest : [
				SourceSystem: Source_System,
				SourceLocation:Source_Location,
				SourceUser:Source_User,
				PreAuthorizationCode:PreAuthorization_code
			]
		]
		exchange.out.body = cwpRequest
		setAuditLogProperties(exchange,false)
		setCSIHttpHeaders(exchange)
		exchange.out.headers.put("CamelHttpUri",apiUrl)
		exchange.properties.put("OceCSIApiName","CancelWirelinePayment")
		println('CancelWirelinePaymentTransformation.transform done')
	}


	public void processResponse(Exchange exchange) throws APIFailedException
	{
		def executionContext = exchange.properties.executionContext;
		def cwpResposne = new XmlSlurper().parseText(exchange.in.body);
		def order = exchange.properties.order;
		def errDesc = ""
		def errCode = ""
		if (cwpResposne.Body.Fault.size()>0){
			
			errCode = cwpResposne.Body.Fault.detail.CSIApplicationException.Response.code.text()
			
			if(cwpResposne.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description) {
				errDesc = cwpResposne.Body.Fault.detail.CSIApplicationException.Response.description.text() + " " +
					cwpResposne.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description.text()
			} else {
				errDesc = cwpResposne.Body.Fault.detail.CSIApplicationException.Response.description
			}
			
			List<ErrorBean> errList = new ArrayList<ErrorBean>();
			errList.add(new ErrorBean(errCode,errDesc))
			OrderUtility.updateErrorList(order,executionContext,errList,null,null,order.CustomerOrderNumber)
		} else {
			addTransactionHistory(exchange,null)
		}
		
		log.debug('CancelWirelinePaymentTransformation.processResponse')
		println('CWP Response :: ' + exchange.in.body)

		println('CancelWirelinePaymentTransformation.processResponse done')
		//return exchange.in.body
	}
	
	
	@Override
	public String getApiUrn() {
		// TODO Auto-generated method stub
		return 'urn:csi:services:pam:CancelWirelinePayment.jws'
	}
	
	
	
	
	
}