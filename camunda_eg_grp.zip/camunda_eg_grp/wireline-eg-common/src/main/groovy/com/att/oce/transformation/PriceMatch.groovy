package com.att.oce.transformation

import org.apache.camel.Exchange
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.codehaus.plexus.util.dag.Vertex
import org.springframework.stereotype.Component;
import com.att.oce.bpm.common.OceConstants
import com.att.oce.bpm.common.WirelineTransformationService;
import com.att.oce.bpm.common.pricematch.OrderPrice
import com.att.oce.bpm.utility.OrderUtility;
import com.att.oce.bpm.common.pricematch.OMSPricePlan
import com.att.oce.bpm.common.pricematch.OMSStandAlonePromStr;
import com.att.oce.bpm.common.util.ErrorBean
import com.google.common.collect.RowSortedTable;
import com.att.oce.bpm.common.WirelineConstants;

@Component('priceMatch')
class PriceMatchService implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		println('---- Entering Price Mismatch Process')
		def order = execution.getVariable("order");
		def executionContext = execution.getVariable("executionContext")
		try {
			def puspoResponse = executionContext.get("puspoResponse");
			def puspoResponseXml = new XmlSlurper().parseText(puspoResponse);
			computePriceMisMatch(order,executionContext,puspoResponseXml.Body.ProcessUnifiedServiceProductOrderResponse)
		} catch (Exception e) {
			e.printStackTrace();
			OrderUtility.throwBPMNError(e, order, executionContext);
		}

	}

	
	def computePriceMisMatch(Order,executionContext,PUSPOResponse)
	{
		
		println('---- Computing OrderPrice List----')
		/* Computing PriceLists*/
		def orderPriceList = computeOrderPriceList(Order)
		println('Order Price List is ::'+orderPriceList)
		println('---- Computing OMSPrice List----')
		def omsPriceList = computeOMSPriceList(Order,PUSPOResponse)
		println('OMSPrice List is ::'+omsPriceList)
		println('---- Computing OMSStandAlonePrice List----')
		def omsSAPriceList = computeOMSStandAlonePriceList(PUSPOResponse)
		println('OMSStandAlonePrice List is ::'+omsSAPriceList)
		/* Adding Price lists in execution context */
		
		executionContext.put("orderPriceList",orderPriceList)
		executionContext.put("omsPriceList",omsPriceList)
		executionContext.put("omsSAPriceList",omsSAPriceList)
		println('PriceLists added in executionContext Successfully')
		/* Comparing PriceLists */
		comparePricePlanLists(orderPriceList,omsPriceList,omsSAPriceList)
		
		/* Recording PriceMismatches */
		boolean isNoPriceMismatch = RecordPriceMisMatches(orderPriceList,omsPriceList,omsSAPriceList,executionContext)
		
		
		/* Returning true if No Price Mismatch Found */
		//return isNoPriceMismatch;
	}
	
	/* This function is to computeOrderPriceList from order payload.
	   the Unit of Measurement changes the way we calculate the promotion amt. If it is FLATOFF, then we negate the amount
	   and use it as is(OMS Promotions comes in as a negative value). If the UOM is PERCENTAGE, then we need to calculate the promotion amt using the formula
	   MSRP of the LineItem relating to this Promotion * -1 * percentage (full number in the promotion amount field - 50 for 50% off 100 for 100% off) * .01
	   (for converting the whole percentage number to a percentage)
	*/
	def computeOrderPriceList(Order)
	{
		List<OrderPrice> orderPriceList = new ArrayList<OrderPrice>();
		OrderPrice op ;
		
		def uversePromotions = getUversePromotions(Order)
		def uverseGroupsId = getUverseGroupsId(Order)
		def uverseLineItems = Order.LineItems.LineItem.findAll { li -> uverseGroupsId.intersect(li.GroupRefs.GroupRef )}
		
		def billingCode = uverseLineItems.findAll { li -> li.SystemName.contains('CombinedProgram')} .collect{it.BillingCode}.flatten().minus(null)
		
		for(def lineItem in uverseLineItems)
		{
			if( lineItem.Price && lineItem.Price?.MSRP != 0 && lineItem.SystemName != 'ADVANCE_PAYMENT' && lineItem.SystemName != 'AUTO_PAYMENT'
			&& lineItem.SystemName != 'CREDIT_MANAGEMENT_FEE' && lineItem.Price?.PriceType != 'DueToday' && lineItem.Price?.PriceType != 'DUENOW'
			&& (billingCode.contains(lineItem.BillingCode) || lineItem.Characteristics?.CommonCharacteristics?.IgnorePricePlanCode != 'Y') )
			{
				for(def quantity in lineItem.Quantity.toInteger())
				{
					op = new OrderPrice()
					op.setPricePlanCode(String.valueOf(lineItem.BillingCode))
					op.setActualPrice(String.valueOf(lineItem.Price?.MSRP))
					op.setChargeType((lineItem.Price?.PriceType == 'RC') ? lineItem.Price?.PriceType : 'OC')
					op.setBaseOfferId(String.valueOf(lineItem.Price?.BaseOfferId))
					op.setPromSalesType('false')
					op.setSystemName(String.valueOf(lineItem.SystemName))
					op.setQuantity('1')
					op.setIgnorePricePlanCode(lineItem.Characteristics?.CommonCharacteristics?.IgnorePricePlanCode == 'Y' ? 'Y':'N')
					op.setMatch('N')
					orderPriceList.add(op);
				}
			}
		}
		def uversePromotion = Order.Promotions?.Promotion.findAll { up ->  uversePromotions.contains(up.Id)}.collect{it}.flatten().minus(null)
		for(def promotion in uversePromotion)
		{
			if(promotion.size() != 0)
			{
				if(promotion.Amount != 0)
				{
					op = new OrderPrice()
					op.setPricePlanCode(promotion.PromotionId)
					
					def promAmt =  promotion.Amount
					def linItmMsrp
					Order.LineItems.LineItem.each{ li ->
						if(li.PromotionRefs?.PromotionRef?.contains(promotion.Id))
							linItmMsrp = li.Price.MSRP
						}
					
					op.setActualPrice((promotion.UnitOfMeasurement == 'FLATOFF') ? String.valueOf((-1) * promAmt) : ((promotion.UnitOfMeasurement == 'PERCENTAGE') ?
								String.valueOf((-1)* promAmt * 0.01 * linItmMsrp) : '0.0' ))
					if(op.getActualPrice()==0)
						op.setActualPrice("UnknownPromotionUOM-" + promotion.UnitOfMeasurement)
						
					op.setChargeType(promotion.PromotionCycle == 'ONETIME' ? 'OC' : 'RC')
					op.setBaseOfferId(promotion.BaseOfferId)
					op.setPromSalesType('true')
					op.setSystemName(promotion.Id)
					op.setQuantity('1')
					op.setMatch('N')
					orderPriceList.add(op);
				}
			}
		}
		return orderPriceList
	}
	
	/* This function is to compute OMSPricePlanList from PUSPO Response */
	def computeOMSPriceList(Order,PUSPOResponse)
	{
		List<OMSPricePlan> omsPriceList = new ArrayList<OMSPricePlan>();
		OMSPricePlan om ;
		def productConfigurationCal = PUSPOResponse.UnifiedServiceProductDetails?.'*'.ProductConfiguration
		def ComponentDetailscal = productConfigurationCal?.'*'.ComponentDetails.size()
		def VOIPNewComponentDetails = OrderUtility.getAllComponentDetailsAsList( [], PUSPOResponse.UnifiedServiceProductDetails.ProductsInNewOffer.ProductConfiguration.ComponentDetails.flatten())
		println(OrderUtility.getAllComponentDetailsAsList([],PUSPOResponse.UnifiedServiceProductDetails.ProductsInNewOffer.ProductConfiguration.ComponentDetails).size)
		for(def puspoComponentData in VOIPNewComponentDetails)
		{
			for(def billingOffer in puspoComponentData.BillingOffers?.findAll{ bo -> ((bo.actionCode != 'NONE' && bo.actionCode != 'RM') || bo.actionCode.size() == 0 ) }.collect{it}.flatten().minus(null))
			{
				def onetime = billingOffer?.OneTimeCalculatedPrices
				def finalAmt = billingOffer?.OneTimeCalculatedPrices?.finalAmount
				if(billingOffer?.OneTimeCalculatedPrices?.size() != 0 && billingOffer?.OneTimeCalculatedPrices?.finalAmount != 0.0)
				{
					om = new OMSPricePlan()
					
					om.setCatalogID('NA')
					om.setPricePlanCode(String.valueOf(billingOffer?.ProductSpecificationPricing?.ChildPricingSchema?.pricePlanCode.text()))
					om.setChargeCodeType('OC')
					om.setChargeCodeReference(String.valueOf(billingOffer?.OneTimeCalculatedPrices?.name.text()))
					om.setActualPrice(String.valueOf(billingOffer?.OneTimeCalculatedPrices?.finalAmount.text()))
					om.setCurrency(String.valueOf(billingOffer?.OneTimeCalculatedPrices?.currency.text()))
					om.setEligibleForNRC('NA')
					om.setMinNumOfInstallment('NA')
					om.setMaxNumOfInstallment('NA')
					om.setPromotioncode('NA')
					om.setPromSaleType(String.valueOf(billingOffer?.promSaleType?.text()))
					om.setBaseOfferId((String.valueOf(billingOffer?.baseOfferId?.text())) ? (String.valueOf(billingOffer.baseOfferId.text())) : "0")
					om.setMatch('N')
					
					omsPriceList.add(om);
				}
			}
		}
		for(def puspoComponentData in VOIPNewComponentDetails)
		{
			for(def billingOffer in puspoComponentData.BillingOffers?.findAll{ bo -> ((bo.actionCode != 'NONE' && bo.actionCode != 'RM')|| bo.actionCode.size() == 0) }.collect{it}.flatten().minus(null))//not exists left
			{
				if(billingOffer?.RecurringCalculatedPrices?.size() != 0 && billingOffer?.RecurringCalculatedPrices?.finalAmount != 0.0)
				{
					om = new OMSPricePlan()
					
					om.setCatalogID('NA')
					om.setPricePlanCode(String.valueOf(billingOffer?.ProductSpecificationPricing?.ChildPricingSchema?.pricePlanCode.text()))
					om.setChargeCodeType('RC')
					om.setChargeCodeReference(String.valueOf(billingOffer?.RecurringCalculatedPrices?.name.text()))
					om.setActualPrice(String.valueOf(billingOffer?.RecurringCalculatedPrices?.finalAmount.text()))
					om.setCurrency(String.valueOf(billingOffer?.RecurringCalculatedPrices?.currency.text()))
					om.setEligibleForNRC('NA')
					om.setMinNumOfInstallment('NA')
					om.setMaxNumOfInstallment('NA')
					om.setPromotioncode('NA')
					om.setPromSaleType(String.valueOf(billingOffer?.promSaleType.text()))
					om.setBaseOfferId(String.valueOf((billingOffer.baseOfferId.text())) ? (String.valueOf(billingOffer.baseOfferId.text())) : null)
					om.setMatch('N')
					
					omsPriceList.add(om);
				}
			}
		}
		return omsPriceList
	}
	
	/* This function is to compute OMSStandAlonePricePlanList from PUSPO Response */
	def computeOMSStandAlonePriceList(PUSPOResponse)
	{
		List<OMSPricePlan> omsSAPriceList = new ArrayList<OMSPricePlan>();
		OMSPricePlan omSA ;
		
		def productConfigurationCal = PUSPOResponse.UnifiedServiceProductDetails?.'*'.ProductConfiguration
		def ComponentDetailscal = productConfigurationCal?.'*'.ComponentDetails.size()
		def VOIPNewComponentDetails = OrderUtility.getAllComponentDetailsAsList( [], PUSPOResponse.UnifiedServiceProductDetails.ProductsInNewOffer.ProductConfiguration.ComponentDetails.flatten())
		println(OrderUtility.getAllComponentDetailsAsList([],productConfigurationCal?.'*'.ComponentDetails).size)
		for(def puspoComponentData in VOIPNewComponentDetails)
		{
			for(def billingOffer in puspoComponentData.BillingOffers?.findAll{ bo -> (bo.actionCode == 'NONE' ) }.collect{it}.flatten().minus(null))
			{
				if(billingOffer?.OneTimeCalculatedPrices?.size() != 0 && billingOffer?.OneTimeCalculatedPrices?.finalAmount != 0.0)
				{
					omSA = new OMSPricePlan()
					
					omSA.setCatalogID('NA')
					omSA.setPricePlanCode(String.valueOf(billingOffer?.ProductSpecificationPricing?.ChildPricingSchema?.pricePlanCode.text()))
					omSA.setChargeCodeType('OC')
					omSA.setChargeCodeReference(String.valueOf(billingOffer?.OneTimeCalculatedPrices?.name.text()))
					omSA.setActualPrice(String.valueOf(billingOffer?.OneTimeCalculatedPrices?.finalAmount.text()))
					omSA.setCurrency(String.valueOf(billingOffer?.OneTimeCalculatedPrices?.currency.text()))
					omSA.setEligibleForNRC('NA')
					omSA.setMinNumOfInstallment('NA')
					omSA.setMaxNumOfInstallment('NA')
					omSA.setPromotioncode('NA')
					omSA.setPromSaleType(String.valueOf(billingOffer?.promSaleType?.text()))
					omSA.setBaseOfferId(String.valueOf((billingOffer?.baseOfferId?.text())) ? (String.valueOf(billingOffer.baseOfferId.text())) : 0)
					omSA.setMatch('N')
					
					omsSAPriceList.add(omSA);
				}
			}
		}
		
		for(def puspoComponentData in VOIPNewComponentDetails)
		{
			for(def billingOffer in puspoComponentData.BillingOffers?.findAll{ bo -> (bo.actionCode = 'NONE' ) }.collect{it}.flatten().minus(null))//not exists left
			{
				if(billingOffer?.RecurringCalculatedPrices?.size() != 0 && billingOffer?.RecurringCalculatedPrices?.finalAmount != 0.0)
				{
					omSA = new OMSPricePlan()
					
					omSA.setCatalogID('NA')
					omSA.setPricePlanCode(String.valueOf(billingOffer?.ProductSpecificationPricing?.ChildPricingSchema?.pricePlanCode.text()))
					omSA.setChargeCodeType('RC')
					omSA.setChargeCodeReference(String.valueOf(billingOffer?.RecurringCalculatedPrices?.name.text()))
					omSA.setActualPrice(String.valueOf(billingOffer?.RecurringCalculatedPrices?.finalAmount.text()))
					omSA.setCurrency(String.valueOf(billingOffer?.RecurringCalculatedPrices?.currency.text()))
					omSA.setEligibleForNRC('NA')
					omSA.setMinNumOfInstallment('NA')
					omSA.setMaxNumOfInstallment('NA')
					omSA.setPromotioncode('NA')
					omSA.setPromSaleType(String.valueOf(billingOffer?.promSaleType?.text()))
					omSA.setBaseOfferId(String.valueOf((billingOffer?.baseOfferId?.text())) ? (String.valueOf(billingOffer.baseOfferId.text())) : null)
					omSA.setMatch('N')
					
					omsSAPriceList.add(omSA);
				}
			}
		}
		return omsSAPriceList
	}
	
	/* This method is to compare various PriceLists and sets Match property as either 'Y' on 'N' based on whether the match is found or not.
	   The parameters are populated below :
		  orderPriceList - computed from method computeOrderPriceList
		 omsPriceList - computed from method computeOMSPriceList
		 omsSAPriceList - computed from method computeOMSStandAlonePriceList
	 */
	def comparePricePlanLists(orderPriceList, omsPriceList, omsSAPriceList)
	{
		List<OrderPrice> orderPriceListIntact = new ArrayList<OrderPrice>();
		for(OrderPrice orderPrice in orderPriceList)
		{
			orderPriceListIntact.add(orderPrice.clone())
		}
		
		compareOrderPriceList(orderPriceList,omsPriceList)
		compareOMSPriceList(orderPriceListIntact,omsPriceList)
		compareOrderPriceList(orderPriceList,omsSAPriceList)
		compareOMSPriceList(orderPriceListIntact,omsSAPriceList)
	}
	
	/* This method is to record Price Mismatches and returns either true or false based on PriceMismatch was found or not */
	def RecordPriceMisMatches(orderPriceList, omsPriceList, omsSAPriceList,executionContext)
	{
		ArrayList<String> PriceMismatchRecords = new ArrayList<String>()
		String PriceMismatchString = "Price MisMatch occurred.Msgs=" + ""
		
		PriceMismatchRecords.addAll(calculateOMSPP1Mismatch(omsPriceList,PriceMismatchString))
		PriceMismatchRecords.addAll(calculateOrderPriceListMismatch(orderPriceList,PriceMismatchString))
		
		def PriceMismatchErrorMessage = PriceMismatchString+PriceMismatchRecords
		executionContext.put("PriceMismatchErrorMessage",PriceMismatchErrorMessage)
		
		boolean isNoPriceMismatch
		if(PriceMismatchRecords)
		{
			constructStanalonePromotionStructure(omsSAPriceList,executionContext)
			isNoPriceMismatch = true
		}
		else
		{
			isNoPriceMismatch = false
		}
		executionContext.put("isNoPriceMismatch",isNoPriceMismatch)
		return isNoPriceMismatch
	}
	
	/* This function create SA Promotion Structure which can be directly consumed by PUSPO request */
	def constructStanalonePromotionStructure(omsSAPriceList,executionContext)
	{
		List<OMSStandAlonePromStr> omsStandAlonePromStr = new ArrayList<OMSStandAlonePromStr>();
		OMSStandAlonePromStr omsSAStr ;
		
		for (OMSPricePlan omsSAPrice in omsSAPriceList)
		{
			if (omsSAPrice.getMatch() == 'Y')
			{
				omsSAStr = new OMSStandAlonePromStr()
				
				omsSAStr.setProductSpecificationPricingId(omsSAPrice.getPricePlanCode())
				omsSAStr.setParentProductId('NA')
				omsSAStr.setParentOperationExtension('NA')
				omsSAStr.setParentProductSpecificationContainmentId('NA')
				omsSAStr.setPromSaleType(omsSAPrice.getPromSaleType())
				omsSAStr.setStatus('NEW')
				omsSAStr.setBaseOfferId(omsSAPrice.getBaseOfferId())
				omsSAStr.setBillingId('NA')
				omsSAStr.setBaseOfferInstanceId('NA')
				omsSAStr.setPromType(omsSAPrice.getChargeCodeType())
				
				omsStandAlonePromStr.add(omsSAStr);
			}
		}
		executionContext.put("omsStandAlonePromStr",omsStandAlonePromStr)
	}
	
	
	def calculateOMSPP1Mismatch(OMSPriceList ,PriceMismatchString)
	{
		ArrayList<String> PriceMismatchList = new ArrayList<String>()
		for (OMSPricePlan omsPrice in OMSPriceList)
		{
			if(omsPrice.getMatch() == 'N')
			{
				def offerId
				if(omsPrice.baseOfferId)
				{
					offerId = ", Offerid=" + omsPrice.getBaseOfferId()
				}
				PriceMismatchList.add ("OMS PricePlans[PPC=" + omsPrice.getPricePlanCode() + ", Price=" + omsPrice.getActualPrice() + ", CT=" + omsPrice.getChargeCodeType() + (offerId == null ? '' : offerId) + "]" )
			}
		}
		return PriceMismatchList.flatten()
	}
	
	def calculateOrderPriceListMismatch(orderPriceList,PriceMismatchString)
	{
		ArrayList<String> PriceMismatchList = new ArrayList<String>()
		for(OrderPrice orderPrice in orderPriceList)
		{
			if(orderPrice.getMatch() == 'N')
			{
				def offerId
				if(orderPrice.baseOfferId != 'null')
				{
					offerId =  ", Offerid=" + orderPrice.getBaseOfferId()
				}
				PriceMismatchList.add("ORDER Price Item[" + orderPrice.getSystemName() + ": PPC=" + orderPrice.getPricePlanCode() + ", Price=" + orderPrice.getActualPrice() + ", CT=" + orderPrice.getChargeType() + (offerId == null ? '' : offerId) + "]")
			}
		}
		return PriceMismatchList.flatten()
	}
	
	
	/* This function is to compare OrderPricePlanList and OMSPriceList  */
	def compareOrderPriceList(orderPriceList,omsPriceList)
	{
		for(OrderPrice orderPrice in orderPriceList)
		{
			for (OMSPricePlan omsPrice in omsPriceList)
			{
				if(compareOMSOrderPriceList(omsPrice,orderPrice) == 'Y')
				{
					orderPrice.setMatch('Y')
				}
			}
		}
		for(OrderPrice orderPrice in orderPriceList)
		{
			if(checkOrderNoMatchList(orderPrice,omsPriceList) == 'N')
			{
				return orderPrice
			}
		}
	}
	
	/* This function is to compare OrderPricePlanList and OMSPriceList  */
	def compareOMSPriceList(orderPriceList,omsPriceList)
	{
		for (OMSPricePlan omsPrice in omsPriceList)
		{
			for(OrderPrice orderPrice in orderPriceList)
			{
				if(compareOMSOrderPriceList(omsPrice,orderPrice) == 'Y')
				{
					omsPrice.setMatch('Y')
				}
			}
		}
		for(OMSPricePlan omsPrice in omsPriceList)
		{
			if(checkOMSNoMatchList(omsPrice,orderPriceList) == 'N')
			{
				return omsPrice
			}
		}
	}
	
	/* This function is to compare OrderPricePlanList and OMSPriceList  */
	def compareOMSOrderPriceList(omsPrice,orderPrice)
	{
		if(orderPrice.getPromSalesType().toLowerCase() == 'false')
		{
			if(omsPrice.getMatch() == 'N' && orderPrice.getMatch() == 'N')
			{
				if((orderPrice.getPricePlanCode() == omsPrice.getPricePlanCode()) &&
				   (Double.parseDouble(orderPrice.getActualPrice()) == Double.parseDouble(omsPrice.getActualPrice())) &&
				   (orderPrice.getChargeType() == omsPrice.getChargeCodeType())
				  )
				{
					return 'Y'
				}
				else
				{
					return 'N'
				}
			}
		}
		else
		{
			if(omsPrice.getMatch() == 'N' && orderPrice.getMatch() == 'N')
			{
				if((orderPrice.getPricePlanCode() == omsPrice.getPricePlanCode()) &&
				   (Double.parseDouble(orderPrice.getActualPrice()) == Double.parseDouble(omsPrice.getActualPrice())) &&
				   (orderPrice.getChargeType() == omsPrice.getChargeCodeType()) &&
					 getBaseOfferIdMatch(omsPrice,orderPrice))
				 {
					return 'Y'
				 }
				 else
				 {
					return 'N'
				 }
			}
		}
	}
	
	/* This function is to get whether BaseOfferId exists or not for particular price detail */
	boolean getBaseOfferIdMatch(omsPrice,orderPrice)
	{
		if(orderPrice.getBaseOfferId() == null && omsPrice.getBaseOfferId() == null)
		{
			return true
		}
		else
			if(orderPrice.getBaseOfferId() == omsPrice.getBaseOfferId())
			{
				return true
			}
			else
			{
				return false
			}
	}
	
	/* This function is to genearte a list of orderPriceList for which no match was found */
	def checkOrderNoMatchList(orderPrice,omsPriceList)
	{
		def array
		for(OMSPricePlan omsPrice in omsPriceList)
		{
			if(compareOMSOrderPriceList(omsPrice,orderPrice) == 'Y')
			{
				array = 'Y'
			}
		}
		def result
		if(array)
		{
			result =  'Y'
		}
		else
		{
			result = 'N'
		}
		
		return result
	}
	/* This function is to genearte a list of OMSPriceList for which no match was found */
	def checkOMSNoMatchList(omsPrice,orderPriceList)
	{
		def array
		for(OrderPrice orderPrice in orderPriceList)
		{
			if(compareOMSOrderPriceList(omsPrice,orderPrice))
			{
				array = 'Y'
			}
		}
		def result
		if(array)
		{
			result = 'Y'
		}
		else
		{
			result = 'N'
		}
	}
	
	/* This method returns the Promotions associated with Uverse Groups. */
	def getUversePromotions(Order)
	{
		def uverseGroupsId = getUverseGroupsId(Order)
		ArrayList<String> uversePromotions = new ArrayList<String>()

		def lineItemPromotionRefs = Order.LineItems.LineItem.findAll { li ->
			uverseGroupsId.intersect(li.GroupRefs.GroupRef )}.collect{it.PromotionRefs?.PromotionRef}.flatten().minus(null)

		def groupPromotionRefs = Order.Groups.Group.findAll { grp ->
			uverseGroupsId.any { grp.Id } }.collect{ it.PromotionRefs?.PromotionRef }.flatten().minus(null)

		if(groupPromotionRefs.size() != 0) {
			return groupPromotionRefs;
		} else {
			return lineItemPromotionRefs
		}

	}

	/* This method returns the groupId of Uverse Groups */
	def getUverseGroupsId(Order)
	{
		def groupList= Order.Groups.Group

		ArrayList<String> uverseGroupIds = new ArrayList<String>();
		for(def group in groupList)
		{
			def productTypes = group.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
			if(productTypes && (productTypes.contains('IPTV')
			|| productTypes.contains('INTERNET')
			|| productTypes.contains('VOIP')
			|| group.GroupCharacteristics.PackageCharacteristics)
			&& group.GroupCharacteristics.LoSGCharacteristics.ProductCategory != 'PACKAGE' )
			{
				uverseGroupIds.add(group.Id)
			}
		}
		return uverseGroupIds
	}

	def checkForWirelineUnifyFlow(Order)
	{
		def losgCharacteristics = Order.Groups.Group.GroupCharacteristics?.LoSGCharacteristics
		def isWirelessUnifyExists
		def isDTVUnifyExists
		def legacyDtvAccount = OrderUtility.getDTVAccount(Order)
		def wirelineLosg
		def unifyLoSGType
		
		for(def losg in losgCharacteristics)
		{
			if(losg)
			{
				if(losg.ProductCategory == 'WIRELESS' && losg.LoSGType == 'UNIFY' )
				{
					isWirelessUnifyExists = true
				}
				
			}
		}
		
		for(def losg in losgCharacteristics)
		{
			if(losg)
			{
				if(losg.ProductCategory == 'DIRECTV' && losg.LoSGType == 'UNIFY' )
				{
					isDTVUnifyExists = true
				}
				
			}
		}
		
		for(def losg in losgCharacteristics)
		{
			if(losg)
			{
				def productTypes = losg.ProductCategory
				if((productTypes.contains('IPTV') || productTypes.contains('INTERNET') || productTypes.contains('DIRECTV')) || losg.LoSGType == 'NEW' )
				{
					wirelineLosg = losg
				}
			}
		}
		
		if(isWirelessUnifyExists && isDTVUnifyExists && legacyDtvAccount.size() != 0 && !wirelineLosg.size() != 0)
		{
			unifyLoSGType = true
		}
		else
		{
			unifyLoSGType = false
		}
		
		return unifyLoSGType
		
	}
	def updateSStoInQueueManualProvReqd(Order,executionContext )
	{
		def uverseAccount = OrderUtility.getUverseAcount(Order)
		List<ErrorBean> errList = new ArrayList<ErrorBean>();
		errList.add(new ErrorBean('300',executionContext.get("PriceMismatchErrorMessage")))
		OrderUtility.updateErrorList(Order,executionContext,errList,WirelineConstants.LOSGSTATUS_IN_QUEUE,WirelineConstants.LOSG_MANUAL_PROVISIONING_REQUIRED,uverseAccount.Id)
	}
	
	
}