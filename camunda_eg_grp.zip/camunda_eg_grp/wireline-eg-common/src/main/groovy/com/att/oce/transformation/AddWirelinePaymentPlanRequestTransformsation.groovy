package com.att.oce.transformation;

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.error.OceErrorHandler
import com.att.oce.config.components.GlobalProperties
import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import com.att.oce.bpm.common.WirelineTransformationService;
import com.att.oce.bpm.common.WirelineConstants;
import com.att.oce.bpm.utility.OrderUtility;

@Component('addWirelinePaymentPlanTransformsation')
class AddWirelinePaymentPlanTransformsation extends WirelineTransformationService {
	static Logger log = LoggerFactory.getLogger(AddWirelinePaymentPlanTransformsation.class)

	@Override String getApiName(){
		return 'AddWirelinePaymentPlan';
	}

	public String getApiUrn() {
		return "urn:csi:services:pam:AddWirelinePaymentPlan.jws";
	}
	
	public boolean preCondition(order){
		log.debug('AddWirelinePaymentPlanTransformsation.preCondition')
		def paymentRef = OrderUtility.getPaymentOptionForAutoPay(order)
	
		if (paymentRef != null)
			return true
		else
			return false
	}
	
	public void transform(Exchange exchange){
		//AddWirelinePaymentPlanRequest.PaymentPlan.PaymentPlanItem.PlanKey.accountNumber
		println ('addWirelinePaymentPlanTransformsation.transform')
		exchange.properties.order = exchange.in.body.order
		def executionContext = exchange.properties.executionContext
		def uverseAcc = OrderUtility.getUverseAcount(exchange.in.body.order)
		exchange.properties.referenceId = uverseAcc.Id

		def apiURN = getApiUrn()
		def apiUrl = super.resolveURN(apiURN, null)
		exchange.properties.apiURN = apiURN
		exchange.properties.apiUrl = apiUrl

		def order = exchange.in.body.order
		def paymentMethodType = getPaymentMethodType(order)
		def msgHeader = createMessageHeader(exchange.in.body.order,executionContext.conversationId)
		def awppRequest = [ messageHeader : msgHeader,
			AddWirelinePaymentPlanRequest : getAWPPRequest(order),
			paymentMethodType : paymentMethodType
		]

		exchange.out.body = awppRequest
		setCSIHttpHeaders(exchange)
		exchange.out.headers.put("CamelHttpUri",apiUrl)
		exchange.properties.put("OceCSIApiName",getApiName())
		println('AddWirelinePaymentPlan.transform done')
	}

	public void processResponse(Exchange exchange) throws APIFailedException
	{
		int index=0
		def order = exchange.properties.order
		def awppResponseXml = new XmlSlurper().parseText(exchange.in.body)
		log.debug(exchange.in.body)
		if (awppResponseXml.Body.Fault.size() > 0){
			def apie = new APIFailedException(
					api : getApiName(),
					code : awppResponseXml.Body.Fault.detail.CSIApplicationException.Response.code,
					codeDescription : awppResponseXml.Body.Fault.detail.CSIApplicationException.Response.description,
					subCode : awppResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code,
					subCodeDescription : awppResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
					)
			addTransactionHistory(exchange,apie)
			exchange.out.body = order
			throw apie
		}
		addTransactionHistory(exchange,null)
		//return exchange.in.body
	}

	def getAWPPRequest(def order)
	{
		int index = 0
		def sourceDetails = getSourceDetails(order)
		def customerAgreement = getCustAgreement(order)
		def uverseAcc = OrderUtility.getUverseAcount(order)
		def addressDetails = getAddress(order, uverseAcc)
		def unParsedAddress = getUnParsedAddress(order)
		def paymentoption = OrderUtility.getPaymentOptionForAutoPay(order)

		def AWPPReq =
				[
					Source : [
						sourceSystem : sourceDetails?.sourceSystem,
						sourceLocation : sourceDetails?.sourceLocation,
						sourceUser: sourceDetails?.sourceUser
					],
					customerAgreement: getCustAgreement(order),
					PaymentPlan:[
						PaymentPlanItem:[
							PlanKey:[
								accountNumber : uverseAcc?.BillingAccountNumber,
								BillingSystem:[
									provider: WirelineConstants.ADD_WIRELINE_PAYMENT_PROVIDER,
									system: WirelineConstants.ADD_WIRELINE_PAYMENT_SYSTEM,
									systemDivision: WirelineConstants.SYSTEM_DIVISION,
									state: addressDetails?.State
								]
							],
							planType: WirelineConstants.PAYMENT_PLAN_TYPE,
						],
						PaymentMethod: getPaymentMethod(order),
					]
				]
		return AWPPReq
	}

	def getSourceDetails(def order) {
		Map<String,Object> transactionLogs = new HashMap<String, Object>();
		def sourceSystem
		def sourceLocation
		def sourceUser
		def PaymentOptions = order.PaymentOptions?.PaymentOption

		if(order.PaymentOptions?.PaymentOption) {
			for(def i=0;i<PaymentOptions.size();i++) {
				def paymnetoption = PaymentOptions.get(i)
				if(paymnetoption != null && paymnetoption?.CAPMConfig != null && paymnetoption?.CAPMConfig?.SourceSystem != null) {
					sourceSystem = paymnetoption?.CAPMConfig?.SourceSystem
				} else {
					sourceSystem = WirelineConstants.ADD_WIRELINE_PAYMENT_SOUCE_SYSTEM
				}
				if(paymnetoption != null && paymnetoption?.CAPMConfig != null && paymnetoption?.CAPMConfig?.SourceLocation != null) {
					sourceLocation = paymnetoption?.CAPMConfig?.SourceLocation
				} else {
					sourceLocation = WirelineConstants.ADD_WIRELINE_PAYMENT_SOUCE_LOCATION
				}
				if(paymnetoption != null && paymnetoption?.CAPMConfig != null && paymnetoption?.CAPMConfig?.SourceUser != null) {
					sourceUser = paymnetoption?.CAPMConfig?.SourceUser
				} else {
					sourceUser = WirelineConstants.ADD_WIRELINE_PAYMENT_SOUCE_SYSTEM
				}
				transactionLogs.put("sourceSystem", sourceSystem)
				transactionLogs.put("sourceLocation", sourceLocation)
				transactionLogs.put("sourceUser", sourceUser)
			}
		} else {
			transactionLogs.put("sourceSystem", WirelineConstants.ADD_WIRELINE_PAYMENT_SOUCE_SYSTEM)
			transactionLogs.put("sourceLocation", WirelineConstants.ADD_WIRELINE_PAYMENT_SOUCE_LOCATION)
			transactionLogs.put("sourceUser", WirelineConstants.ADD_WIRELINE_PAYMENT_SOUCE_SYSTEM)
		}

		return transactionLogs
	}

	def getCustAgreement(def order){
		def custAgreement
		def paymentOption = OrderUtility.getPaymentOptionForAutoPay(order)

		if(paymentOption?.PaymentMethod?.CAPM?.CustomerAgreementVersion){
			custAgreement = paymentOption?.PaymentMethod?.CAPM?.CustomerAgreementVersion
		}
		else if(paymentOption?.PaymentMethod?.LastPaymentMethod?.CustomerAgreementVersion){
			custAgreement = paymentOption?.PaymentMethod?.LastPaymentMethod?.CustomerAgreementVersion
		}
		else{
			custAgreement = WirelineConstants.YES
		}
		return custAgreement
	}


	/*
	 * This function will return UVERSE account from Accounts in a list
	 * @param - order object
	 * */

	def getUverseAccount(def order){
		def accountList = order?.Accounts?.Account

		for(def i=0;i<accountList.size();i++){
			def accountMap=accountList.get(i)
			if(accountMap.AccountCategory == WirelineConstants.ACCOUNTCATEGORY_UVERSE_ACCOUNT &&
			accountMap.AccountCategory == WirelineConstants.AccountSubCategory_NEW ){
				return accountMap;
			}
		}
		return null;
	}

	/*
	 * This function will return address from order of corresponding Account
	 * @param - order object,UVERSE Account object
	 * */
	def getAddress(def order, def uverseAcc){
		def addressMap;
		def addressDetails
		List<String> Addresses = order.Addresses?.Address
		if(Addresses && uverseAcc?.BillingInfo && uverseAcc?.BillingInfo[0]?.AddressRef){
			for(def address in Addresses) {
				if(address?.Id == uverseAcc?.BillingInfo[0]?.AddressRef) {
					addressMap=address
					break
				}
			}

		}
		if(addressMap?.ParsedAddress != null) {
			addressDetails = addressMap?.ParsedAddress
		} else {
			addressDetails = addressMap?.UnparsedAddress
		}
		return addressDetails
	}

	def getUnParsedAddress(def order){
		def addressMap;
		def addressDetails
		def addressRef
		List<String> Addresses = order.Addresses?.Address
		def paymnetOption = order.PaymentOptions?.PaymentOption[0]
		addressRef =  paymnetOption?.PaymentMethod?.CreditCard?.AddressRef
		if(Addresses && paymnetOption != null && addressRef != null){
			for(def address in Addresses) {
				if(address?.Id == addressRef) {
					addressMap=address
					break
				}
			}

		}
		if(addressMap?.UnparsedAddress != null) {
			addressDetails = addressMap?.UnparsedAddress
		}

		return addressDetails
	}

	def getPaymentMethodType(def order)
	{
		def paymentMethodType
		def paymentoption = OrderUtility.getPaymentOptionForAutoPay(order)

		if(paymentoption!=null){
			if(paymentoption?.PaymentMethod?.CAPM){
				if(paymentoption?.PaymentMethod?.CAPM.CreditCardNumber)
				{
					paymentMethodType = "CAPMCreditCard"
				}
				else
				{
					paymentMethodType = "CAPM"
				}
			}
			else if(paymentoption?.PaymentMethod?.CreditCard && (paymentoption?.PaymentMethod?.CreditCard?.PreAuthDetail?.AuthorizationCode==null) ){
				paymentMethodType = "CreditCard"
			}
			else if(paymentoption?.PaymentMethod?.CreditCard && paymentoption?.PaymentMethod?.CreditCard?.PreAuthDetail?.AuthorizationCode){
				paymentMethodType = "PreAuthProfile"
			}
			else if(paymentoption?.PaymentMethod?.ACH){
				paymentMethodType = "ACH"
			}
			else if(paymentoption?.PaymentMethod?.LastPaymentMethod){
				paymentMethodType = "LastPaymentMethod"
			}
		}
		return paymentMethodType
	}

	def getPaymentMethod(def order)
	{
		def paymentMethod
		def paymentOption = OrderUtility.getPaymentOptionForAutoPay(order)
		def paymentMethodType = getPaymentMethodType(order)
		
		println('paymentMethodType = '+paymentMethodType)
		if(paymentMethodType == "CAPM"){
			paymentMethod =	[
				Profile :[
					Source: [
						sourceSystem : paymentOption?.CAPMConfig?.SourceSystem ? paymentOption?.CAPMConfig?.SourceSystem : WirelineConstants.PAYMENT_SOURCE_SYSTEM_HARDROCK,
						sourceLocation: paymentOption?.CAPMConfig?.SourceLocation ? paymentOption?.CAPMConfig?.SourceLocation : WirelineConstants.PAYMENT_SOURCE_LOCATION_CS,
						sourceUser: paymentOption?.CAPMConfig?.SourceLocation ? paymentOption?.CAPMConfig?.SourceLocation : WirelineConstants.PAYMENT_SOURCE_USER_HARDROCK
					],
					profileName: paymentOption?.PaymentMethod?.CAPM?.ProfileName,
					profileOwnerId: paymentOption?.PaymentMethod?.CAPM?.ProfileOwnerId,
					merchantId: paymentOption?.CAPMConfig?.MerchantID ? paymentOption?.CAPMConfig?.MerchantID : "Consumer"
				]
			]
		}
		
		else if(paymentMethodType == "CAPMCreditCard"){
			def ccType
			switch(paymentOption?.PaymentMethod?.CAPM?.CreditCardType) {

				case 'AMERICAN_EXPRESS' : ccType = WirelineConstants.PAYMENT_CREDIT_TYPE_AE
					break;
				case 'DISCOVER' : ccType = WirelineConstants.PAYMENT_CREDIT_TYPE_DISC
					break;
				case 'MASTERCARD' : ccType = WirelineConstants.PAYMENT_CREDIT_TYPE_MC
					break;
				case 'DINER\'S_CLUB' : ccType = WirelineConstants.PAYMENT_CREDIT_TYPE_DINE
					break;
				default: ccType = paymentOption?.PaymentMethod?.CAPM?.CreditCardType
			}
			def expirationDate = paymentOption?.PaymentMethod?.CAPM?.ExpirationYearMonth
			println('length is - '+expirationDate.length())
			def ExpirationYearMonth = expirationDate.substring(2,4)+expirationDate.substring(5,7)
			
			paymentMethod =	[
				CAPMCreditCard:[
					method:WirelineConstants.PAYMENT_METHOD_CREDIT_CARD,
					CreditCardDetails :[
						CardNumber :[
							creditCardNumber :paymentOption?.PaymentMethod?.CAPM.CreditCardNumber],
						cardName : paymentOption?.PaymentMethod?.CAPM?.creditCardHolderName,
						cardExpirationDate : ExpirationYearMonth,
						creditCardType : ccType,
						BillingAddress :[
							Zip:[
								zipCode: paymentOption?.PaymentMethod?.CAPM.CardBillingZipCode]
						],
						merchantId:paymentOption?.CAPMConfig?.MerchantID ? paymentOption?.CAPMConfig?.MerchantID : "Consumer"
					]
				]
			]
		}
		
		else if(paymentMethodType == "CreditCard" || paymentMethodType == "PreAuthProfile"){
			def ccType
			switch(paymentOption?.PaymentMethod?.CreditCard?.CreditCardType) {

				case 'AMERICAN_EXPRESS' : ccType = WirelineConstants.PAYMENT_CREDIT_TYPE_AE
					break;
				case 'DISCOVER' : ccType = WirelineConstants.PAYMENT_CREDIT_TYPE_DISC
					break;
				case 'MASTERCARD' : ccType = WirelineConstants.PAYMENT_CREDIT_TYPE_MC
					break;
				case 'DINER\'S_CLUB' : ccType = WirelineConstants.PAYMENT_CREDIT_TYPE_DINE
					break;
				default: ccType = paymentOption?.PaymentMethod?.CreditCard?.CreditCardType
			}
			
			def expirationDate = paymentOption?.PaymentMethod?.CreditCard?.ExpirationYearMonth
			def ExpirationYearMonth = expirationDate.substring(2,4)+expirationDate.substring(5,7)

			paymentMethod =	[
				CreditCard:[
					method:WirelineConstants.PAYMENT_METHOD_CREDIT_CARD,
					CreditCardDetails :[
						CardNumber :[
							creditCardNumber :paymentOption?.PaymentMethod?.CreditCard?.CreditCardNumber],
						cardName : paymentOption?.PaymentMethod?.CreditCard?.creditCardHolderName,
						cardExpirationDate : ExpirationYearMonth,
						creditCardType : ccType,
						BillingAddress :[
							Zip:[
								zipCode: paymentOption?.PaymentMethod?.CreditCard?.CardBillingZipCode]
						],
						merchantId:paymentOption?.CAPMConfig?.MerchantID ? paymentOption?.CAPMConfig?.MerchantID : "Consumer"
					]
				]
			]
		}

		else if(paymentMethodType == "ACH"){
			paymentMethod = [
				Check :[
					checkTypeIndicator : 'CHECK',
					method: 'ACH',
					BankInformation: [
						accountType: OrderUtility.getAccountType(paymentOption),
						routingNumber: paymentOption?.PaymentMethod?.ACH?.BankAccountDetails?.RoutingNumber,
						accountNumber: paymentOption?.PaymentMethod?.ACH?.BankAccountDetails?.AccountNumber,
						accountName: paymentOption?.PaymentMethod?.ACH?.BankAccountDetails?.AccountHolderName
					],
					businessAccount: 'false'
				]

			]
		}

		else if(paymentMethodType == "LastPaymentMethod"){
			def merchantId = null
			if(paymentOption?.PaymentMethod?.LastPaymentMethod?.LPMPaymentType == 'CREDIT_CARD')
			{
				merchantId = 'Consumer'
			}
			paymentMethod = [
				LastPaymentMethod :[
					lastPaymentReferenceNumber : paymentOption?.PaymentMethod?.LastPaymentMethod?.LPMReferenceNumber,
					merchantId: merchantId
				]

			]
		}
		return paymentMethod
	}


}