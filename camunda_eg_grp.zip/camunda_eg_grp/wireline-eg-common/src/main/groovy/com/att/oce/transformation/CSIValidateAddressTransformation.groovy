package com.att.oce.transformation

import org.springframework.stereotype.Component;
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import com.att.oce.bpm.common.WirelineConstants;
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.utility.OrderUtility;

import org.apache.camel.Exchange
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.common.WirelineTransformationService;

@Component('csiValidateAddressTransformation')
class CSIValidateAddressTransformation  extends WirelineTransformationService {
	static Logger log = LoggerFactory.getLogger(CSIValidateAddressTransformation.class)

	String url;

	@Override String getApiName()
	{
		return 'ValidateAddress';
	}
	
	public String getApiUrn() {
		return "urn:csi:services:compass:ValidateAddress.jws";
	}
	
	/*
	 * Method to gather data to frame the outbound request for a given API
	 * @param uri
	 * @param exchange
	 * @return
	 */
	public void transform(Exchange exchange){
		log.info('ValidateAddressTransformation.transform <-- Entering')
		/*Setting values for Camel Header*/
		setCSIHttpHeaders(exchange)
		def order = exchange.in.body.order
		exchange.out.headers.put("CamelHttpUri",resolveURN(getApiUrn(),url))
		exchange.properties.put("OceCSIApiName","ValidateAddress")
		exchange.properties.put("referenceId",order.CustomerOrderNumber)

		
		log.debug('Testing JSONOUTPUT: Body:' + JsonOutput.toJson(order))
		def address = exchange.in.body.address

		log.debug('ValidateAddressTransformation.transform: order --> :' + order)
		log.debug('ValidateAddressTransformation.transform: addressReq -->:' + address)
		/*to retain the original arguments */
		exchange.properties.put('order',order)
		exchange.properties.put('address',address)

		/*Setting Values required for SOAP Body*/
		def Address;
		
		if(address?.UnparsedAddress) {
			
			def Structure = ['type' : address?.UnparsedAddress?.Structure?.Type,
				'value' : address?.UnparsedAddress?.Structure?.Value]

			def Elevation = ['type' : address?.UnparsedAddress?.Elevation?.Type,
				'value' : address?.UnparsedAddress?.Elevation?.Value]

			def Unit = ['type' : address?.UnparsedAddress?.Unit?.Type,
				'value' : address?.UnparsedAddress?.Unit?.Value]

			def PostalCode = ['zipCode' : address?.UnparsedAddress?.Zip]

			def AddressUnfielded = ['addressLine1' : (address?.UnparsedAddress?.AddressLine1) ? address?.UnparsedAddress?.AddressLine1 : null,
				'addressLine2' : address?.UnparsedAddress?.AddressLine2,
				'addressLine3' : address?.UnparsedAddress?.AddressLine3,
				'structure' : Structure,
				'elevation' : Elevation,
				'unit' : Unit,
				'city' : address?.UnparsedAddress?.City,
				'state' : address?.UnparsedAddress?.State,
				'postalCode' : PostalCode]

			def AddressData = ['addressUnfielded': AddressUnfielded]

			Address = ['addressData' : AddressData,
				'county' : address?.UnparsedAddress?.County,
				'country' : address?.UnparsedAddress?.Country,
				'attention' : address?.UnparsedAddress?.Attention,
				'urbanizationCode' : address?.UnparsedAddress?.UrbanizationCode]
			
		}		
		else {
			
			def PostalCode = ['zipCode' : address?.ParsedAddress?.Zip]
			
						def addressLines;
						addressLines = address?.ParsedAddress?.AddressStreetLine+' '+address?.ParsedAddress?.StreetName+' '+address?.ParsedAddress?.StreetType
			
						def AddressUnfielded = ['addressLines' : addressLines,
							'city' : address?.ParsedAddress?.City,
							'state' : address?.ParsedAddress?.State,
							'postalCode' : PostalCode]
			
						def AddressData = ['addressUnfielded': AddressUnfielded]
			
						Address = ['addressData' : AddressData,
							'county' : address?.ParsedAddress?.County,
							'country' : address?.ParsedAddress?.Country,
							'addressId' : address?.AddressId]
			
		}

		def validateAddressRequest = ['address' : Address, 'mode' : 'U']
		def soapRequest = ['messageHeader' : createMessageHeader(order),
			'validateAddressRequest' : validateAddressRequest]


		exchange.properties.address = address
		soapRequest = removeKeysWithoutValues(soapRequest);
		log.debug('ValidateAddressTransformation.transform: Body:' + soapRequest)
		log.debug('ValidateAddressTransformation.transform --> Exiting')
		exchange.out.body = soapRequest
//		return soapRequest
	}

	/*
	 * Method to Process the response back from the API
	 * @param exchange
	 * @return
	 */
	public void processResponse(Exchange exchange){
		log.debug('ValidateAddressTransformation.processResponse <-- Entering')

		/* Initialize */
		def executionContext = exchange.properties.executionContext
		if(!executionContext){
			executionContext = [:]
		}
		def sValidateAddressResponse = exchange.in.body
		def order = exchange.properties.order
		log.debug('ValidateAddressTransformation.processResponse: Body:' + JsonOutput.toJson(order))
		log.debug('CSIVA :::'+order.Addresses)
		order.Addresses.Address.each{
			log.debug('CSIVA :::'+it)
		}
		def address = exchange.properties.address
		log.debug('ValidateAddressTransformation.processResponse: Response XML :' + sValidateAddressResponse)

		/* Parse the response as an XML*/
		def validateAddressResponse = new XmlSlurper().parseText(sValidateAddressResponse)

		if (validateAddressResponse.Body.Fault.size()>0){
			def e = new APIFailedException();
			e.api = getApiName()
			e.code = validateAddressResponse.Body.Fault.detail.CSIApplicationException.Response.code
			e.codeDescription = validateAddressResponse.Body.Fault.detail.CSIApplicationException.Response.description
			e.subCode = validateAddressResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code
			e.subCodeDescription = validateAddressResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
			addTransactionHistory(exchange,e)
			exchange.out.body = order
			//			throw e
		} else {

			/* Updating the execution context */
			executionContext.put('ValidateAddress.pass', 'SUCCESS')
			exchange.properties.put('executionContext',executionContext)

			def confidenceLevel = globalConfig.validateAddressConfidence
			log.debug('validateAddressConfidence' + confidenceLevel)
			def body = validateAddressResponse.Body.ValidateAddressResponse
			log.debug('CSIVA :::'+body)
			/* Matching the confidence and getting the best available match*/
			def matchedAddress = body.MatchedAddressResult.AddressMatchResult.findAll{ ma -> Integer.parseInt(ma.confidence.toString()) > confidenceLevel}.sort{it.confidence}.collect{it.Address}[0]
			log.debug('CSIVA :::'+matchedAddress)
			log.debug('CSIVA :::'+matchedAddress.addressType)
			def parsedAddress = address.ParsedAddress
			def addressTypes = globalConfig.mAddressTypes
			log.debug('CSIVA :::'+addressTypes)
			//		def addressTypesMap = propertyToMap(addressTypes)
			log.debug('CSIVA :::'+addressTypes)
			//def addressType = addressTypes.get('AddressType.'+matchedAddress.addressType.text())
			def addressType = matchedAddress.addressType.text()

			Map modParsedAddress;

			def matchedAddressFields = ['AddressStreetLine': matchedAddress.addressLine1.text(),
				'HouseNumberPrefix': matchedAddress.Street?.streetNumberPrefix.text(),
				'HouseNumber': matchedAddress.Street?.streetNumber.text(),
				'HouseNumberSuffix': matchedAddress.Street?.streetNumberPrefix.text(),
				'Direction': matchedAddress.Street?.streetDirection.text(),
				'AssignedStreetNumber': matchedAddress.Street?.assignedStreetNumber.text(),
				'StreetName': matchedAddress.Street?.streetName.text(),
				'StreetType': matchedAddress.Street?.streetType.text(),
				'PostOfficeBox': matchedAddress.postOfficeBox.text(),
				'City': matchedAddress.city.text(),
				'State': matchedAddress.state.text(),
				'Zip': matchedAddress.Zip?.zipCode.text(),
				'InternationalZip': matchedAddress.internationalZip.text(),
				'ZipGeoCode': matchedAddress.Zip?.zipGeoCode.text(),
				'ZipCodeExtension': matchedAddress.Zip?.zipCodeExtension.text(),
				'County': matchedAddress.county.text(),
				'Country': matchedAddress.country.text()]
			
			OrderUtility.removeEmptyFields(matchedAddressFields)
			
			if(parsedAddress){
				parsedAddress.putAll(matchedAddressFields)
				modParsedAddress = (Map) parsedAddress
			}
			else{
				modParsedAddress = (Map) matchedAddressFields
			}

			
			/* Replacing the contents in the existing order */
			order.Addresses.Address.each{ ad ->
				if(ad.Id == address.Id){
					ad.put('ParsedAddress',modParsedAddress)
				}
				log.debug('CSIVA :::'+ad)
			}

			removeKeysWithoutValues(order)
			addTransactionHistory(exchange,null)
			log.debug('ValidateAddressTransformation.processResponse: Body:' + order)
			log.debug('ValidateAddressTransformation.processResponse --> Exiting')
		}
//		return order;
	}


	public def getLoopCollection(order){
		def addressList = order.Addresses.Address
		return addressList;
	}

	public int getLoopCount(order){
		def addressList = order.Addresses.Address
		def defaultLoopCount = 0;
		return (addressList.size()>0)?addressList.size(): defaultLoopCount;
	}

	private Map<String,String> propertyToMap(String types){
		if(types == null || types == ""){
			types = "AddressType.S:UNITED_STATES,AddressType.R:RURAL_ROUTE,AddressType.M:MILITARY,AddressType.P:P.O._BOX,AddressType.F:INTERNATIONAL";
		}
		def map = [:]
		def typesArray = types.split(",")
		for(String entries: typesArray){
			def elements = entries.split(":")
			map.put(elements[0], elements[1])
		}
		log.debug('CSIVA :::'+map)
		return map
	}

}
