package com.att.oce.transformation

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.common.WirelineTransformationService
import com.att.oce.bpm.error.APIFailedException

import java.util.LinkedHashMap
import java.util.Map;
import org.camunda.bpm.engine.delegate.BpmnError
import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.utility.OrderUtility
import com.att.oce.bpm.common.WirelineConstants
import com.att.oce.bpm.utility.WirelineUtility
import com.att.oce.bpm.common.util.ErrorBean
import groovy.json.JsonOutput

@Component('inquireUnifiedServiceProductDetailsTransformation')
class InquireUnifiedServiceProductDetailsTransformation extends WirelineTransformationService
{

	String url;

	@Override String getApiName(){
		return "InquireUnifiedServiceProductDetails";
	}
	
	public String getApiUrn() {
		return "urn:csi:services:oms:InquireUnifiedServiceProductDetails.jws";
	}

	public void transform(Exchange exchange){


		println('InquireUnifiedServiceProductDetailsTransformation.transformation')
		def order = exchange.in.body.order
		exchange.properties.order = exchange.in.body.order
		exchange.properties.order = exchange.in.body.order
		exchange.properties.fedIndicator = false;
		
		
		def executionContext  = exchange.in.body.executionContext
		println('Final-----order-----'+JsonOutput.toJson(order))
		def apiURN = getApiUrn()
		def apiUrl = super.resolveURN(apiURN, null)
		exchange.properties.apiURN = apiURN
		exchange.properties.apiUrl = apiUrl

		if(!executionContext.flowType || executionContext.flowType.isEmpty())
			executionContext.flowType = WirelineConstants.EXISTING_WL_NEW_FMO_WIRELINE
		def msgHeader = OrderUtility.removeEmptyFields(createUnifiedMessageHeader(order,executionContext.conversationId))
		def inquireUnifiedServiceAccountResp = executionContext.get("iusaResp")

		/*def IUSAResponse = new XmlSlurper().parseText(inquireUnifiedServiceAccountResp)

		def iusaRes = IUSAResponse?.Body.InquireUnifiedServiceAccountResponse*/
		
		def flowType = (executionContext.flowType == WirelineConstants.EXISTING_WL_NEW_FMO_WIRELINE)? WirelineConstants.NEW_ORDER:WirelineConstants.MODIFY_ORDER
		def mask_catalog_lite = WirelineConstants.MASK_CATALOG_LITE

		def uverseAcc = OrderUtility.getUverseAcount(order)
		exchange.properties.put("referenceId",uverseAcc.Id)
		def creditRisk = executionContext.creditRisk
		// set customer in mapping
		def customer =  OrderUtility.getCustomerData(order,creditRisk)

		def OrderingContext =  OrderUtility.getOrderingContext()
		def activityForConfiguration = (executionContext.flowType == WirelineConstants.EXISTING_WL_NEW_FMO_WIRELINE)? WirelineConstants.ACTIVITY_CONFIG_PROVIDE:WirelineConstants.ACTIVITY_CONFIG_MODIFY
		def ConfigurationOptions = [activityForConfiguration : activityForConfiguration,
			orderType : flowType.toLowerCase(),
			masks : [WirelineConstants.MASK_DISPLAYINFO,WirelineConstants.MASK_CATELOG_LITE,WirelineConstants.MASK_ONLY_VISIBLE]]

		if(OrderUtility.isWirelessUnifyPresentInOrder(order)){
			ConfigurationOptions.wirelessConvergeIndicator = WirelineConstants.Boolean_TRUE
		}

		executionContext.OfferSpecStructure = constructOfferSpecIdStructure(order,uverseAcc)
		exchange.properties.executionContext  = exchange.in.body.executionContext
		def ProductConfiguration = (executionContext.flowType == WirelineConstants.EXISTING_WL_NEW_FMO_WIRELINE)? constructProductConfigurationforModify(order,executionContext.OfferSpecStructure) : constructNewProductsInNewOfferProvide(order,executionContext.OfferSpecStructure)
		def InquireUnifiedServiceProductDetailsRequest = [ mode : WirelineConstants.MODE_DETAIL,
			OrderingContext : OrderingContext,
			Customer : customer,
			ConfigurationOptions : ConfigurationOptions,
			ProductConfiguration : ProductConfiguration
		]
		
		def iuspdRequest = [ messageHeader : msgHeader,
			InquireUnifiedServiceProductDetailsRequest : InquireUnifiedServiceProductDetailsRequest
		]
		setAuditLogProperties(exchange,false)
		exchange.out.body = iuspdRequest
		setCSIHttpHeaders(exchange)
		exchange.out.headers.put(
				"CamelHttpUri",apiUrl)
		exchange.properties.put("OceCSIApiName",getApiName())
		println('InquireUnifiedServiceProductDetails.transform done')

	}

	def constructNewProductsInNewOfferProvide(def Order, def OfferSpecStructure){

		def context = [:]
		
		def ProductSpecificationIds = []
		def newProductsInNewOffer = []
		

		for(def offerSpecDetail : OfferSpecStructure.OfferSpecDetails){

			newProductsInNewOffer.add( [offerId : offerSpecDetail.offerId,
				productSpecificationIds : offerSpecDetail.productsOfferSpecificationIds ])

		}
		return [NewProductsInNewOffer : newProductsInNewOffer]
	}
	
	def constructNewProductsInNewOfferModify(def Order, def OfferSpecStructure){
		
						def ProductSpecificationIds = []
						def newProductsInNewOffer = []
						
				
						for(def offerSpecDetail : OfferSpecStructure.OfferSpecDetails){
							// To do 17.08 verify IF condition
							if(offerSpecDetail.offerType == WirelineConstants.NEW_ORDER){
								newProductsInNewOffer.add( [offerId : offerSpecDetail.offerId,
									productSpecificationIds : offerSpecDetail.productsOfferSpecificationIds ])
							}
				
						}
						return newProductsInNewOffer
					}
			
	def constructProductConfigurationforModify(def Order, def OfferSpecStructure){
		def AssignedProducts = [retrieveAssignedProductsIndicator : WirelineConstants.Boolean_TRUE]
		return [AssignedProducts : AssignedProducts,
				NewProductsInNewOffer : constructNewProductsInNewOfferModify(Order, OfferSpecStructure)]
	}

	def void processResponse(Exchange exchange) throws APIFailedException {
		println('IUSPD Response :: ' + exchange.in.body)
		println('InquireUnifiedServiceProductDetailsTransformation.processResponse done')


		def order = exchange.properties.order
		def executionContext = exchange.properties.executionContext
		def groupId = exchange.properties.groupId
		def iuspdResponseXml = new XmlSlurper().parseText(exchange.in.body)


		if (iuspdResponseXml.Body.Fault.toString().size()>0){
			def e = new APIFailedException();
			e.api = getApiName()
			e.code = iuspdResponseXml.Body.Fault.detail.CSIApplicationException.Response.code
			e.codeDescription = iuspdResponseXml.Body.Fault.detail.CSIApplicationException.Response.description
			e.subCode = iuspdResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code
			e.subCodeDescription = iuspdResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
			addTransactionHistory(exchange,e);
			throw e
		} else
		{
			addTransactionHistory(exchange,null);
		}
		executionContext.iuspdResp = exchange.in.body
		//executionContext.iuspdResp = iuspdResponseXml.Body.InquireUnifiedServiceProductDetailsResponse
		//def hsComponentConfiguration = setHSComponentConfiguration(executionContext,'NEW',order)
		
			
		executionContext.put("iuspdProcessCompletionIndicator",iuspdResponseXml.Body.InquireUnifiedServiceProductDetailsResponse.processCompleteIndicator.text())


	}

	def getUverseWorkOrderID(def Order){
		def UverseWorkOrderID
		def UVProdCatagoryList = Order.Groups.Group.findAll{ grp -> grp.GroupCharacteristics.LoSGCharacteristics?.ProductCategory in [WirelineConstants.PRODUCTCATEGORY_IPTV , WirelineConstants.PRODUCTCATEGORY_INTERNET , WirelineConstants.PRODUCTCATEGORY_VOIP]}

		def SchedulingInfo = UVProdCatagoryList?.GroupCharacteristics?.LoSGCharacteristics?.SchedulingInfoRef

		for(def schedulingInfo : Order.SchedulingInfos?.SchedulingInfo){

			if(schedulingInfo?.Id in SchedulingInfo){
				UverseWorkOrderID = schedulingInfo.ActualSchedule?.WorkOrderId
			}

		}
		return UverseWorkOrderID
	}

	def getDTVWorkOrderID(def Order){
		def dTVWorkOrderID
		def DTVLoSG = Order.Groups.Group.findAll
		{ grp -> grp.GroupCharacteristics.LoSGCharacteristics?.LoSGType in [WirelineConstants.LoSGType_NEW , WirelineConstants.LOSGTYPE_CHANGE]}

		def dTVSchedulingInfo = DTVLoSG.findAll
		{ grp -> grp.GroupCharacteristics.LoSGCharacteristics?.ProductCategory == WirelineConstants.PRODUCTCATEGORY_DTV}
		def SchedulingInfo = dTVSchedulingInfo?.GroupCharacteristics?.LoSGCharacteristics?.SchedulingInfoRef

		for(def schedulingInfo : Order.SchedulingInfos?.SchedulingInfo){
			
			if(schedulingInfo.Id in SchedulingInfo){
				dTVWorkOrderID = schedulingInfo.ActualSchedule?.WorkOrderId
			}

		}
		return dTVWorkOrderID
	}


	
	/**
	 * PUSPO SetHSComponent configuration
	 * @param context
	 * @return
	 */
	def setHSComponentConfiguration(def context, def order){
		def ProductConfigurations = [:]
		if(!context.OfferSpecStructure)
		   context.put('OfferSpecStructure',[:])
 
		if(context.flowType == WirelineConstants.EXISTING_WL_NEW_FMO_WIRELINE)	{
		   ProductConfigurations = getNewProductComponentConfiguration(context, order)
		}else{
		   if(context.OfferSpecStructure?.OfferSpecDetails){
			   //need to concat the values fetched below
			   ProductConfigurations = getAssignedProductComponentConfiguration(context, order)
			   ProductConfigurations = getNewProductComponentConfiguration(context, order)
			   ProductConfigurations = getRemovedProductComponentConfigurationMapping(context, order)
		   }else
			   ProductConfigurations = getAssignedProductComponentConfiguration(context, order)
			   ProductConfigurations = getRemovedProductComponentConfigurationMapping(context, order)
 
		}

		context.put("HSComponentConfiguration", ['ProductConfigurations': ProductConfigurations])
		println('-------------'+JsonOutput.toJson(context.HSComponentConfiguration))
		def uverseWorkOrderId = getUverseWorkOrderID(order)
		def hsComponentConfiguration
		if(uverseWorkOrderId && !uverseWorkOrderId.isEmpty()){
			hsComponentConfiguration = setHSComponentConfigurationForUverseWoID(context,'UMC',order)
			context.put("HSComponentConfiguration",hsComponentConfiguration)
		}
		def dtvWorkOrderID = getDTVWorkOrderID(order)
		if(dtvWorkOrderID && !dtvWorkOrderID.isEmpty()){
			// call DTV WorkorderID
			hsComponentConfiguration = SetHSComponentConfigurationForDTVWoID(context,'ATTDTVMain',order)
			context.put("HSComponentConfiguration",hsComponentConfiguration)
		}
		
		def errors = validateHSComponentConfig(context.HSComponentConfiguration)
		if(!errors.isEmpty()){
			OrderUtility.updateErrorList(order,context,errors, WirelineConstants.LOSG_STATUS_IN_QUEUE,
				WirelineConstants.LOSG_MANUAL_PROVISIONING_REQUIRED,order.CustomerOrderNumber)
			
			throw new BpmnError("CRC001");
		}
		println('-------------'+JsonOutput.toJson(context.HSComponentConfiguration))
	 }
 
	
	def getNewProductComponentConfiguration(def context, def order){
		def NewOfferComponentMapping
		def PkgOfferGroups = order.Groups.Group.findAll{grp -> grp.Type == WirelineConstants.GROUPTYPE_PACKAGE}
		// Can comment below line
		//context.OfferSpecStructure = constructOfferSpecIdStructure(order)
		def OfferSpecDetails = context.OfferSpecStructure?.OfferSpecDetails.findAll{osd -> osd.offerType == 'NEW'}
		def NewProductConfigurations = []
		// DISS  -- check ProductConfiguration Structure
		def iuspdResp = new XmlSlurper().parseText(context.iuspdResp)
		def IUSPDProdConfig = iuspdResp.Body.InquireUnifiedServiceProductDetailsResponse.UnifiedServiceProductDetails.ProductsInNewOffer.ProductConfiguration.flatten().minus(null)
 
 
		for(def OfferSpecDetail : OfferSpecDetails){
			println(OfferSpecDetail.offerId)
		   def PkgOfferGroupId = order.Groups.Group.find{grp -> grp.Type == WirelineConstants.GROUPTYPE_PACKAGE &&
		   grp.GroupCharacteristics?.PackageCharacteristics?.Code == OfferSpecDetail.offerId}.Id
			println(PkgOfferGroupId)
	   def LineItems = order.LineItems.LineItem.findAll{ li -> li.Action == WirelineConstants.ACTION_ADD && li.GroupRefs.GroupRef.contains(PkgOfferGroupId) &&
			   li.Characteristics?.CommonCharacteristics?.ComponentConfiguration?.any{
				   cc -> cc.ComponentMapRequired == WirelineConstants.Boolean_TRUE && cc.ComponentOperations.any{
					   co -> co?.OperationName.intersect([WirelineConstants.PUSPOREQ,'PUSPOQtResponse'])}} }
		   
			   def ProductsInNewOfferConfigurations = []
			   def ComponentConfigurations = []
			   println(LineItems?.Characteristics?.CommonCharacteristics?.ComponentConfiguration?.ComponentMapRequired)
			   println('---------'+LineItems?.Characteristics?.CommonCharacteristics?.ComponentConfiguration)
			   def compConfigs = LineItems?.Characteristics?.CommonCharacteristics?.ComponentConfiguration.flatten().minus(null)
			   compConfigs.each{println(it?.ComponentOperations)}
			   if(compConfigs?.any{cc ->cc.ComponentCode == 'QVideoBasic'}){
					   ComponentConfigurations = compConfigs?.findAll{
					   cc -> cc.ComponentMapRequired == WirelineConstants.Boolean_TRUE &&
					   (cc.ComponentOperations.any{
						   co -> co?.OperationName.contains(WirelineConstants.PUSPOREQ)} ||
						   (cc.ComponentOperations.any{
						   co -> co?.OperationName.contains('PUSPOQtResponse')} && cc.ComponentCode=='QVideoBasic' ||
						   cc.ComponentPath.contains('VideoBasic')))}
				}else if(compConfigs?.any{cc ->cc.ComponentCode == 'WirelessService'}){
						ComponentConfigurations = compConfigs?.findAll{
					    cc -> cc.ComponentMapRequired == WirelineConstants.Boolean_TRUE &&
					    (cc.ComponentOperations.any{
						   co -> co?.OperationName.contains(WirelineConstants.PUSPOREQ)} ||
						   (cc.ComponentOperations.any{
						   co -> co?.OperationName.contains('PUSPOQtResponse')} && cc.ComponentCode=='WirelessService'))}
				}else{
					   ComponentConfigurations = compConfigs?.findAll{
					   cc -> cc.ComponentMapRequired == WirelineConstants.Boolean_TRUE && cc.ComponentOperations.any{
						   co -> co?.OperationName.contains(WirelineConstants.PUSPOREQ)}}
				}
			   if(ComponentConfigurations && !ComponentConfigurations.isEmpty()){
				  for(def ComponentConfiguration : ComponentConfigurations){
				  //def lineItem  = LineItems.find{li -> li.Characteristics?.CommonCharacteristics.ComponentConfigurations.any{cc -> cc.ComponentCode == ComponentConfiguration.ComponentCode}}
				  def OrderSpecId = LineItems.Characteristics?.CommonCharacteristics.find{cc -> cc.ComponentConfiguration.any{ccf -> ccf.ComponentCode == ComponentConfiguration.ComponentCode}}.ProductSpecificationId
				  // DISS For Voip multiple ComponentDetails---code matches ComponentConfiguration.ComponentCode
				  def IUSPDProductConfiguration
				   for(def iuspdConfig : IUSPDProdConfig){
						   def comDetails = OrderUtility.getAllComponentDetailsAsList([],iuspdConfig.ComponentDetails)
						  
						   if(iuspdConfig.productOfferingId.text() == OfferSpecDetail.offerId && comDetails.any{
					  cc -> cc.ProductSpecificationContainment?.ContainedProducts?.code.text() == ComponentConfiguration.ComponentCode}){
								  IUSPDProductConfiguration = iuspdConfig
								
						   }
				   }
				  // DISS IUSPDProductConfiguration.ComponentDetails --- nested ComponentDetails for child ComponentDetails
				   /*println('YEYE::'+IUSPDProductConfiguration.ComponentDetails.size())
				   println('YEYE::'+getAllComponentDetailsAsList([],IUSPDProductConfiguration.ComponentDetails).size())*/
				  if(IUSPDProductConfiguration) {
					  def IUSPDProdCoponentDetails = OrderUtility.getAllComponentDetailsAsList([],IUSPDProductConfiguration.ComponentDetails).find{
							  cd -> cd.ProductSpecificationContainment?.ContainedProducts?.code.text() == ComponentConfiguration.ComponentCode}
								  
							  if(OrderSpecId == IUSPDProductConfiguration.productOfferingProductSpecificationId.text() || IUSPDProductConfiguration.productOfferingId.text() == OfferSpecDetail.offerId){
								  ProductsInNewOfferConfigurations.add(
									  [
										  productOfferingProductSpecId : IUSPDProductConfiguration.productOfferingProductSpecificationId.text(),
										  OperationExtn : IUSPDProductConfiguration.operationExtension.text(),
										  ComponentConfiguration : getComponentConfiguration(IUSPDProdCoponentDetails, ComponentConfiguration, LineItems)
									   ]
								  )
							  }else{
								  ProductsInNewOfferConfigurations.add(
									  getNewOfferDetailsFromPayload(OrderSpecId, ComponentConfiguration, OfferSpecDetail.offerId+':'+OrderSpecId+':OfferIdAndSpecIdMismatch', LineItems)
								  )
							  }
						  }else{
							  ProductsInNewOfferConfigurations.add(
								  getNewOfferDetailsFromPayload(OrderSpecId, ComponentConfiguration, 'ComponentCodeNotFound', LineItems)
							  )
						  }
				  }
 
 
 
				   NewProductConfigurations.add([	Action : LineItems[0].Action,
											   OfferId : OfferSpecDetail.offerId,
											   ProductsInNewOfferConfigurations : ProductsInNewOfferConfigurations])
			   }
		   
		}
		NewOfferComponentMapping = [NewProductConfigurations : NewProductConfigurations]
		return [NewOfferComponentMapping : NewOfferComponentMapping]
	}
	
	
	def getAssignedProductComponentConfiguration(def context, def order){
			def AssignedProductComponentMapping
			def PkgOfferGroups = order.Groups.Group.findAll{grp -> grp.Type == WirelineConstants.GROUPTYPE_PACKAGE}
			def AssignedProductConfigurations = []
			def iuspdResp = new XmlSlurper().parseText(context.iuspdResp)
			def IUSPDProdConfig = iuspdResp.Body.InquireUnifiedServiceProductDetailsResponse.UnifiedServiceProductDetails.AssignedProducts.ProductConfiguration.flatten().minus(null)
			   def PkgOfferGroupId = order.Groups.Group.find{grp -> grp.Type == WirelineConstants.GROUPTYPE_PACKAGE &&
			   grp.GroupCharacteristics?.PackageCharacteristics?.Code == OfferSpecDetail.offerId}.Id
				def LineItems = []
				def FMOLineItems = []
			if(!PkgOfferGroups.isEmpty()){
		   LineItems = order.LineItems.LineItem.findAll{ li -> li.Action in [WirelineConstants.ACTION_ADD,'UPDATE'] && !li.GroupRefs.GroupRef.contains(PkgOfferGroupId) &&
				   li.Characteristics?.CommonCharacteristics?.ComponentConfiguration?.any{
					   cc -> cc.ComponentMapRequired == WirelineConstants.Boolean_TRUE && cc.ComponentOperations.any{
						   co -> co?.OperationName.intersect([WirelineConstants.PUSPOREQ,'PUSPOQtResponse'])}} }
			
			FMOLineItems = order.LineItems.LineItem.findAll{ li -> li.Action in [WirelineConstants.ACTION_ADD,'UPDATE','NO_CHANGE'] && !li.GroupRefs.GroupRef.contains(PkgOfferGroupId) &&
				   li.Characteristics?.CommonCharacteristics?.ComponentConfiguration?.any{
					   cc -> cc.ComponentMapRequired == WirelineConstants.Boolean_TRUE && cc.ComponentOperations.any{
						   co -> co?.OperationName.intersect([WirelineConstants.PUSPOREQ,'PUSPOQtResponse'])}} }
			}else{
			LineItems = order.LineItems.LineItem.findAll{ li -> li.Action in [WirelineConstants.ACTION_ADD,'UPDATE']  &&
				   li.Characteristics?.CommonCharacteristics?.ComponentConfiguration?.any{
					   cc -> cc.ComponentMapRequired == WirelineConstants.Boolean_TRUE && cc.ComponentOperations.any{
						   co -> co?.OperationName.contains(WirelineConstants.PUSPOREQ)}} }
						   
			FMOLineItems = order.LineItems.LineItem.findAll{ li -> li.Action in [WirelineConstants.ACTION_ADD,'UPDATE','NO_CHANGE'] &&
				   li.Characteristics?.CommonCharacteristics?.ComponentConfiguration?.any{
					   cc -> cc.ComponentMapRequired == WirelineConstants.Boolean_TRUE && cc.ComponentOperations.any{
						   co -> co?.OperationName.intersect([WirelineConstants.PUSPOREQ,'PUSPOQtResponse'])}} }
						   }
				   def ComponentConfigurations = []
				   def compConfigs = LineItems?.Characteristics?.CommonCharacteristics?.ComponentConfiguration.flatten().minus(null)
				   compConfigs.each{println(it?.ComponentOperations)}
				   if(compConfigs?.any{
					   cc ->cc.ComponentCode == 'QVideoBasic'}){
					   ComponentConfigurations = compConfigs?.findAll{
					   cc -> cc.ComponentMapRequired == WirelineConstants.Boolean_TRUE &&
					   (cc.ComponentOperations.any{
						   co -> co?.OperationName.contains(WirelineConstants.PUSPOREQ)} ||
						   (cc.ComponentOperations.any{
						   co -> co?.OperationName.contains('PUSPOQtResponse')} && cc.ComponentCode=='QVideoBasic' ||
						   cc.ComponentPath.contains('VideoBasic')))}
				   }else if(compConfigs?.any{
					   cc ->cc.ComponentCode == 'WirelessService'}){
					ComponentConfigurations = compConfigs?.findAll{
					   cc -> cc.ComponentMapRequired == WirelineConstants.Boolean_TRUE &&
					   (cc.ComponentOperations.any{
						   co -> co?.OperationName.contains(WirelineConstants.PUSPOREQ)} ||
						   (cc.ComponentOperations.any{
						   co -> co?.OperationName.contains('PUSPOQtResponse')} && cc.ComponentCode=='WirelessService'))}
				   }
				   else{
					   ComponentConfigurations = compConfigs?.findAll{
					   cc -> cc.ComponentMapRequired == WirelineConstants.Boolean_TRUE && cc.ComponentOperations.any{
						   co -> co?.OperationName.contains(WirelineConstants.PUSPOREQ)}}
				   }
				   if(ComponentConfigurations && !ComponentConfigurations.isEmpty()){
					  for(def ComponentConfiguration : ComponentConfigurations){
					  def OrderSpecId = LineItems.Characteristics?.CommonCharacteristics.find{cc -> cc.ComponentConfiguration.any{ccf -> ccf.ComponentCode == ComponentConfiguration.ComponentCode}}.ProductSpecificationId
					  def IUSPDProductConfiguration
					   for(def iuspdConfig : IUSPDProdConfig){
							   def comDetails = OrderUtility.getAllComponentDetailsAsList([],iuspdConfig.ComponentDetails)
							  
							   if(comDetails.any{cc -> cc.ProductSpecificationContainment?.ContainedProducts?.code.text() == ComponentConfiguration.ComponentCode}){
									  IUSPDProductConfiguration = iuspdConfig
									
							   }
					   }
					   def action = LineItems.any{li -> li.Action == 'UPDATE'} ? 'UPDATE' : 'ADD'
					  if(IUSPDProductConfiguration) {
						  def IUSPDProdCoponentDetails = OrderUtility.getAllComponentDetailsAsList([],IUSPDProductConfiguration.ComponentDetails).find{
								  cd -> cd.ProductSpecificationContainment?.ContainedProducts?.code.text() == ComponentConfiguration.ComponentCode}
									  
								  
								  AssignedProductConfigurations.add([action : action,
								  offerId:IUSPDProductConfiguration.productOfferingId.text(),
								  productOfferingProductSpecId: IUSPDProductConfiguration.productOfferingProductSpecificationId.text(),
								  productId: IUSPDProductConfiguration.productId.text(),
								  OperationExtn : IUSPDProductConfiguration.operationExtension.text(),
								  ComponentConfiguration : getComponentConfiguration(IUSPDProdCoponentDetails, ComponentConfiguration, LineItems)])
							  }else{
								  AssignedProductConfigurations.add(
									  getNewOfferDetailsFromPayload(OrderSpecId, ComponentConfiguration, 'ComponentCodeNotFound', LineItems)
								  )
							  }
					  }
				   }
			   
			
			AssignedProductComponentMapping = [AssignedProductConfigurations : AssignedProductConfigurations]
			return [AssignedProductComponentMapping : AssignedProductComponentMapping]
		}
	
	def getRemovedProductComponentConfigurationMapping(def context, def order){
		def AssignedProductComponentMapping
		def PkgOfferGroups = order.Groups.Group.findAll{grp -> grp.Type == WirelineConstants.GROUPTYPE_PACKAGE}
		def AssignedProductConfigurations = []
		def iuspdResp = new XmlSlurper().parseText(context.iuspdResp)
		def IUSPDProdConfig = iuspdResp.Body.InquireUnifiedServiceProductDetailsResponse.UnifiedServiceProductDetails.AssignedProducts.ProductConfiguration.flatten().minus(null)
		   def PkgOfferGroupId = order.Groups.Group.find{grp -> grp.Type == WirelineConstants.GROUPTYPE_PACKAGE &&
		   grp.GroupCharacteristics?.PackageCharacteristics?.Code == OfferSpecDetail.offerId}.Id
			def LineItems = []
	   LineItems = order.LineItems.LineItem.findAll{ li -> li.Action =='REMOVE' && li.ProductType =='OPTIONAL_FEATURE'  &&
			   li.Characteristics?.CommonCharacteristics?.ComponentConfiguration?.any{
				   cc -> cc.ComponentOperations.any{
					   co -> co?.OperationName.intersect([WirelineConstants.PUSPOREQ,'PUSPOQtResponse'])}} }
		for(def lineItem : LineItems){
			   def ComponentConfigurations = []
			   def compConfigs = lineItem?.Characteristics?.CommonCharacteristics?.ComponentConfiguration.flatten().minus(null)
			   compConfigs.each{println(it?.ComponentOperations)}
			   if(compConfigs?.any{
				   cc ->cc.ComponentCode == 'QVideoBasic'}){
				   ComponentConfigurations = compConfigs?.findAll{
				   cc.ComponentOperations.any{
					   co -> co?.OperationName.contains('PUSPOQtResponse')}}
			   }
			   else{
				   ComponentConfigurations = compConfigs?.findAll{
				   cc -> cc.ComponentOperations.any{
					   co -> co?.OperationName.contains(WirelineConstants.PUSPOREQ)}}
			   }
			   if(ComponentConfigurations && !ComponentConfigurations.isEmpty()){
				  for(def ComponentConfiguration : ComponentConfigurations){
				  def IUSPDProductConfiguration
				   for(def iuspdConfig : IUSPDProdConfig){
						   def comDetails = OrderUtility.getAllComponentDetailsAsList([],iuspdConfig.ComponentDetails)
						  
						   if(comDetails.any{cc -> cc.ProductSpecificationContainment?.ContainedProducts?.code.text() == ComponentConfiguration.ComponentCode}){
								  IUSPDProductConfiguration = iuspdConfig
								
						   }
				   }
				  if(IUSPDProductConfiguration) {
					  def IUSPDProdCoponentDetails = OrderUtility.getAllComponentDetailsAsList([],IUSPDProductConfiguration.ComponentDetails).find{
							  cd -> cd.ProductSpecificationContainment?.ContainedProducts?.code.text() == ComponentConfiguration.ComponentCode}
								  
							  
							  RemovedProductConfigurations.add([action : lineItem.Action,
							  offerId:IUSPDProductConfiguration.productOfferingId.text(),
							  productOfferingProductSpecId: IUSPDProductConfiguration.productOfferingProductSpecificationId.text(),
							  productId: IUSPDProductConfiguration.productId.text(),
							  parentOperationExtension : IUSPDProductConfiguration.ParentOperationExtn.text(),
							  ])
						  }
				  }
			   }
		   
		}
		RemovedProductComponentMapping = [RemovedProductConfigurations : RemovedProductConfigurations]
		return [RemovedProductComponentMapping : RemovedProductComponentMapping]
	}
	
	 def getComponentConfiguration(def IUSPDProdComponentDetails, def ComponentConfiguration, def LineItems){
	   
	   def operationExtension = IUSPDProdComponentDetails.operationExtension ? IUSPDProdComponentDetails.operationExtension?.text() : java.util.UUID.randomUUID().toString()+'-oce'
	   def puspoAttributes = ComponentConfiguration.Attributes.findAll{attr -> attr.AttributeOperations.any{ao -> ao.OperationName.contains(WirelineConstants.PUSPOREQ)}}
	   def attributeCodes = puspoAttributes.AttributeCode.unique()
	   def Attributes = []
	   for(def i=0;i< attributeCodes.size();i++){
		   def puspoAttribute = puspoAttributes.find{pa -> pa.AttributeCode == attributeCodes[i]}
		   Attributes.add([Code : puspoAttribute.AttributeCode,
		   Value : getAttributeValue(puspoAttribute.AttributeCode,puspoAttribute.AttributeValue,ComponentConfiguration,LineItems),
		   CharacteristicsId :  IUSPDProdComponentDetails.CharacteristicDetails.find{cd -> cd?.ProductSpecificationCharacteristic?.code == puspoAttribute.AttributeCode}?.productSpecificationCharacteristicId.text() ,
		   AttributeOperations : puspoAttribute.AttributeOperations[0].OperationName[0]])
	   }
	   return [isComponentMapped : WirelineConstants.Boolean_TRUE,
									   componentCode : ComponentConfiguration.ComponentCode,
									   operationExtension : operationExtension,
									   componentPATH : ComponentConfiguration.ComponentPath,
									   displayName : null ,//LineItems.find{li -> li.Characteristics?.CommonCharacteristics?.ComponentConfiguration.any{cc -> cc.ComponentCode == ComponentConfiguration.ComponentCode}}.DisplayName,
									   productSpecificationContainmentId : IUSPDProdComponentDetails.productSpecificationContainmentId.text(),
									   productId : IUSPDProdComponentDetails.productId.text() ,
									   componentMapping : WirelineConstants.Boolean_TRUE,
									   Attributes : Attributes]
 
 
 
	   }
 
	  def getNewOfferDetailsFromPayload(def OrderSpecId, def ComponentConfiguration, def note,def LineItems) {

			def attributeCodes = ComponentConfiguration?.Attributes ? ComponentConfiguration?.Attributes?.AttributeCode?.unique():[]
			def Attributes = []
			for(int i = 0;i< attributeCodes.size();i++){
			
			def attributeValues = ComponentConfiguration.Attributes.AttributeValue
			def attributeValue = getAttributeValue(attributeCodes[i],attributeValues[i],ComponentConfiguration,LineItems )
				Attributes.add(
					[
						code : attributeCodes[i],
						Value : attributeValue,
						CharacteristicsId : null ,
						AttributeOperations : ComponentConfiguration.Attributes[i].AttributeOperations.flatten().OperationName[0]
					]
				)
			}
			
			def compCongig = [isComponentMapped : WirelineConstants.Boolean_FALSE,
								componentCode : ComponentConfiguration?.ComponentCode,
								componentPATH : ComponentConfiguration?.ComponentPath,
								displayName : LineItems.find{li -> li.Characteristics?.CommonCharacteristics?.ComponentConfiguration.any{cc -> cc?.ComponentCode == ComponentConfiguration?.ComponentCode}}?.DisplayName,
								productSpecificationContainmentId : null,
								productId : null,
								componentMapping : WirelineConstants.Boolean_TRUE,
								Attributes : Attributes,
								Note : note]
			
			
				return 	[
							productOfferingProductSpecId : OrderSpecId,
							OperationExtn : null,
							ComponentConfiguration : compCongig
						]

		}
	
	
	
	def getAttributeValue(attributeCode,attributeValue,ComponentConfiguration,lineItems) {
		   
		   def sum
		   if(attributeValue.contains('@')) {
			   
			   def quantList = lineItems.findAll{li -> li.Characteristics?.CommonCharacteristics?.ComponentConfiguration.any{cc -> cc.ComponentCode == ComponentConfiguration.ComponentCode && cc.Attributes.AttributeCode.contains(attributeCode)}}//.collect{it.Quantity}.flatten().minus(null)
				  
			   def totalQuantity = quantList?.Quantity?.sum()
			   
			   
			   return totalQuantity
			}
		   else {
			   
			   return attributeValue
			   
		   }
	   }
 
	   /**
		*
		*/
	   def constructOfferSpecIdStructure(def Order, def uverseAcc) {
		   def OfferSpecDetails = []
		   def offerPckGroupList = Order.Groups.Group.findAll { grp -> grp?.Type == WirelineConstants.GROUPTYPE_PACKAGE  && grp?.GroupCharacteristics?.PackageCharacteristics?.Category == WirelineConstants.CATEGORY_OFFER}
		   def ProductSpecificationIds = new HashSet();
		   def isNewUverseAcc = (uverseAcc?.AccountSubCategory == "NEW")
 
		   for(def offerPckGroup in offerPckGroupList )
		   {
			   def pckCharc = offerPckGroup.GroupCharacteristics?.PackageCharacteristics
 
			   if(pckCharc && !pckCharc.isEmpty()) {
 
				   def offerId = pckCharc.Code
				   def offerType = pckCharc.Type ? pckCharc.Type : (isNewUverseAcc ? uverseAcc?.AccountSubCategory : '')
 
 
				   def lineItems = Order.LineItems.LineItem.findAll{li -> li.GroupRefs.GroupRef.contains(offerPckGroup.Id)}
 
				   for(def lineItem in lineItems){
					   //Distinct productSpecificationId - using hashset for this
						ProductSpecificationIds.add(lineItem?.Characteristics?.CommonCharacteristics?.ProductSpecificationId)
						ProductSpecificationIds.remove(null) //remove null if present
				   }
 
				   OfferSpecDetails.add([ offerType : offerType,
					   offerId : pckCharc.Code,
					   productsOfferSpecificationIds : ProductSpecificationIds
					   ])
			   }
 
			   else {
 
				   continue
			   }
		   }
 
 
		   return [OfferSpecDetails : OfferSpecDetails]
	   }
	   
	   def getComponentConfigurationVoip(def ComponentConfiguration, def UMCNewComponentDetails,def UverseWorkOrderID){
		   // Pass the correct VOIP Group and Use that only to create Attributes
		   def Attributes = []
		   for(def charDetail : UMCNewComponentDetails.CharacteristicDetails.flatten().minus(null)){
			// Add Attribute value from IUSAPResponse
			Attributes.add([code : charDetails.ProductSpecificationCharacteristic.code,
									  Value : UverseWorkOrderID,
									  CharacteristicsId : charDetails.productSpecificationCharacteristicId,
									  AttributeOperations : WirelineConstants.PUSPOREQ])
		   }
		   ComponentConfiguration.remove('Note');
		   ComponentConfiguration.Attributes = Attributes
		
		   return 	ComponentConfiguration
		
	   }
	   
	   def setHSComponentConfigurationForUverseWoID(def context,def componentArray, def order){
		   def ProductConfigurations = [:]
			def iuspdResp = new XmlSlurper().parseText(context.iuspdResp)
			def UMCNewComponentDetails = OrderUtility.getAllComponentDetailsAsList([],iuspdResp.Body.InquireUnifiedServiceProductDetailsResponse.UnifiedServiceProductDetails.ProductsInNewOffer.ProductConfiguration.ComponentDetails.flatten()).findAll{pc -> pc.ProductSpecificationContainment.ContainedProducts.code == componentArray}
			def UMCAssignedComponentDetails = OrderUtility.getAllComponentDetailsAsList([],iuspdResp.Body.InquireUnifiedServiceProductDetailsResponse.UnifiedServiceProductDetails.AssignedProducts.ProductConfiguration.ComponentDetails.flatten()).findAll{pc -> pc.ProductSpecificationContainment.ContainedProducts.code == componentArray}
		
		   /*def UMCNewComponentDetails = context.iuspdResp.UnifiedServiceProductDetails.ProductsInNewOffer.ProductConfiguration.ComponentDetails.flatten().findAll{pc -> pc.ProductSpecificationContainment.ContainedProducts.code == componentArray}
		   def UMCAssignedComponentDetails = context.iuspdResp.UnifiedServiceProductDetails.AssignedProducts.ProductConfiguration.ComponentDetails.flatten().findAll{pc -> pc.ProductSpecificationContainment.ContainedProducts.code == componentArray}*/
		   def NewOfferComponentMapping
		   def VOIPLineItem = order.LineItems.LineItem.find{li -> li.Characteristics?.CommonCharacteristics?.ComponentConfiguration?.any{cc -> cc.ComponentCode == componentArray}}
		   //def uverseOfferId = order.Groups.Group.findAll{grp -> grp.Id in VOIPLineItem.GroupRefs.GroupRef  && grp.GroupCharacteristics?.PackageCharacteristics?.Category == WirelineConstants.PACKAGE_CATEGORY}.GroupCharacteristics?.PackageCharacteristics.Code
		   //def componantPath = VOIPLineItem.Characteristics?.CommonCharacteristics?.ComponentConfiguration.flatten().minus(null).find{cc -> cc.ComponentCode == componentArray}?.ComponentPath
		   def uverseOfferId = WirelineConstants.UVERSE_OFFER_ID
		   def operationExtn = java.util.UUID.randomUUID().toString()
		   def NewProductConfigurations = []
		   def UverseSchedulingRef = order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.findAll
			{los -> los?.ProductCategory in [WirelineConstants.PRODUCTCATEGORY_IPTV , WirelineConstants.PRODUCTCATEGORY_INTERNET , WirelineConstants.PRODUCTCATEGORY_VOIP]}
		   def UverseWorkOrderID = order.SchedulingInfos?.SchedulingInfo?.findAll{sch -> sch?.Id in UverseSchedulingRef?.SchedulingInfoRef}?.ActualSchedule?.WorkOrderId
	
			   for(def newProductConfig : context.HSComponentConfiguration?.ProductConfigurations?.NewOfferComponentMapping?.NewProductConfigurations){
				   def prodNewOfferConfig = []
				   def newComCodeExist = false
				   if(newProductConfig.OfferId == uverseOfferId[0]){
				   //action
					   for(def ProductsInNewOfferConfiguration : newProductConfig?.ProductsInNewOfferConfigurations){
						   if(ProductsInNewOfferConfiguration?.ComponentConfiguration?.componentCode == componentArray ){
						   newComCodeExist = true
						   // Change only Attributes in ComponentConfiguration
							   prodNewOfferConfig.add([productOfferingProductSpecId : ProductsInNewOfferConfiguration?.productOfferingProductSpecificationId,
									   OperationExtn : ProductsInNewOfferConfiguration?.operationExtension,
									   ComponentConfiguration : getComponentConfigurationDTV(ProductsInNewOfferConfiguration?.ComponentConfiguration, UMCNewComponentDetails, UverseWorkOrderID)])
									   // to do
						   }else{
							   prodNewOfferConfig.add(ProductsInNewOfferConfiguration)
						   }
	
					   }
					   if(UMCNewComponentDetails && !UMCNewComponentDetails.isEmpty() && !newComCodeExist){
						   //for(def voipCompDetails : UMCNewComponentDetails.findAll{vnc -> vnc.selectedIndicator == true && vnc.actionCode in ['AD','UP']}){
							   //def prodConf = context.puspoResp.UnifiedServiceProductDetails.ProductsInNewOffer.find{pino -> pino.ProductConfiguration.productOfferingId in uverseOfferId}.ProductConfiguration
							   def prodConf = iuspdResp.Body.InquireUnifiedServiceProductDetailsResponse.UnifiedServiceProductDetails.ProductsInNewOffer.ProductConfiguration[0]
							   def compConfig = []
							   
							   prodNewOfferConfig.add([productOfferingProductSpecId : prodConf.productOfferingProductSpecificationId.text(),
									   OperationExtn : !!prodConf.operationExtension ? prodConf.operationExtension.text() : operationExtn,
									   ComponentConfiguration : [
												 isComponentMapped : true,
												 componentCode : UMCNewComponentDetails[0].ProductSpecificationContainment.ContainedProducts.code.text() ,
												 operationExtension : !!UMCNewComponentDetails[0].operationExtension ? UMCNewComponentDetails[0].operationExtension.text() : operationExtn,
												 displayName : UMCNewComponentDetails[0].ProductSpecificationContainment.ContainedProducts.name.text(),
												 productSpecificationContainmentId : UMCNewComponentDetails[0].ProductSpecificationContainment.id.text(),
												 productId : UMCNewComponentDetails[0].productId.text(),
												 componentMapping : true,
												 Attributes : getAttributesDTV(UMCNewComponentDetails[0], UverseWorkOrderID)
								 ]])
							   
	
						   //}
	
					   }
					   NewProductConfigurations.add([	Action : newProductConfig?.Action,
												   OfferId : newProductConfig?.OfferId,
												   ProductsInNewOfferConfigurations : prodNewOfferConfig])
				   }else{
					   NewProductConfigurations.add(newProductConfig)
				   }
			   }
		   NewOfferComponentMapping = [NewProductConfigurations : NewProductConfigurations]
	
			ProductConfigurations = [ NewOfferComponentMapping : NewOfferComponentMapping]
	
		   return [ProductConfigurations : ProductConfigurations]
   }
	   
	   
	   def SetHSComponentConfigurationForDTVWoID(def context,def componentArray, def order){
		   def ProductConfigurations = [:]
			  def iuspdResp = new XmlSlurper().parseText(context.iuspdResp)
			  def UMCNewComponentDetails = OrderUtility.getAllComponentDetailsAsList([],iuspdResp.Body.InquireUnifiedServiceProductDetailsResponse.UnifiedServiceProductDetails.ProductsInNewOffer.ProductConfiguration.ComponentDetails.flatten()).findAll{pc -> pc.ProductSpecificationContainment.ContainedProducts.code == componentArray}
			  def UMCAssignedComponentDetails = OrderUtility.getAllComponentDetailsAsList([],iuspdResp.Body.InquireUnifiedServiceProductDetailsResponse.UnifiedServiceProductDetails.AssignedProducts.ProductConfiguration.ComponentDetails.flatten()).findAll{pc -> pc.ProductSpecificationContainment.ContainedProducts.code == componentArray}
		   //def PUSPOAssignedProductConfigurations = context.puspoResp.UnifiedServiceProductDetails.AssignedProducts.ProductConfiguration
		   // below lines for Local testing
			  //def UMCNewComponentDetails = OrderUtility.getAllComponentDetailsAsList([],context.iuspdResp.UnifiedServiceProductDetails.ProductsInNewOffer.ProductConfiguration.ComponentDetails.flatten()).findAll{pc -> pc?.ProductSpecificationContainment?.ContainedProducts?.code == componentArray}
		   //def UMCAssignedComponentDetails = OrderUtility.getAllComponentDetailsAsList([],context.iuspdResp.UnifiedServiceProductDetails.AssignedProducts.ProductConfiguration.ComponentDetails.flatten()).findAll{pc -> pc.ProductSpecificationContainment.ContainedProducts.code == componentArray}
		   def NewOfferComponentMapping
		   def VOIPLineItem = order.LineItems.LineItem.find{li -> li.Characteristics?.CommonCharacteristics?.ComponentConfiguration?.any{cc -> cc.ComponentCode == componentArray}}
		   //def uverseOfferId = order.Groups.Group.findAll{grp -> grp.Id in VOIPLineItem.GroupRefs.GroupRef  && grp.GroupCharacteristics?.PackageCharacteristics?.Category == WirelineConstants.PACKAGE_CATEGORY}.GroupCharacteristics?.PackageCharacteristics.Code
		   //def componantPath = VOIPLineItem.Characteristics?.CommonCharacteristics?.ComponentConfiguration.flatten().minus(null).find{cc -> cc.ComponentCode == componentArray}?.ComponentPath
		   def dtvOfferId = WirelineConstants.DTV_OFFER_ID
		   def operationExtn = java.util.UUID.randomUUID().toString()
		   def NewProductConfigurations = []
		   def dtvSchedulingRef = order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.findAll
			{los -> los?.ProductCategory in [WirelineConstants.PRODUCTCATEGORY_DTV ]}
		   def dtvWorkOrderID = order.SchedulingInfos?.SchedulingInfo?.findAll{sch -> sch?.Id in dtvSchedulingRef?.SchedulingInfoRef}?.ActualSchedule?.WorkOrderId
	   
			   for(def newProductConfig : context.HSComponentConfiguration?.ProductConfigurations?.NewOfferComponentMapping?.NewProductConfigurations){
				   def prodNewOfferConfig = []
				   def newComCodeExist = false
				   if(newProductConfig.OfferId == dtvOfferId[0]){
				   //action
					   for(def ProductsInNewOfferConfiguration : newProductConfig?.ProductsInNewOfferConfigurations){
						   if(ProductsInNewOfferConfiguration?.ComponentConfiguration?.componentCode == componentArray ){
						   newComCodeExist = true
						   // Change only Attributes in ComponentConfiguration
							   prodNewOfferConfig.add([productOfferingProductSpecId : ProductsInNewOfferConfiguration?.productOfferingProductSpecificationId,
									   OperationExtn : ProductsInNewOfferConfiguration?.operationExtension,
									   ComponentConfiguration : getComponentConfigurationDTV(ProductsInNewOfferConfiguration?.ComponentConfiguration, UMCNewComponentDetails, dtvWorkOrderID)])
									   // to do
						   }else{
							   prodNewOfferConfig.add(ProductsInNewOfferConfiguration)
						   }
	   
					   }
					   if(UMCNewComponentDetails && !UMCNewComponentDetails.isEmpty() && !newComCodeExist){
						   //for(def voipCompDetails : UMCNewComponentDetails.findAll{vnc -> vnc.selectedIndicator == true && vnc.actionCode in ['AD','UP']}){
							   //def prodConf = context.puspoResp.UnifiedServiceProductDetails.ProductsInNewOffer.find{pino -> pino.ProductConfiguration.productOfferingId in uverseOfferId}.ProductConfiguration
							   def prodConf = iuspdResp.Body.InquireUnifiedServiceProductDetailsResponse.UnifiedServiceProductDetails.ProductsInNewOffer.ProductConfiguration[0]
							   def compConfig = []
							   
							   prodNewOfferConfig.add([productOfferingProductSpecId : prodConf.productOfferingProductSpecificationId.text(),
									   OperationExtn : !!prodConf.operationExtension ? prodConf.operationExtension.text() : operationExtn,
									   ComponentConfiguration : [
												 isComponentMapped : true,
												 componentCode : UMCNewComponentDetails[0].ProductSpecificationContainment.ContainedProducts.code.text() ,
												 operationExtension : !!UMCNewComponentDetails[0].operationExtension ? UMCNewComponentDetails[0].operationExtension.text() : operationExtn,
												 displayName : null /*UMCNewComponentDetails[0].ProductSpecificationContainment.ContainedProducts.name.text()*/,
												 productSpecificationContainmentId : UMCNewComponentDetails[0].ProductSpecificationContainment.id.text(),
												 productId : UMCNewComponentDetails[0].productId.text(),
												 componentMapping : true,
												 Attributes : getAttributesDTV(UMCNewComponentDetails[0], dtvWorkOrderID)
								 ]])
							   
	   
						   //}
	   
					   }
					   NewProductConfigurations.add([	Action : newProductConfig?.Action,
												   OfferId : newProductConfig?.OfferId,
												   ProductsInNewOfferConfigurations : prodNewOfferConfig])
				   }else{
					   NewProductConfigurations.add(newProductConfig)
				   }
			   }
		   NewOfferComponentMapping = [NewProductConfigurations : NewProductConfigurations]
	   
			ProductConfigurations = [ NewOfferComponentMapping : NewOfferComponentMapping]
	   
		   return [ProductConfigurations : ProductConfigurations]
	  }
	   
	  def getComponentConfigurationDTV(def ComponentConfiguration, def UMCNewComponentDetails,def dtvWorkOrderID){
	   // Pass the correct VOIP Group and Use that only to create Attributes
	   def Attributes = []
		   for(def charDetail : UMCNewComponentDetails?.CharacteristicDetails.flatten().minus(null)){
			// Add Attribute value from IUSAPResponse
			   if(charDetail?.ProductSpecificationCharacteristic?.code == WirelineConstants.WORK_ORDER_ID){
				Attributes.add([code : charDetail?.ProductSpecificationCharacteristic.code,
										   Value : dtvWorkOrderID[0],
										  CharacteristicsId : charDetail?.productSpecificationCharacteristicId,
										  AttributeOperations : WirelineConstants.PUSPOREQ])
			   }
		   }
		   ComponentConfiguration.Attributes = Attributes
		   return ComponentConfiguration
		   
	  }
	  
	  def getAttributesDTV(def UMCNewComponentDetails,def dtvWorkOrderID){
		  // Pass the correct VOIP Group and Use that only to create Attributes
		  def Attributes = []
			  for(def charDetail : UMCNewComponentDetails?.CharacteristicDetails?.flatten().findAll{cd -> cd?.ProductSpecificationCharacteristic?.code == WirelineConstants.WORK_ORDER_ID}){
			   // Add Attribute value from IUSAPResponse
				  
				   Attributes.add([code : charDetail?.ProductSpecificationCharacteristic.code.text(),
											  Value : dtvWorkOrderID[0],
											 CharacteristicsId : charDetail?.productSpecificationCharacteristicId.text(),
											 AttributeOperations : WirelineConstants.PUSPOREQ])
				  
			  }
			  return Attributes
		 }
	  
	  def validateHSComponentConfig(def HSConfig){
		 def Errors = [] 
		 def compConfigs = HSConfig?.ProductConfigurations?.NewOfferComponentMapping?.NewProductConfigurations?.ProductsInNewOfferConfigurations?.flatten()?.ComponentConfiguration.findAll{cc -> cc?.isComponentMapped == WirelineConstants.Boolean_FALSE}
		 for(def compConfig : compConfigs){
				 if(compConfig.Note.endsWith('OfferIdAndSpecIdMismatch')){
					 Errors.add(new ErrorBean('ErrorHSComp01', compConfig.Note.split(':')[1]+ ' mismatch found in IUSPD Response.'))
				 }else if(compConfig.Note == 'ComponentCodeNotFound'){
				 	Errors.add(new ErrorBean('ErrorHSComp02',compConfig.componentCode+' is missing for '+compConfig.displayName+ ' in IUSPD Response.'))
					 
			 }
		 }
		 return Errors
	  }

}
