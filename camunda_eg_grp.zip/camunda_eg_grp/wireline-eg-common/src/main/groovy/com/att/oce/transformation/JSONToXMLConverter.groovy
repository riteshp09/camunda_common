package com.att.oce.transformation

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate
import org.camunda.bpm.engine.impl.bpmn.delegate.JavaDelegateInvocation
import org.springframework.stereotype.Component;

import com.att.oce.bpm.utility.OrderUtility;

@Component("jsontoXMLConverter")
class JSONToXMLConverter implements JavaDelegate {

	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		def order = execution.getVariable("order")
		
		def jsonOrder = [Order:order]
		
		def xmlOrder = OrderUtility.convertJsonToXml(jsonOrder)
		
		println('XML Order after conversion>>>>>>'+xmlOrder)
		execution.setVariable("xmlOrder",xmlOrder)
		
	}
}
