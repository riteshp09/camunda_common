package com.att.oce.transformation

import groovy.json.*

import java.util.ArrayList;
import java.util.Collections
import java.util.Date;
import java.util.List;
import java.util.Map;
import com.att.oce.config.components.GlobalProperties
import com.att.oce.bpm.common.WirelineTransformationService
import com.att.oce.bpm.common.util.ErrorBean
import com.att.oce.bpm.error.APIFailedException;
import com.att.oce.config.components.ErrorConfig

import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component('validateOrder')
class WirelineOrderValidation extends WirelineTransformationService {

	@Override String getApiName(){
		return "BusinessRulesValidation";
	}

	@Autowired
	protected ErrorConfig config;

	def validateWirelineOrder(def Order)
	{
		List nackErrorList = new ArrayList()
		Map<List> errorList = new HashMap<List>()

		nack507(Order,nackErrorList)
		nack508(Order,nackErrorList)
		nack521(Order,nackErrorList)
		nack522(Order,nackErrorList)
		nack524(Order,nackErrorList)
		nack527(Order,nackErrorList)
		nack528(Order,nackErrorList)
		nack529(Order,nackErrorList)
		nack533(Order,nackErrorList)
		nack534(Order,nackErrorList)
		nack536(Order,nackErrorList)
		nack538(Order,nackErrorList)
		nack540(Order,nackErrorList)
		nack541(Order,nackErrorList)
		nack542(Order,nackErrorList)
		nack545(Order,nackErrorList)
		nack546(Order,nackErrorList)
		nack550(Order,nackErrorList)
		nack551(Order,nackErrorList)
		nack570(Order,nackErrorList)
		nack571(Order,nackErrorList)
		nack585(Order,nackErrorList)
		nack586(Order,nackErrorList)
		nack587(Order,nackErrorList)
		nack627(Order,nackErrorList)
		nack628(Order,nackErrorList)
		nack504(Order,nackErrorList)
		nack509(Order,nackErrorList)
		nack510(Order,nackErrorList)
		nack512(Order,nackErrorList)
		nack515(Order,nackErrorList)
		nack517(Order,nackErrorList)
		nack518(Order,nackErrorList)
		nack519(Order,nackErrorList)
		nack520(Order,nackErrorList)
		nack532(Order,nackErrorList)
		nack535(Order,nackErrorList)
		nack543(Order,nackErrorList)
		nack544(Order,nackErrorList)
		nack555(Order,nackErrorList)
		nack556(Order,nackErrorList)
		nack557(Order,nackErrorList)
		nack558(Order,nackErrorList)
		nack559(Order,nackErrorList)
		nack561(Order,nackErrorList)
		nack562(Order,nackErrorList)
		nack563(Order,nackErrorList)
		nack564(Order,nackErrorList)
		nack565(Order,nackErrorList)
		nack569(Order,nackErrorList)
		nack572(Order,nackErrorList)
		nack573(Order,nackErrorList)
		nack574(Order,nackErrorList)
		nack575(Order,nackErrorList)
		nack576(Order,nackErrorList)
		nack577(Order,nackErrorList)
		nack579(Order,nackErrorList)
		nack580(Order,nackErrorList)
		nack581(Order,nackErrorList)
		nack593(Order,nackErrorList)
		nack596(Order,nackErrorList)
		nack611(Order,nackErrorList)
		nack612(Order,nackErrorList)
		nack617(Order,nackErrorList)
		nack500(Order,nackErrorList)
		nack501(Order,nackErrorList)
		nack502(Order,nackErrorList)
		nack503(Order,nackErrorList)
		nack511(Order,nackErrorList)
		nack513(Order,nackErrorList)
		nack514(Order,nackErrorList)
		nack525(Order,nackErrorList)
		nack526(Order,nackErrorList)
		nack530(Order,nackErrorList)
		nack552(Order,nackErrorList)
		nack001(Order,nackErrorList)
		nack598(Order,nackErrorList)
		nack599(Order,nackErrorList)
		nack600(Order,nackErrorList)
		nack601(Order,nackErrorList)
		nack602(Order,nackErrorList)
		nack608(Order,nackErrorList)
		nack609(Order,nackErrorList)
		nack615(Order,nackErrorList)
		nack506(Order,nackErrorList)

		List<ErrorBean> errBeanList = new ArrayList<ErrorBean>();

		if(!nackErrorList.isEmpty())
		{
			for(error in nackErrorList)
			{
				String ErrorDescription = config.getErrorDescription(error.get("ErrorCode"))

				//nackErrorList.add(['ErrorCode':'nack504','Reference': ['Type':'LINE_OF_SERVICE','IdRef' : groupMap?.Id]])

				ErrorBean err = new ErrorBean(error.get("ErrorCode"),ErrorDescription,error.Reference?.Type,error.Reference?.IdRef);
				errBeanList.add(err);
				error.put("ErrorDescription",ErrorDescription)
			}
			errorList.put("Error",nackErrorList)
			//			Order.put("Errors",errorList)
		}
		return errBeanList
	}

	public def nack507(def Order, def nackErrorList)
	{
		def lineItemList=Order?.LineItems?.LineItem
		def lineItemCount=lineItemList?.size();
		for(def i=0;i<lineItemCount;i++)
		{
			def lineItemMap=lineItemList.get(i)
			if(lineItemMap?.Price && lineItemMap?.Price?.PriceType && lineItemMap?.Price?.PriceType == "DueToday")
			{
				if(lineItemMap?.Price && lineItemMap?.Price?.Amount && lineItemMap.Price.Amount > 0)
				{
					if(lineItemMap.Payments?.Payment?.PaymentOptionRef.get(0)){

					}
					else{
						nackErrorList.add(['ErrorCode':'nack507','Reference': ['Type':'LineItem','IdRef' :lineItemMap.Id ]])
					}
				}
			}
		}
	}

	public def nack508(def Order, def nackErrorList)
	{

		def groupList=Order.Groups.Group
		def losgCount=groupList.size();

		for(def i=0;i<losgCount;i++)
		{
			def groupMap=groupList.get(i)
			if(groupMap?.Type=="LINE_OF_SERVICE" && groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics &&
			groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="WIRELESS" &&
			(groupMap?.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod=="DF" || groupMap?.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod=="C2S"))
			{
				def losgType = groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
				if((losgType=="NEW" || losgType=="AL" || losgType=="ALF" || losgType=="UP") &&
				groupMap?.GroupCharacteristics?.LoSGCharacteristics?.WirelessLOSChars && groupMap?.GroupCharacteristics?.LoSGCharacteristics?.WirelessLOSChars?.UpgradeInfo)
				{
					if(groupMap?.GroupCharacteristics?.LoSGCharacteristics?.WirelessLOSChars?.UpgradeInfo?.Relationship!="DONOR")
					{
						def accountlist=Order?.Accounts?.Account
						def accountCount=accountlist.size();

						for(def j=0;j<accountCount;j++)
						{
							def accountMap=accountlist.get(j)
							if(accountMap?.Id==groupMap?.GroupCharacteristics?.LoSGCharacteristics?.AccountRef && accountMap?.PaymentArrangement=="POSTPAID")
							{
								def lineItemlist=Order?.LineItems?.LineItem
								def lineItemCount=lineItemlist.size();

								for(def k=0;k<lineItemCount;k++)
								{
									def lineItemMap=lineItemlist.get(k)
									if(lineItemMap?.ProductType && lineItemMap?.ProductType=="HARDGOOD" && lineItemMap?.HardGood?.HardGoodType=="DEVICE")
									{
										if(lineItemMap?.ContractDetails?.ContractType=="REGULAR" && (Order?.IsPassThrough!=true))
										{
											if(lineItemMap?.ContractDetails?.ContractLength && lineItemMap?.ContractDetails?.TotalSalePrice)
											{
											}
											else
											{
												nackErrorList.add(['ErrorCode':'nack508','Reference': ['Type':'LineItem','IdRef' :lineItemMap.Id ]])
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack521(def Order, def nackErrorList)
	{
		def	AccountList=Order?.Accounts?.Account
		def OrderVal=Order?.IsPassThrough
		if(AccountList!=null && AccountList.size() > 0 || OrderVal)
		{
		}
		else
		{
			nackErrorList.add(['ErrorCode':'nack521','Reference': ['Type':'ACCOUNT','IdRef' : AccountList?.Id]])
		}
	}

	public def nack522(def Order, def nackErrorList)
	{
		def	AccountList=Order?.Accounts?.Account

		for(def i=0;AccountList!= null && i<AccountList.size();i++)
		{
			def AccountMap =AccountList.get(i)
			def channel = Order?.OrderSource?.Channel
			if(AccountMap != null && (channel=="CDE-HS" || channel=="EDE-EG" || channel=="SMB-WEB-CENTER") )
			{
				if( (Order?.OrderSource?.Channel=="SMB-WEB-CENTER" && AccountMap?.AccountSubCategory != null && AccountMap?.AccountSubCategory=="NEW") || ( (AccountMap?.AccountSubCategory != null && AccountMap?.AccountCategory=="MOBILITY_ACCOUNT") &&
				(AccountMap?.AccountSubCategory != null && AccountMap?.AccountSubCategory=="NEW") ) )
				{
					if(AccountMap?.Id !=null &&
					AccountMap?.AccountCategory !=null &&
					AccountMap?.AccountSubCategory !=null &&
					AccountMap?.PaymentArrangement !=null &&
					AccountMap?.AccountType !=null &&
					AccountMap?.AccountSubType !=null &&
					AccountMap?.Market !=null )
					{
					}
					else
					{
						nackErrorList.add(['ErrorCode':'nack522','Reference': ['Type':'ACCOUNT','IdRef' : AccountMap?.Id]])
					}
				}
				else if(AccountMap?.AccountSubCategory != null && AccountMap?.AccountSubCategory=="EXISTING")
				{
					if(AccountMap?.Id !=null &&
					AccountMap?.AccountCategory !=null &&
					AccountMap?.AccountSubCategory !=null &&
					AccountMap?.PaymentArrangement !=null)
					{
					}
					else
					{
						nackErrorList.add(['ErrorCode':'nack522','Reference': ['Type':'ACCOUNT','IdRef' : AccountMap?.Id]])
					}
				}
			}
		}
	}

	public def nack524(def Order, def nackErrorList)
	{
		if(Order?.IsPassThrough==true)
		{
		}
		else
		{
			def paymentOptionList=Order?.PaymentOptions?.PaymentOption

			if(paymentOptionList != null) {
				def paymentOptionCount=paymentOptionList?.size();

				for(def i=0;i<paymentOptionCount;i++)
				{
					def paymentOptionMap=paymentOptionList.get(i)
					if(Order.DueAmount?.Amount && Order.DueAmount?.Amount>0)
					{
						if(paymentOptionMap?.PaymentMethod)
						{
						}
						else
						{
							nackErrorList.add(['ErrorCode':'nack524','Reference': ['Type':'PaymentOption','IdRef' :paymentOptionMap?.Id ]])
						}
					}
				}
			}
		}
	}

	public def nack527(def Order, def nackErrorList)
	{
		def groupList=Order?.Groups?.Group
		def losgCount=groupList?.size();
		def shippingInfoList=Order.ShippingInfos?.ShippingInfo
		if(shippingInfoList != null) {
			def shippingInfoCount=shippingInfoList.size();
			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(Order?.OrderSource?.Channel != "CRU-MOBILITY" && groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics)
				{
					def losg=groupMap?.GroupCharacteristics?.LoSGCharacteristics
					if(losg?.ProductCategory =="WIRELESS" && losg?.FulfillmentMethod == "DF")
					{
						for(def j=0;j<shippingInfoCount;j++)
						{
							def shippingInfoMap=shippingInfoList.get(j)
							if(shippingInfoMap?.Id == losg.ShippingInfoRef)
							{
								if(shippingInfoMap?.NameRef && shippingInfoMap?.AddressRef && shippingInfoMap?.ShippingCode && shippingInfoMap?.ShippingPriceCode && shippingInfoMap?.ShippingMethod)
								{
								}
								else
								{
									nackErrorList.add(['ErrorCode':'nack527','Reference': ['Type':'ShippingInfo','IdRef' :shippingInfoMap?.Id ]])
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack528(def Order, def nackErrorList)
	{
		def groupList=Order?.Groups?.Group
		def losgCount=groupList.size();
		def  OrderVal=Order?.IsPassThrough
		if(OrderVal)
		{
		}
		else
		{
			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics &&
				groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="WIRELESS")
				{
					def losgType=groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
					if((losgType =="NEW" || losgType == "AL" || losgType == "ALF" || losgType == "UP"|| losgType == "ACC"))
					{
						if(Order?.OrderType=="CREATE" && Order?.AgentCode!=null && Order?.AgentLocation!=null)
						{
						}
						else{
							nackErrorList.add(['ErrorCode':'nack528','Reference': ['Type':'ORDER','IdRef' :Order?.CustomerOrderNumber ]])
						}
					}
				}
			}
		}
	}

	public def nack529(def Order, def nackErrorList)
	{
		def groupList=Order?.Groups?.Group
		def losgCount=groupList.size();
		for(def i=0;i<losgCount;i++)
		{
			def groupMap=groupList.get(i)
			if(groupMap?.Type=="LINE_OF_SERVICE" && groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics &&
			groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="WIRELESS" && groupMap?.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod=="DF")
			{
				def losgType=groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
				if((losgType =="NEW" || losgType == "AL" || losgType == "ALF" || losgType == "UP" || losgType == "ACC") )
				{
					def	accountList=Order?.Accounts?.Account
					def accountCount=accountList.size();
					for(def j=0;j<accountCount;j++)
					{
						def accountMap=accountList.get(j)

						if((accountMap.Id==groupMap?.GroupCharacteristics?.LoSGCharacteristics?.AccountRef) && accountMap?.EnterpriseType=="CON")
						{
							if(Order?.DeliveryPromiseNoteEnglish || Order?.DeliveryPromiseNoteSpanish)
							{
							}
							else
							{
								nackErrorList.add(['ErrorCode':'nack529','Reference': ['Type':'ORDER','IdRef' :Order?.CustomerOrderNumber ]])
							}
						}
					}
				}
			}
		}
	}

	public def nack533(def Order, def nackErrorList)
	{
		def groupList=Order?.Groups?.Group
		def losgCount=groupList.size();
		def  OrderVal=Order?.IsPassThrough
		if(OrderVal)
		{
		}
		else
		{
			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if((Order?.OrderType=="CREATE")&& groupMap?.Type=="LINE_OF_SERVICE" && groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics &&
				groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="WIRELESS")
				{
					def losgType=groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
					if((losgType =="NEW" || losgType == "AL" || losgType == "ALF") && (groupMap?.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo!=null))
					{
						if(groupMap?.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo?.PortTelephoneNumber==null)
						{
							nackErrorList.add(['ErrorCode':'nack533','Reference':['Type':'LINE_OF_SERVICE','IdRef' :groupMap?.Id ]])
						}
					}
				}
			}
		}
	}

	public def nack534(def Order, def nackErrorList)
	{
		def OrderVal=Order?.IsPassThrough
		if(OrderVal)
		{
		}
		else
		{
			for(def losg in Order?.Groups?.Group)
			{
				if(losg?.GroupCharacteristics && losg?.GroupCharacteristics?.LoSGCharacteristics)
				{
					List<Integer> losgIdList=Order.Groups.Group.GroupCharacteristics?.LoSGCharacteristics?.LoSGReferenceId
					if((losg.GroupCharacteristics?.LoSGCharacteristics?.LoSGReferenceId && Collections.frequency(losgIdList, losg.GroupCharacteristics?.LoSGCharacteristics?.LoSGReferenceId) == 1))
					{
					}
					else
					{
						nackErrorList.add(['ErrorCode':'nack534','Reference': ['Type':'ORDER','IdRef' :Order.CustomerOrderNumber ]])
					}
				}
			}
		}
	}

	public def nack536(def Order, def nackErrorList)
	{
		def groupList=Order?.Groups?.Group
		def losgCount=groupList.size();
		for(def i=0;i<losgCount;i++)
		{
			def groupMap=groupList.get(i)
			if((Order?.OrderSource?.Channel=="CDE-HS" || Order?.OrderSource?.Channel=="SMB-WEB-CENTER") &&
			(groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory))
			{
				if(groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="INTERNET")
				{
					if(groupMap?.GroupCharacteristics?.LoSGCharacteristics?.InternetLOSChars?.IPDSLAIndicator!=null)
					{
					}
					else
					{
						nackErrorList.add(['ErrorCode':'nack536','Reference':['Type':'LINE_OF_SERVICE','IdRef' :groupMap.Id ]])
					}
				}
			}
		}
	}

	public def nack538(def Order, def nackErrorList)
	{
		def OrderVal=Order?.IsPassThrough
		if(OrderVal)
		{
		}
		else
		{
			for(def lineItem in Order?.LineItems?.LineItem)
			{
				List<Integer> lineIdList=Order?.LineItems?.LineItem?.Id
				if((lineItem?.Id && Collections.frequency(lineIdList, lineItem.Id) == 1))
				{
				}
				else
				{
					nackErrorList.add(['ErrorCode':'nack538','Reference': ['Type':'LineItem','IdRef' :Order.CustomerOrderNumber ]])
				}
			}
		}
	}

	public def nack540(def Order, def nackErrorList)
	{
		def groupList=Order?.Groups?.Group
		def losgCount=groupList.size();
		def	accountList=Order?.Accounts?.Account
		def accountCount=accountList.size();
		def OrderVal=Order?.IsPassThrough
		if(OrderVal)
		{
		}
		else
		{
			for(def i=0;i<losgCount;i++)
			{
				def groupMap = groupList.get(i)
				if((Order?.OrderSource?.Channel=="CRU-MOBILITY" || Order?.OrderSource?.Channel=="SMB-WEB-CENTER" ) &&
				groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics && (groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType!="UNLOCK"))
				{
					for(def j=0;j<accountCount;j++)
					{
						def accountMap = accountList.get(j)
						if(accountMap?.Id==groupMap?.GroupCharacteristics?.LoSGCharacteristics?.AccountRef)
						{
							if(accountMap?.BillingInfo)
							{
								if((accountMap?.BillingInfo[0]?.NameRef) || (Order?.PRCTicketNumber && losgType=="ACC"))
								{
								}
								else
								{
									nackErrorList.add(['ErrorCode':'nack540','Reference': ['Type':'ACCOUNT','IdRef' : accountMap?.Id]])
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack541(def Order, def nackErrorList)
	{
		def groupList=Order?.Groups?.Group
		def losgCount=groupList.size();
		def accountList=Order?.Accounts?.Account
		def accountCount=accountList.size();
		for(def i=0;i<losgCount;i++)
		{
			def groupMap = groupList.get(i)
			if(Order?.OrderSource?.Channel!="CRU-MOBILITY" && groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics && 
				(groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType=="NEW"))
			{
				for(def j=0;j<accountCount;j++)
				{
					def accountMap = accountList.get(j)
					if((accountMap?.Id==groupMap?.GroupCharacteristics?.LoSGCharacteristics?.AccountRef) && accountMap?.BillingInfo && 
						(accountMap.AccountCategory != "ADDON-SOLUTIONS_ACCOUNT") && accountMap.AccountSubCategory == "NEW")
					{
						if(Order?.OrderSource?.Channel == "SMB-WEB-CENTER" && (accountMap?.BillingInfo[0]?.Authentication?.DriversLicense) ||
						(accountMap?.BillingInfo[0]?.Authentication?.SSN) || accountMap?.BillingInfo[0]?.Authentication?.FederalTaxId)
						{
						}
						else if( (accountMap?.BillingInfo[0]?.Authentication?.DriversLicense) || (accountMap?.BillingInfo[0]?.Authentication?.SSN))
						{
						}
						else
						{
							nackErrorList.add(['ErrorCode':'nack541','Reference': ['Type':'ACCOUNT','IdRef' : accountMap?.Id]])
						}

					}
				}
			}
		}
	}

	public def nack542(def Order, def nackErrorList)
	{
		def	accountList=Order?.Accounts?.Account
		def accountCount=accountList.size();
		for(def j=0;j<accountCount;j++)
		{
			def accountMap = accountList.get(j)
			if(accountMap?.AccountSubCategory && accountMap?.AccountSubCategory == "NEW" && accountMap?.AccountCategory ==  "UVERSE_ACCOUNT" && accountMap?.BillingInfo)
			{
				if(accountMap?.BillingInfo[0]?.Authentication)
				{
					if(accountMap?.BillingInfo[0]?.Authentication?.SecurityVerification)
					{
					}
					else
					{
						nackErrorList.add(['ErrorCode':'nack542','Reference': ['Type':'Account','IdRef' : accountMap?.Id]])
					}
				}
			}
		}
	}

	public def nack545(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel=="CDE-HS" || Order?.OrderSource?.Channel=="EDE-EG" || Order?.OrderSource?.Channel=="SMB-WEB-CENTER")
		{
			if(Order?.SalesCode || Order?.SalesLocation)
			{
			}
			else
			{
				nackErrorList.add(['ErrorCode':'nack545','Reference':['Type':'ORDER','IdRef' :Order?.CustomerOrderNumber ]])
			}
		}
	}

	public def nack546(def Order, def nackErrorList)
	{
		String nameRef;

		if(Order?.OrderContact)
			nameRef = Order?.OrderContact?.NameRef

		def nameList=Order?.Names?.Name
		//		def nameCount=nameList.size();
		for(def i=0;nameList!= null && i<nameList.size();i++)
		{
			def nameMap=nameList.get(i)
			if(nameMap?.Id==nameRef)
			{
				if(nameMap?.PrimaryContactPhone || (Order?.OrderSource?.Channel=="UNLOCK") || (Order?.IsPassThrough==true))
				{
				}
				else
				{
					nackErrorList.add(['ErrorCode':'nack546','Reference':['Type':'ORDER','IdRef' :nameRef ]])
				}
			}
		}
	}


	public def nack550(def Order, def nackErrorList)
	{
		def accountList=Order?.Accounts?.Account
		def accountCount=accountList.size();
		for(def i=0;i<accountCount;i++)
		{
			def accountMap=accountList.get(i)
			if(accountMap?.AccountSubCategory=="EXISTING" && Order?.OrderSource?.Channel!="CRU-MOBILITY")
			{
				if(accountMap?.BillingAccountNumber)
				{
				}
				else
				{
					nackErrorList.add(['ErrorCode':'nack550','Reference':['Type':'ACCOUNT','IdRef' :accountMap?.Id  ]])
				}
			}
		}
	}

	public def nack551(def Order, def nackErrorList)
	{
		def groupList=Order.Groups.Group
		def losgCount=groupList.size();
		def accountList=Order.Accounts.Account
		def accountCount=accountList.size();
		for(def i=0;i<losgCount;i++)
		{
			def groupMap = groupList.get(i)
			if((Order.OrderSource.Channel=="CDE-HS" || Order.OrderSource.Channel=="EDE-EG" || Order.OrderSource.Channel=="SMB-WEB-CENTER") && groupMap.Type=="LINE_OF_SERVICE")
			{
				if(groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics)
				{
					def productCategory = groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory
					def losgType = groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType
					def accountRef = groupMap.GroupCharacteristics.LoSGCharacteristics.AccountRef
					if(losgType=="NEW" && (productCategory=="INTERNET" || productCategory=="IPTV" || productCategory=="VOIP"))
					{
						for(def j=0;j<accountCount;j++)
						{
							def accountMap=accountList.get(j)
							if(accountMap?.Id==accountRef && accountMap?.AccountCategory &&
							(accountMap?.AccountCategory=="UVERSE_ACCOUNT" || accountMap?.AccountCategory=="ADDON-SOLUTIONS_ACCOUNT" || accountMap?.AccountCategory=="WIRELINE_ACCOUNT"))
							{
								if(accountMap?.BillingDeliveryPreference)
								{
								}
								else
								{
									nackErrorList.add(['ErrorCode':'nack551','Reference':['Type':'Account','IdRef' :accountMap?.Id  ]])
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack570(def Order, def nackErrorList)
	{
		def	groupList=Order?.Groups?.Group
		def losgCount=groupList.size();
		for(def i=0;i<losgCount;i++)
		{
			def groupMap =groupList.get(i)
			def channel=Order?.OrderSource?.Channel
			if((channel=="CDE-HS"||channel=="EDE-EG"||channel=="DE-MOBILITY"||channel=="CRU-MOBILITY"||channel=="SMB-WEB-CENTER") &&
			groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod)
			{
				def	lineItemList=Order?.LineItems?.LineItem
				def lineItemCount=lineItemList.size();
				for(def j=0;j<lineItemCount;j++)
				{
					def lineItemMap =lineItemList.get(j)
					if(lineItemMap?.Price || Order?.IsPassThrough==true)
					{
						if(!(lineItemMap?.Price?.Amount==null))
						{
						}
						else
						{
							nackErrorList.add(['ErrorCode':'nack570','Reference': ['Type':'LINEITEM','IdRef' : lineItemMap?.Id]])
						}
					}
				}
			}
		}
	}

	public def nack571(def Order, def nackErrorList)
	{
		def	lineItemList=Order?.LineItems?.LineItem
		def lineItemCount=lineItemList.size();
		for(def i=0;i<lineItemCount;i++)
		{
			def lineItemMap =lineItemList.get(i)
			if(Order?.OrderSource?.Channel=="CDE-HS"||Order?.OrderSource?.Channel=="EDE-EG"||Order?.OrderSource?.Channel=="SMB-WEB-CENTER")
			{
				if(Order?.Promotions && Order.Promotions?.Promotion)
				{
					def	promoList=Order?.Promotions?.Promotion
					if(promoList != null) {
						def promoCount=promoList.size();
						for(def j=0;j<promoCount;j++)
						{
							def promoMap=promoList.get(j)
							if(promoMap?.Id==lineItemMap.PromotionRefs?.PromotionRef?.get(0))
							{
								if(promoMap?.PromotionType && promoMap.PromotionCycle && promoMap?.UnitOfMeasurement)
								{
								}
								else
								{
									nackErrorList.add(['ErrorCode':'nack571','Reference': ['Type':'PROMOTION','IdRef' : promoMap?.Id]])
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack585(def Order, def nackErrorList)
	{
		def	groupList=Order?.Groups?.Group
		def losgCount=groupList.size();
		def	accountList=Order?.Accounts?.Account
		def accountCount=accountList.size();
		List<String> Channels = new ArrayList<String>();
		Channels.add("CDE-HS");
		Channels.add("DE-MOBILITY");
		Channels.add("CRU-MOBILITY");
		Channels.add("SMB-WEB-CENTER");

		for(def i=0;i<losgCount;i++)
		{
			def groupMap =groupList.get(i)
			if(groupMap?.Type=="LINE_OF_SERVICE" && groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics &&
			groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="WIRELESS")
			{
				if(Channels.contains(Order?.OrderSource?.Channel) && groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType != "UNLOCK")
				{
					for(def j=0;j<accountCount;j++)
					{
						def accountMap =accountList.get(j)
						if((accountMap?.Id==groupMap?.GroupCharacteristics?.LoSGCharacteristics?.AccountRef) && accountMap?.BillingInfo)
						{
							if((accountMap?.BillingInfo[0]?.AddressRef) || (Order?.IsPassThrough==true))
							{
							}
							else
							{
								nackErrorList.add(['ErrorCode':'nack585','Reference': ['Type':'ACCOUNT','IdRef' : accountMap?.Id]])
							}
						}
					}
				}
			}
		}
	}

	public def nack586(def Order, def nackErrorList)
	{
		def	groupList=Order?.Groups?.Group
		def losgCount=groupList.size();
		List<String> Channels = new ArrayList<String>();
		Channels.add("CDE-HS");
		Channels.add("EDE-EG");
		Channels.add("SMB-WEB-CENTER");

		for(def i=0;i<losgCount;i++)
		{
			def groupMap =groupList.get(i)
			if(Channels.contains(Order?.OrderSource?.Channel) && groupMap?.Type == "PACKAGE")
			{
				if(groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.PackageCharacteristics)
				{
				}
				else
				{
					nackErrorList.add(['ErrorCode':'nack586','Reference': ['Type':'PACKAGE_GROUP','IdRef' : groupMap?.Id]])
				}
			}
		}
	}

	public def nack587(def Order, def nackErrorList)
	{
		def	groupList=Order?.Groups?.Group
		def losgCount=groupList.size();

		for(def i=0;i<losgCount;i++)
		{
			def groupMap =groupList.get(i)
			if(groupMap?.Type=="LINE_OF_SERVICE" && groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics &&
			(Order?.OrderSource?.Channel == "CDE-HS" || Order?.OrderSource?.Channel == "SMB-WEB-CENTER"))
			{
				def productCategory = groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
				def losgType = groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
				if( (productCategory=="INTERNET" || productCategory=="IPTV" || productCategory=="VOIP" || productCategory=="DIRECTV" || productCategory=="POTS" || productCategory=="DSL")
				&& (losgType == "CHANGE" || losgType == "NO_CHANGE"))
				{
					if(groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ServiceLocationRef)
					{
					}
					else
					{
						nackErrorList.add(['ErrorCode':'nack587','Reference': ['Type':'LINE_OF_SERVICE','IdRef' : groupMap?.Id]])
					}
				}
			}
		}
	}

	public def nack627(def Order, def nackErrorList)
	{
		String nameRef;

		if(Order?.OrderContact)
			nameRef = Order?.OrderContact?.NameRef

		def	groupList=Order?.Groups?.Group
		def losgCount=groupList.size();
		def	accountList=Order?.Accounts?.Account
		def accountCount=accountList.size();

		for(def i=0;i<losgCount;i++)
		{
			def groupMap =groupList.get(i)
			if((Order?.OrderSource?.Channel=="DE-MOBILITY" || Order?.OrderSource?.Channel=="CDE-HS" || Order?.OrderSource?.Channel=="SMB-WEB-CENTER") &&
			groupMap?.Type=="LINE_OF_SERVICE" && groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics)
			{
				def productCategory=groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
				if((productCategory=="WIRELESS" || productCategory=="INTERNET" || productCategory=="VOIP" || productCategory=="IPTV") &&
				groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType=="NEW")
				{
					for(def j=0;j<accountCount;j++)
					{
						def accountMap=accountList.get(j)
						if( (accountMap?.Id==groupMap?.GroupCharacteristics?.LoSGCharacteristics?.AccountRef) &&
						accountMap?.AccountCategory && (accountMap?.AccountCategory=="UVERSE_ACCOUNT" || accountMap?.AccountCategory=="MOBILITY_ACCOUNT" || accountMap?.AccountCategory=="ADDON-SOLUTIONS_ACCOUNT" || accountMap?.AccountCategory=="WIRELINE_ACCOUNT")
						&& accountMap?.AccountSubCategory=="NEW")
						{
							def nameList=Order?.Names?.Name
							def nameCount=nameList.size();
							for(def k=0;k<nameCount;k++)
							{
								def nameMap = nameList.get(k)
								if((nameMap.Id==nameRef))
								{
									if(nameMap?.PrimaryContactPhone  && nameMap?.PrimaryContactPhone?.ConsentDetails && nameMap?.PrimaryContactPhone?.ConsentDetails?.ConsentDetail[0])
									{
										def consentDetail=nameMap?.PrimaryContactPhone?.ConsentDetails?.ConsentDetail[0]
										if(!(consentDetail?.ConsentType.get(0)==null) && !(consentDetail?.ConsentCategory.get(0)==null) && !(consentDetail?.ConsentSelection.get(0)==null))
										{
										}
										else
										{
											nackErrorList.add(['ErrorCode':'nack627','Reference':['Type':'NAME','IdRef' :nameMap.Id  ]])
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack628(def Order, def nackErrorList)
	{
		String nameRef;

		if(Order?.OrderContact)
			nameRef = Order?.OrderContact?.NameRef

		def	groupList=Order?.Groups?.Group
		def losgCount=groupList.size();
		def	accountList=Order?.Accounts?.Account
		def accountCount=accountList.size();

		for(def i=0;i<losgCount;i++)
		{
			def groupMap =groupList.get(i)
			if((Order?.OrderSource?.Channel=="DE-MOBILITY" || Order?.OrderSource?.Channel=="CDE-HS" || Order?.OrderSource?.Channel=="SMB-WEB-CENTER")
			&& groupMap?.Type=="LINE_OF_SERVICE" && groupMap?.GroupCharacteristics?.LoSGCharacteristics )
			{
				def productCategory=groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
				if((productCategory=="WIRELESS" || productCategory=="INTERNET" || productCategory=="VOIP" || productCategory=="IPTV") &&
				groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType=="NEW")
				{
					for(def j=0;j<accountCount;j++)
					{
						def accountMap=accountList.get(j)
						if( (accountMap?.Id==groupMap?.GroupCharacteristics?.LoSGCharacteristics?.AccountRef) &&
						accountMap?.AccountCategory && (accountMap?.AccountCategory=="UVERSE_ACCOUNT" || accountMap?.AccountCategory=="MOBILITY_ACCOUNT" || accountMap?.AccountCategory=="ADDON-SOLUTIONS_ACCOUNT" || accountMap?.AccountCategory=="WIRELINE_ACCOUNT")
						&& accountMap?.AccountSubCategory=="NEW")
						{
							def nameList=Order?.Names?.Name
							def nameCount=nameList.size();
							for(def k=0;k<nameCount;k++)
							{
								def nameMap = nameList.get(k)
								def addContactPhone = nameMap?.AdditionalContactPhone

								if((nameMap?.Id==nameRef) && nameMap?.AdditionalContactPhone )
								{
									if(nameMap?.AdditionalContactPhone?.ConsentDetails && nameMap?.AdditionalContactPhone?.ConsentDetails?.ConsentDetail[0])
									{
										def consentDetail = nameMap?.AdditionalContactPhone?.ConsentDetails?.ConsentDetail[0]
										if(!(consentDetail?.ConsentType.get(0)==null) && !(consentDetail?.ConsentCategory.get(0)==null) && !(consentDetail?.ConsentSelection.get(0)==null))
										{
										}
										else
										{
											nackErrorList.add(['ErrorCode':'nack628','Reference':['Type':'NAME','IdRef' :nameMap?.Id  ]])
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	/* NON-SMB */

	public def nack504(def Order, def nackErrorList)
	{
		def groupList = null
		def channel = Order.OrderSource.Channel
		groupList=Order.Groups.Group
		def losgCount=groupList.size();

		for(def i=0;i<losgCount;i++){
			def groupMap=groupList.get(i)
			if(groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics)
			{
				if((groupMap.GroupCharacteristics.LoSGCharacteristics?.LoSGType =="NEW"||
				groupMap.GroupCharacteristics.LoSGCharacteristics?.LoSGType == "AL" ||
				groupMap.GroupCharacteristics.LoSGCharacteristics?.LoSGType == "ALF")
				&& (groupMap.GroupCharacteristics.LoSGCharacteristics?.NumberPortInfo == null)
				&& ((channel=="CDE-HS" || channel=="UNLOCK" || channel=="DE-MOBILITY") ||
				(channel=="CRU-MOBILITY"  && (Order.PRCTicketNumber == null)))) {

					if(groupMap.GroupCharacteristics.LoSGCharacteristics?.FulfillmentMethod=="DF" ||
					groupMap.GroupCharacteristics.LoSGCharacteristics?.FulfillmentMethod=="C2S") {

						if(!(groupMap.GroupCharacteristics.LoSGCharacteristics?.IsPrimary != null &&
						groupMap.GroupCharacteristics.LoSGCharacteristics?.DealerCode != null &&
						groupMap.GroupCharacteristics.LoSGCharacteristics?.Market != null &&
						groupMap.GroupCharacteristics.LoSGCharacteristics?.SubMarket != null  &&
						groupMap.GroupCharacteristics.LoSGCharacteristics?.ServiceArea != null  &&
						groupMap.GroupCharacteristics.LoSGCharacteristics?.PriceCode != null) )
						{
							nackErrorList.add(['ErrorCode':'nack504','Reference': ['Type':'LINE_OF_SERVICE','IdRef' : groupMap?.Id]])
						}
					}
				}
			}
		}
	}

	public def nack509(def Order, def nackErrorList)
	{

		def groupList=Order.Groups.Group
		def losgCount=groupList.size();
		def channel = Order.OrderSource.Channel

		for(def i=0;i<losgCount;i++)
		{
			def groupMap=groupList.get(i)
			if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
			groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS" &&
			(groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF" || groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="C2S") &&
			(channel=="CDE-HS" || channel=="UNLOCK" || channel=="DE-MOBILITY" || channel=="CRU-MOBILITY") )
			{
				if((groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="NEW" || groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="AL" ||
				groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="ALF" || groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="UP") &&
				(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo) )
				{
					if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo.Relationship!="DONOR")
					{
						def accountlist=Order.Accounts.Account
						def accountCount=accountlist.size();

						for(def j=0;j<accountCount;j++)
						{
							def accountMap=accountlist.get(j)
							if(accountMap.Id==groupMap.GroupCharacteristics.LoSGCharacteristics.AccountRef && accountMap.PaymentArrangement=="POSTPAID" && accountMap.EnterpriseType=="CON")
							{
								def lineItemlist=Order.LineItems.LineItem
								def lineItemCount=lineItemlist.size();

								for(def k=0;k<lineItemCount;k++)
								{
									def lineItemMap=lineItemlist.get(k)
									if(lineItemMap.ProductType && lineItemMap.ProductType=="HARDGOOD" && lineItemMap.HardGood.HardGoodType=="DEVICE")
									{
										if((lineItemMap.ContractDetails.ContractType=="LEASE" || lineItemMap.ContractDetails.ContractType=="INSTALLMENT") )
										{
											if(lineItemMap.ContractDetails.ContractLength!=null &&
											lineItemMap.ContractDetails.TotalSalePrice!=null &&
											lineItemMap.ContractDetails.ContractType!=null &&
											lineItemMap.ContractDetails.InstallmentPlanDef!=null &&
											lineItemMap.ContractDetails.ContractDisplayName!=null &&
											lineItemMap.ContractDetails.AnnualPercentageRate!=null &&
											lineItemMap.ContractDetails.FinanceCharge!=null &&
											lineItemMap.ContractDetails.DownPayment!=null &&
											lineItemMap.ContractDetails.PrepaidFinanceCharge!=null &&
											lineItemMap.ContractDetails.InstallmentAmount!=null)
											{
											}
											else
											{
												nackErrorList.add(['ErrorCode':'nack509','Reference': ['Type':'LineItem','IdRef' :lineItemMap.Id ]])
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack510(def Order, def nackErrorList)
	{

		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS")
					if(groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="UP" && groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF")
				{
					def lineItemlist=Order.LineItems.LineItem
					def lineItemCount=lineItemlist.size();

					for(def j=0;j<lineItemCount;j++)
					{
						def lineItemMap=lineItemlist.get(j)
						if(lineItemMap.Characteristics && lineItemMap.Characteristics.WirelessLineItemChars && lineItemMap.Characteristics.WirelessLineItemChars.TradeInInfo)
						{
							if(lineItemMap.Characteristics.WirelessLineItemChars.TradeInInfo.ClaimId && lineItemMap.Characteristics.WirelessLineItemChars.TradeInInfo.ExchangeType)
							{
							}
							else
							{
								nackErrorList.add(['ErrorCode':'nack510','Reference': ['Type':'LineItem','IdRef' :lineItemMap.Id ]])
							}
						}
					}
				}
			}
		}
	}

	public def nack512(def Order, def nackErrorList)
	{
		List<String> Channels = new ArrayList<String>();
		Channels.add("CDE-HS");
		Channels.add("DE-MOBILITY");
		Channels.add("EDE-EG");
		Channels.add("CRU-MOBILITY");

		def groupList=Order.Groups.Group
		def losgCount=groupList.size();

		for(def i=0;i<losgCount;i++)
		{
			def groupMap=groupList.get(i)
			if(groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics && Channels.contains(Order.OrderSource.Channel))
			{
				def lineItemList=Order.LineItems.LineItem
				def lineItemCount=lineItemList.size();

				for(def j=0;j<lineItemCount;j++)
				{
					def lineItemMap=lineItemList.get(j)
					if(lineItemMap.ProductType && lineItemMap.ProductType == "HARDGOOD")
					{
						def accountList=Order.Accounts.Account
						def paymentArrangement=accountList.PaymentArrangement
						def accountCount=accountList.size();
						if(paymentArrangement)
						{ }
						else{
							nackErrorList.add(['ErrorCode':'nack512','Reference': ['Type':'LineItem','IdRef' :lineItemMap?.Id ]])
						}
					}
				}
			}
		}
	}

	public def nack515(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS")
				{
					if(groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="ACTIVATION")
					{
						def LineItemlist=Order.LineItems.LineItem
						def LineItemCount=LineItemlist.size();

						for(def j=0;j<LineItemCount;j++)
						{
							def lineItem=LineItemlist.get(j)
							if((lineItem.HardGood != null) && (lineItem.HardGood.HardGoodType=="ICCID" ||lineItem.HardGood.HardGoodType=="CSN" ))
							{
							}
							else
							{
								nackErrorList.add(['ErrorCode':'nack515','Reference': ['Type':'LineItem','IdRef' :LineItemlist?.Id ]])
								break;
							}
						}

					}
				}
			}
		}
	}

	public def nack517(def Order, def nackErrorList)
	{
		def  OrderVal=Order.IsPassThrough
		if(OrderVal)
		{
		}
		else
		{
			if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
			{
				def LineItemlist=Order.LineItems.LineItem
				def LineCount=LineItemlist.size();

				for(def i=0;i<LineCount;i++)
				{
					def LineMap=LineItemlist.get(i)
					if((LineMap.HardGood != null)&&(LineMap.HardGood.BYOD))
					{
						if(LineMap.HardGood.WirelessHardGoodChars.Imei== null)
						{
							nackErrorList.add(['ErrorCode':'nack517','Reference': ['Type':'LineItem','IdRef' :LineMap?.Id ]])
						}
						else
						{
						}

					}
				}
			}
		}
	}

	public def nack518(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics && (groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS"))
				{
					if((groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="NEW" || groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="AL" || groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="ALF"
					|| groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="UP" || groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="ACC") &&
					groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF")
					{
						def shippingInfoList=Order.ShippingInfos?.ShippingInfo
						if(shippingInfoList != null) {
							def shippingInfoCount=shippingInfoList.size();

							for(def j=0;j<shippingInfoCount;j++)
							{
								def shippingInfoMap=shippingInfoList.get(j)
								if(shippingInfoMap.Id==groupMap.GroupCharacteristics.LoSGCharacteristics.ShippingInfoRef)
								{
								}
								else
								{
									nackErrorList.add(['ErrorCode':'nack518','Reference': ['Type':'LINE_OF_SERVICE','IdRef' :groupMap?.Id ]])
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack519(def Order, def nackErrorList)
	{
		if(Order?.IsPassThrough == true)
		{
		}
		else
		{
			List<String> Channels = new ArrayList<String>();
			Channels.add("CDE-HS");
			Channels.add("DE-MOBILITY");
			Channels.add("EDE-EG");
			def unlockGroup
			def value
			def groupList=Order?.Groups?.Group
			def priContactPhone = Order?.Names?.Name?.PrimaryContactPhone
			def nameList=Order?.Names?.Name
			for(def i=0;i<groupList.size();i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType=="UNLOCK")
				{
					unlockGroup = groupMap
				}
				break;
			}
			if( (priContactPhone!=null) || (unlockGroup!=null)){
				value = true
			}
			for(def j=0;j<nameList.size();j++)
			{
				def nameMap=nameList.get(j)
				if(Channels.contains(Order?.OrderSource?.Channel))
				{
					if((nameMap?.FirstName!=null) && (nameMap?.LastName!=null) && (value==true))
					{
					}
					else
					{
						nackErrorList.add(['ErrorCode':'nack519','Reference': ['Type':'ORDER','IdRef' :Order.CustomerOrderNumber ]])
					}
				}
			}
		}
	}

	public def nack520(def Order, def nackErrorList)
	{
		def	AddressList=Order.Addresses.Address
		//		def losgCount=AddressList.size();
		for(def i=0;AddressList != null && i<AddressList.size();i++)
		{
			def AddressMap =AddressList.get(i)
			def channel = Order.OrderSource.Channel
			if(channel=="CDE-HS" || channel=="DE-MOBILITY" || channel=="EDE-EG" )
			{
				if(AddressMap.UnparsedAddress!=null)
				{
				}
				else
				{
					nackErrorList.add(['ErrorCode':'nack520','Reference': ['Type':'ADDRESS','IdRef' : AddressMap?.Id]])
				}
			}
		}
	}

	public def nack532(def Order, def nackErrorList)
	{
		def	groupList=Order.Groups.Group
		def losgCount=groupList.size();
		def  OrderVal=Order.IsPassThrough
		if(OrderVal)
		{

		}
		else
		{
			if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
			{
				for(def i=0;i<losgCount;i++)
				{
					def groupMap=groupList.get(i)
					if((Order.OrderType=="CREATE")&& groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
					groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS")
					{
						if(groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType == "UP")
						{
							if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.MobileNumber!=null)
							{
							}
							else
							{
								nackErrorList.add(['ErrorCode':'nack532','Reference':['Type':'LINE_OF_SERVICE','IdRef' :groupMap.Id ]])
							}
						}
					}
				}
			}
		}
	}

	public def nack535(def Order, def nackErrorList)
	{
		def	groupList=Order.Groups.Group
		def losgCount=groupList.size();
		def	accountList=Order.Accounts.Account
		def accountCount=accountList.size();
		def OrderVal=Order.IsPassThrough
		if(OrderVal)
		{
		}
		else
		{
			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics )
				{
					if(Order.OrderSource.Channel=="SMB-WEB-CENTER" && groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="ADDON-SOLUTIONS")
					{
					}
					else if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="NEW")
					{
						for(def j=0;j<accountCount;j++)
						{
							def accountMap=accountList.get(j)
							if((accountMap.Id==groupMap.GroupCharacteristics.LoSGCharacteristics.AccountRef) && accountMap.PaymentArrangement=="POSTPAID")
							{
								if(groupMap.GroupCharacteristics.LoSGCharacteristics.ServiceLocationRef)
								{
								}
								else
								{
									nackErrorList.add(['ErrorCode':'nack535','Reference': ['Type':'LoSGGroup','IdRef' :groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGReferenceId ]])
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack543(def Order, def nackErrorList)
	{
		if(Order.OrderSource.Channel!="CRU-MOBILITY" && Order.OrderSource.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();
			def	accountList=Order.Accounts.Account
			def accountCount=accountList.size();
			for(def i=0;i<losgCount;i++)
			{
				def groupMap = groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics && (groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="NEW"))
				{
					for(def j=0;j<accountCount;j++)
					{
						def accountMap = accountList.get(j)
						if((accountMap.Id==groupMap.GroupCharacteristics.LoSGCharacteristics.AccountRef) &&
						(accountMap.PaymentArrangement=="POSTPAID") && (accountMap.AccountSubCategory=="NEW") && accountMap.BillingInfo)
						{
							if(accountMap.BillingInfo[0].Authentication)
							{
								if(accountMap.BillingInfo[0].Authentication.DOB)
								{
								}
								else
								{
									nackErrorList.add(['ErrorCode':'nack543','Reference': ['Type':'ACCOUNT','IdRef' : accountMap.Id]])
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack544(def Order, def nackErrorList)
	{
		def groupList=Order.Groups.Group
		def losgCount=groupList.size();
		for(def i=0;i<losgCount;i++)
		{
			def groupMap = groupList.get(i)
			if((Order.OrderSource.Channel=="EDE-EG") && groupMap.Type=="LINE_OF_SERVICE" &&
			groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
			(groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="DIRECTV" && groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="NEW"))
			{
				if(groupMap.GroupCharacteristics.LoSGCharacteristics.SchedulingInfoRef)
				{
				}
				else
				{
					nackErrorList.add(['ErrorCode':'nack544','Reference': ['Type':'LINE_OF_SERVICE','IdRef' : groupMap?.Id]])
				}
			}
		}
	}

	public def nack555(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				(groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS") && (groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF"))
				{
					if((groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="UP") &&
					(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo))
					{
						if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.IsCrossUpgrade==true && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo.Relationship=="DONOR")
						{
							def lineItemlist=Order.LineItems.LineItem
							def lineItemCount=lineItemlist.size();
							def simLineItem  = lineItemlist.findAll {a -> a.ProductType=="HARDGOOD" && a.HardGood && a.HardGood.HardGoodType=="SIM"}
							if(simLineItem)
							{
								for(def j=0;j<lineItemCount;j++)
								{
									def lineItemMap=lineItemlist.get(j)
									if(lineItemMap.ProductType && lineItemMap.ProductType=="HARDGOOD")
									{
										if(lineItemMap.HardGood.HardGoodType && lineItemMap.HardGood.HardGoodType=="DEVICE")
										{
											if(!(lineItemMap.HardGood.WirelessHardGoodChars.Imei==null))
											{
											}
											else
											{
												nackErrorList.add(['ErrorCode':'nack555','Reference': ['Type':'LINEITEM','IdRef' :lineItemMap.Id ]])
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack556(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				(groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS"))
				{
					if((groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="UP") &&
					groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo)
					{
						if((groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo.Relationship=="DONOR" && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.IsCrossUpgrade==false))
						{
							def lineItemlist=Order.LineItems.LineItem
							def simLineItem  = lineItemlist.findAll {a -> a.ProductType=="HARDGOOD" && a.HardGood && a.HardGood.HardGoodType=="SIM"}
							def collateralLineItem  = lineItemlist.findAll {a -> a.ProductType=="HARDGOOD" && a.HardGood && a.HardGood.HardGoodType=="COLLATERAL"}

							if(simLineItem && collateralLineItem)
							{
							}
							else
							{
								nackErrorList.add(['ErrorCode':'nack556','Reference': ['Type':'GROUP','IdRef' :groupMap.Id ]])
							}
						}
					}
				}
			}
		}
	}

	public def nack557(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				(groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS") && (groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF"))
				{
					if((groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="UP") &&
					groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo)
					{
						if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo.Relationship=="RECIPIENT" && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.IsCrossUpgrade==true)
						{
							def lineItemlist=Order.LineItems.LineItem
							def simLineItem  = lineItemlist.findAll {a -> a.ProductType=="HARDGOOD" && a.HardGood && a.HardGood.HardGoodType=="SIM"}
							def collateralLineItem  = lineItemlist.findAll {a -> a.ProductType=="HARDGOOD" && a.HardGood && a.HardGood.HardGoodType=="COLLATERAL"}

							if(simLineItem && collateralLineItem)
							{
							}
							else
							{
								nackErrorList.add(['ErrorCode':'nack557','Reference': ['Type':'GROUP','IdRef' :groupMap.Id ]])
							}
						}
					}
				}
			}
		}
	}

	public def nack558(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars)
				{
					if(groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS" && groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF" &&
					groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="UP")
					{
						def relationship = groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo.find{ it.key == "Relationship" }?.value
						if(relationship==null)
						{
							def lineItemlist=Order.LineItems.LineItem
							def lineItemCount=lineItemlist.size();

							for(def j=0;j<lineItemCount;j++)
							{
								def lineItemMap=lineItemlist.get(j)
								if(lineItemMap.ContractDetails && lineItemMap.ContractDetails.ContractType && (lineItemMap.ContractDetails.ContractType!="NOCOMMIT"))
								{
									if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeQualificationInfo)
									{
										def upgradeQualificationInfo = groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeQualificationInfo[0]
										if(!(upgradeQualificationInfo.OfferCategory==null) && !(upgradeQualificationInfo.QualificationLevel==null) && !(upgradeQualificationInfo.QualificationType==null) &&
										!(upgradeQualificationInfo.QualificationMessage==null) && !(upgradeQualificationInfo.PolicyCategory==null) && !(upgradeQualificationInfo.DeviceType==null) &&
										!(upgradeQualificationInfo.IsUpgradeFeeWaived==null) && !(upgradeQualificationInfo.DiscountUOM==null) && !(upgradeQualificationInfo.PriceList==null) &&
										!(upgradeQualificationInfo.MinimumCommitment==null) && !(upgradeQualificationInfo.MinimumMRC==null) && !(upgradeQualificationInfo.MaximumMRC==null) &&
										!(upgradeQualificationInfo.ContractExtended==null) && !(upgradeQualificationInfo.ApprovalNumber==null) )
										{
										}
										else
										{
											nackErrorList.add(['ErrorCode':'nack558','Reference': ['Type':'LINE_OF_SERVICE','IdRef' :groupMap.Id ]])
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack559(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS" &&
				(groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF") && groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="UP")
				{
					if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo)
					{
						if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.IsCrossUpgrade==true && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo.Relationship=="RECIPIENT")
						{
							def lineItemlist=Order.LineItems.LineItem
							def lineItemCount=lineItemlist.size();

							for(def j=0;j<lineItemCount;j++)
							{
								def lineItemMap=lineItemlist.get(j)
								if(lineItemMap.ContractDetails && lineItemMap.ContractDetails.ContractType)
								{
									if(!(lineItemMap.ContractDetails.ContractType=="NOCOMMIT"))
									{
										if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeQualificationInfo)
										{
										}
										else
										{
											nackErrorList.add(['ErrorCode':'nack559','Reference': ['Type':'LINE_OF_SERVICE','IdRef' :groupMap.Id ]])
										}
									}
								}

							}
						}
					}
				}
			}
		}
	}

	public def nack561(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS" && (groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF")
				&& groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="UP")
				{
					if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo)
					{
						if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.IsCrossUpgrade==true && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo.Relationship=="RECIPIENT")
						{
							def lineItemlist=Order.LineItems.LineItem
							def lineItemCount=lineItemlist.size();

							for(def j=0;j<lineItemCount;j++)
							{
								def lineItemMap=lineItemlist.get(j)
								if(lineItemMap.ContractDetails && lineItemMap.ContractDetails.ContractType)
								{
									if(!(lineItemMap.ContractDetails.ContractType=="NOCOMMIT"))
									{
										if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeQualificationInfo &&
										!(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeQualificationInfo[0].ContractExtended==null))
										{
										}
										else
										{
											nackErrorList.add(['ErrorCode':'nack561','Reference': ['Type':'LINE_OF_SERVICE','IdRef' :groupMap.Id ]])
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack562(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS" &&
				(groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF") && groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="UP")
				{
					def lineItemlist=Order.LineItems.LineItem
					def lineItemCount=lineItemlist.size();

					for(def j=0;j<lineItemCount;j++)
					{
						def lineItemMap=lineItemlist.get(j)
						if(lineItemMap.Characteristics && lineItemMap.Characteristics.WirelessLineItemChars && lineItemMap.Characteristics.WirelessLineItemChars.TradeInInfo)
						{
							if(!(lineItemMap.HardGood.WirelessHardGoodChars.Imei==null))
							{
							}
							else
							{
								nackErrorList.add(['ErrorCode':'nack562','Reference': ['Type':'LINEITEM','IdRef' :lineItemMap.Id ]])
							}
						}
					}
				}
			}
		}
	}

	public def nack563(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS" &&
				(groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF") && groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="UP")
				{
					def lineItemlist=Order.LineItems.LineItem
					def lineItemCount=lineItemlist.size();

					for(def j=0;j<lineItemCount;j++)
					{
						def lineItemMap=lineItemlist.get(j)
						if(lineItemMap.Characteristics && lineItemMap.Characteristics.WirelessLineItemChars && lineItemMap.Characteristics.WirelessLineItemChars.TradeInInfo)
						{
							if(!(lineItemMap.ProductSku==null))
							{
							}
							else
							{
								nackErrorList.add(['ErrorCode':'nack563','Reference': ['Type':'LINEITEM','IdRef' :lineItemMap.Id ]])
							}
						}
					}
				}
			}
		}
	}

	public def nack564(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS" &&
				(groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF") && groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="UP")
				{
					def lineItemlist=Order.LineItems.LineItem
					def lineItemCount=lineItemlist.size();

					for(def j=0;j<lineItemCount;j++)
					{
						def lineItemMap=lineItemlist.get(j)
						if(lineItemMap.Characteristics && lineItemMap.Characteristics.WirelessLineItemChars && lineItemMap.Characteristics.WirelessLineItemChars.TradeInInfo)
						{
							if(!(lineItemMap.Characteristics.WirelessLineItemChars.TradeInInfo.NonComplianceFee==null))
							{
							}
							else
							{
								nackErrorList.add(['ErrorCode':'nack564','Reference': ['Type':'LINEITEM','IdRef' :lineItemMap.Id ]])
							}
						}
					}
				}
			}
		}
	}

	public def nack565(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS" &&
				(groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF") && groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="UP")
				{
					if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.IsCrossUpgrade==false)
					{
						if(groupMap.GroupCharacteristics.LoSGCharacteristics.DealerCode &&
						groupMap.GroupCharacteristics.LoSGCharacteristics.Market &&
						groupMap.GroupCharacteristics.LoSGCharacteristics.SubMarket &&
						groupMap.GroupCharacteristics.LoSGCharacteristics.PriceCode )
						{
						}
						else
						{
							nackErrorList.add(['ErrorCode':'nack565','Reference': ['Type':'LINE_OF_SERVICE','IdRef' :groupMap.Id ]])
						}
					}
				}
			}
		}
	}

	public def nack569(def Order, def nackErrorList)
	{

		def groupList=Order.Groups.Group
		def losgCount=groupList.size();
		def channel = Order.OrderSource.Channel

		for(def i=0;i<losgCount;i++)
		{
			def groupMap=groupList.get(i)
			if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
			groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS" && (channel=="CDE-HS" || channel=="DE-MOBILITY" || channel=="CRU-MOBILITY" ) )
			{
				def fulfillmentMethod=groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod
				def losgType=groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType
				if((fulfillmentMethod=="DF" || fulfillmentMethod=="C2S") && (losgType=="NEW" || losgType=="AL" || losgType=="ALF" || losgType=="UP") &&
				(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo) )
				{
					def isCrossUpgrade = groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.find{ it.key == "IsCrossUpgrade" }?.value
					if((isCrossUpgrade==null || isCrossUpgrade==false) && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo.Relationship=="RECIPIENT")
					{
						def lineItemlist=Order.LineItems.LineItem
						def lineItemCount=lineItemlist.size();

						for(def k=0;k<lineItemCount;k++)
						{
							def lineItemMap=lineItemlist.get(k)
							if(lineItemMap.ProductType && lineItemMap.ProductType=="HARDGOOD" && lineItemMap.HardGood.HardGoodType=="DEVICE")
							{
								if((lineItemMap.ContractDetails.ContractType=="LEASE" || lineItemMap.ContractDetails.ContractType=="INSTALLMENT") )
								{
									if(lineItemMap.Price.MSRP || Order.IsPassThrough==true)
									{
									}
									else
									{
										nackErrorList.add(['ErrorCode':'nack569','Reference': ['Type':'LINEITEM','IdRef' :lineItemMap.Id ]])
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack572(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def	lineItemList=Order.LineItems.LineItem
			def lineItemCount=lineItemList.size();

			for(def i=0;i<lineItemCount;i++)
			{
				def lineItemMap =lineItemList.get(i)
				if(lineItemMap.ProductType == "HARDGOOD")
				{
					if(lineItemMap.HardGood && (lineItemMap.HardGood.BYOD == true) && (lineItemMap.HardGood.HardGoodType == "DEVICE") && lineItemMap.HardGood.WirelessHardGoodChars)
					{
						if(lineItemMap.HardGood.WirelessHardGoodChars?.TechType && lineItemMap.HardGood.WirelessHardGoodChars?.EquipmentType)
						{
						}
						else
						{
							nackErrorList.add(['ErrorCode':'nack572','Reference': ['Type':'LINEITEM','IdRef' : lineItemMap?.Id]])
						}
					}
				}
			}
		}
	}

	public def nack573(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)

				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo)
				{
					def losgType = groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType
					if((losgType=="NEW" || losgType=="AL" || losgType=="ALF" || losgType=="UP") &&
					groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS" && (groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF"))
					{
						def lineItemlist=Order.LineItems.LineItem
						def lineItemCount=lineItemlist.size();

						for(def k=0;k<lineItemCount;k++)
						{
							def lineItemMap=lineItemlist.get(k)

							if(lineItemMap.ProductType && lineItemMap.ProductType=="HARDGOOD" && lineItemMap.HardGood && lineItemMap.HardGood.HardGoodType=="DEVICE" &&
							lineItemMap.HardGood.BYOD==false )
							{
								if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo.Relationship!="DONOR")
								{
									if(lineItemMap.HardGood.WirelessHardGoodChars && lineItemMap.HardGood.WirelessHardGoodChars.ImeiType)
									{
									}
									else
									{
										nackErrorList.add(['ErrorCode':'nack573','Reference': ['Type':'LINEITEM','IdRef' :lineItemMap.Id ]])
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack574(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS" &&
				(groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF") && groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="UP")
				{
					if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo)
					{
						if( groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.IsCrossUpgrade==true && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo.Relationship=="RECIPIENT")
						{
							if(groupMap.GroupCharacteristics.LoSGCharacteristics.DealerCode &&
							groupMap.GroupCharacteristics.LoSGCharacteristics.Market &&
							groupMap.GroupCharacteristics.LoSGCharacteristics.SubMarket &&
							groupMap.GroupCharacteristics.LoSGCharacteristics.PriceCode )
							{
							}
							else
							{
								nackErrorList.add(['ErrorCode':'nack574','Reference': ['Type':'LINE_OF_SERVICE','IdRef' :groupMap.Id ]])
							}
						}
					}
				}
			}
		}
	}

	public def nack575(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" &&  groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS")
				{
					def losgType = groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType
					if(losgType=="NEW" || losgType=="AL" || losgType=="ALF" || losgType=="UP" || losgType=="ACC")
					{
						def LineItemlist=Order.LineItems.LineItem
						def LineItemCount=LineItemlist.size();

						for(def j=0;j<LineItemCount;j++)
						{
							def lineItemMap=LineItemlist.get(j)
							if(lineItemMap.Price && lineItemMap.Price.TaxInfo && lineItemMap.Price.TaxInfo.LineItemTax )
							{
								if(lineItemMap.Price.TaxInfo.LineItemTax[0].TaxCode)
								{
									def lineItemTax=lineItemMap.Price.TaxInfo.LineItemTax[0]
									if(!(lineItemTax.TaxLineID==null) && !(lineItemTax.Memo==null) && !(lineItemTax.PrintName==null) &&
									!(lineItemTax.TaxableIndicator==null) && !(lineItemTax.SKUSpecificIndicator==null) &&
									!(lineItemTax.JurisdictionLevel==null) && !(lineItemTax.JurisdictionName==null) &&
									!(lineItemTax.TaxAmount==null) && !(lineItemTax.TaxRate==null) && !(lineItemTax.TaxDate==null))
									{
									}
									else
									{
										nackErrorList.add(['ErrorCode':'nack575','Reference': ['Type':'LINEITEM','IdRef' :LineItemlist?.Id ]])
									}
								}
							}

						}
					}
				}
			}
		}
	}

	public def nack576(def Order, def nackErrorList)
	{
		def groupList=Order.Groups.Group
		def losgCount=groupList.size();

		for(def i=0;i<losgCount;i++)
		{
			def groupMap = groupList.get(i)
			if(groupMap.Type=="SHARED_PLAN" && Order.OrderSource.Channel!="CRU-MOBILITY" && Order.OrderSource.Channel!="SMB-WEB-CENTER")
			{
				if(groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.SharedPlanCharacteristics && groupMap.GroupCharacteristics.SharedPlanCharacteristics.PlanType=="MOBILE_SHARE")
				{
					if(groupMap.GroupCharacteristics.SharedPlanCharacteristics.DataGroupId || groupMap.GroupCharacteristics.SharedPlanCharacteristics.GroupReferenceCode)
					{
					}
					else
					{
						nackErrorList.add(['ErrorCode':'nack576','Reference':['Type':'SHARED_PLAN_GROUP','IdRef' :groupMap.Id  ]])
					}
				}
			}
		}
	}

	public def nack577(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS" && groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF")
				{
					def losgType = groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType
					if(losgType=="NEW" || losgType=="AL" || losgType=="ALF" || losgType=="UP" || losgType=="ACC")
					{
						def	paymentList=Order.PaymentOptions?.PaymentOption
						def paymentSeqList=paymentList.PaymentSequence
						if(paymentSeqList != null) {
							def paymentCount=paymentList.size();

							for(def j=0;j<paymentCount;j++)
							{
								def paymentMap =paymentList.get(j)
								if(paymentMap.PaymentMethod && paymentMap.PaymentMethod.CreditCard && paymentMap.PaymentMethod.CreditCard.PreAuthDetail && paymentMap.PaymentMethod.CreditCard.PreAuthDetail.AuthorizationCode)
								{
									def PreAuthDetail=paymentMap.PaymentMethod.CreditCard.PreAuthDetail
									if(!(PreAuthDetail.AuthorizationDate==null) && !(PreAuthDetail.AuthorizationExpirationDate==null) && !(PreAuthDetail.AuthorizationKey==null))
									{
									}
									else
									{
										nackErrorList.add(['ErrorCode':'nack577','Reference': ['Type':'PAYMENT_OPTIONS','IdRef' :paymentMap?.Id ]])
									}
								}

							}
						}
					}
				}
			}
		}
	}

	public def nack579(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS" && groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod=="DF")
				{
					if(groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType=="CHANGE")
					{
						def lineItemlist=Order.LineItems.LineItem
						def planLineItem  = lineItemlist.findAll {a -> a.ProductType=="PLAN" && (a.Action=="ADD" || a.Action=="REMOVE")}
						def featureLineItem  = lineItemlist.findAll {a -> a.ProductType=="OPTIONAL_FEATURE" && (a.Action=="ADD" || a.Action=="REMOVE")}

						if(planLineItem || featureLineItem)
						{
						}
						else
						{
							nackErrorList.add(['ErrorCode':'nack579','Reference': ['Type':'ORDER','IdRef' :Order.CustomerOrderNumber ]])
						}
					}
				}
			}
		}
	}

	public def nack580(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def	groupList=Order.Groups.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap =groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics )
				{
					if(groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS" && groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType == "CHANGE")
					{
						if(groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.MobileNumber)
						{
						}
						else
						{
							nackErrorList.add(['ErrorCode':'nack580','Reference': ['Type':'LINE_OF_SERVICE','IdRef' : groupMap?.Id]])
						}
					}
				}
			}
		}
	}

	public def nack581(def Order, def nackErrorList)
	{
		def	groupList=Order.Groups.Group
		def losgCount=groupList.size();
		if((Order.OrderSource.Channel=="DE-MOBILITY" || Order.OrderSource.Channel=="CRU-MOBILITY" ) && Order.IsPassThrough!=true)
		{
			for(def i=0;i<losgCount;i++)
			{
				def groupMap =groupList.get(i)

				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics)
				{
					def losgType = groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType
					if((losgType=="NEW" || losgType=="AL" || losgType=="ALF" || losgType=="UP") &&
					groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars && groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo)
					{
						def relationship = groupMap.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.UpgradeInfo.find{ it.key == "Relationship" }?.value
						if(relationship==null || relationship=="RECIPIENT")
						{
							def	lineItemList=Order.LineItems.LineItem
							def lineItemCount=lineItemList.size();
							for(def j=0;j<lineItemCount;j++)
							{
								def lineItemMap=lineItemList.get(j)
								if(lineItemMap.HardGood && lineItemMap.HardGood.HardGoodType!="SIM")
								{
									if(groupMap.GroupCharacteristics.LoSGCharacteristics.ServiceLocationRef)
									{
									}
									else
									{
										nackErrorList.add(['ErrorCode':'nack581','Reference': ['Type':'LINE_OF_SERVICE','IdRef' : groupMap?.Id]])
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack593(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def	accountList=Order.Accounts.Account
			def accountCount=accountList.size();

			for(def i=0;i<accountCount;i++)
			{
				def accountMap =accountList.get(i)
				if(accountMap.EnterpriseType == "IRU")
				{
					def	b2bList=Order.B2Bs?.B2B
					if(b2bList != null) {
						def b2bCount=b2bList.size();
						def b2bRef=accountMap.B2BRef
						for(def j=0;j<b2bCount;j++)
						{
							def b2bMap=b2bList.get(j)
							if(b2bMap.Id==b2bRef)
							{
								if(b2bMap.B2BFAN && b2bMap.B2BContractProvider && b2bMap.B2BContractType && b2bMap.B2BFANBusinessName)
								{
								}
								else
								{
									nackErrorList.add(['ErrorCode':'nack593','Reference': ['Type':'LINE_OF_SERVICE','IdRef' : b2bMap?.Id]])
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack596(def Order, def nackErrorList)
	{
		def	groupList=Order.Groups.Group
		def losgCount=groupList.size();
		def	accountList=Order.Accounts.Account
		def accountCount=accountList.size();

		for(def i=0;i<losgCount;i++)
		{
			def groupMap =groupList.get(i)
			if((Order.OrderSource.Channel=="DE-MOBILITY") && groupMap.Type=="LINE_OF_SERVICE" &&
			groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS")
			{
				def losgType=groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType
				if(losgType=="NEW" || losgType=="AL" || losgType=="ALF" || losgType=="UP" || losgType=="CHANGE")
				{
					for(def j=0;j<accountCount;j++)
					{
						def accountMap =accountList.get(j)
						if((accountMap?.Id==groupMap.GroupCharacteristics?.LoSGCharacteristics?.AccountRef) && accountMap?.AccountCategory &&
						(accountMap?.AccountCategory=="MOBILITY_ACCOUNT" || accountMap?.AccountCategory=="ADDON-SOLUTIONS_ACCOUNT" || accountMap?.AccountCategory=="WIRELINE_ACCOUNT"))
						{
							if(accountMap?.Id && accountMap?.AccountCategory && accountMap?.AccountSubCategory && accountMap?.PaymentArrangement &&
							accountMap?.AccountType && accountMap?.AccountSubType && accountMap?.Market && accountMap?.SubMarket)
							{
							}
							else
							{
								nackErrorList.add(['ErrorCode':'nack596','Reference': ['Type':'ACCOUNT','IdRef' : accountMap?.Id]])
							}
						}
					}
				}
			}
		}
	}

	public def nack611(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def	lineItemlist=Order.LineItems.LineItem
			def lineItemCount=lineItemlist.size();
			for(def i=0;i<lineItemCount;i++)
			{
				def lineItemMap=lineItemlist.get(i)
				if(lineItemMap.ProductType=="HARDGOOD")
				{
					def paymentOptionList=Order.PaymentOptions?.PaymentOption

					if(paymentOptionList != null) {
						def paymentOptionCount=paymentOptionList.size();

						for(def j=0;j<paymentOptionCount;j++)
						{
							def paymentOptionMap=paymentOptionList.get(j)
							if(paymentOptionMap.Id==lineItemMap.Payments?.Payment?.PaymentOptionRef)
							{
								if(paymentOptionMap.PaymentMethod && paymentOptionMap.PaymentMethod.CAPM &&
								paymentOptionMap.PaymentMethod.CAPM.ProfileName && paymentOptionMap.PaymentMethod.CAPM.ProfileOwnerId)
								{
									if(paymentOptionMap.PaymentMethod.CAPM.CreditCardLast4Digits && paymentOptionMap.PaymentMethod.CAPM.CreditCardType)
									{
									}
									else
									{
										nackErrorList.add(['ErrorCode':'nack611','Reference': ['Type':'PAYMENT_OPTIONS','IdRef' :paymentOptionMap?.Id]])
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack612(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def	lineItemlist=Order.LineItems.LineItem
			def lineItemCount=lineItemlist.size();
			for(def i=0;i<lineItemCount;i++)
			{
				def lineItemMap=lineItemlist.get(i)
				if(lineItemMap.ProductType=="HARDGOOD")
				{
					def paymentOptionList=Order.PaymentOptions?.PaymentOption
					if(paymentOptionList != null) {
						def paymentOptionCount=paymentOptionList.size();

						for(def j=0;j<paymentOptionCount;j++)
						{
							def paymentOptionMap=paymentOptionList.get(j)
							if(paymentOptionMap.Id==lineItemMap.Payments?.Payment?.PaymentOptionRef)
							{
								if(paymentOptionMap.PaymentMethod && paymentOptionMap?.PaymentMethod?.CAPM && (paymentOptionMap.PaymentMethod?.CAPM?.IsGiftCard==false)
								&& paymentOptionMap.PaymentMethod?.CAPM?.PreAuthDetail?.AuthorizationCode)
								{
									def preAuthDetail = paymentOptionMap.PaymentMethod?.CAPM?.PreAuthDetail
									if(!(preAuthDetail.AuthorizationDate==null) && !(preAuthDetail.AuthorizationExpirationDate==null) &&
									!(preAuthDetail.AVScode==null) && !(preAuthDetail.AuthorizationKey==null))
									{
									}
									else
									{
										nackErrorList.add(['ErrorCode':'nack612','Reference': ['Type':'PAYMENT_OPTIONS','IdRef' :paymentOptionMap?.Id]])
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack617(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def	lineItemlist=Order.LineItems.LineItem
			def lineItemCount=lineItemlist.size();
			for(def i=0;i<lineItemCount;i++)
			{
				def lineItemMap=lineItemlist.get(i)
				if(lineItemMap.ProductType=="HARDGOOD")
				{
					def paymentOptionList=Order.PaymentOptions?.PaymentOption
					if(paymentOptionList != null) {
						def paymentOptionCount=paymentOptionList.size();

						for(def j=0;j<paymentOptionCount;j++)
						{
							def paymentOptionMap=paymentOptionList.get(j)
							if(paymentOptionMap.Id==lineItemMap.Payments?.Payment?.PaymentOptionRef)
							{
								if(paymentOptionMap.PaymentMethod && paymentOptionMap.PaymentMethod.CAPM && paymentOptionMap.PaymentMethod.CAPM.PreAuthDetail &&
								paymentOptionMap.PaymentMethod.CAPM.PreAuthDetail.AuthorizationCode && (paymentOptionMap.PaymentMethod.CAPM.IsGiftCard==true))
								{
									def authDate = paymentOptionMap.PaymentMethod.CAPM.PreAuthDetail.AuthorizationDate
									def authExpDate = paymentOptionMap.PaymentMethod.CAPM.PreAuthDetail.AuthorizationExpirationDate
									def authKey = paymentOptionMap.PaymentMethod.CAPM.PreAuthDetail.AuthorizationKey
									if(!(authDate==null) && !(authKey==null) && !(authKey==null))
									{
									}
									else
									{
										nackErrorList.add(['ErrorCode':'nack617','Reference': ['Type':'PAYMENT_OPTIONS','IdRef' :paymentOptionMap?.Id]])
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack500(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			int counter = 0
			for(def group in Order.Groups.Group)
			{
				if(group.Type == 'LINE_OF_SERVICE')
				{
					counter++
				}
			}
			if(counter == 0)
				nackErrorList.add(['ErrorCode':'nack500','Reference': ['Type':'LINE_OF_SERVICE','IdRef' : Order.CustomerOrderNumber]])
		}
	}

	public def nack501(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			List<String> Groups = new ArrayList<String>();
			for(group in Order.Groups.Group)
			{
				if(group.Type == 'LINE_OF_SERVICE')
					Groups.add(group.Id)
			}

			for(lineItem in Order.LineItems.LineItem)
			{
				List<String> GroupRefs = lineItem.GroupRefs.GroupRef
				List<String> Status = new ArrayList<String>();
				for (def group in GroupRefs)
				{
					if(Groups.contains(group))
						Status.add(lineItem)
				}
				if(Status.isEmpty())
					nackErrorList.add(['ErrorCode':'nack501','Reference': ['Type':'LINE_ITEM','IdRef' : lineItem.Id]])
			}
		}
	}

	public def nack502(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			for(def group in Order.Groups.Group)
			{
				if(group.Type == 'LINE_OF_SERVICE')
				{
					if(group.GroupCharacteristics && group.GroupCharacteristics.LoSGCharacteristics)
					{}
					else
					{
						nackErrorList.add(['ErrorCode':'nack502','Reference': ['Type':'LINE_OF_SERVICE','IdRef' : group.Id]])
					}
				}
			}
		}
	}

	public def nack503(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			int counter = 0
			for(def group in Order.Groups.Group)
			{
				if(group.Id && group.Type == 'LINE_OF_SERVICE')
				{
					counter++
				}
			}
			if(counter == 0)
				nackErrorList.add(['ErrorCode':'nack503','Reference': ['Type':'LINE_OF_SERVICE','IdRef' : Order.CustomerOrderNumber]])
		}
	}

	public def nack511(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();
			List<String> FulfillmentTypes = new ArrayList<String>();
			FulfillmentTypes.add("DF");
			FulfillmentTypes.add("C2S");
			FulfillmentTypes.add("ACTIVATION");

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics)
				{
					def lineItemlist=Order.LineItems.LineItem
					def lineItemCount=lineItemlist.size();

					for(def j=0;j<lineItemCount;j++)
					{
						def lineItemMap=lineItemlist.get(j)
						if(lineItemMap.ProductType && lineItemMap.ProductType=="HARDGOOD")
						{
							if(FulfillmentTypes.contains(groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod))
							{
							}
							else
							{
								nackErrorList.add(['ErrorCode':'nack511','Reference': ['Type':'GROUP','IdRef' :groupMap.Id ]])
							}
						}
					}
				}
			}
		}
	}

	public def nack513(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def lineItemList=Order.LineItems.LineItem
			def lineItemCount=lineItemList.size();
			for(def i=0;i<lineItemCount;i++)
			{
				def lineItemMap=lineItemList.get(i)
				if(lineItemMap.ProductType=="HARDGOOD")
				{
					if(lineItemMap.HardGood)
					{
					}
					else
					{
						nackErrorList.add(['ErrorCode':'nack513','Reference': ['Type':'LineItem','IdRef' :lineItemList?.Id ]])
					}
				}
			}
		}
	}

	public def nack514(def Order, def nackErrorList)
	{

		def groupList=Order.Groups.Group
		def losgCount=groupList.size();

		for(def i=0;i<losgCount;i++)
		{
			def groupMap=groupList.get(i)
			if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
			groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS")
			{
				def losgType=groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType
				if(losgType=="NEW" || losgType=="AL" || losgType=="ALF")
				{
					def LineItemlist=Order.LineItems.LineItem
					def LineItemCount=LineItemlist.size();

					for(def j=0;j<LineItemCount;j++)
					{
						def lineItemMap=LineItemlist.get(j)
						if(Order.OrderSource.Channel=="CDE-HS" || Order.OrderSource.Channel=="DE-MOBILITY")
						{
							if((lineItemMap.ProductType && lineItemMap.HardGood && lineItemMap.HardGood.WirelessHardGoodChars &&
							lineItemMap.ProductType=="HARDGOOD" && lineItemMap.HardGood.BYOD==false && lineItemMap.HardGood.HardGoodType=="DEVICE" )
							&& (groupMap.Characteristics==null || groupMap.Characteristics.WirelessLineItemChars == null || groupMap.Characteristics.WirelessLineItemChars.TradeInInfo == null))
							{
								def wlsHardgoodChars=lineItemMap.HardGood.WirelessHardGoodChars
								if(!(wlsHardgoodChars.TechType==null) && !(wlsHardgoodChars.EquipmentType==null) &&
								!(wlsHardgoodChars.PhoneType==null))
								{
								}
								else
								{
									nackErrorList.add(['ErrorCode':'nack514','Reference': ['Type':'LineItem','IdRef' :LineItemlist?.Id ]])
								}
							}
						}
					}

				}
			}
		}
	}


	public def nack525(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def paymentOptionList=Order.PaymentOptions?.PaymentOption

			if(paymentOptionList != null) {
				def paymentOptionCount=paymentOptionList.size();

				for(def i=0;i<paymentOptionCount;i++)
				{
					def paymentOptionMap=paymentOptionList.get(i)
					if(paymentOptionMap.PaymentMethod && paymentOptionMap.PaymentMethod.CreditCard){
						if(paymentOptionMap.PaymentMethod.CreditCard.PaymentAmount)
						{}
						else
						{
							nackErrorList.add(['ErrorCode':'nack525','Reference': ['Type':'PaymentOption','IdRef' :paymentOptionMap.Id ]])
						}
					}
				}
			}
		}
	}

	public def nack526(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();
			def paymentOptionList=Order.PaymentOptions?.PaymentOption
			if(paymentOptionList != null) {
				def paymentOptionCount=paymentOptionList.size();
				def fulfillmentMethod

				for(def i=0;i<losgCount;i++)
				{
					def groupMap=groupList.get(i)
					if(groupMap.GroupCharacteristics.LoSGCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
					(groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod =="DF"||
					groupMap.GroupCharacteristics.LoSGCharacteristics.FulfillmentMethod == "C2S"))
					{
						fulfillmentMethod = true
					}
				}
				for(def j=0;j<paymentOptionCount;j++)
				{
					def paymentOptionMap=paymentOptionList.get(j)
					if(paymentOptionMap.PaymentMethod && paymentOptionMap.PaymentMethod.BTM && fulfillmentMethod == true){
						if(paymentOptionMap.PaymentMethod.BTM.TotalAmount)
						{}
						else
						{
							nackErrorList.add(['ErrorCode':'nack526','Reference': ['Type':'PaymentOption','IdRef' :paymentOptionMap.Id ]])
						}
					}
				}
			}
		}
	}


	public def nack530(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def  OrderVal=Order.IsPassThrough
			if((Order.OrderType == "CREATE" && Order.OrderContact) || OrderVal==true)
			{
			}
			else
			{
				nackErrorList.add(['ErrorCode':'nack530','Reference': ['Type':'Order','IdRef' :Order.CustomerOrderNumber ]])
			}
		}
	}

	public def nack552(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def groupList=Order.Groups.Group
			def losgCount=groupList.size();
			if(Order.IsPassThrough)
			{
			}
			else
			{
				for(def i=0;i<losgCount;i++)
				{
					def groupMap = groupList.get(i)
					if(groupMap.Type=="SHARED_PLAN")
					{
						if(groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.SharedPlanCharacteristics)
						{
						}
						else
						{
							nackErrorList.add(['ErrorCode':'nack552','Reference':['Type':'GROUP:SHARED_PLAN','IdRef' :groupMap.Id  ]])
						}
					}
				}
			}
		}
	}

	public def nack001(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def accountList=Order.Accounts.Account
			def accountCount=accountList.size();
			def dtvAccount  = accountList.findAll {a -> a.AccountCategory!= null && a.AccountCategory=="DTV_ACCOUNT" }
			def uverseAccount  = accountList.findAll {a -> a.AccountCategory != null && a.AccountCategory=="UVERSE_ACCOUNT" }
			for(def i=0;i<accountCount;i++)
			{
				def accountMap = accountList.get(i)
				if(dtvAccount)
				{
					if(dtvAccount && uverseAccount && uverseAccount?.AccountSubCategory=="NEW")
					{
						if(uverseAccount.BillingAccountNumber)
						{
						}
						else
						{
							nackErrorList.add(['ErrorCode':'nack001','Reference':['Type':'ACCOUNT','IdRef' :accountMap.Id  ]])
						}
					}
				}
			}
		}
	}

	public def nack598(def Order, def nackErrorList)
	{
		def custOrderNumber = Order.CustomerOrderNumber
		if(Order.IsCommonOrder==true && Order.OrderSource.Channel != "CRU-MOBILITY" && Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			if(custOrderNumber.length()<=18)
			{
			}
			else
			{
				nackErrorList.add(['ErrorCode':'nack598','Reference': ['Type':'ORDER','IdRef' : Order.CustomerOrderNumber]])
			}
		}
	}

	public def nack599(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			for(def group in Order.Groups.Group)
			{
				if(Order.IsCommonOrder == true && group.Type == 'LINE_OF_SERVICE' && group.GroupCharacteristics &&
				group.GroupCharacteristics.LoSGCharacteristics && group.GroupCharacteristics.LoSGCharacteristics.ProductCategory &&
				group.GroupCharacteristics.LoSGCharacteristics.ProductCategory == 'WIRELESS')
				{
					List<Integer> LoSGSequenceNumbers = Order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.LoSGSequenceNumber
					if(group.GroupCharacteristics.LoSGCharacteristics.LoSGSequenceNumber &&
					Collections.frequency(LoSGSequenceNumbers, group.GroupCharacteristics.LoSGCharacteristics.LoSGSequenceNumber) == 1)
					{
					}
					else
					{
						nackErrorList.add(['ErrorCode':'nack599','Reference': ['Type':'LINE_OF_SERVICE','IdRef' : group.Id]])
					}
				}
			}
		}
	}

	public def nack600(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			List<String> lineItems =  Order.LineItems.LineItem
			List<String> Groups = new ArrayList<String>();
			List<Integer>  LineItemSequenceList = lineItems.LineItemSequence
			for(def group in Order.Groups.Group)
			{
				if(Order.IsCommonOrder == true && group.Type == 'LINE_OF_SERVICE' && group.GroupCharacteristics &&
				group.GroupCharacteristics.LoSGCharacteristics && group.GroupCharacteristics.LoSGCharacteristics.ProductCategory &&
				group.GroupCharacteristics.LoSGCharacteristics.ProductCategory == 'WIRELESS')
					Groups.add(group.Id)
			}
			if(Groups.isEmpty() == false)
			{
				for(def lineItem in lineItems)
				{
					if(lineItem.LineItemSequence &&
					Collections.frequency(LineItemSequenceList, lineItem.LineItemSequence) == 1)
					{
					}
					else
						nackErrorList.add(['ErrorCode':'nack600','Reference': ['Type':'LINEITEM','IdRef' : lineItem.Id]])
				}
			}
		}
	}

	public def nack601(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			if(Order.IsPassThrough==true)
			{
				if(Order.OrderStatus)
				{
				}
				else
				{
					nackErrorList.add(['ErrorCode':'nack601','Reference': ['Type':'ORDER','IdRef' : Order.CustomerOrderNumber]])
				}
			}
		}
	}

	public def nack602(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			List<Integer>  AccountSequenceNumberList = new ArrayList<String>();

			if(Order.Accounts && Order.Accounts.Account)
				AccountSequenceNumberList = Order.Accounts.Account.AccountSequenceNumber

			if(Order.Accounts && Order.Accounts.Account)
			{
				for(def account in Order.Accounts.Account)
				{
					if(Order.IsCommonOrder == true && account.AccountCategory && account.AccountCategory == 'MOBILITY_ACCOUNT')
					{
						if(account && account.AccountSequenceNumber &&
						Collections.frequency(AccountSequenceNumberList, account.AccountSequenceNumber) == 1)
						{
						}
						else
						{
							nackErrorList.add(['ErrorCode':'nack602','Reference': ['Type':'ACCOUNT','IdRef' : account.Id]])
						}
					}
				}
			}
		}
	}

	public def nack608(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def	groupList=Order.Groups.Group
			def losgCount=groupList.size();
			def	lineItemList=Order.LineItems.LineItem
			def lineItemCount=lineItemList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap =groupList.get(i)
				if(groupMap.Type=="LINE_OF_SERVICE" && groupMap.GroupCharacteristics && groupMap.GroupCharacteristics.LoSGCharacteristics &&
				groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory=="WIRELESS")
				{
					for(def j=0;j<lineItemCount;j++)
					{
						def lineItemMap=lineItemList.get(j)
						if( (lineItemMap.GroupRefs.GroupRef[0]==groupMap.Id) && lineItemMap.ProductType=="MISC_CHARGE")
						{
							if(!(lineItemMap.DisplayName==null) && lineItemMap.Price && !(lineItemMap.Price.Amount==null))
							{
							}
							else
							{
								nackErrorList.add(['ErrorCode':'nack608','Reference': ['Type':'LINEITEM','IdRef' : lineItemMap?.Id]])
							}
						}

					}
				}
			}
		}
	}

	public def nack609(def Order, def nackErrorList)
	{
		if(Order.IsCommonOrder==true)
		{
			def	accountList=Order.Accounts.Account
			def accountCount=accountList.size();

			for(def i=0;i<accountCount;i++)
			{
				def accountMap =accountList.get(i)
				if(accountMap && accountMap.AccountCategory && accountMap.AccountCategory == "MOBILITY_ACCOUNT" && Order.OrderSource.Channel!="UNLOCK" && Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
				{
					if(accountMap.CreditCheck && (accountMap.CreditCheck.CCRan=="true"))
					{
						if(accountMap.CreditCheck.ApplicationNumber)
						{
						}
						else
						{
							nackErrorList.add(['ErrorCode':'nack609','Reference': ['Type':'ACCOUNT','IdRef' : accountMap?.Id]])
						}
					}
				}
			}
		}
	}

	public def nack615(def Order, def nackErrorList)
	{
		if(Order?.OrderSource?.Channel!="SMB-WEB-CENTER")
		{
			def	lineItemlist=Order.LineItems.LineItem
			def lineItemCount=lineItemlist.size();
			for(def i=0;i<lineItemCount;i++)
			{
				def lineItemMap=lineItemlist.get(i)
				if(lineItemMap.ProductType=="HARDGOOD")
				{
					def paymentOptionList=Order.PaymentOptions?.PaymentOption
					if(paymentOptionList != null) {
						def paymentOptionCount=paymentOptionList.size();

						for(def j=0;j<paymentOptionCount;j++)
						{
							def paymentOptionMap=paymentOptionList.get(j)
							if(paymentOptionMap.Id==lineItemMap.Payments?.Payment?.PaymentOptionRef)
							{
								if(paymentOptionMap.PaymentMethod && paymentOptionMap.PaymentMethod.CreditCard && paymentOptionMap.PaymentMethod.CreditCard.SaveProfileIndicator)
								{
									def giftCard = paymentOptionMap.PaymentMethod.CreditCard.find{ it.key == "IsGiftCard" }?.value
									def cardBillingZipCode = paymentOptionMap.PaymentMethod.CreditCard.find{ it.key == "CardBillingZipCode" }?.value
									if((giftCard==null || giftCard==false) && cardBillingZipCode==null)
									{
										nackErrorList.add(['ErrorCode':'nack615','Reference': ['Type':'PAYMENT_OPTIONS','IdRef' :paymentOptionMap?.Id]])
									}
									else
									{
									}
								}
							}
						}
					}
				}
			}
		}
	}

	public def nack506(def Order, def nackErrorList)
	{
		def channel = Order?.OrderSource?.Channel
		if(channel!="SMB-WEB-CENTER")
		{
			def groupList=Order?.Groups?.Group
			def losgCount=groupList.size();

			for(def i=0;i<losgCount;i++)
			{
				def groupMap=groupList.get(i)
				if(groupMap?.Type=="LINE_OF_SERVICE" && groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics &&
				groupMap?.GroupCharacteristics && groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == "WIRELESS")
				{
					def losgType = groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
					def fulfillmentMethod = groupMap?.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod
					if((losgType=="NEW" || losgType=="AL" || losgType=="ALF" || losgType=="ACC" || losgType=="CHANGE" || losgType=="UP" || losgType=="DEVICE") &&
					(fulfillmentMethod=="DF" || fulfillmentMethod=="C2S"))
					{
						def lineItemlist=Order.LineItems.LineItem
						def lineItemCount=lineItemlist.size();

						for(def j=0;j<lineItemCount;j++)
						{
							def lineItemMap=lineItemlist.get(j)
							def prodType = lineItemMap?.ProductType
							if(prodType=="HARDGOOD" && channel=="DE-MOBILITY")
							{
								if(lineItemMap?.ProductSku!=null &&
								lineItemMap?.ProductCode!=null &&
								lineItemMap?.HardGood?.HardGoodType!=null &&
								lineItemMap?.DisplayName!=null &&
								lineItemMap?.SystemName!=null &&
								lineItemMap?.LocationID!=null)
								{
								}
								else
								{
									nackErrorList.add(['ErrorCode':'nack506','Reference': ['Type':'LineItem','IdRef' :lineItemMap?.Id ]])
								}
							}
							else if((channel=="CDE-HS" || channel=="EDE-EG" || channel=="CRU-MOBILITY") && prodType=="HARDGOOD")
							{
								if(lineItemMap?.ProductSku!=null &&
								lineItemMap?.ProductCode!=null &&
								lineItemMap?.HardGood?.HardGoodType!=null &&
								lineItemMap?.DisplayName!=null &&
								lineItemMap?.SystemName!=null )
								{
								}
								else
								{
									nackErrorList.add(['ErrorCode':'nack506','Reference': ['Type':'LineItem','IdRef' :lineItemMap?.Id ]])
								}
							}
							else if(prodType=="PLAN" || prodType=="INCLUDED_FEATURE" || prodType=="OPTIONAL_FEATURE" || prodType=="MISC_CHARGES" || prodType=="ADDRESS_CHANGE")
							{
								if(lineItemMap?.BillingCode!=null &&
								lineItemMap?.ProductCode!=null &&
								lineItemMap?.DisplayName!=null &&
								lineItemMap?.SystemName!=null )
								{
								}
								else
								{
									nackErrorList.add(['ErrorCode':'nack506','Reference': ['Type':'LineItem','IdRef' :lineItemMap?.Id ]])
								}
							}
						}
					}
				}
			}
		}
	}
	
	public void transform(Exchange exchange) {}
	public void processResponse(Exchange exchange) throws APIFailedException {}
	public String getApiUrn() {}
}
