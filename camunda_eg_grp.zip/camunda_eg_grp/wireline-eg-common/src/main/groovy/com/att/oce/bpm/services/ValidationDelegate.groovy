package com.att.oce.bpm.services

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component
import org.springframework.beans.factory.annotation.Autowired
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.transformation.WirelineOrderValidation

@Component('validateNackRules')
class ValidationDelegate implements JavaDelegate{
	
	@Autowired private WirelineOrderValidation wlnValidate
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		def order = (HashMap<String, Object>) execution.getVariable("order");
		def executionContext = (LinkedHashMap<String, Object>) execution.getVariable("executionContext");
		
		if(executionContext == null) {
		 	executionContext = new LinkedHashMap<String, Object>(); 
		}
		executionContext.put("referenceId",order.CustomerOrderNumber);
		List nackErrorList = wlnValidate.validateWirelineOrder(order)
		if(nackErrorList != null && nackErrorList.size()>0)
		{
			executionContext.put("LOSGStatus", "IN_QUEUE")
			def e = new APIFailedException();
			e.api = 'BusinessRulesValidation'
			e.code = 200
			e.codeDescription = "Business Rule Validation Failed"
			wlnValidate.addTransactionHistory(executionContext,e)
		}
		else
		{
			wlnValidate.addTransactionHistory(executionContext,null)
		}
		executionContext.get('errorList',nackErrorList)
		execution.setVariable("executionContext",executionContext)	
	}

}
