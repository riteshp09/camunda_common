package com.att.oce.transformation

import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import com.att.oce.bpm.common.OceConstants
import com.att.oce.bpm.common.util.ErrorBean
import com.att.oce.bpm.utility.OrderUtility
import com.att.oce.bpm.common.WirelineConstants;


@Component('workServiceConflictResolution')
class WorkServiceConflictResolution {
	
	/* This function checks the serviceExistIndicator for ProductType = 'LIGHTSPEED' from ITPA Response and accordingly sends a boolean value */
	def getWSCIndicatorfromITPA(ITPAResponse)
	{
		def ITPAResponseJson = new XmlSlurper().parseText(ITPAResponse.toString())
		def isWscExistsFrmITPA = false
		ITPAResponseJson.ProductLSDTVW?.FiberServiceQualification?.QualStatusLocation?.NetworkTransport?.Product.each { 
				if(prod.contains(prod.productType==WirelineConstants.SERVICE_EXIST_INDICATOR_LIGHTSPEED) && prod.productType.serviceExistIndicator) {
					isWscExistsFrmITPA = true
				}
		}						
		return isWscExistsFrmITPA
	}
	
	/* This function sets the S/SS as IN_QUEUE/WSC_CLEARED_INCOMPLETE */
	def updateSStoInQueueWSC_CLEARED_INCOMPLETE(Order,executionContext )
	{
		def uverseAccount = OrderUtility.getUverseAcount(Order)
		List<ErrorBean> errList = new ArrayList<ErrorBean>();
		errList.add(new ErrorBean('300',WirelineConstants.LOSGSUBSTATUS_WSC_CLEARED_INCOMPLETE))
		OrderUtility.updateErrorList(Order,executionContext,errList,WirelineConstants.LOSGSTATUS_IN_QUEUE,WirelineConstants.LOSGSUBSTATUS_WSC_CLEARED_INCOMPLETE,uverseAccount.Id)
	}
	
	/* This function sets the S/SS as CANCELED/XXXX_NRFC */
	def updateSStoCANCELLEDXXXX_NRFC(Order,executionContext )
	{
		def uverseAccount = OrderUtility.getUverseAcount(Order)
		List<ErrorBean> errList = new ArrayList<ErrorBean>();
		errList.add(new ErrorBean('300',WirelineConstants.LOSGSUBSTATUS_WORKING_SERVICE_NRFC))
		OrderUtility.updateErrorList(Order,executionContext,errList,WirelineConstants.LOSGSTATUS_WORKING_SERVICE_CANCEL,WirelineConstants.LOSGSUBSTATUS_WORKING_SERVICE_NRFC,uverseAccount.Id)
		executionContext.put("LOSGStatus", WirelineConstants.LOSGSTATUS_WORKING_SERVICE_CANCEL)
	}
	
	def updateSStoInQueueManualProvReqd(Order,executionContext )
	{
		def uverseAccount = OrderUtility.getUverseAcount(Order)
		List<ErrorBean> errList = new ArrayList<ErrorBean>();
		errList.add(new ErrorBean('300','Potential conflicting DTV Service identified'))
		OrderUtility.updateErrorList(Order,executionContext,errList,WirelineConstants.LOSGSTATUS_IN_QUEUE,WirelineConstants.LOSG_MANUAL_PROVISIONING_REQUIRED,uverseAccount.Id)
	}
	
	
	/*	This function checks for the acceptableServiceTypes	and ConflictingServiceIndicator from ServiceFacilityQualification */
	def workServiceConflictExists(def Order)
	{
		def acceptableServiceTypes = WirelineConstants.ACCEPTABLE_SERVICE_TYPE
		def serviceQualification = getServiceFacilityQualification(Order)
		def serviceType = serviceQualification.FacilityCheck?.ServiceType?.findAll{ fc -> acceptableServiceTypes?.contains(fc?.ServiceType)}.collect{it?.ServiceType}.flatten().minus(null)
		boolean isAcceptableServiceType = (serviceType != null && serviceType.size()>0) 
		def conflictIndicator = serviceQualification.FacilityCheck?.ServiceType?.ConflictingServiceIndicator
		
		return !(isAcceptableServiceType && conflictIndicator)
	}
	
	/* This function returns list of ServiceFacilityQualification related to Uverse groups	*/
	def getServiceFacilityQualification(Order)
	{
		def uverseGroups = OrderUtility.getUverseGroups(Order)
		for(def loSGCharacteristics in uverseGroups.GroupCharacteristics.LoSGCharacteristics)
		{
			def serviceQualificationRef = loSGCharacteristics.ServiceQualificationRef
			def serviceFacilityQualification = Order.ServiceFacilityQualifications?.ServiceFacilityQualification?.findAll{ sfq -> serviceQualificationRef.contains(sfq.Id) }.collect{it}.flatten().minus(null)
			return serviceFacilityQualification
		}
	}
	
	def determineAutoPendSwitch()
	{
		def autoPendSwitch = WirelineConstants.AUTOPENDSWITCH
		return autoPendSwitch
	}
	
	def checkDTVConflict(Order)
	{
		def flowType = OrderUtility.determineFlowType(Order)
		boolean dtvconflictExists
		if(WirelineConstants.DTVCONFLICTFLAG)
		{
			if(flowType == WirelineConstants.FLOWTYPE_STANDALONEUV)
			{
				dtvconflictExists = false
			}
			else
			{
				if(getDTVMoveInOrderInd(Order))
				{
					dtvconflictExists = true
				}
				else
				{
					dtvconflictExists = false
				}
			}
		}
		return dtvconflictExists
	}
	
	def getDTVMoveInOrderInd(Order)
	{
		boolean dtvMoveInOrderIndicator
		for(def losg in Order.Groups.Group.GroupCharacteristics?.LoSGCharacteristics)
		{
			if(losg)
			{
				if(losg.ProductCategory == 'DIRECTV' && losg.LoSGType == 'NEW' )
				{
					if(losg.DirecTVLOSChars.MoveInOrder == 'Y')
					{
						dtvMoveInOrderIndicator = true
					}
				}
				
			}
		}
		return dtvMoveInOrderIndicator
	}
	
	
}