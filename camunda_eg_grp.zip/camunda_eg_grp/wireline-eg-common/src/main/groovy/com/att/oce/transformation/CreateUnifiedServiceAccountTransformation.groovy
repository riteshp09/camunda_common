package com.att.oce.transformation

import com.att.oce.bpm.common.WirelineConstants;
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.error.OceErrorHandler
import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import java.text.SimpleDateFormat
import java.util.Map
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import javax.resource.spi.work.ExecutionContext;

import com.att.oce.bpm.common.TransformationService;
import com.att.oce.bpm.common.WirelineTransformationService
import com.att.oce.bpm.common.util.JsonConverters
import com.att.oce.bpm.utility.OrderUtility
import com.att.oce.bpm.common.util.CommonUtility

import groovy.json.JsonSlurper
import groovy.util.XmlSlurper;

@Component('createUnifiedServiceAccountTransformation')
class CreateUnifiedServiceAccountTransformation extends WirelineTransformationService {

	String url;
	static Logger log = LoggerFactory.getLogger(CreateUnifiedServiceAccountTransformation.class)

	@Override String getApiName(){
		return 'CreateUnifiedServiceAccount';
	}

	public boolean preCondition(order){
		log.debug('CreateUnifiedServiceAccountTransformation.preCondition')
		def productTypes = OrderUtility.determineProductTypes(order)
		def checkUverseAccount = OrderUtility.checkForNEWUverseAccount(order)

		if (checkUverseAccount == 'NEW_UVERSE_ACCOUNT_WITHOUT_BAN' &&
		(productTypes?.contains('INTERNET~NEW') || productTypes?.contains('IPTV~NEW') || productTypes?.contains('DIRECTV~NEW')))
			return true;
		else
			return false;
	}
	
	public String getApiUrn() {
		return "urn:csi:services:lscrm:CreateUnifiedServiceAccount.jws";
	}

	public void transform(Exchange exchange){
		log.debug('CreateUnifiedServiceAccountTransformation.transform')

		exchange.properties.order = exchange.in.body.order
		exchange.properties.executionContext  = exchange.in.body.executionContext
		exchange.properties.fedIndicator = false;

		def apiURN = getApiUrn()
		def apiUrl = super.resolveURN(apiURN, null)
		exchange.properties.apiURN = apiURN
		exchange.properties.apiUrl = apiUrl

		def order = exchange.in.body.order

		def msgHeader = createUnifiedMessageHeader(order,null)
		def cusaRequest = [ messageHeader : msgHeader,
			createUnifiedServiceAccountRequest : getCUSARequest(order,exchange)
		]

		setAuditLogProperties(exchange,false)
		exchange.out.body = cusaRequest
		println("************CUSARequest Formed***********"+cusaRequest)
		setCSIHttpHeaders(exchange)
		exchange.out.headers.put("CamelHttpUri", apiUrl)
		exchange.properties.put("OceCSIApiName",getApiName())
		log.debug('CreateUnifiedServiceAccountTransformation.transform done')
	}

	public void processResponse(Exchange exchange) throws APIFailedException {
		log.debug('CreateUnifiedServiceAccountTransformation.processResponse')
		int index=0
		def order = exchange.properties.order
		
		//println('CUSA Response :: ' +exchange.in.body)
		def cusaResponseXml = new XmlSlurper().parseText(exchange.in.body)
		log.debug(exchange.in.body)
		if (cusaResponseXml.Body.Fault.size() > 0){
			def apie = new APIFailedException(
					api : getApiName(),
					code : cusaResponseXml.Body.Fault.detail.CSIApplicationException.Response.code,
					codeDescription : cusaResponseXml.Body.Fault.detail.CSIApplicationException.Response.description,
					subCode : cusaResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code,
					subCodeDescription : cusaResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
					)
			def uverseAcc = OrderUtility.getUverseAcount(order);
			OrderUtility.updateLoSGStatusForAccount(order, uverseAcc.Id,WirelineConstants.LOSG_STATUS_IN_QUEUE,"CUSA_FAIL");
			exchange.properties.executionContext.put("LOSGStatus","IN_QUEUE")
			addTransactionHistory(exchange,apie)
			exchange.out.body = order
			throw apie
		}
		else
		{
			addTransactionHistory(exchange,null)
		}

		Map<String,Object> cusaUpdatedOrder = updateOrder(order,cusaResponseXml)
		log.debug("updated Order is"+cusaUpdatedOrder);
		exchange.in.body = cusaUpdatedOrder
	}

	/**
	 * updates the order based on CUSA response
	 * @param order
	 * @param cusaResponseXml
	 * @return
	 */
	def updateOrder(order,cusaResponseXml){
		def uverseAcc = OrderUtility.getUverseAcount(order)
		def ban
		log.debug('CreateUnifiedServiceAccountTransformation.updateOrder')
		if (cusaResponseXml instanceof String)
			cusaResponseXml = new XmlSlurper().parseText(cusaResponseXml)

		ban = cusaResponseXml?.Body.CreateUnifiedServiceAccountResponse?.BillingCustomerIdDetails?.customerId.text()

		uverseAcc.put("BillingAccountNumber",ban)
		log.debug('CreateUnifiedServiceAccountTransformation.updateOrder done')
		return order
	}

	private def getCUSARequest(def order,def exchange)
	{

		int index = 0
		/*
		 * Getting Account, Name and Address information associated with Uverse Account
		 */
		def uverseAcc = OrderUtility.getUverseAcount(order)
		exchange.properties.referenceId = uverseAcc.Id
		def nameRef = uverseAcc?.BillingInfo[index]?.NameRef
		def accountName = OrderUtility.getName(order,nameRef)

		def addressRef = uverseAcc?.ServiceLocationRef
		def addressMap = order.Addresses.Address.find {add -> add.Id == addressRef}
		def unparsedAddress = addressMap?.UnparsedAddress
		def parsedAddress = addressMap?.ParsedAddress

		Date now = new Date()
		SimpleDateFormat timestamp = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss")

		//ITPAResponse variable is the response from ITPA api

		def xmlPayload = exchange.properties.executionContext.itpaResponse
		//def xmlPayload = new File("D:/rk00330305/TECHM/CamundaHSAutomation/camunda_entertainment_group/wireline-eg/wireline-eg-bpmn/src/test/resources/data/ITPAResponse.xml").text
		def slurper = new XmlSlurper()
		def ITPAResponse = slurper.parseText(xmlPayload)
		def itpaRes = ITPAResponse?.Body?.InquireTransportProductAvailabilityResponse
		def serviceFieldedAddress  = itpaRes?.ProductLSDTVW?.LocationMatchAvailabilityResults?.ExactLocationAvailabilityResults?.Location?.LocationList.findAll {a -> a?.LocationDetails?.addressType.text() == WirelineConstants.CUSA_ADDRESS_TYPE_SERVICE}.collect{it?.LocationDetails?.FieldedAddress}
		def uspsFieldedAddress =  itpaRes?.ProductLSDTVW?.LocationMatchAvailabilityResults?.ExactLocationAvailabilityResults?.Location?.LocationList.findAll {a -> a?.LocationDetails?.addressType.text() == WirelineConstants.CUSA_ADDRESS_TYPE_USPS}.collect{it?.LocationDetails?.FieldedAddress}
		def mapServiceFSP = getServiceMapAddress(order, itpaRes, serviceFieldedAddress[index], addressMap, WirelineConstants.CUSA_SERVICE_MAP_FSP, timestamp)
		def mapServiceSAG = getServiceMapAddress(order, itpaRes, serviceFieldedAddress[index], addressMap, WirelineConstants.CUSA_SERVICE_MAP_SAG, timestamp)
		def mapServiceUSPS = getServiceMapAddress(order, itpaRes, uspsFieldedAddress[index], addressMap, WirelineConstants.CUSA_SERVICE_MAP_USPS, timestamp)
		def billingCustomerBusinessType = order.B2Bs?.B2B?.find{ b2b -> uverseAcc?.B2BRef == b2b.Id}.BusinessType
		
		def scqIndicator = getScqIndicator(uverseAcc)
		def transactionId = getTransactionId(uverseAcc)
		def creditRisk = getCreditRisk(uverseAcc)
		def creditRefDate = CommonUtility.formatDate(String.valueOf(order?.SubmitedDate),"yyyy-MM-dd'T'HH:mm:ssZ")//order?.SubmittedDate
		def billingCustomerCreditScore
		if(OrderUtility.isSMB(order)){
			billingCustomerCreditScore = [
							adverseLetterIndicator : WirelineConstants.STRING_TRUE,
							scqWirelessIndicator : scqIndicator,
							transactionId : transactionId,
							creditScoreDate : creditRefDate,
							creditRisk : creditRisk,
							eidNumber : uverseAcc?.CreditCheck?.EIDNumber
			]
		}
		
		def cusaReq = [
			OriginatorDetails : [
				systemIdentifier : WirelineConstants.CUSA_SYSTEM_IDENTIFIER,
				originatorSystemName : WirelineConstants.SOURCE_USER_OCE
			],
			primaryContact : getPrimaryContact(order, uverseAcc, accountName),
			MapAddressesExt : [
				type : WirelineConstants.CUSA_SERVICE_MAP_BILLING,
				updateStamp : timestamp.format(now),
				siteId : getSiteId(parsedAddress),
				address1 : getAddress1(parsedAddress),
				isValid : WirelineConstants.CUSA_IS_VALID,
				cassLine1 : accountName?.FirstName+" "+accountName?.LastName,
				cassLine2 : unparsedAddress?.AddressLine1,
				cassLine3 : unparsedAddress?.City+" "+parsedAddress?.State+" "+parsedAddress?.Zip,
				county : parsedAddress?.County,
				houseNumber : parsedAddress?.HouseNumber,
				street : parsedAddress?.StreetName,
				subtype : WirelineConstants.CUSA_SUBTYPE,
				city : parsedAddress?.City,
				state : parsedAddress?.State,
				zip : parsedAddress?.Zip,
				country : parsedAddress?.Country
			],
			MapAddressesExt1 : mapServiceFSP,
			MapAddressesExt2 : mapServiceSAG,
			MapAddressesExt3 : mapServiceUSPS,

			BillingProfileExtension : [
				billCycle : 0,
				cycleStartDay : 0,
				cycleCloseDay : 0,
				entityId : 100000000,
				creditClass : getCreditClass(uverseAcc),
				paperBillOption : getPaperBillOption(uverseAcc)
			],
			preferredBillMedia : WirelineConstants.CUSA_PREFERRED_BILL,
			affiliate : WirelineConstants.CUSA_AFFILIATE,
			billingCustomerType : WirelineConstants.CUSA_BILLING_CUSTOMER,
			billingCustomerSubType : OrderUtility.isSMB(order) ? WirelineConstants.CUSA_BILLING_CUSTOMER_SubType[1] : WirelineConstants.CUSA_BILLING_CUSTOMER_SubType[0],
			name : StringEscapeUtils.escapeXml11(uverseAcc?.BusinessAccountName),
			billingCustomerBusinessType : billingCustomerBusinessType,
			billingCustomerIncorporationDateRefusedFlag : 'true',
			billingCustomerTaxId : uverseAcc?.BillingInfo ? uverseAcc?.BillingInfo[0]?.Authentication?.FederalTaxId : null ,
			billingCustomerState : parsedAddress.State,
			ubConvergedBillIndicator : isUnifyWirelessPresent(order),
			passcode : uverseAcc?.PassCode,
			BillingCustomerCreditScore : billingCustomerCreditScore,
			billingLanguagePreference : getLangPref(uverseAcc)
		]
		return cusaReq
	}


	private def getPrimaryContact(def order, def uverseAcc, def accountName)
	{
		int index = 0
		def primaryCon = []
		Date now = new Date()
		SimpleDateFormat timestamp = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss")
		def mobileNum
		if(accountName?.AdditionalContactPhone && accountName?.AdditionalContactPhone[index]?.PhoneNumber && accountName?.AdditionalContactPhone[index]?.ContactPhoneType == WirelineConstants.CUSA_CONTACTPHONE_TYPE )
		{
			mobileNum = accountName?.AdditionalContactPhone[index]?.PhoneNumber
		}
		def scqIndicator = getScqIndicator(uverseAcc)
		def transactionId = getTransactionId(uverseAcc)
		def creditRisk = getCreditRisk(uverseAcc)
		def creditRefDate = CommonUtility.formatDate(String.valueOf(order?.SubmitedDate),"yyyy-MM-dd'T'HH:mm:ssZ")//order?.SubmittedDate
		def BillingInfo = uverseAcc?.BillingInfo

		for(def i=0;i<BillingInfo.size();i++)
		{
			def nameRef = BillingInfo[i]?.NameRef
			def accName = OrderUtility.getName(order,nameRef)
			def alternatePhone = getAlternatePhone(order,accName)
			def alternatePhoneType = getAlternatePhoneType(accName)


			def role
			def owner
			def b2b = order?.B2Bs?.B2B.find{a-> a?.Id==uverseAcc?.B2BRef}
			def ownerAcc = new ArrayList()
			ownerAcc = uverseAcc?.BillingInfo.findAll{ bi -> bi?.BillingType == "OWNER"}
			def ownerCount = ownerAcc.size();
			if(i==0 && uverseAcc?.BillingInfo[0].BillingType == "OWNER")
			{
				owner = "owner1"
			}
			else if(ownerCount>0)
			{
				owner = "owner2"
			}
			if(uverseAcc?.BillingInfo[i].BillingType == "AUTHORIZED")
			{
				role = "Authorized"
			}
			else if(uverseAcc?.BillingInfo[i].BillingType == "OWNER")
			{
				if(b2b?.BusinessType.toLowerCase() == "PARTNERSHIP".toLowerCase() )
				{
					if(owner=="owner1")
					{
						role = "Primary"
					}
					else if(owner=="owner2")
					{
						role = "Partner"
					}
				}
				if(b2b?.BusinessType.toLowerCase() in ["LLC".toLowerCase() ,"Corporation".toLowerCase()])
				{
					if(owner=="owner1")
					{
						role = "Primary"
					}
					else if(owner=="owner2")
					{
						role = "Authorized"
					}
				}
				if(b2b?.BusinessType.toLowerCase() == "SoleProprietorship".toLowerCase())
				{
					role = "Primary"
				}
			}
			def creditScoreExt
			// For IST testing !OrderUtility.isSMB(order) is reverted
			if(!OrderUtility.isSMB(order)){
				creditScoreExt = [
									adverseLetterIndicator : WirelineConstants.STRING_TRUE,
									scqWirelessIndicator : scqIndicator,
									transactionId : transactionId,
									creditScoreDate : creditRefDate,
									creditRisk : creditRisk,
									eidNumber : uverseAcc?.CreditCheck?.EIDNumber
								]
			}

			def primaryContactVar =
					[
						phoneType : "WORK_PHONE",
						preferredMode : "EMAIL",
						preferredTime : order?.OrderContact?.PreferredTimeOfDayForContact ? order?.OrderContact?.PreferredTimeOfDayForContact : WirelineConstants.CUSA_PREFERRED_TIME,
						authenticationQuestion : uverseAcc?.BillingInfo[i]?.Authentication?.SecurityVerification?.SecurityQuestion,
						authenticationAnswer : uverseAcc?.BillingInfo[i]?.Authentication?.SecurityVerification?.SecurityAnswer,
						role : role,
						productOfInterest : WirelineConstants.CUSA_PRODUCTOF_INTEREST,
						dateOfBirth : uverseAcc?.BillingInfo[i]?.Authentication?.DOB,
						updateStamp : timestamp.format(now),
						firstName : accName?.FirstName,
						lastName : accName?.LastName,
						phone : getPhone(accName, BillingInfo[i], order),
						mobile : mobileNum,
						CreditScoreExt : creditScoreExt,
						alternatePhone : alternatePhone,
						altenatePhoneType : alternatePhoneType,
						SSN : uverseAcc?.BillingInfo[i]?.Authentication?.SSN,
						emailCanBeUsedFlag : WirelineConstants.STRING_TRUE,
						email : getEmail(BillingInfo[i], order)
					]
			primaryCon.add(primaryContactVar)
		}

		return [PrimaryContact : primaryCon]
	}

	private def getPhone(def billAccName, def billingInfo, order) {
		def phone
		if(billingInfo?.BillingType == "AUTHORIZED") {
			def name = order.OrderContact.NameRef
			def accName = OrderUtility.getName(order,name)
			if(accName?.PrimaryContactPhone) {
				phone = accName?.PrimaryContactPhone[0]?.PhoneNumber
			}
		} else {
			if(billAccName?.PrimaryContactPhone) {
				phone = billAccName?.PrimaryContactPhone[0]?.PhoneNumber
			}
		}
		return phone
	}

	private def getEmail(def billingInfo, order) {
		def email
		def nameRef = billingInfo?.NameRef
		def accName = OrderUtility.getName(order,nameRef)

		if(billingInfo?.BillingType == "AUTHORIZED")
		{
			email = order.OrderContact?.PrimaryEmailAddress
		}
		else if(accName?.EmailAddress!=null)
		{
			email = accName.EmailAddress
		}
		return email
	}

	private def getServiceMapAddress(def order, def ITPAResponse, def fieldedAddress, def addressMap, String type, def timestamp)
	{
		Date now = new Date()
		def locationProp = ITPAResponse?.ProductLSDTVW?.LocationMatchAvailabilityResults?.ExactLocationAvailabilityResults?.LocationProperties?.LocationProperties
		def addressfield = StringUtils.join([fieldedAddress?.houseNumber?.text(),fieldedAddress?.streetName?.text(),fieldedAddress?.streetThoroughfare?.text()], ' ')
		def serviceMap =
				[
					type : type,
					updateStamp : timestamp.format(now),
					siteId : 0,
					address1 : addressfield,
					isValid : WirelineConstants.CUSA_IS_VALID,
					clli8 : locationProp?.sbcServingOfficeWirecenter,
					county : fieldedAddress?.county,
					houseNumber : fieldedAddress?.houseNumber,
					legalEntity : locationProp?.legalEntity,
					npaNXX : locationProp?.primaryNpaNxx,
					smartMovesFlag : getSmartMovesFlag(locationProp),
					street : fieldedAddress?.streetName,
					thoroughFare : fieldedAddress?.streetThoroughfare,
					subtype : WirelineConstants.CUSA_SUBTYPE,
					vho : locationProp?.videoHubOffice,
					zip4 : getpostalCodePlus4(fieldedAddress),
					//zip4 : fieldedAddress?.postalCodePlus4,
					city : fieldedAddress?.city,
					state : fieldedAddress?.state,
					zip : fieldedAddress?.postalCode,
					amnqAddressId : addressMap?.AddressId
				]
		return serviceMap
	}

	def getpostalCodePlus4(fieldedAddress)
	{
		def zip4 = fieldedAddress?.postalCodePlus4?.text()
		
		println("ZIP4 : " + fieldedAddress?.postalCodePlus4)
		
		if(zip4 && !"".equals(zip4))
		{
			return zip4
		}
		else
		{
			return null
		}
	}
	
	def getTransactionId(def uverseAcc){
		def transactionId

		if(uverseAcc?.CreditCheck?.CCMTransactionID) {
			transactionId = uverseAcc?.CreditCheck?.CCMTransactionID
		}
		else {
			transactionId = WirelineConstants.CUSA_TRANSACTION_ID_UNKNOWN
		}
		return transactionId
	}

	def getCreditRisk(def uverseAcc){
		def creditRisk

		if(uverseAcc?.CreditCheck?.CreditClass == WirelineConstants.CUSA_CREDIT_CLASS_HIGH) {
			creditRisk = WirelineConstants.CUSA_CREDIT_High
		}
		else if(uverseAcc?.CreditCheck?.CreditClass == WirelineConstants.CUSA_CREDIT_CLASS_LOW) {
			creditRisk = WirelineConstants.CUSA_CREDIT_Low
		}
		else if(uverseAcc?.CreditCheck?.CreditClass == WirelineConstants.CUSA_CREDIT_CLASS_MEDIUM) {
			creditRisk = WirelineConstants.CUSA_CREDIT_Medium
		}
		else if(uverseAcc?.CreditCheck?.CreditClass == WirelineConstants.CUSA_CREDIT_CLASS_UNKNOWN) {
			creditRisk = WirelineConstants.CUSA_CREDIT_Unknown
		}

		return creditRisk
	}

	def getAlternatePhone(def order,def accountName){
		def alternatePhone
		int index = 0

		if(order?.OrderContact?.PreferredContactMethod=="SMS" && accountName?.AdditionalContactPhone &&
		accountName?.AdditionalContactPhone?.ContactPhoneType == WirelineConstants.CUSA_CONTACTPHONE_TYPE &&
		accountName?.AdditionalContactPhone?.PhoneNumber){

			alternatePhone = accountName?.AdditionalContactPhone[index]?.PhoneNumber
		}
		else if(accountName?.PrimaryContactPhone) {
			alternatePhone = accountName?.PrimaryContactPhone[index]?.PhoneNumber
		}
		return alternatePhone
	}

	def getAlternatePhoneType(def accountName){
		def alternatePhoneType
		int index = 0

		if(accountName?.AdditionalContactPhone && accountName?.AdditionalContactPhone?.ContactPhoneType){
			alternatePhoneType = accountName?.AdditionalContactPhone[index]?.ContactPhoneType
		}
		else if(accountName?.PrimaryContactPhone) {
			alternatePhoneType = accountName?.PrimaryContactPhone[index]?.ContactPhoneType
		}
		return alternatePhoneType
	}

	def getSiteId(def parsedAddress) {
		def siteId
		if(parsedAddress != null && parsedAddress.SiteId){
			siteId = parsedAddress.SiteId
		}
		else {
			siteId = 0
		}
		return siteId
	}

	def getAddress1(def parsedAddress) {
		def address1
		if(parsedAddress != null){
			if(parsedAddress.AddressStreetLine) {
				address1 = parsedAddress.AddressStreetLine
			}
			else {
				address1 = parsedAddress.HouseNumber+" "+parsedAddress.StreetName+" "+parsedAddress.StreetType
			}
		}
		return address1
	}

	def getCreditClass(def uverseAcc){
		def creditClass

		if(uverseAcc?.CreditCheck?.CreditClass == WirelineConstants.CUSA_CREDIT_CLASS_HIGH) {
			creditClass = WirelineConstants.CUSA_CREDIT_CLASS_E
		}
		else if(uverseAcc?.CreditCheck?.CreditClass == WirelineConstants.CUSA_CREDIT_CLASS_LOW) {
			creditClass = WirelineConstants.CUSA_CREDIT_CLASS_A
		}
		else if(uverseAcc?.CreditCheck?.CreditClass == WirelineConstants.CUSA_CREDIT_CLASS_MEDIUM) {
			creditClass = WirelineConstants.CUSA_CREDIT_CLASS_B
		}
		else if(uverseAcc?.CreditCheck?.CreditClass == WirelineConstants.CUSA_CREDIT_CLASS_UNKNOWN) {
			creditClass = WirelineConstants.CUSA_CREDIT_CLASS_J
		}
		else{
			creditClass = ''
		}

		return creditClass
	}

	def getPaperBillOption(def uverseAcc){
		def billOption

		if(uverseAcc?.BillingDeliveryPreference == "PAPER") {
			billOption = "F"
		}
		else{
			billOption = "N"
		}

		return billOption
	}

	def getScqIndicator(def account){
		def scqIndicator

		if(account?.CreditCheck?.SingleCreditQueryWirelessIndicator) {
			scqIndicator = account?.CreditCheck?.SingleCreditQueryWirelessIndicator
		}
		else {
			scqIndicator = WirelineConstants.STRING_TRUE
		}
		return scqIndicator
	}

	def getSmartMovesFlag(def locationProp) {
		def smartmoveflag
		if(locationProp?.smartmoves && locationProp?.smartmoves == WirelineConstants.CUSA_SMARTMOVES) {
			smartmoveflag = WirelineConstants.STRING_FALSE
		}
		else {
			smartmoveflag = WirelineConstants.STRING_TRUE
		}
		return smartmoveflag
	}

	def isUnifyWirelessPresent(def order){
		def unifyWls
		def unifyGroup  = order?.Groups?.Group.findAll{a -> a?.LoSGType == "UNIFY" && a?.ProductType == "WIRELESS"}

		if(unifyGroup  != null){
			unifyWls = true
		}
		else{
			unifyWls = false
		}
		return unifyWls
	}

	def getLangPref(def uverseAcc){
		def languagePref

		if((uverseAcc?.BillingLanguagePreference==null) || (uverseAcc?.BillingLanguagePreference == "ENGLISH") || (uverseAcc?.BillingLanguagePreference == "OTHER")) {
			languagePref = WirelineConstants.CUSA_LANG_PREF
		}
		else if(uverseAcc?.BillingLanguagePreference == "SPANISH") {
			languagePref = "Spanish"
		}
		else{
			languagePref = WirelineConstants.CUSA_LANG_PREF
		}
		return languagePref
	}
}
