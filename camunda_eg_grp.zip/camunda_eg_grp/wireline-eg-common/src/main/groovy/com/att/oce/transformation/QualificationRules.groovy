package com.att.oce.transformation

import groovy.json.*

import java.util.ArrayList;
import java.util.Collections
import java.util.Date;
import java.util.List;
import java.util.Map;
import com.att.oce.bpm.utility.PaymentFunctions
import com.att.oce.config.components.GlobalProperties


import org.camunda.bpm.engine.delegate.BpmnError
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component
import com.att.oce.bpm.common.WirelineTransformationService
import com.att.oce.bpm.utility.OrderUtility
import com.att.oce.bpm.common.QualificationConfigConstants
import com.att.oce.bpm.common.WirelineConstants
import com.att.oce.bpm.common.QualificationConfig
import com.att.oce.bpm.utility.VoipFunctions


@Component('qualificationRules')
class QualificationRules /*extends JavaDelegate*/ {

	/*@Override String getApiName(){
	 return "BusinessRulesValidation";
	 }*/

	def errorDesc = "";

	//	@Autowired
	//	protected QualConfig config;

	/*This function is called from BPMN for all types of flow unification/provide/modify  */
	def qualifyOrder(def Order, def executionContext)
	{
			List<String> qualErrorList = new ArrayList<String>();
		
	
			
			if(OrderUtility.getcheckForWirelineProvideFlow(Order) == true)
			{
				CheckDTVReferralExists(Order, qualErrorList)
				checkSafeScan(Order, qualErrorList)
				CheckAuthenticationQuestion(Order, qualErrorList)
				dateOfBirth(Order, qualErrorList)
				
			}
			
			if(OrderUtility.getcheckForWirelineModifyFlow(Order) == true)
			{
				
				checkIfAutoBillStatusForHighRiskCustomer(Order, qualErrorList)//UNIT TEST
				
			}
			
		try {
			QualificationChecksForVOIP(Order, qualErrorList)
			ProvideModifyChecks(Order, qualErrorList)
			CommonAutomationChecks(Order, qualErrorList)
			CheckSalesChannel(Order, qualErrorList)
			CheckCreditCard(Order, qualErrorList)
			
		} catch (Exception e) {
			OrderUtility.throwBPMNError(e, Order, executionContext);
		}
		return qualErrorList
	}


	/* Checks required for all type of flows unification/provide/modify  */
	public def CommonAutomationChecks(def Order, def qualErrorList)
	{

		checkOfferId(Order, qualErrorList)
		checkLPMInfoExists(Order, qualErrorList)
		checkAutopayLPMTermsandConditions(Order, qualErrorList)
		checkMobilityBAN(Order, qualErrorList) //BAN FOR COMMON
		checkUverseBAN(Order, qualErrorList) //BAN FOR COMMON

		return qualErrorList
	}
	
	/* Checks required for all type of flows provide/modify  */
	
	public def ProvideModifyChecks(def Order, def qualErrorList)//YELLOW IN SHEET
	{
		def voipGrpRef=""
		def desc=""
		checkCAPM(Order, qualErrorList)
		checkServiceAddress(Order, qualErrorList)
		checkMorethanOnePaymentOptionForAutopay(Order, qualErrorList)
		checkForShippingAddressNotVerified(Order, qualErrorList)
		checkACHDetailsExists(Order, qualErrorList)
//		checkForConflictingServices(Order, voipGrpRef, qualErrorList, desc)
		checkIfAutopayForHighRiskCustomer(Order, qualErrorList)
		checkForCAPMProfileName(Order, qualErrorList)
		checkIsPOTSAvailable(Order, qualErrorList)
		IsDSLAvailable(Order, qualErrorList)
		CreditCardMissing(Order, qualErrorList)
		SalesChannelMissing(Order, qualErrorList)
		CheckMultipleInstallmentTerms(Order, qualErrorList)

		return qualErrorList
	}

	/* check if Date of Birth is missing */
	public def dateOfBirth(def Order, def qualErrorList)
	{


		def UverseAccount = OrderUtility.getUverseAcount(Order);
		if(UverseAccount != null && UverseAccount.BillingInfo?.Authentication?.DOB == null) {

			//				def QualConfig = QualificationConfigConstants.QUALIFICATION_CONFIG.get("DateOfBirthExist")
			qualErrorList.add("DateOfBirthDoesNotExist");
		}
		return qualErrorList
	}

	/* check if AuthenticationQuestion is missing */
	public def CheckAuthenticationQuestion(def Order, def qualErrorList)
	{
		def UverseAccount = OrderUtility.getUverseAcount(Order);
		if(UverseAccount != null && UverseAccount.BillingInfo?.Authentication?.SecurityVerification?.SecurityQuestion == null) {
			qualErrorList.add("AuthenticationQuestionDoesNotExist");
		}
		return qualErrorList
	}

	/* Check Multiple Instalment Billing Exists */
	public def CheckMultipleInstallmentTerms(def Order, def qualErrorList)
	{


		def AdditionalDetailList = Order.AdditionalDetails?.AdditionalDetail

		if(AdditionalDetailList) {
			for(def i=0;i<AdditionalDetailList.size();i++){
				def AdditionalDetailMap=AdditionalDetailList.get(i)
				if(AdditionalDetailMap?.Type == 'INSBL' && AdditionalDetailMap?.Code == 'MULTI_INSTL_TERMS' ){
					if (AdditionalDetailMap.Value == WirelineConstants.STRING_TRUE)
						qualErrorList.add("MultipleInstallmentTermsTrue");
				}
			}
		}
		return qualErrorList

	}

	/*check if SafeScanAlertIndicator exists and true(),
	If SafeScanPassIndicator exists and true(), then qualify the order else Safe scan error and will disqualify the order.
	this check is for all three flows -- unify, provide and modify*/
	public def checkSafeScan(def Order, def qualErrorList)
	{
		def UverseAccount = OrderUtility.getUverseAcount(Order);
		if(UverseAccount?.CreditCheck?.SafeScanAlertIndicator) {

			if(UverseAccount?.CreditCheck?.SafeScanPassIndicator)
			{
			}
			else{
				qualErrorList.add("SafeScanVerification");
			}
		}
		else
		{

		}
		return qualErrorList
	}

	/* Check if DTV Referral exists */
	public def CheckDTVReferralExists(def Order, def qualErrorList)
	{
		def LineofServiceGroup = OrderUtility.getLosgsFromOrder(Order);
		for(def i=0; i<LineofServiceGroup?.size(); i++){
			def groupMap = LineofServiceGroup.get(i);

			if(groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == WirelineConstants.LoSGType_NEW &&
			groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == WirelineConstants.PRODUCTCATEGORY_DTV){

				def AdditionalDetailList = groupMap?.GroupCharacteristics?.LoSGCharacteristics?.AdditionalDetails?.AdditionalDetail
				for(def j=0; j<AdditionalDetailList?.size(); j++){
					def AdditionalDetailMap = AdditionalDetailList.get(j);

					if (AdditionalDetailMap?.Code == WirelineConstants.dtvRefAccNum){

					}
					else {
						qualErrorList.add("DTVReferralExists");
					}
				}
			}
		}
		return qualErrorList
	}

	/* check if Sales Channel is missing*/
	public def CheckSalesChannel(def Order, def qualErrorList)
	{
		if(Order.OrderSource?.Channel == null){
			qualErrorList.add("SalesChannelDoesNotExist");

		}
		return qualErrorList
	}

	/* check if CreditCardNumber exists or not
	If PaymentMethod is CreditCard then CreditCardNumber needs to be there. */
	public def CheckCreditCard(def Order, def qualErrorList)
	{
		def CreditCardPaymentList = Order.PaymentOptions?.PaymentOption

		for(def i=0;i<CreditCardPaymentList?.size();i++){
			def CreditCardPaymentListMap = CreditCardPaymentList.get(i)
			if(CreditCardPaymentListMap?.PaymentMethod?.CreditCard != null){
				if (CreditCardPaymentListMap?.PaymentMethod?.CreditCard?.CreditCardNumber != null){

				}
				else
				{
					qualErrorList.add("CreditCardExists");
				}
			}
		}
		return qualErrorList
	}

	/*  check if DSL Indicator value ServiceFacilityQualifications
	If exists value should be 'false' other wise fallout
	this check is applicable only if Order has gigapower Indicator as true*/
	public def IsDSLAvailable(def Order, def qualErrorList)
	{
		def ServiceFacilityQualificationList = Order.ServiceFacilityQualifications?.ServiceFacilityQualification
		if(ServiceFacilityQualificationList != null){
			for(def i=0;i<ServiceFacilityQualificationList.size();i++){
				def ServiceFacilityQualificationMap = ServiceFacilityQualificationList.get(i)
				if(ServiceFacilityQualificationMap?.IsDSLAvailable == true){
					qualErrorList.add("checkIsDSLAvailable");
				}
			}
			return qualErrorList
		}
	}

	/* check if POTS Indicator value ServiceFacilityQualifications
	If exists value should be 'false' other wise fallout
	this check is applicable only if Order has gigapower Indicator as true */
	public def checkIsPOTSAvailable(def Order, def qualErrorList)
	{
		def ServiceFacilityQualificationList = Order.ServiceFacilityQualifications?.ServiceFacilityQualification
		if(ServiceFacilityQualificationList != null){
		for(def i=0;i<ServiceFacilityQualificationList.size();i++){
			def ServiceFacilityQualificationMap=ServiceFacilityQualificationList.get(i)
			if(ServiceFacilityQualificationMap?.IsPOTSAvailable == null || !ServiceFacilityQualificationMap?.IsDSLAvailable){
				
			}
				else
					qualErrorList.add("checkIsPOTSAvailable");
			}
		}
		
		return qualErrorList
	}

	/* check if Last payment method Info exists
	If payment method is LPM, then LPM reference# should be present
	this check is for all three flows -- unify, provide and modify */
	public def checkLPMInfoExists(def Order, def qualErrorList)
	{
		def PaymentOptionsList = Order.PaymentOptions?.PaymentOption

		for(def i=0;i<PaymentOptionsList?.size();i++){
			def PaymentOptionsMap=PaymentOptionsList?.get(i)
			if(PaymentOptionsMap?.PaymentMethod?.LastPaymentMethod != null){
				if (PaymentOptionsMap?.PaymentMethod?.LastPaymentMethod?.LPMReferenceNumber != null){

				}
				else
					qualErrorList.add("CheckLPMInfoExists");
			}
		}
		return qualErrorList
	}

	/* check if Last payment method Info exists
	If payment method is LPM, then customer agreement version should be present
	this check is for all three flows -- unify, provide and modify */
	public def checkAutopayLPMTermsandConditions(def Order, def qualErrorList)
	{
		def PaymentOptionsList = Order.PaymentOptions?.PaymentOption

		for(def i=0;i<PaymentOptionsList?.size();i++){
			def PaymentOptionsMap=PaymentOptionsList?.get(i)
			if(PaymentOptionsMap?.PaymentMethod?.LastPaymentMethod != null){
				if (PaymentOptionsMap?.PaymentMethod?.LastPaymentMethod?.CustomerAgreementVersion != null){

				}
				else
					qualErrorList.add("CheckAutopayLPMTermsConditions");
			}
		}
		return qualErrorList
	}

	/* Check for offerId in order if it is AccountSubCategory is NEW */
	public def checkOfferId(def Order, def qualErrorList)
	{
		def UverseAccount = OrderUtility.getUverseAcount(Order);
		def isOfferGrp = false

		if(UverseAccount?.AccountSubCategory == WirelineConstants.AccountSubCategory_NEW) {
			def groupList=Order.Groups?.Group

			for(def i=0;i<groupList?.size();i++){
				def groupMap=groupList.get(i)

				if(groupMap?.GroupCharacteristics?.PackageCharacteristics?.Category == 'OFFER'
					&& groupMap?.GroupCharacteristics?.PackageCharacteristics?.Code){
					isOfferGrp = true
					break
				}
			}
			if(!isOfferGrp) {
				qualErrorList.add("checkForOfferId")
			}
		}
		return qualErrorList

	}

	/*This function checks if CAPM tag is present and Order has 'AutoPay' option
	then profileOwnerId should be less than 9 characters.
	This check is used only in Provide and Modify flow.*/
	public def checkCAPM(def Order, def qualErrorList)
	{
		def PaymentRefAutoPay = PaymentFunctions.getPaymentRefforAutoPayId(Order)
		def PaymentOptionList=Order.PaymentOptions?.PaymentOption
		for(def i=0;i<PaymentOptionList?.size();i++){
			def PaymentOptionMap=PaymentOptionList?.get(i)
			def PaymentOptionId = PaymentOptionMap?.Id

			if(PaymentRefAutoPay!= null && PaymentOptionId== PaymentRefAutoPay){
				if (PaymentOptionMap?.PaymentMethod?.CAPM != null){
					if (PaymentOptionMap?.PaymentMethod?.CAPM?.ProfileOwnerId?.length() > 9){
						qualErrorList.add("checkForCAPMID");
					}
				}
			}

		}
		return qualErrorList
	}

	/* Check for check ACHDetailsExists in order */
	public def checkACHDetailsExists(def Order, def qualErrorList)
	{
		def PaymentRefAutoPay = PaymentFunctions.getPaymentRefforAutoPayId(Order)
		def paymentRef_AdvancePay = PaymentFunctions.getPaymentRefforAdvancePayId(Order)

		def PaymentOptionList=Order.PaymentOptions?.PaymentOption
		for(def i=0;i<PaymentOptionList?.size();i++){
			def PaymentOptionMap=PaymentOptionList?.get(i)
			def PaymentOptionId = PaymentOptionMap?.Id

			if((PaymentRefAutoPay!= null && PaymentOptionId == PaymentRefAutoPay) || (paymentRef_AdvancePay!= null && PaymentOptionId == paymentRef_AdvancePay) ){
				if(PaymentOptionId != null && PaymentOptionMap?.PaymentMethod?.ACH){

					def paymentMehtod = PaymentOptionMap.PaymentMethod?.ACH?.BankAccountDetails
					//def ach = paymentMehtod.ACH.BankAccountDetails

					//def accNumber = ach.AccountNumber

					if (paymentMehtod?.AccountHolderName != null
					&& paymentMehtod?.AccountNumber != null
					&& paymentMehtod?.RoutingNumber != null
					&& paymentMehtod?.AccountType != null){

					} else {
						qualErrorList.add("CheckACHDetailsExists");
					}

				}
			}
		}
		return qualErrorList
	}

	/*check if Autopay Could Not be Determined For High Risk Customer
	if CreditClass value is High or Unknown and AutoBillIndicator is N or blank then we fallout the order
	this check is only for provide and modify flows */
	public def checkIfAutopayForHighRiskCustomer(def Order, def qualErrorList)
	{
//		def CreditClassHigh = "High"
//		def CreditClassUnknown="Unknown"
		if (Order.CreditPolicy?.CRSMOnFlag == true){

		}
		else{
			def AccountList=Order.Accounts?.Account
			for(def i=0;i<AccountList?.size();i++){
				def AccountMap=AccountList?.get(i)
				if(AccountMap?.CreditCheck?.CreditClass == WirelineConstants.CUSA_CREDIT_High || AccountMap?.CreditCheck?.CreditClass == WirelineConstants.CUSA_CREDIT_Unknown){
					def PaymentOptionList=Order.PaymentOptions?.PaymentOption
					for(def j=0;j<PaymentOptionList?.size();j++){
						def PaymentOptionMap=PaymentOptionList?.get(j)
						if(PaymentOptionMap?.AutoBillIndicator!= null){
							if(PaymentFunctions.doesOrderhaveAutopay(Order))
							{

							}
							else
								qualErrorList.add("AutopayCouldNotbeDeterminedForHighRiskCustomer");
						}

					}
				}
			}
		}
		return qualErrorList
	}

	/* Check for MorethanOnePaymentOptionForAutopay in order. Used in Provide and Modify flow */
	public def checkMorethanOnePaymentOptionForAutopay(def Order, def qualErrorList){

		def LineItemList=Order.LineItems?.LineItem
		def paymentCount = 0
		for(def i=0;i<LineItemList?.size();i++){
			def LineItemMap=LineItemList?.get(i)

			if(LineItemMap?.SystemName == WirelineConstants.LINEITEM_DISPLAY_NAME_AUTO_PAY ){
				def PaymentList = LineItemMap?.Payments?.Payment

				for(def j=0;j<PaymentList?.size();j++){

					def PaymentMap = PaymentList.get(j)
					paymentCount++
				}
			}
		}

		if(paymentCount>1){
			qualErrorList.add("MorethanOnePaymentOptionForAutopay");
		}
		return qualErrorList

	}

	/*check In the frontend, when a AddWirelinePaymentProfile CSI is invoked and if the Service is down the response for the
	profile name returned is 'EAY5IGY800000000' then automation will disqualify the order and fall it out to manual queue*/
	public def checkForCAPMProfileName(def Order, def qualErrorList){
		def PaymentOptionList=Order.PaymentOptions?.PaymentOption
		for(def i=0;i<PaymentOptionList?.size();i++){
			def PaymentOptionMap=PaymentOptionList?.get(i)

			if(PaymentOptionMap?.PaymentMethod?.CAPM != null){
				if(PaymentOptionMap?.PaymentMethod?.CAPM.ProfileName == WirelineConstants.CAPM_INVALID_PROFILE_EAY5IGY800000000){
					qualErrorList.add("checkCAPMProfileName");
				}
			}
		}
		return qualErrorList
	}

	/*Check for ServiceAddress in order
	Used in Provide and Modify flow*/
	public def checkServiceAddress(def Order, def qualErrorList){
		
		def modifyorNewUverseIPTVorHSIALOSGCharacteristics = OrderUtility.getModifyorNewUverseServiceQualificationRef(Order)
		
		def ServiceFacilityQualification = Order.ServiceFacilityQualifications?.ServiceFacilityQualification
		if(ServiceFacilityQualification != null){
		for(def i=0;i<ServiceFacilityQualification?.size();i++){
			def ServiceFacilityQualificationMap = ServiceFacilityQualification.get(i)
			if(modifyorNewUverseIPTVorHSIALOSGCharacteristics?.contains(ServiceFacilityQualificationMap?.Id)){
				def ServiceAddressRef = ServiceFacilityQualificationMap?.AddressRef

				def AddressList = Order.Addresses?.Address
				for(def j=0;j<AddressList?.size();j++){
					def AddressMap=AddressList?.get(j)
					if(AddressMap?.Id == ServiceAddressRef){
						if(AddressMap?.AddressId != null){}
						else
							qualErrorList.add("checkForServiceAddress");
					}

				}
			}
		}
		}
		return qualErrorList
	}

	/*For VOIP related qualification checks and flow type is Provide or Modify
	This function will perform the checks for all the VOIP lines received in the order payload
	
	*Porting Address Not Verfied
	*Porting Eligibility Line Response Does not Exists
	*Porting Accounts Not Same
	*Porting Address Not Same*/
	public def QualificationChecksForVOIP(def Order , def qualErrorList)
	{

		def countVoipGrps = VoipFunctions.getVOIPLineCountInOrder(Order)
		def voipPGrpRef = VoipFunctions.getVoipPrimaryGrpRef(Order)
		def PortAdd1NotVerfied, PortEligLine1RespDoesnotExists, checkPortingAccountsNotSame
		def PortAdd2NotVerfied, PortEligLine2RespDoesnotExists, checkPortingAddressNotSame

		if(countVoipGrps > 0){
			if(countVoipGrps == 1){
				if(voipPGrpRef != null){
					PortAdd1NotVerfied = checkForPortingAddressNotVerfied(Order, voipPGrpRef, qualErrorList, "PortingAddress1NotVerfied")
					PortEligLine1RespDoesnotExists = checkForPortingEligibilityLineRespDoesnotExists(Order, voipPGrpRef,qualErrorList, "PortingEligibilityLine1RespDoesnotExists")
				}
			}
			else{
				def voipAGrpRef = VoipFunctions.getVoipAdditionalGrpRef(Order)
				if(voipPGrpRef != null && voipAGrpRef != null){
					PortAdd1NotVerfied = checkForPortingAddressNotVerfied(Order, voipPGrpRef, qualErrorList, "PortingAddress1NotVerfied")
					PortEligLine1RespDoesnotExists = checkForPortingEligibilityLineRespDoesnotExists(Order, voipPGrpRef, qualErrorList, "PortingEligibilityLine1RespDoesnotExists")
					PortAdd2NotVerfied = checkForPortingAddressNotVerfied(Order, voipAGrpRef, qualErrorList, "PortingAddress2NotVerfied")
					PortEligLine2RespDoesnotExists = checkForPortingEligibilityLineRespDoesnotExists(Order, voipAGrpRef, qualErrorList, "PortingEligibilityLine2RespDoesnotExists")
					checkPortingAccountsNotSame = checkIfPortingAccountsNotSame(Order, voipPGrpRef, voipAGrpRef, qualErrorList)
					checkPortingAddressNotSame = checkIfPortingAddressNotSame(Order, voipPGrpRef, voipAGrpRef, qualErrorList)
				}
			}
		}

		return qualErrorList
	}

	/* check for Porting Address Not Verfied generic function */
	public def checkForPortingAddressNotVerfied(def Order, def voipGrpRef, def qualErrorList, def desc){
		def groupList=Order.Groups?.Group

		for(def i=0;i<groupList?.size();i++){
			def groupMap=groupList?.get(i)

			if(voipGrpRef != null && groupMap?.Id == voipGrpRef){
				if(groupMap?.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo?.PreviousAddressRef != null){
					def PreviousAddressRef = groupMap?.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo?.PreviousAddressRef
					def AddressList=Order.Addresses?.Address
					for(def j=0;j<AddressList?.size();j++){
						def AddressMap=AddressList?.get(j)
						if(PreviousAddressRef!=null && AddressMap?.Id == PreviousAddressRef){
							if(AddressMap?.ParsedAddress!= null){

							} else {
								qualErrorList.add(desc);
							}
						}
					}

				}
			}
		}
		return qualErrorList
	}

	/* check if Porting Accounts are Not Same */
	public def checkIfPortingAccountsNotSame(def Order, def voipPGrpRef,def voipAGrpRef, def qualErrorList){
		def groupList=Order.Groups?.Group
		def NumberPortInfoP
		def NumberPortInfoA
		
		Order.Groups?.Group.each { grp ->
			if(voipPGrpRef != null && grp?.Id == voipPGrpRef )
				NumberPortInfoP = grp?.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo
			
			if(voipAGrpRef != null && grp?.Id == voipAGrpRef )
				NumberPortInfoA = grp?.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo
		}
		
		if(voipAGrpRef == null) {
			if(NumberPortInfoP?.NonATTPortIn == WirelineConstants.EC_VAL_NO)
				qualErrorList.add("PortingAccountsNotSame");
		} else {
			if(NumberPortInfoP?.NonATTPortIn == WirelineConstants.EC_VAL_NO && NumberPortInfoA?.NonATTPortIn == WirelineConstants.EC_VAL_NO)
				qualErrorList.add("PortingAccountsNotSame");
		}
		
		/*for(def i=0;i<groupList.size();i++){
			def groupMap=groupList.get(i)

			if(groupMap.Id == voipPGrpRef){
				if(groupMap.GroupCharacteristics.LoSGCharacteristics.NumberPortInfo != null){
					NumberPortInfoP = groupMap.GroupCharacteristics.LoSGCharacteristics.NumberPortInfo
					
					}
					else{
						if(groupMap.Id == voipAGrpRef){
							NumberPortInfoA = groupMap.GroupCharacteristics.LoSGCharacteristics.NumberPortInfo
							
						}
					}

				}
			}
		if(voipAGrpRef == null){
			if(NumberPortInfoP.NonATTPortIn == WirelineConstants.EC_VAL_NO){
				qualErrorList.add("PortingAccountsNotSame");
			}
		}
		else{
			if(NumberPortInfoP.NonATTPortIn == WirelineConstants.EC_VAL_NO && NumberPortInfoA.NonATTPortIn == WirelineConstants.EC_VAL_NO){
				qualErrorList.add("PortingAccountsNotSame");
			}
		}*/
		return qualErrorList
	}

	/*check if Porting Eligibility Line Response Does not Exists generic function*/
	public def checkForPortingEligibilityLineRespDoesnotExists(def Order, def voipGrpRef, def qualErrorList, def desc){
		def groupList=Order.Groups?.Group

		for(def i=0;i<groupList?.size();i++){
			def groupMap=groupList?.get(i)

			if(voipGrpRef != null && groupMap?.Id == voipGrpRef){
				if(groupMap?.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo != null){
					def NumberPortInfo = groupMap?.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo
					if(NumberPortInfo?.PortTelephoneNumber != null){
						if(NumberPortInfo?.PortEligibility == null || NumberPortInfo?.PortEligibility == WirelineConstants.EC_VAL_NO){

						}
						qualErrorList.add(desc);//common error
					}

				}
			}
		}
		return qualErrorList
	}

	public def checkIfPortingAddressNotSame(def Order, def voipPGrpRef,def voipAGrpRef, def qualErrorList){
		def groupList=Order?.Groups?.Group
		def NumberPortInfoP
		def NumberPortInfoA
		def parsedAddressA
		def parsedAddressP
		for(def i=0;i<groupList?.size();i++){
			def groupMap=groupList?.get(i)

			if(groupMap?.Id == voipPGrpRef){
				if(groupMap?.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo != null){
					NumberPortInfoP = groupMap?.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo
				}

			}
			if(groupMap?.Id == voipAGrpRef){
				NumberPortInfoA = groupMap?.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo
			}


		}
		Order.Addresses?.Address.each{ add ->

			if(add?.Id == NumberPortInfoP?.PreviousAddressRef){
				parsedAddressP = add?.ParsedAddress
			}


			if(add?.Id == NumberPortInfoA?.PreviousAddressRef){
				parsedAddressA = add?.ParsedAddress
			}
		}


		if(NumberPortInfoP?.NonATTPortIn == WirelineConstants.EC_VAL_YES && NumberPortInfoA?.NonATTPortIn == WirelineConstants.EC_VAL_YES){
			if(parsedAddressA?.AddressStreetLine == parsedAddressP?.AddressStreetLine
			&& parsedAddressA?.HouseNumber == parsedAddressP?.HouseNumber
			&& parsedAddressA?.City == parsedAddressP?.City
			&& parsedAddressA?.StreetName == parsedAddressP?.StreetName
			&& parsedAddressA?.State == parsedAddressP?.State
			&& parsedAddressA?.Zip == parsedAddressP?.Zip){

			}
			else{
				qualErrorList.add("PortingAddressNotSame");
			}
		}

		return qualErrorList
	}
	public def MultipleInstallmentTerms(def Order, def qualErrorList){
		
				def shippingInfo = Order.ShippingInfos?.ShippingInfo
				def uverseGroups = OrderUtility.getUverseGroups(Order)
		
				def groupList=Order.Groups?.Group
		
				for(def i=0;i<groupList?.size();i++){
					def groupMap=groupList?.get(i)
					if(groupMap.Id == uverseGroups){
						if(shippingInfo.Id == groupMap.GroupCharacteristics?.LoSGCharacteristics?.ShippingInfoRef){
							
						}
						else
						{if(WirelineConstants.CONFLICT_FLAG)
							qualErrorList.add("MultipleInstallmentTermsTrue");
							break;
						}
					}
					
				}
		
				return qualErrorList
			}


	
	public def checkForShippingAddressNotVerified(def Order, def qualErrorList){

		def shippingInfo = Order.ShippingInfos?.ShippingInfo
		def uverseGroups = OrderUtility.getUverseGroups(Order)
		def groupList=Order.Groups?.Group
		
		def addIds = shippingInfo.findAll { si -> uverseGroups.GroupCharacteristics.LoSGCharacteristics?.ShippingInfoRef.contains(si.Id) }.collect{it.AddressRef}.flatten()
		
		def adds = Order.Addresses.Address.each {aid ->
			if(addIds.contains(aid.Id) && aid.ParsedAddress == null) {
				qualErrorList.add("ShippingAddressNotVerified");
			}
		}
		
		return qualErrorList
	}
	
	/*public def checkForConflictingServices(def Order, def voipGrpRef, def qualErrorList, def desc){//TBD
		
		def NewUverseLOSGcharacteristicsQualRef = OrderUtility.getNewUverseServiceQualificationRef(Order)
		def losgChar = OrderUtility.checkChangeNo_ChangeUverseLOSG(Order)
		if(losgChar.size()==0){
			def facilityCheck = Order.ServiceFacilityQualifications.ServiceFacilityQualification.findAll {
				sid -> NewUverseLOSGcharacteristicsQualRef.contains(sid.id)
			}.collect{it.FacilityCheck}.minus(null)
			if ( facilityCheck.size()!=0 || NewUverseLOSGcharacteristicsQualRef == null)
			{
				
			}
			else
			{
				if (WirelineConstants.CONFLICT_FLAG)
				qualErrorList.add("ConflictingServicesCouldNotBeCompleted");
			}
		}
		else{
			
		}
		return qualErrorList
	}*/
	
	public def CreditCardMissing(def Order, def qualErrorList){
		def PaymentOptionList=Order.PaymentOptions?.PaymentOption
		for(def i=0;i<PaymentOptionList?.size();i++){
			def PaymentOptionMap=PaymentOptionList?.get(i)

			if(PaymentOptionMap?.PaymentMethod?.CreditCard != null){
				if(PaymentOptionMap?.PaymentMethod?.CreditCard.CreditCardNumber != null){
					qualErrorList.add("CreditCardExists");
					break;
				}
			}
		}
		return qualErrorList
	}
	
		public def SalesChannelMissing(def Order, def qualErrorList){

		if(Order.OrderSource?.Channel != null){
		
		}
		else
		{
			qualErrorList.add("SalesChannelExist");
		}
		return qualErrorList
	}
		
	public def checkIfAutoBillStatusForHighRiskCustomer(def Order, def qualErrorList){
		if (Order.CreditPolicy?.CRSMOnFlag == true){

		}
		else{
			def AccountList=Order.Accounts?.Account
			for(def i=0;i<AccountList?.size();i++){
				def AccountMap=AccountList?.get(i)
				if( WirelineConstants.CUSA_CREDIT_High.equalsIgnoreCase(AccountMap?.CreditCheck?.CreditClass) 
					|| WirelineConstants.CUSA_CREDIT_Unknown.equalsIgnoreCase(AccountMap?.CreditCheck?.CreditClass) ){

					println("### AccountMap?.ExistingAutobillStatus = " + AccountMap?.ExistingAutoBillStatus)
					if(AccountMap?.ExistingAutoBillStatus == null || AccountMap?.ExistingAutoBillStatus?.trim() == ""){
						qualErrorList.add("AutopayStatusCouldNotbeDeterminedForHighRiskCustomer");
						break;
					}
				}

			}
		}
		return qualErrorList
	}
	
public def checkUverseBAN(def Order, def qualErrorList){

		if(checkBANForExistingUverse(Order) && checkBANForNewUverse(Order)){
		}
		else
		{
			qualErrorList.add("checkForBAN");
		}
		return qualErrorList
	}

			public def checkBANForNewUverse(def Order){
	
	
			def uverseNewAccount = Order.Accounts?.Account.findAll {
				acc -> acc.AccountCategory == WirelineConstants.ACCOUNTCATEGORY_UVERSE && acc.AccountSubCategory == WirelineConstants.AccountSubCategory_NEW
			}.collect{it}.flatten().minus(null)
			
			def mobilityNewAccount = Order.Accounts?.Account.findAll {
				acc -> acc.AccountCategory == WirelineConstants.ACCOUNTCATEGORY_MOBILITY_ACCOUNT && acc.AccountSubCategory == WirelineConstants.AccountSubCategory_NEW
			}.collect{it}.flatten().minus(null)
			
			if(uverseNewAccount && uverseNewAccount.size > 0) {
				if(mobilityNewAccount && mobilityNewAccount.size() > 0) {
					if(uverseNewAccount?.BillingAccountNumber != null){
						return true
					} else {
						return false
					}
				} else {
					return true
				}
			} else {
				return true
			}
			}
	
		public def checkBANForExistingUverse(def Order) {
	
			def AccountList=Order.Accounts?.Account
	
			for(def i=0;i<AccountList?.size();i++){
				def AccountMap=AccountList?.get(i)
				if(AccountMap?.AccountCategory == WirelineConstants.ACCOUNTCATEGORY_UVERSE && AccountMap?.AccountSubCategory == WirelineConstants.AccountSubCategory_EXISTING){
	
					if(AccountMap?.AccountCategory == WirelineConstants.ACCOUNTCATEGORY_UVERSE && AccountMap?.BillingAccountNumber != null){
						return true
					}
					else
						return false
				}
				else
					return true
			}
		}
		
public def checkMobilityBAN(def Order, def qualErrorList){

		def groupList=Order.Groups?.Group

		for(def i=0;i<groupList?.size();i++){
			def groupMap=groupList?.get(i)
			if(groupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == WirelineConstants.ProductCategory_WIRELESS){
				def AccountList=Order.Accounts?.Account

				for(def j=0;j<AccountList?.size();j++){
					def AccountMap=AccountList?.get(j)
					if(AccountMap?.AccountCategory == WirelineConstants.ACCOUNTCATEGORY_MOBILITY_ACCOUNT && AccountMap?.BillingAccountNumber != null){

					}
					else
					{
						qualErrorList.add("checkForBAN");
					}
				}
			}
		}
		return qualErrorList
	}
	
	
	

}
