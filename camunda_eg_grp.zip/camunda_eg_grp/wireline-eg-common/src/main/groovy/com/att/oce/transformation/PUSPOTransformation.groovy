package com.att.oce.transformation

import org.springframework.stereotype.Component;
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import com.att.oce.bpm.common.WirelineConstants;
import com.att.oce.bpm.error.APIFailedException;
import org.apache.camel.Exchange
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.common.WirelineTransformationService;
import com.att.oce.bpm.utility.OrderUtility
import org.apache.commons.lang3.StringEscapeUtils;
import com.att.oce.bpm.common.util.ErrorBean;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.apache.commons.lang3.StringUtils;

@Component('puspotransformation')
class PUSPOTransformation  extends WirelineTransformationService {
	static Logger log = LoggerFactory.getLogger(PUSPOTransformation.class)
	
	String url;
	
	@Override String getApiName()
	{
		return 'ProcessUnifiedServiceProductOrder';
	}
	
	public String getApiUrn() {
		return "urn:csi:services:oms:ProcessUnifiedServiceProductOrder.jws";
	}
	
	/*
	 * Method to gather data to frame the outbound request for a given API
	 * @param uri
	 * @param exchange
	 * @return
	 */
	public void transform(Exchange exchange){
		log.info('PUSPOTransformation.transform <-- Entering')
		
		exchange.properties.order = exchange.in.body.order
		exchange.properties.executionContext  = exchange.in.body.executionContext
		exchange.properties.fedIndicator = false;

		def apiURN = 'urn:csi:services:oms:ProcessUnifiedServiceProductOrder.jws'
		def apiUrl = super.resolveURN(apiURN, null)
		exchange.properties.apiURN = apiURN
		exchange.properties.apiUrl = apiUrl
		
		def uverseAcc = OrderUtility.getUverseAcount(exchange.in.body.order)
		exchange.properties.referenceId = uverseAcc.Id
		
		/*Setting values for Camel Header*/
		
		def mappingData = [:]
		//remove this for real Scenarios
		def order = exchange.in.body.order
		def executionContext = exchange.in.body.executionContext
		mappingData.order = order
		//mappingData =  init(mappingData)
		mappingData = executionContext
		mappingData.puspoCallType = exchange.in.body.callType
		def ProcessUnifiedServiceProductOrderRequest
		def flowType = (mappingData.flowType == WirelineConstants.EXISTING_WL_NEW_FMO_WIRELINE)?'NEW':'CHANGE'
				
		if(flowType.equals('NEW'))
			ProcessUnifiedServiceProductOrderRequest = getPUSPOProvideRequest(mappingData, order)
		else
			ProcessUnifiedServiceProductOrderRequest = getPUSPOModifyRequest(mappingData)
		
		def header = removeEmptyFields(createUnifiedMessageHeader(order,executionContext.conversationId))
		def soapRequest = ['messageHeader' : header,
			'processUnifiedServiceProductOrderRequest' : ProcessUnifiedServiceProductOrderRequest]

		soapRequest = removeKeysWithoutValues(soapRequest);
		log.debug('PUSPOTransformation.transform: Body:' + soapRequest)
		setCSIHttpHeaders(exchange)
		setAuditLogProperties(exchange,false)
		exchange.out.body = soapRequest
		exchange.out.headers.put("CamelHttpUri",apiUrl)
		exchange.properties.put("OceCSIApiName",getApiName())
		log.debug('PUSPOTransformation.transform --> Exiting')
	}
	
	
	private def getPUSPOProvideRequest(def mappingData,def order){
		def iusaRespXml = new XmlSlurper().parseText(mappingData.iusaResponse)
		def iusaResponse = iusaRespXml.Body.InquireUnifiedServiceAccountResponse
		def mode = mappingData.puspoCallType
		def creditRisk = mappingData.creditRisk
		// set customer in mapping
		def customer =  getCustomerData(order,creditRisk)
		def product = []
		/*for Modify
		def assignedProductConfig*/
		def creditPolicy
		def processUnifiedServiceProductOrderRequest
		def billingDetails
		def AddressDetails
		def contact
		def iuspdResp = new XmlSlurper().parseText(mappingData.iuspdResp)
		log.debug('PUSPOTransformation.transform: order --> :' + order)
		
		if(mode == WirelineConstants.PUSPO_SUBMIT){
			def puspoResp = new XmlSlurper().parseText(mappingData.puspoResponse)
			if(order?.CreditPolicy?.CRSMOnFlag)
				creditPolicy  = setCreditPolicyDetails(order)
				product = prepareProductsInNewOfferConfiguration(puspoResp.Body.ProcessUnifiedServiceProductOrderResponse ,mappingData.HSComponentConfiguration, mode, mappingData.omsStandAlonePromStr,mappingData.Appointments)
				billingDetails = getBillingInfo(order , iusaResponse)
				AddressDetails = getAddressDetails(iusaResponse)
				contact = getContactDetails(order)
		}else if(mode == WirelineConstants.PUSPO_VOIP_QUOT){
			def puspoResp = new XmlSlurper().parseText(mappingData.puspoResponse)
			product = prepareProductsInNewOfferConfiguration(puspoResp.Body.ProcessUnifiedServiceProductOrderResponse ,mappingData.HSComponentConfiguration, mode, null, null)

		}else{
			product = prepareProductsInNewOfferConfiguration(iuspdResp.Body.InquireUnifiedServiceProductDetailsResponse ,mappingData.HSComponentConfiguration, mode, null, null)
				
		}
		
		def ProductFilter = ['returnRemovedItemsIndicator': WirelineConstants.Boolean_TRUE,
			'configurationLevel': WirelineConstants.FULL_VAL]
		
		def ConfigurationOptions = prepareConfigurationOptions(mappingData.puspoCallType,isuvWireless(order))
		
		def productConfigurationDetails = [
			'returnCachedProductIndicator':false,
			'ProductsInNewOfferConfiguration':product]
		if(OrderUtility.isCDEHS(order) && Boolean.valueOf(order.IsCommonOrder) == true)
			productConfigurationDetails.commonOrderId = order.CustomerOrderNumber
		    /*add below field for Modify Flow to productConfigurationDetails
			'AssignedProductConfiguration':assignedProductConfig */
		def orderingContext = getOrderingContext()
		//Add Remove keys with null values
		return ['orderingContext':orderingContext,
			'customer': customer,
			'CreditPolicy' : creditPolicy,
			'BillingDetails' : billingDetails,
			'ProductConfigurationDetails' : productConfigurationDetails,
			'Contact' : contact,
			'AddressDetails' : AddressDetails,
			'ProductFilter': ProductFilter,
			'ConfigurationOptions': ConfigurationOptions]
		//add removeEmptyFields
	}
	
	private def getPUSPOModifyRequest(def mappingData){
		def iusaRespXml = new XmlSlurper().parseText(mappingData.iusaResponse)
		def iusaResponse = iusaRespXml.Body.InquireUnifiedServiceAccountResponse
		def mode = mappingData.puspoCallType
		def creditRisk = mappingData.creditRisk
		// set customer in mapping
		def customer =  getCustomerData(order,creditRisk)
		def product = []
		/*for Modify
		def assignedProductConfig*/
		def creditPolicy
		def processUnifiedServiceProductOrderRequest
		def billingDetails
		def AddressDetails
		def contact
		def iuspdResp = new XmlSlurper().parseText(mappingData.iuspdResp)
		log.debug('PUSPOTransformation.transform: order --> :' + order)
		
		if(mode == WirelineConstants.PUSPO_SUBMIT){
			def puspoResp = new XmlSlurper().parseText(mappingData.puspoResponse)
			if(order?.CreditPolicy?.CRSMOnFlag)
				creditPolicy  = setCreditPolicyDetails(order)
				product = prepareProductsInNewOfferConfiguration(puspoResp.Body.ProcessUnifiedServiceProductOrderResponse ,mappingData.HSComponentConfiguration, mode, mappingData.omsStandAlonePromStr,mappingData.Appointments)
				AddressDetails = getAddressDetails(iusaResponse)
				contact = getContactDetails(order)
		}else if(mode == WirelineConstants.PUSPO_VOIP_QUOT){
			def puspoResp = new XmlSlurper().parseText(mappingData.puspoResponse)
			product = prepareProductsInNewOfferConfiguration(puspoResp.Body.ProcessUnifiedServiceProductOrderResponse ,mappingData.HSComponentConfiguration, mode, null, null)

		}else{
			product = prepareProductsInNewOfferConfiguration(iuspdResp.Body.InquireUnifiedServiceProductDetailsResponse ,mappingData.HSComponentConfiguration, mode, null, null)
				
		}
		
		def ProductFilter = ['returnRemovedItemsIndicator': WirelineConstants.Boolean_TRUE,
			'configurationLevel': WirelineConstants.FULL_VAL]
		
		def ConfigurationOptions = prepareConfigurationOptions(mappingData.puspoCallType,isuvWireless(order))
		
		def productConfigurationDetails = [
			'returnCachedProductIndicator':false,
			'ProductsInNewOfferConfiguration':product]
		if(OrderUtility.isCDEHS(order) && Boolean.valueOf(order.IsCommonOrder) == true)
			productConfigurationDetails.commonOrderId = order.CustomerOrderNumber
		    /*add below field for Modify Flow to productConfigurationDetails
			'AssignedProductConfiguration':assignedProductConfig */
		def orderingContext = getOrderingContext()
		//Add Remove keys with null values
		return ['orderingContext':orderingContext,
			'customer': customer,
			'CreditPolicy' : creditPolicy,
			'BillingDetails' : getBillingInfo(order , iusaResponse),
			'ProductConfigurationDetails' : productConfigurationDetails,
			'Contact' : contact,
			'AddressDetails' : AddressDetails,
			'ProductFilter': ProductFilter,
			'ConfigurationOptions': ConfigurationOptions]
	}

	
	/*
	 * Method to Process the response back from the API
	 * @param exchange
	 * @return
	 */
	
	public void processResponse(Exchange exchange) throws APIFailedException {
		log.debug('PUSPOTransformation.processResponse <-- Entering')
		
		/* Initialize */
		def executionContext = exchange.properties.executionContext
		def order = exchange.properties.order
		def puspoResponse = exchange.in.body
		/* Parse the response as an XML*/
		def puspoResp = new XmlSlurper().parseText(puspoResponse)
		
		if (puspoResp.Body.Fault.size()>0){
			def e = new APIFailedException();
			e.api = getApiName()
			e.code = puspoResp.Body.Fault.detail.CSIApplicationException.Response.code
			e.codeDescription = puspoResp.Body.Fault.detail.CSIApplicationException.Response.description
			e.subCode = puspoResp.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code
			e.subCodeDescription = puspoResp.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
			addTransactionHistory(exchange,e)
			exchange.out.body = order
			throw e
		}
		
		/* Updating the execution context */
		validatePUPSOResponse(puspoResp.Body.ProcessUnifiedServiceProductOrderResponse,order,executionContext)
		executionContext.put('PUSPO.pass', 'SUCCESS')
		executionContext.put('puspoResponse', puspoResponse)
		executionContext.put("puspoProcessCompletionIndicator",puspoResp.Body.ProcessUnifiedServiceProductOrderResponse.processCompleteIndicator.text())
		exchange.properties.put('executionContext',executionContext)
		//removeKeysWithoutValues(order)
		addTransactionHistory(exchange,null)
		//log.debug('PUSPOTransformation.processResponse: Body:' + order)
		log.debug('PUSPOTransformation.processResponse --> Exiting')
		
	}
	
	def validatePUPSOResponse(def pupoResp,def order,def context){
		def newOfferMessage = pupoResp.UnifiedServiceProductDetails.ProductsInNewOffer.ProductConfiguration.Messages.flatten()
		def assignedMessage = pupoResp.UnifiedServiceProductDetails.AssignedProducts.ProductConfiguration.Messages.flatten()
		if(newOfferMessage?.Severity?.code?.any{code -> Integer.valueOf(code.text()) >= 4} || assignedMessage?.Severity?.code?.any{code -> Integer.valueOf(code.text()) >= 4}){
			def errors = []
			def ruleid = newOfferMessage.text.collect{if(it.text().contains('[')) it.text().substring(it.text().indexOf('[')+1, it.text().lastIndexOf(']'))}.minus(null)
			ruleid.addAll(assignedMessage.text.collect{if(it.text().contains('[')) it.text().substring(it.text().indexOf('[')+1, it.text().lastIndexOf(']'))}.minus(null))
			errors.add(new ErrorBean('ErrorPUSPOSev','AUTOMATION FAILED( PUSPO QUOT / COMP HAS SEVERITY GREATER THAN EQUAL TO 4) '+ ruleid))
			OrderUtility.updateErrorList(order,context,errors, WirelineConstants.LOSG_STATUS_IN_QUEUE,
				WirelineConstants.LOSG_MANUAL_PROVISIONING_REQUIRED,order.CustomerOrderNumber)
			throw new BpmnError("CRC001");
		}
 
	}
	
	private def setCreditPolicyDetails(def order){
		def LineItem_AdvancePay = order.LineItems.LineItem.find{li -> li?.SystemName == WirelineConstants.ADVANCE_PAYMENT && li?.DisplayName == WirelineConstants.DISPLAY_ADVANCEPAYMENT}
		def LineItem_Non_Refundable_Fee = order.LineItems.LineItem.find{li -> li?.SystemName == WirelineConstants.NON_REFUNDABLE_FEE && li?.DisplayName == WirelineConstants.DISPLAY_NON_REFUNDABLE_FEE}
		def DownPayment= order.LineItems.LineItem?.ContractDetails?.DownPayment?.minus(null)

	   
		def securityAmount = 0
		
		if(!LineItem_Non_Refundable_Fee?.isEmpty()){
		   securityAmount = LineItem_Non_Refundable_Fee.each{li -> securityAmount+=li?.Price?.Amount}
		   securityType = 'Fee'
		   }
		else if(!LineItem_AdvancePay?.isEmpty()){
		   securityAmount = LineItem_AdvancePay.each{li -> securityAmount+=li?.Price?.Amount}
		   securityType = 'ADVPAY'
		   }
		else if(!DownPayment.isEmpty()){
			   securityAmount = DownPayment.each{li -> securityAmount+=li}
			   securityType = 'DWNPAY'
		   }
		   
		return removeEmptyFields([
				   'unifiedPolicyTransactionId' : order?.CreditPolicy?.CreditPolicyTransactionId,
				   'securityAmount' : securityAmount,
				   'securityType' : securityType
			   ])
	}
	
	private def getBillingInfo(def order, def iusaResp){
		//constructSalesCodeValue function to be done -- check if working
		// Added Logic for OrderSource.Channel : "SMB-WEB-CENTER" -- '2ZYZFAA'
		def salesCode
		if(order.OrderSource.Channel == 'SMB-WEB-CENTER')
			salesCode = WirelineConstants.SMB_SALES_CODE
		else	
			salesCode = (order.SalesCode && !order.SalesCode.isEmpty() && order.SalesCode != WirelineConstants.NOT_AVAILABLE) ? order.SalesCode : WirelineConstants.FMO_STATE_SALES_CODE
		
		return [
				'csrSalesCode' : salesCode,
				'nextBillCycleCode' : iusaResp.CustomerIdDetailsByOrgId.BillingProfileExt.cycleCloseDay.text(),
				'billingCycleCode' : iusaResp.CustomerIdDetailsByOrgId.BillingProfileExt.billCycle.text()
			]
	 
	}
	

	private def prepareProductsInNewOfferConfiguration(def apiResp, def HSCompConfig, def mode, def SAPromotionStructure, def Appointments){
		//remove keys with null values
		def ProductsInNewOfferConfiguration = []
		def NewProducts = []
		for(def pino : apiResp.UnifiedServiceProductDetails.ProductsInNewOffer){
			def productConfs = pino.ProductConfiguration.findAll{pf -> pf.productOfferingId.text() == pino.productOfferingId.text()}
			for(def pf: productConfs){
					def tempProductChanges 
					def allCompDetails = OrderUtility.getAllComponentDetailsAsList([],pf.ComponentDetails)
					if(mode == WirelineConstants.PUSPO_VOIP_QUOT)
						tempProductChanges = constructProductChangesVoip(HSCompConfig.ProductConfigurations, allCompDetails)
					else
						tempProductChanges = constructProductChanges(HSCompConfig.ProductConfigurations, allCompDetails)
					def ProductChanges = constructChgedProducts(tempProductChanges.ChangedContainedProducts,mode)
					
					ProductChanges.OrderAction = ['shipToType' : WirelineConstants.SHIP_TO_TYPE]
					if(mode == WirelineConstants.PUSPO_SUBMIT){
						// TO Do -- Set Date Time format
						def appointment = Appointments.find{ap -> ap?.ProductOfferingId == pino.productOfferingId.text()}
						ProductChanges.NewAssignedBillingOffers = SAPromotionStructure
						if(appointment){
							ProductChanges.DueDate = [appointmentDateTimeTo : appointment.SelectedAppointmentDate + 'T' + appointment.EndTime + '.000Z',
													  appointmentDateTimeFrom : appointment.SelectedAppointmentDate + 'T' + appointment.StartTime + '.000Z',
													  appointmentComments : appointment.AppointmentComments];	
						}					  
					}
					NewProducts.add(['productOfferingProductSpecificationId' : pf.productOfferingProductSpecificationId.text(),
						'operationExtension' : pf.operationExtension.text(),
						'basicPriceSchemaId' : pf.basicPriceSchemaId.text(),
						'installationAddressId' : pf.installationAddressId.text(),
						'ProductChanges' : ProductChanges])
				}

			ProductsInNewOfferConfiguration.add(['productOfferingId': pino.productOfferingId.text(),
					'subscriptionGroupId': pino.subscriptionGroupId.text(),
					'installationAddressId': pino.installationAddressId.text(),
					'NewProducts': NewProducts
					])
		}
		ProductsInNewOfferConfiguration = removeEmptyObjects(ProductsInNewOfferConfiguration)
		return ProductsInNewOfferConfiguration
	}
	
	private def getChangedProducts(def changecompconfig, def newChanged){
		def ChangedProd
		def ProductCharacteristics = []
		def valueExsist = changecompconfig.ProductCharacteristics.any{pc -> pc.value}
		for(def pc: changecompconfig.ProductCharacteristics){
			if(newChanged){

					ProductCharacteristics.add(['characteristicId' : pc.characteristicId,
						'value' : StringEscapeUtils.escapeXml11(pc.value),
						'comment' : pc.comment
						])

			}else{
					ProductCharacteristics.add(['characteristicId' : pc.characteristicId,
						'value' : StringEscapeUtils.escapeXml11(pc.value),
						'comment' : pc.comment
						])
					
				}
			}	
		
			def cps =  ['operationExtension':changecompconfig.operationExtension,
				'productSpecificationContainmentId':changecompconfig.productSpecificationContainmentId,
				'parentOperationExtension':changecompconfig.parentOperationExtension,
				'parentProductSpecificationContainmentId':changecompconfig.parentProductSpecificationContainmentId,
				'ProductCharacteristics' : ProductCharacteristics]
				if(!newChanged)
					cps.productId = changecompconfig.productId					
					
		return cps
	}
	
	
	private def constructProductChanges(def ProdConfig, def iuspdComponentDetails){
		def ChangedProd
		def ChangedContainedProducts = []
		def ProductCharacteristics
		def compConfig = ProdConfig.NewOfferComponentMapping.NewProductConfigurations?.ProductsInNewOfferConfigurations?.ComponentConfiguration.flatten().minus(null)
		for(def icd : iuspdComponentDetails){
		if(icd.selectedIndicator == true || compConfig.any{cc -> cc.componentCode == icd?.ProductSpecificationContainment?.ContainedProducts?.code?.text() }){
			def operationExtension = icd.operationExtension?.text()
			println(icd?.productSpecificationContainmentId?.text())
			def tempCompConfig = compConfig.find{cc -> cc.productSpecificationContainmentId == icd?.productSpecificationContainmentId?.text()}
			//def parentCompCode = tempCompConfig.componentPATH?.text().split('|')[0]
			def parentCompCode = tempCompConfig?.componentPATH?.contains('|') ? tempCompConfig.componentPATH?.split('|')[0] : null
			def parentOperationExtension = parentCompCode ? compConfig.find{c -> c.componentCode == parentCompCode}?.operationExtension : null
			def parentProductSpecificationContainmentId = parentCompCode ? compConfig.find{c -> c.componentCode == parentCompCode}?.productSpecificationContainmentId : null
			if(!operationExtension){
				 operationExtension = tempCompConfig.operationExtension
			}
			if(!parentProductSpecificationContainmentId){
				parentOperationExtension = icd.ParentOperationExtn.text()
			}
			if(!parentOperationExtension){
				parentProductSpecificationContainmentId = icd.ParentProductSpecContainmentID.text()
			}
			// set them
			ProductCharacteristics = constructProductCharacteristics(tempCompConfig, icd).findAll{pc -> pc?.characteristicId != null }
			ChangedContainedProducts.add(['productId':icd.productId.text(),
				'productSpecificationContainmentId':icd.productSpecificationContainmentId.text(),
				'operationExtension': operationExtension,
				'parentOperationExtension':parentOperationExtension,
				'parentProductSpecificationContainmentId': parentProductSpecificationContainmentId,
				'ProductCharacteristics':ProductCharacteristics])
			for(def comDetail:iuspdComponentDetails?.ComponentDetails){
				ChangedContainedProducts.add(constructProductChanges(ProdConfig, comDetail))
			}
			
			
			}
		}
		//removeKeysWithoutValues(ChangedContainedProducts)
		ChangedProd =  ['ChangedContainedProducts': ChangedContainedProducts,
			 ]
		def temp = removeEmptyObjects(ChangedContainedProducts)

		return ChangedProd
	}
	
	private def constructProductChangesVoip(def ProdConfig, def ComponentDetails){
		def ChangedProd
		def ChangedContainedProducts = []
		def ProductCharacteristics
		def pupsoComponentDetails = ComponentDetails.findAll{cc -> cc.selectedIndicator == true && cc.actionCode in ['AD','UP']}
		def compConfig = ProdConfig.NewOfferComponentMapping.NewProductConfigurations?.ProductsInNewOfferConfigurations?.ComponentConfiguration.flatten().minus(null)
		for(def compDetail : pupsoComponentDetails){
		  def tempCompConfig = compConfig.find{it.productSpecificationContainmentId == compDetail?.productSpecificationContainmentId?.text() && it.operationExtension == compDetail.operationExtension?.text()}
		  def parentCompCode = tempCompConfig?.componentPATH?.contains('|') ? tempCompConfig.componentPATH?.split('|')[0] : null
		  def parentOperationExtension = compConfig.find{c -> c.componentCode == parentCompCode}?.operationExtension
		  def parentProductSpecificationContainmentId = compConfig.find{c -> c.componentCode == parentCompCode}?.productSpecificationContainmentId
		  if(!parentProductSpecificationContainmentId){
				  parentOperationExtension = compDetail.ParentOperationExtn.text()
			  }
		  if(!parentOperationExtension){
				  parentProductSpecificationContainmentId = compDetail.ParentProductSpecContainmentID.text()
			  }
		  ProductCharacteristics = constructProductCharacteristics(tempCompConfig, compDetail).findAll{pc -> pc?.characteristicId != null }
		  ChangedContainedProducts.add(['productId':compDetail.productId.text(),
				  'productSpecificationContainmentId':compDetail.productSpecificationContainmentId.text(),
				  'operationExtension':  compDetail.operationExtension?.text(),
				  'parentOperationExtension':parentOperationExtension,
				  'parentProductSpecificationContainmentId': parentProductSpecificationContainmentId,
				  'ProductCharacteristics':ProductCharacteristics])
				  
		  for(def comDetail : pupsoComponentDetails?.ComponentDetails){
				  ChangedContainedProducts.add(constructProductChanges(ProdConfig, comDetail))
		  }
		}
		
		  
	  ChangedProd =  ['ChangedContainedProducts': ChangedContainedProducts,
			   ]
		  def temp = removeEmptyObjects(ChangedContainedProducts)
		  
		  return ChangedProd
	}
	
	
	private def constructProductCharacteristics(def HSComponentConfiguration, def iuspdCompDetail){
		def ProductCharacteristics = []
		def componentCode = iuspdCompDetail.ProductSpecificationContainment.ContainedProducts.code.text()
		for(def characDetails : iuspdCompDetail.CharacteristicDetails){
			def iuspdcharacteristicId  = characDetails.productSpecificationCharacteristicId.text()
			//def HSComponentConfiguration  = HSComponentConfigurations.NewOfferComponentMapping.ProductsInNewOfferConfigurations.ComponentConfiguration[hsis:productSpecificationContainmentId=productSpecificationContainmentId]
			def Attributes  = HSComponentConfiguration?.Attributes.find{attr -> attr?.CharacteristicsId == iuspdcharacteristicId}
			def characteristicsId  = Attributes?.CharacteristicsId
			if(characteristicsId){
				ProductCharacteristics.add(['characteristicId' : characteristicsId,
					'value' : Attributes?.Value,
					'comment' : componentCode+'|'+Attributes?.Code+ '_OCE'
					])
			}else{
				def code =  characDetails.ProductSpecificationCharacteristic.code.text()
				def compPath = (HSComponentConfiguration?.componentCode == code)? HSComponentConfiguration?.componentPATH : null
				if(!compPath)
					compPath = componentCode
				if(characDetails.value && !characDetails.value.text().isEmpty()){	
					ProductCharacteristics.add(['characteristicId' : iuspdcharacteristicId,
						'value' : characDetails.value.text(),
						'comment' : compPath+'|'+code
						])
				}
			}
		}
		return ProductCharacteristics
	}

	
	private def constructNewContProducts(def changecompconfig){
		return [ 'operationExtension':changecompconfig.operationExtension,
						'productSpecificationContainmentId':changecompconfig.productSpecificationContainmentId,
						'parentProductSpecificationContainmentId':changecompconfig.parentProductSpecificationContainmentId
					  ]
		//return ['NewContainedProducts': NewContainedProducts]
	}
	
	
	
	private def constructChgedProducts(def ChangedComponentConfiguration, def mode){
		def ChangedContainedProducts = []
		def NewContainedProducts = []
		def temp
		for(def ccc : ChangedComponentConfiguration){
			temp = ccc.ProductCharacteristics?.any{element -> element.value}
			if(ccc.operationExtension?.endsWith('-oce')){
				NewContainedProducts.add(constructNewContProducts(ccc))
			if(temp)
				ChangedContainedProducts.add(getChangedProducts(ccc,true))
			}else{
				/*if(mode != 'submit')*/
				ChangedContainedProducts.add(getChangedProducts(ccc,false))
			}
		}
		temp = removeEmptyObjects(ChangedContainedProducts)
		return ['ChangedContainedProducts': ChangedContainedProducts,
				'NewContainedProducts': NewContainedProducts]
	}
	
	
	/*verify this with IUSA Resp*/
	private def getAddressDetails(def iusaResp){
		def mapAddressesExtBilling = iusaResp?.CustomerIdDetailsByOrgId?.MapAddressesExt?.findAll{mpe -> mpe?.type == 'Billing'}
		def mapAddressesExtService = iusaResp?.CustomerIdDetailsByOrgId?.MapAddressesExt?.findAll{mpe -> mpe?.type == 'ServiceFSP'}
		
		
		return [getAddressDetailMap(mapAddressesExtBilling, true),getAddressDetailMap(mapAddressesExtService, false)]
	}
	
	private def getAddressDetailMap(def MapAddressesExtService, def isBilling){
			def addType = isBilling ? MapAddressesExtService?.type?.text()?.toUpperCase():'ACCEPTANCE'
			
			def AddressTechDetails = ['clli8' : MapAddressesExtService?.CLLI8?.text(),
					'npaNXX' : MapAddressesExtService?.npaNXX?.text(),
					'buildingType' : MapAddressesExtService?.buildingType?.text(),
					'legalEntity' : MapAddressesExtService?.legalEntity?.text(),
					'ccId' : MapAddressesExtService?.connectedCommunityId?.text()
					]
			
			if(AddressTechDetails.clli8.isEmpty() && AddressTechDetails.npaNXX.isEmpty() && AddressTechDetails.buildingType.isEmpty() && AddressTechDetails.legalEntity.isEmpty() && AddressTechDetails.ccId.isEmpty())
				AddressTechDetails = null
				
		return  OrderUtility.removeEmptyFields([
			'adressType' : addType,
			'City' : MapAddressesExtService.city.text(),
			'country' : MapAddressesExtService.country.text(),
			'legalEntity' : MapAddressesExtService.legalEntity.text(),
			'siteId' : MapAddressesExtService.siteId.text(),
			'state' : MapAddressesExtService.state.text(),
			'addInfo' : MapAddressesExtService.additionalInfo.text(),
			'addressNumber' : MapAddressesExtService.houseNumber.text(),  // MapAddressesExtService.address1.text()
			'attention' : MapAddressesExtService.attention.text(),
			'auxiliaryLine1' : MapAddressesExtService.auxiliaryLine1.text(),
			'auxiliaryLine2' : MapAddressesExtService.auxiliaryLine2.text(),
			'auxiliaryLine3' : MapAddressesExtService.auxiliaryLine3.text(),
			'auxiliaryLine4' : MapAddressesExtService.auxiliaryLine4.text(),
			'auxiliaryLine5' : MapAddressesExtService.auxiliaryLine5.text(),
			'box' : MapAddressesExtService.postOfficeBox.text(),
			'busName' : MapAddressesExtService.businessName.text(),
			'cassInfo' : MapAddressesExtService.cassAddnlInfo.text(),
			'cassLine1' : MapAddressesExtService.cassLine1.text(),
			'cassLine2' : MapAddressesExtService.cassLine2.text(),
			'cassLine3' : MapAddressesExtService.cassLine3.text(),
			'cassLine4' : MapAddressesExtService.cassLine4.text(),
			'cassLine5' : MapAddressesExtService.cassLine5.text(),
			'county' : MapAddressesExtService.county.text(),
			'levelType' : MapAddressesExtService.levelType.text(),
			'levelVal' : MapAddressesExtService.levelValue.text(),
			'numberPrefix' : MapAddressesExtService.houseNumberPrefix.text(),
			'numberSuffix' : MapAddressesExtService.houseNumberSuffix.text(),
			'route' : MapAddressesExtService.route.text(),
			'streetSuffix' : MapAddressesExtService.streetSuffix.text(),
			'streetType' : MapAddressesExtService.thoroughfare.text(),
			'structureType' : MapAddressesExtService.structureType.text(),
			'structureVal' : MapAddressesExtService.structureValue.text(),
			'zipCode' : MapAddressesExtService.zip.text(),
			'zipPlus4' : MapAddressesExtService.zip4.text(),
			'unitType' : MapAddressesExtService.unitType.text(),
			'unitVal' : MapAddressesExtService.unitValue.text(),
			'rateZoneCodeDMA' : MapAddressesExtService.dmaCode.text(),
			'ccid' : MapAddressesExtService.connectedCommunityId.text(),
			'isValidatedIndicator' :  MapAddressesExtService.isValid.text()=='V' ? true : false,
			'AddressTechDetails': AddressTechDetails
		   
		   ])
	}
	
	private def prepareConfigurationOptions(def mode, def isUVWireless){
		def masks = []
		def submitProductOrderIndicator
		def ruleMessagesApprovedIndicator
		def productActivity
		def runCompatibilityRulesIndicator
		def toCallEnablerFlag
		def sendPromoBundleHistoryFlag
		def wirelessConvergeIndicator
		def newProductsIndicator
		def productConfigurationReturnIndicator
		if(mode == WirelineConstants.PUSPO_SUBMIT){
			masks = [WirelineConstants.MASK_CATALOG_LITE,
					 WirelineConstants.MASK_QUOTED_PRICES,
					 WirelineConstants.MASK_PROD_CONFIG]
			submitProductOrderIndicator = WirelineConstants.Boolean_TRUE			
		}else if(mode == WirelineConstants.PUSPO_VOIP){
			productActivity = WirelineConstants.ACTIVITY_CONFIG_PUSPO_VOIP
			masks = [WirelineConstants.MASK_DISPLAY_INFO,				
					 WirelineConstants.MASK_PROD_CONFIG]
			ruleMessagesApprovedIndicator = WirelineConstants.Boolean_TRUE
			runCompatibilityRulesIndicator = WirelineConstants.Boolean_TRUE
			newProductsIndicator = WirelineConstants.Boolean_TRUE
			productConfigurationReturnIndicator = WirelineConstants.Boolean_TRUE
		}else{	
		 if(mode == WirelineConstants.PUSPO_QUOT){
			 productActivity = WirelineConstants.ACTIVITY_CONFIG_PUSPO_QUOT
		 }else if (mode == WirelineConstants.PUSPO_VOIP_QUOT){
		 	productActivity = WirelineConstants.ACTIVITY_CONFIG_PUSPO_VOIP_QUOT
		 }	
			masks = [WirelineConstants.MASK_QUOTED_TAX,
					 WirelineConstants.MASK_CROSS_PROD_DISCOUNT_DATA,
					 WirelineConstants.MASK_QUOTED_PRICES,
					 WirelineConstants.MASK_DISPLAY_INFO,
					 WirelineConstants.MASK_PROD_CONFIG,
					 ]
			ruleMessagesApprovedIndicator = WirelineConstants.Boolean_TRUE
			runCompatibilityRulesIndicator = WirelineConstants.Boolean_TRUE
			newProductsIndicator = WirelineConstants.Boolean_TRUE
			productConfigurationReturnIndicator = WirelineConstants.Boolean_TRUE
			sendPromoBundleHistoryFlag = WirelineConstants.Boolean_TRUE
			toCallEnablerFlag = WirelineConstants.Boolean_TRUE
		}
		if(isUVWireless){
			wirelessConvergeIndicator = WirelineConstants.Boolean_TRUE
		}
		
		def temp = ['masks': masks,
			'wirelessConvergeIndicator': wirelessConvergeIndicator,
			'submitProductOrderIndicator':submitProductOrderIndicator,
			'newProductsIndicator': newProductsIndicator,
			'productConfigurationReturnIndicator':  productConfigurationReturnIndicator,
			'productActivity': productActivity,
			'toCallEnablerFlag': toCallEnablerFlag,
			'sendPromoBundleHistoryFlag': sendPromoBundleHistoryFlag,
			'runCompatibilityRulesIndicator': runCompatibilityRulesIndicator,
			'ruleMessagesApprovedIndicator': ruleMessagesApprovedIndicator]
		
		removeKeysWithoutValues(temp)
		return temp
	}
	
	
	private def getContactDetails(def order){
		// Need Changes for 17.05
		def nameRefs = order.SchedulingInfos?.SchedulingInfo?.NameRef ? order.SchedulingInfos?.SchedulingInfo?.NameRef : OrderUtility.getUverseAcount(order)?.BillingInfo?.NameRef
		def contactName = order.Names.Name.find{name -> name.Id in nameRefs}
		return [
					method : order?.OrderContact?.PreferredContactMethod  ,
					lastName : contactName?.FirstName ,
					firstName : contactName?.LastName ,
					email : order?.OrderContact?.PrimaryEmailAddress ,
					phoneType : contactName?.PrimaryContactPhone ? (StringUtils.isBlank(contactName?.PrimaryContactPhone[0]?.ContactPhoneType)? 'WORK_PHONE' : contactName?.PrimaryContactPhone[0]?.ContactPhoneType): null,
					phoneNumber : contactName?.PrimaryContactPhone ? contactName?.PrimaryContactPhone[0]?.PhoneNumber: null ,
					alternatePhoneType : contactName?.AdditionalContactPhone ? contactName?.AdditionalContactPhone[0].ContactPhoneType: null ,
					alternatePhoneNumber : contactName?.AdditionalContactPhone ? contactName?.AdditionalContactPhone[0].PhoneNumber: null ,
					contactRole : 'Primary'
				]
	}
	
	private def getCustomerData(def order,def creditRisk){
		def uverseAcc = OrderUtility.getUverseAcount(order)
		return [creditRiskClass :  creditRisk,
				customerSubType : uverseAcc.AccountSubType,
				ban : uverseAcc.BillingAccountNumber]
	}
	
	/*Initialize here PUSPO call*/
	
		
	private def isuvWireless(def order){
		def wlAccRef = order.Groups.Group.find{it.LoSGType == WirelineConstants.LOSGTYPE_UNIFY && it.ProductCategory == WirelineConstants.PRODUCTCATEGORY_WIRELESS}?.AccountRef
		if(wlAccRef){
			if(order.Accounts.Account.any{it.identity == wlAccRef})
			return true
		}
		return false
	}
	
	def removeEmptyObjects(def myList){
		def removeList = []
		for(def obj:myList){
			obj = removeEmptyFields(obj)
			if(obj.keySet().size() == 0){
				removeList.add(obj)
			}
		}
		for(def i : removeList){
			myList.remove(i)
		}
		return myList
	}
	
	def removeEmptyFields(def map){
		def keylist = map.keySet()
		def remKeyList = []
		for(def key: keylist){
			if(map.get(key) == null || map.get(key) == '' || map.get(key) == []){
				remKeyList.add(key)
			}else{
				if(map.get(key) instanceof List){
					removeEmptyObjects(map.get(key))
				}else if(map.get(key) instanceof Map){
					removeEmptyFields(map.get(key))
				}
			}
		}
		for(def j: remKeyList){
			map.remove(j)
		}
		return map
	}
	
	private def getOrderingContext(){
		return ['salesChannel' : WirelineConstants.SALES_CHANNEL,
				'applicationId' :  WirelineConstants.APP_ID ]
	}
	
	
	   
	   def getAttributeValue(attributeCode,attributeValue,ComponentConfiguration,lineItems) {
		   
		   def sum
		   if(attributeValue.contains('@')) {
			   
			   def quantList = lineItems.findAll{li -> li.Characteristics?.CommonCharacteristics?.ComponentConfiguration.any{cc -> cc.ComponentCode == ComponentConfiguration.ComponentCode && cc.Attributes.AttributeCode.contains(attributeCode)}}//.collect{it.Quantity}.flatten().minus(null)
				  
			   def totalQuantity = quantList.Quantity.sum()
			   
			   
			   return totalQuantity
			}
		   else {
			   
			   return attributeValue
			   
		   }
	   }
 
	   //Tested
	   def constructOfferSpecIdStructure(def Order) {
		   def OfferSpecDetails = []
		   def offerPckGroupList = Order.Groups.Group.findAll { grp -> grp.Type == WirelineConstants.GROUPTYPE_PACKAGE  && grp.GroupCharacteristics?.PackageCharacteristics?.Category == WirelineConstants.CATEGORY_OFFER}
		   def ProductSpecificationIds = new HashSet();
 
		   for(def offerPckGroup in offerPckGroupList )
		   {
			   def pckCharc = offerPckGroup.GroupCharacteristics.PackageCharacteristics
 
			   if(pckCharc && !pckCharc.isEmpty()) {
 
				   def offerId = pckCharc.Code
				   def offerType = pckCharc.Type
 
 
				   def lineItems = Order.LineItems.LineItem.findAll{li -> li.GroupRefs.GroupRef.contains(offerPckGroup.Id)}
 
				   for(def lineItem in lineItems){
					   //Distinct productSpecificationId - using hashset for this
						ProductSpecificationIds.add(lineItem?.Characteristics?.CommonCharacteristics?.ProductSpecificationId)
						ProductSpecificationIds.remove(null) //remove null if present
				   }
 
				   OfferSpecDetails.add([ offerType : offerType,
					   offerId : pckCharc.Code,
					   productsOfferSpecificationIds : ProductSpecificationIds
					   ])
 
				   //OfferSpecStructure.add([OfferSpecDetails : OfferSpecDetails])
 
			   }
 
			   else {
 
				   continue
			   }
		   }
 
 
		   return [OfferSpecDetails : OfferSpecDetails]
	   }
	   
	   def callHSComponentsForVoip(def context, def order){
		   def hsComponentConfiguration = setHSComponentConfigurationForVoIP(context,order,'CVOIP')
		   println('CVOIP setHSComponentConfiguration-----'+JsonOutput.toJson(hsComponentConfiguration))
		   context.put("HSComponentConfiguration",hsComponentConfiguration)
		   hsComponentConfiguration = setHSComponentConfigurationForVoIP(context,order,'VOIPLINE')
		   println('setHSComponentConfiguration-----'+JsonOutput.toJson(hsComponentConfiguration))
		   context.put("VOIPLINE HSComponentConfiguration",hsComponentConfiguration)
		   def isDLexist = order.Groups.Group.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.flatten()?.size() > 0
		   if(isDLexist){
			   hsComponentConfiguration = setHSComponentConfigurationForVoIP(context,order,'VOIPDL')
			   println('VOIPDL setHSComponentConfiguration-----'+JsonOutput.toJson(hsComponentConfiguration))
			   context.put("HSComponentConfiguration",hsComponentConfiguration)
		   }
		   
	   }
	
	   def setHSComponentConfigurationForVoIP(def context, def order , def componentArray){
		   def ProductConfigurations = [:]
		   def check = context.puspoResponse
		   def tempList = []
		   def puspoResponse = new XmlSlurper().parseText(context.puspoResponse)
		   for(def newOffer : puspoResponse.Body.ProcessUnifiedServiceProductOrderResponse.UnifiedServiceProductDetails.ProductsInNewOffer)
		   		OrderUtility.getAllComponentDetailsAsList( tempList, newOffer.ProductConfiguration.ComponentDetails)		   
		   def VOIPNewComponentDetails = tempList.findAll{pc -> pc.ProductSpecificationContainment.ContainedProducts.code.text() == componentArray}	
		   def VOIPAssignedComponentDetails = []//puspoResponse.Body.ProcessUnifiedServiceProductOrderResponse.UnifiedServiceProductDetails.AssignedProducts.ProductConfiguration.ComponentDetails.flatten().findAll{pc -> pc.ProductSpecificationContainment.ContainedProducts.code.text() == componentArray}
		   def PUSPOAssignedProductConfigurations = puspoResponse.Body.ProcessUnifiedServiceProductOrderResponse.UnifiedServiceProductDetails.AssignedProducts.ProductConfiguration
		   def VOIPLineItem = order.LineItems.LineItem.find{li -> li.Characteristics?.CommonCharacteristics?.ComponentConfiguration?.any{cc -> cc.ComponentCode == componentArray}}
		   //def uverseOfferId = order.Groups.Group.findAll{grp -> grp.Id in VOIPLineItem.GroupRefs.GroupRef  && grp.GroupCharacteristics?.PackageCharacteristics?.Category == WirelineConstants.PACKAGE_CATEGORY}.GroupCharacteristics?.PackageCharacteristics.Code
		   def componantPath = VOIPLineItem?.Characteristics?.CommonCharacteristics?.ComponentConfiguration.flatten().minus(null).find{cc -> cc.ComponentCode == componentArray}?.ComponentPath
		   def uverseOfferId = ['2000043']
		   def operationExtn = java.util.UUID.randomUUID().toString()
		   def NewProductConfigurations = []
		   def AssignedProductComponentMapping
		   def NewOfferComponentMapping
		   if(VOIPNewComponentDetails && !VOIPNewComponentDetails.isEmpty()){
			   for(def newProductConfig : context.HSComponentConfiguration.ProductConfigurations.NewOfferComponentMapping.NewProductConfigurations){
				   def prodNewOfferConfig = []
				   def newComCodeExist = false
				   if(newProductConfig.OfferId == uverseOfferId[0]){
					   for(def ProductsInNewOfferConfiguration : newProductConfig.ProductsInNewOfferConfigurations){
						   if(ProductsInNewOfferConfiguration.ComponentConfiguration.componentCode.contains(componentArray) ){
						   newComCodeExist = true
						   // Change only Attributes in ComponentConfiguration
							   prodNewOfferConfig.add([productOfferingProductSpecId : ProductsInNewOfferConfiguration.productOfferingProductSpecificationId,
									   OperationExtn : ProductsInNewOfferConfiguration.operationExtension,
									   ComponentConfiguration : getComponentConfigurationVoip(ProductsInNewOfferConfiguration.ComponentConfiguration, VOIPNewComponentDetails,componentArray ,order)])
									   // to do
						   }else{
							   prodNewOfferConfig.add(ProductsInNewOfferConfiguration)
						   }
						   
					   }
					   if(VOIPNewComponentDetails && !VOIPNewComponentDetails.isEmpty() && !newComCodeExist){
						   for(def voipCompDetails : VOIPNewComponentDetails.findAll{vnc -> (vnc.selectedIndicator == true && vnc.actionCode in ['AD','UP']) || componentArray == 'VOIPDL'}){
							   def prodConf = context.puspoResponse.UnifiedServiceProductDetails.ProductsInNewOffer.find{pino -> pino.ProductConfiguration.productOfferingId in uverseOfferId}.ProductConfiguration
							   def compConfig = []
							   prodNewOfferConfig.add([productOfferingProductSpecId : prodConf.productOfferingProductSpecificationId,
									   OperationExtn : !!prodConf.operationExtension ? prodConf.operationExtension : operationExtn,
									   ComponentConfiguration : [
												 isComponentMapped : true,
												 componentCode : voipCompDetails.ProductSpecificationContainment.ContainedProducts.code ,
												 operationExtension : !!voipCompDetails.operationExtension ? voipCompDetails.operationExtension : operationExtn,
												 componentPATH : componantPath[0],
												 displayName : voipCompDetails.ProductSpecificationContainment.ContainedProducts.name.text(),
												 productSpecificationContainmentId : voipCompDetails.ProductSpecificationContainment.id.text(),
												 productId : voipCompDetails.productId.text(),
												 componentMapping : true,
												 Attributes : getMapAttributeValueVOIP(VOIPNewComponentDetails,componentArray,order )// to do
								 ]])
						   
						   }
					   
					   }
					   NewProductConfigurations.add([	action : newProductConfig.action,
												   OfferId : newProductConfig.offerId,
												   ProductsInNewOfferConfigurations : prodNewOfferConfig])
				   }else{
					   NewProductConfigurations.add(newProductConfig)
				   }
			   }
			   NewOfferComponentMapping = [NewProductConfigurations : NewProductConfigurations]
		   }
		   
		   if(VOIPAssignedComponentDetails && !VOIPAssignedComponentDetails.isEmpty()){
			   def AssignedProductConfigurations = []
			   def assignComCodeExist = false
			   for(def assignProductConfig : context.HSComponentConfiguration.ProductConfigurations.AssignedProductComponentMapping.AssignedProductConfigurations){
				   if(assignProductConfig.ComponentConfiguration.componentCode == componentArray ){
				   assignComCodeExist = true
					   AssignedProductConfigurations.add([action : assignProductConfig.actionCode ,
						   offerId : assignProductConfig.offerId,
						   productOfferingProductSpecId : assignProductConfig.productOfferingProductSpecId ,
						   productId : assignProductConfig.productId,
						   OperationExtn : assignProductConfig.OperationExtn,
						   ComponentConfiguration : getComponentConfigurationVoip(assignProductConfig.ComponentConfiguration,VOIPAssignedComponentDetails ,componentArray,order )])
				   }else{
					   AssignedProductConfigurations.add(assignProductConfig)
				   }
			   }
			   if(VOIPAssignedComponentDetails && VOIPAssignedComponentDetails.isEmpty() && !assignComCodeExist){
				   for(def voipCompDetails : VOIPAssignedComponentDetails.findAll{vnc -> (vnc.selectedIndicator == true && vnc.actionCode in ['AD','UP']) || componentArray == 'VOIPDL'}){
					   AssignedProductConfigurations.add([action : voipCompDetails.actionCode = 'AD' ? 'ADD' : 'UPDATE',
						   offerId : uverseOfferId[0],
						   productOfferingProductSpecId : PUSPOAssignedProductConfigurations.productOfferingProductSpecificationId.text(),
						   productId : PUSPOAssignedProductConfigurations.productId.text(),
						   OperationExtn : operationExtension,
						   ComponentConfiguration : [
							   	 isComponentMapped : true,
								 componentCode : voipCompDetails.ProductSpecificationContainment.ContainedProducts.code,
								 operationExtension : !!voipCompDetails.operationExtension ? voipCompDetails.operationExtension : operationExtn,
								 componentPATH : componantPath[0],
								 displayName : voipCompDetails.ProductSpecificationContainment.ContainedProducts.name.text(),
								 productSpecificationContainmentId : voipCompDetails.ProductSpecificationContainment.id.text(),
								 productId : voipCompDetails.productId.text(),
								 componentMapping : true,
								 Attributes : getMapAttributeValueVOIP(VOIPAssignedComponentDetails,componentArray,order)
								 ]])
				   }
			   }
			   AssignedProductComponentMapping = [AssignedProductConfigurations : AssignedProductConfigurations]
		   }
		   ProductConfigurations = [ NewOfferComponentMapping : NewOfferComponentMapping,
			   						 AssignedProductComponentMapping : AssignedProductComponentMapping]
		   //def check2 = context.puspoResponse.UnifiedServiceProductDetails.ProductsInNewOffer.ProductConfiguration.ComponentDetails.flatten().findAll{pc -> pc.ProductSpecificationContainment.ContainedProducts.code.text() == componentArray}
		   return [ProductConfigurations : ProductConfigurations]
   }
   
    def getComponentConfigurationVoip(def ComponentConfiguration, def VOIPComponentDetails,def componentArray,def order){
	   // Pass the correct VOIP Group and Use that only to create Attributes
	   ComponentConfiguration.Attributes = getMapAttributeValueVOIP(VOIPComponentDetails,componentArray,order)
									   
	   return 	ComponentConfiguration
	   
	   }
	   
	   
  public def getMapAttributeValueVOIP(def VOIPComponentDetails, def componentArray, def order){
	def cvoipArray = ['homeAlarm','e911Ack','isPartOfPackage','portInType','e911AckDateTime',
				'tosCvoipDateTime','tosCvoipIndicator','callerIdName','initialDeliveryQty']
	def voiplineArray = ['primaryLine','shadowLRN','lergLRN','esrn','rateCenter',
				'tnSource','initialCallerIDBlock','initialCallForwarding','e911VoiplineDateTime','nativeTn','exchangeCode','current    SPID','lsLRN','TimeStamp','portInTn','oldServiceProviderTN',
				'oldServiceProviderCusCode','action_type','e911VoiplineIndicator','nonPublishedQuantity','initialCallForwardingAMSS','initialCallerIDBlockAMSS']
	def voipdlArray = ['omitAddress','lastName','firstName','firstDLIndicator','mainDirectoryListing']

	if(order.OrderSource.Channel == WirelineConstants.CHANNEL_SMB){
		voipdlArray.addAll(['accountType','BFirstName','BLastName',
				'titleAddress1','titleAddress2','designation','location1','location2','city','state','zip','directoryListingType','yphCode'])
	}
	   def Attributes = []
	   def charcDetails = []
	   VOIPComponentDetails.each{charcDetails.addAll(it.CharacteristicDetails)}
	   if(componentArray == 'CVOIP'){
		   for(def charDetails : charcDetails){
			   def val = getMapAttributeValueCVOIP(charDetails.ProductSpecificationCharacteristic.code, order)
			   if(charDetails.ProductSpecificationCharacteristic.code in cvoipArray && val){
				   Attributes.add([code : charDetails.ProductSpecificationCharacteristic.code,
								  Value : val,
								  CharacteristicsId : charDetails.productSpecificationCharacteristicId,
								  AttributeOperations : WirelineConstants.PUSPOREQ])
			   }
		   }
	   }else if(componentArray == 'VOIPLINE'){
		   for(def charDetails : charcDetails){
			   def val = getMapAttributeValueVOIPLINE(charDetails.ProductSpecificationCharacteristic.code, order)
			   if(charDetails.ProductSpecificationCharacteristic.code in voiplineArray && val){
				   Attributes.add([code : charDetails.ProductSpecificationCharacteristic.code,
								  Value : val,
								  CharacteristicsId : charDetails.productSpecificationCharacteristicId,
								  AttributeOperations : WirelineConstants.PUSPOREQ])
			   }
		   }
	   }else{
		   for(def charDetails : charcDetails){
			   def val = getMapAttributeValueVOIPDL(charDetails.ProductSpecificationCharacteristic.code, order)
			   if(charDetails.ProductSpecificationCharacteristic.code in voipdlArray && val){
				   Attributes.add([code : charDetails.ProductSpecificationCharacteristic.code,
								  Value : val,
								  CharacteristicsId : charDetails.productSpecificationCharacteristicId,
								  AttributeOperations : WirelineConstants.PUSPOREQ])
			   }
		   }
	   
	   }
   }
   
   def getMapAttributeValueCVOIP(def attrCOde, def order){
	   def cvoipGroups = order.Groups.Group.GroupCharacteristics?.LoSGCharacteristics.findAll{losg -> losg?.ProductCategory == WirelineConstants.PRODUCT_VOIP_CATEGORY_ATTRIBUTE && losg?.LoSGType == WirelineConstants.LOSGTYPE_NEW && losg?.IsPrimary == true}
	   def value
	   switch(attrCOde){
		   case 'homeAlarm' : value = order.E911Info?.HomeAlarmSystemIndicator == 'Y' ? 1 : (order.E911Info?.HomeAlarmSystemIndicator == 'N' ?  0 : null )  ; break;
		   case 'callerIdName' : value =  getCallerID(cvoipGroups.VOIPLOSChars?.DirectoryListing?.Name) ; break;
		   case 'initialDeliveryQty' : value =  order.Groups.Group.GroupCharacteristics?.LoSGCharacteristics.findAll{losg -> losg?.ProductCategory == WirelineConstants.PRODUCT_VOIP_CATEGORY_ATTRIBUTE && losg?.LoSGType in [WirelineConstants.LOSGTYPE_NEW && losg?.IsPrimary,'NO_CHANGE','CHANGE']}.size()  ; break;
		   case 'tosCvoipIndicator' : value =  cvoipGroups?.TCAccepted?.Accepted == 'Y' ? 'YES' :  'NO'  ; break;
		   case 'e911Ack' : value = order.E911Info?.TC911?.Accepted == 'Y' ?  1 : (order.E911Info?.TC911?.Accepted == 'Y'?  0 : null)  ; break;
		   case 'isPartOfPackage' : value =  'No'  ; break;
		   case 'portInType' : value = cvoipGroups?.NumberPortInfo?.PortTelephoneNumber?.any{tn -> !!tn} ? 'Y' : null  ; break;
		   case 'e911AckDateTime' : value = !cvoipGroups?.E911Info?.TC911?.Timestamp?.isEmpty() ? cvoipGroups?.E911Info?.TC911?.Timestamp[0]?.split('.')[0] : null ; break;// to do
		   case 'tosCvoipDateTime' : value =  !cvoipGroups?.TCAccepted?.Timestamp.isEmpty() ?  cvoipGroups?.TCAccepted?.Timestamp[0]?.split('.')[0] : null ; break;//to do
		   }
	   return value
   }
   
   def getCallerID(def name){
	   def callerID = !name?.isEmpty() ? name[0]?.split("\\s").collect{(it == '&amp;' || it.contains('AND'))? '' : it}.minus('') : []
	   
	   return String.join(' ', callerID)
   }
   
   def getMapAttributeValueVOIPDL(def attrCOde, def order){
	   // to do
	   def cvoipGroups = order.Groups.Group.findAll{grp -> grp.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == WirelineConstants.PRODUCT_VOIP_CATEGORY_ATTRIBUTE && grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == WirelineConstants.LOSGTYPE_NEW}
	   def cvoipPrimary = cvoipGroups.find{grp -> grp.GroupCharacteristics?.LoSGCharacteristics?.IsPrimary == true}
	   def cvoipAG = cvoipGroups.findAll{grp -> grp.GroupCharacteristics?.LoSGCharacteristics?.IsPrimary == false}
	   // to check for alternate voip and change LosgType
	   def cvoip = cvoipPrimary ? cvoipPrimary : cvoipAG
	   def VFSPD_VOIP = [AMSSCVOIPTitle1: TITLE, action_type: A, tnSource: TELCO, mainDirectoryListing: Main, additionalDirectoryListing: Additional, directoryListingType_Published: Published]
	   def value
	   def listBySurname = cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.Listing?.ListBy?.contains('Surname')
	   switch(attrCOde){
		   case 'omitAddress' : value = cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.OmitAddress.any{omit -> omit == true} ? 1 : 0 ; break;
		   case 'lastName' : value =  cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.Name.any{name -> !!name} ? cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.Name[0] : order.Names.Name.findAll{name -> name.Id in cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.NameRef}.LastName ; break;
		   case 'firstName' : value =  cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.Name.any{name -> !!name} ? cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.Name[0] : order.Names.Name.findAll{name -> name.Id in cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.NameRef}.FirstName ; break;
		   case 'firstDLIndicator' : value =  cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.Listing?.ListingType.contains(VFSPD_VOIP.directoryListingType_Published) ? true : null  ; break;
		   case 'mainDirectoryListing' : value =  cvoipPrimary ? VFSPD_VOIP.mainDirectoryListing :  VFSPD_VOIP.additionalDirectoryListing; break;
		   case 'accountType' : value = listBySurname ? 'S':'B'; break;
		   case 'BFirstName' : value = !listBySurname ? order.Names.Name.find{name -> name.Id in cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.NameRef}.FirstName : '' ; break;
		   case 'BLastName' : value = !listBySurname ? order.Names.Name.find{name -> name.Id in cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.NameRef}.LastName : '' ; break;
		   case 'titleAddress1' : value = order.Names.Name.findAll{name -> name.Id in cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.NameRef}.Prefix ; break;
		   case 'titleAddress2' : value = order.Names.Name.findAll{name -> name.Id in cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.NameRef}.Prefix ; break;
		   case 'designation' : value = cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.AdditionalDetails?.AdditionalDetail.flatten().find{add -> add.Code == 'Designation'}?.Value ; break; // need to check
		   case 'location1' : order.Addresses.Address.find{add -> add.AddressId in cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.Addressref}.AddressLine1 ; break;; break;
		   case 'location2' : order.Addresses.Address.find{add -> add.AddressId in cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.Addressref}.AddressLine2 ; break;; break;
		   case 'city' : order.Addresses.Address.find{add -> add.AddressId in cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.Addressref}.City ; break;; break;
		   case 'state' : value = order.Addresses.Address.find{add -> add.AddressId in cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.Addressref}.State ; break;; break;
		   case 'zip' : value = order.Addresses.Address.find{add -> add.AddressId in cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.Addressref}.Zip ; break;; break;
		   case 'directoryListingType' : value = cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.Listing?.ListingType[0]; break;
		   case 'yphCode' : value = cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.Listing?.ListingCategory; break;
		   default : value = null; break
		   }
	   return value
   }
   
   def getMapAttributeValueVOIPLINE(def attrCOde, def order){
	   def cvoipGroups = order.Groups.Group.GroupCharacteristics?.LoSGCharacteristics.findAll{losg -> losg?.ProductCategory == WirelineConstants.PRODUCT_VOIP_CATEGORY_ATTRIBUTE && losg?.LoSGType == WirelineConstants.LOSGTYPE_NEW}
	   def cvoipPrimaryGrp = order.Groups.Group.find{grp -> (grp.GroupCharacteristics?.LoSGCharacteristics.IsPrimary == true && grp.GroupCharacteristics?.LoSGCharacteristics.ProductCategory == WirelineConstants.PRODUCT_VOIP_CATEGORY_ATTRIBUTE && grp.GroupCharacteristics?.LoSGCharacteristics.LoSGType == WirelineConstants.LOSGTYPE_NEW)}
	   def cvoipAG = cvoipGroups.findAll{losg -> losg.IsPrimary == false}
	   // to check for alternate voip and change LosgType
	   def cvoip = cvoipPrimaryGrp
	   def value
	   switch(attrCOde){
		   case 'initialCallerIDBlockAMSS' : value = order.LineItems.LineItem.any{li -> li.GroupRefs?.GroupRef?.contains(cvoip.Id) && li.Characteristics?.VOIPLineItemChars?.CallerIdIndicator == 'YES'}? 'Show' : null ; break;
		   case 'initialCallForwardingAMSS' : value =  order.LineItems.LineItem.any{li -> li.GroupRefs?.GroupRef?.contains(cvoip.Id) && !!li.Characteristics?.VOIPLineItemChars?.UVerseMessaging}? 'Allow' : null ; break;
		   case 'nonPublishedQuantity' : value =  order.Groups.Group.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.DirectoryListing?.flatten().minus(null).findAll{dl -> dl.Listing?.ListingType == 'NONPUBLISHED'}.size(); break;
		   case 'e911VoiplineIndicator' : value = order.E911Info?.TC911?.Accepted == 'Y' ?  1 : (order.E911Info.TC911.Accepted == 'Y'?  0 : null)  ; break;
		   case 'action_type' : value =  'A'; break;
		   case 'oldServiceProviderCusCode' : value =  cvoip.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo?.OSPAccountNumber; break;
		   case 'oldServiceProviderTN' : value =  cvoip.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo?.NonATTPortIn == 'N' ? cvoip.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo?.PortTelephoneNumber : null; break;
		   case 'portInTn' : value =  cvoip.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo?.PortTelephoneNumber; break;
		   case 'TimeStamp' : value =  order.SubmitedDate.split('.')[0]; break;
		   case 'lsLRN' : value =  'A'; break;
		   case 'currentSPID' : value =  cvoip.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo?.CurrentSPID; break;
		   case 'exchangeCode' : value =  order.Addresses.Address.find{ad -> ad.Id == OrderUtility.getUverseAcount(order)?.ServiceLocationRef}?.ParsedAddress?.ExchangeCode; break;
		   case 'primaryLine' : value =  cvoip.isPrimay ? 'PTL' : null; break;
		   case 'shadowLRN' : value =  cvoip.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo?.ShadowLRN; break;
		   case 'lergLRN' : value =   cvoip.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo?.LERGLRN; break;
		   case 'esrn' : value =  cvoip.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo?.ESRN; break;
		   case 'rateCenter' : value =  order.Addresses.Address.find{ad -> ad.Id == OrderUtility.getUverseAcount(order)?.ServiceLocationRef}?.ParsedAddress?.RateCenterCode; break;
		   case 'tnSource' : value =  'TELCO'; break;
		   case 'initialCallerIDBlock' : value = order.LineItems.LineItem.any{li -> li.GroupRefs.GroupRef.contains(cvoip.Id) && li.Characteristics?.VOIPLineItemChars?.CallerIdIndicator == 'YES'}? 'Show' : null ; break;
		   case 'initialCallForwarding' : value = order.LineItems.LineItem.any{li -> li.GroupRefs.GroupRef.contains(cvoip.Id) && !!li.Characteristics?.VOIPLineItemChars?.UVerseMessaging}? 'Allow' : null ; break;
		   case 'e911VoiplineDateTime' : value = order.E911Info?.TC911?.Timestamp ; break;
		   case 'nativeTn' : value = cvoip.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.ReservedTelephoneNumber
		   default : value = null
		   }
	   return value
	   
   }
   
  
   
	
}
