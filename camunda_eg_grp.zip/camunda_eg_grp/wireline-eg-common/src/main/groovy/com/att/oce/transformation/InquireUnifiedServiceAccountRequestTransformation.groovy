package com.att.oce.transformation

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.common.WirelineConstants;
import com.att.oce.bpm.common.WirelineTransformationService;
import com.att.oce.bpm.common.util.ErrorBean
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.error.OceErrorHandler
import com.att.oce.config.components.GlobalProperties
import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import com.att.oce.bpm.utility.OrderUtility

/**
 * 
 * @author SK00444055
 *
 */
@Component('inquireUnifiedServiceAccountRequestTransformation')
class InquireUnifiedServiceAccountRequestTransformation extends WirelineTransformationService
 {



	@Override String getApiName(){
		return 'InquireUnifiedServiceAccount';
	}

	/**
	 * @param exchange
	 */
	
	public String getApiUrn() {
		return "urn:csi:services:lscrm:InquireUnifiedServiceAccount.jws";
	}
	
	public void transform(Exchange exchange) {
		println ('IUSARequestTransformation.transform')
		exchange.properties.order = exchange.in.body.order
		exchange.properties.executionContext  = exchange.in.body.executionContext

		def order = exchange.in.body.order
		def uverseAcc = OrderUtility.getUverseAcount(order)
		def ban = uverseAcc.BillingAccountNumber
		
		def executionContext = exchange.in.body.executionContext
		def iusaRequest = [ messageHeader : createUnifiedMessageHeader(order,null),
			InquireUnifiedServiceAccountRequest : [
				billingAccountNumber : ban,
				systemIdentifier : WirelineConstants.IUSA_SYSTEM_IDENTIFIER,
				originatorSystemName : WirelineConstants.IUSA_ORIGINATOR_SYSTEM_NAME
			]
		]

		exchange.out.body = iusaRequest
		setCSIHttpHeaders(exchange)
		exchange.out.headers.put("CamelHttpUri",resolveURN(getApiUrn(),null))
		exchange.properties.put("OceCSIApiName","InquireUnifiedServiceAccount")
		println('InquireUnifiedServiceAccountRequestTransformation.transform done')
	}

	public void processResponse(Exchange exchange) throws APIFailedException {
		def order = exchange.properties.order
		def executionContext = exchange.properties.executionContext

		def inquireUnifiedServiceAccountResponse = exchange.in.body
		println('IUSA Response :: ' +inquireUnifiedServiceAccountResponse)
		def iusaResponse = new XmlSlurper().parseText(inquireUnifiedServiceAccountResponse)
		//println("iusaResponse is**********************"  +iusaResponse)

		if (iusaResponse.Body.Fault.size()>0)
		{
			def e = new APIFailedException();
			e.api = getApiName()
			e.code = iusaResponse.Body.Fault.detail.CSIApplicationException.Response.code
			e.codeDescription = iusaResponse.Body.Fault.detail.CSIApplicationException.Response.description
			e.subCode = iusaResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code
			e.subCodeDescription = iusaResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
			addTransactionHistory(exchange,e)
			throw e
		}
		else
		{
			addTransactionHistory(exchange,null)
		}

		def addressId = iusaResponse.Body.InquireUnifiedServiceAccountResponse.CustomerIdDetailsByOrgId.MapAddressesExt.address1.text()
		println("addressId is:::"+addressId)
		executionContext.iusaResponse = inquireUnifiedServiceAccountResponse
		executionContext.conversationId = iusaResponse.Header.MessageHeader.TrackingMessageHeader.conversationId.text()
		executionContext.creditRisk = iusaResponse.Body.InquireUnifiedServiceAccountResponse.CustomerIdDetailsByOrgId.PrimaryContact.CreditScoreExt.creditRisk.text()
		if(addressId != null)
		{
			executionContext.put("iusaAddressIdPresent", true)
		}
		else
		{
			executionContext.put("iusaAddressIdPresent", false)
		}

		println('InquireUnifiedServiceAccountRequestTransformation.processResponse done')
		//return exchange.in.body
	}

	def appendError(order,executionContext)
	{
		List<ErrorBean> errList = new ArrayList<ErrorBean>();
		errList.add(new ErrorBean('300','ServiceAddress for the Order is not available'))
		OrderUtility.updateErrorList(order,executionContext,errList,'IN_QUEUE','IUSA_FAIL')
	}
	
//	public void printRequest(Exchange exchange)
//	{
//		println("**************** REQUEST is****************************"+exchange.in.body)
//	}
}