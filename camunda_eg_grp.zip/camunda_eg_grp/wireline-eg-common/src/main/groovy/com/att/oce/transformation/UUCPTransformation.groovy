package com.att.oce.transformation;

import org.apache.camel.Exchange
import org.camunda.bpm.engine.delegate.BpmnError
import org.slf4j.Logger;
import org.springframework.stereotype.Component

import com.att.oce.bpm.common.TransformationService;
import com.att.oce.bpm.common.WirelineConstants
import com.att.oce.bpm.common.WirelineTransformationService
import com.att.oce.bpm.common.util.CommonUtility;
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.utility.OrderUtility
import org.slf4j.Logger
import org.slf4j.LoggerFactory;

@Component('uucpTransformation')
class UUCPTransformation extends WirelineTransformationService {
	
	static Logger log = LoggerFactory.getLogger(UUCPTransformation.class)
	private boolean isCancelUUCP
	
	@Override String getApiName(){
		return 'UpdateUnifiedCreditPolicy';
	}
	
	public String getApiUrn() {
		return "urn:csi:services:icas:UpdateUnifiedCreditPolicy.jws";
	}

	public boolean preCondition(order,executionContext){
		log.debug('UUCPTransformation.preCondition')
		this.isCancelUUCP = executionContext.get("isCancelUUCP")
		
		def WirelessGroups = OrderUtility.getWirelessGroups(order)
		def WirelineGroups = OrderUtility.getWirelineGroups(order)
		def CreditPolicyUUCP = OrderUtility.isCreditPolicyUUCP(order)
		def CreditPolicyUUCPCancel = OrderUtility.isCreditPolicyUUCPCancel(order)
		def isCancelled  = OrderUtility.isCancelledGroupPresent(order)
				
		if(isCancelUUCP) {
			
			if(WirelineGroups && CreditPolicyUUCPCancel)
			return true
			else 
			return false
			
		}
		else {
			
			if(CreditPolicyUUCP || (isCancelled && CreditPolicyUUCPCancel)) {
				if(WirelessGroups || WirelineGroups) {
					return true
				} else {
					return false
				}
			} else {
				return false
			}
		}
	}
	
	public void transform(Exchange exchange)
	{
		exchange.properties.order = exchange.in.body.order
		exchange.properties.executionContext  = exchange.in.body.executionContext
		
		def executionContext = exchange.properties.executionContext
		
		this.isCancelUUCP = executionContext.get("isCancelUUCP")
		print('isCancelUUCP>>>>'+isCancelUUCP)
		def order = exchange.in.body.order
		println('order in UUCP transform()>>>>'+ order)
		def msgHeader = createMessageHeader((Map<String,Object>)exchange.in.body.order)
		def uucpRequest = prepareRequest(order,msgHeader)
		
		exchange.out.body = uucpRequest
		setCSIHttpHeaders(exchange)
		exchange.out.headers.put("CamelHttpUri",resolveURN(getApiUrn(),null))
		exchange.properties.put("OceCSIApiName",getApiName())
		println('UpdateUnifiedCreditPolicy.transform done')
	}
	
	def prepareRequest(order, msgHeader) {
		
		[ messageHeader : msgHeader,
			UpdateUnifiedCreditPolicyRequest : [
				"requestorCorrelationId": order.CustomerOrderNumber,
				"sourceApplicationId": WirelineConstants.SOURCE_APPLICATION_ID_MYATTSALES,
				"numberOfPolicies": WirelineConstants.NUMBER_OF_POLICIES_1,
				"PolicyDetails" : [
					"unifiedPolicyTransactionId": order?.CreditPolicy?.CreditPolicyTransactionId,
					"orderStatus":getOrderStatus(order)
				]
			]
		]
	}

	def getOrderStatus(def order)
	{
		if(isCancelUUCP) {
			
			return WirelineConstants.ORDER_STATUS_CA
		}
		
		else if(!OrderUtility.isCancelledGroupPresent(order)) {
			
			return WirelineConstants.ORDER_STATUS_PE
		}
		else {
				
			return WirelineConstants.ORDER_STATUS_CA
		}
	}
	
	public void processResponse(Exchange exchange) throws APIFailedException
	{
		int index=0
        def order = exchange.properties.order
		println('order in UUCP processResponse()>>>>'+ order)
		def executionContext = exchange.properties.executionContext
        def uucpResponseXml = new XmlSlurper().parseText(exchange.in.body)
		def uucpcResponse = exchange.in.body;
		this.isCancelUUCP = executionContext.get("isCancelUUCP")
		
		def uverseAccount = OrderUtility.getUverseAcount(order)
		//updating s/SS in Transaction History
		def transactionHistory = executionContext.get("transactionHistory")

		print("Transaction>>>>"+transactionHistory)
		if( transactionHistory == null){
			transactionHistory = new ArrayList<Map<String,Object>>()
		}
		
        if (uucpResponseXml.Body.Fault.size() > 0){
            def apie = new APIFailedException(
                api : getApiName(),
                code : uucpResponseXml.Body.Fault.detail.CSIApplicationException.Response.code,
                codeDescription : uucpResponseXml.Body.Fault.detail.CSIApplicationException.Response.description,
                subCode : uucpResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code,
                subCodeDescription : uucpResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
            )
			
			def subCode = uucpResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code
//			print('Subcode>>>> '+subCode)
			
			executionContext.put("LOSGStatus", "IN_QUEUE")
			if(isCancelUUCP) {
				if(subCode == '200'){
					
					OrderUtility.updateLoSGStatusForAccount(order, uverseAccount?.Id,WirelineConstants.LOSGSTATUS_CANCELED,"UPDATE_UNIFIED_POLICY_CANCELED_TIMEOUT");
//					transactionHistory.add(CommonUtility.getMap("StartTime", TransformationService.getXmlDateTime(),
//						"EndTime", TransformationService.getXmlDateTime(),"api","",
//						"success",false,"status",WirelineConstants.LOSGSTATUS_CANCELED,"subStatus",'UPDATE_UNIFIED_POLICY_CANCELED_TIMEOUT',"ReferenceId",uverseAccount?.Id));
					
				}
				else {
					OrderUtility.updateLoSGStatusForAccount(order, uverseAccount?.Id,WirelineConstants.LOSGSTATUS_CANCELED,"UPDATE_UNIFIED_POLICY_CANCELED_FAIL");
//					transactionHistory.add(CommonUtility.getMap("StartTime", TransformationService.getXmlDateTime(),
//						"EndTime", TransformationService.getXmlDateTime(),"api","",
//						"success",false,"status",WirelineConstants.LOSGSTATUS_CANCELED,"subStatus",'UPDATE_UNIFIED_POLICY_CANCELED_FAIL',"ReferenceId",uverseAccount?.Id))
					}
				
				addTransactionHistory(exchange,apie)
				return;
			}
			else {
				addTransactionHistory(exchange,apie)
				throw apie
			}
        
        }

		if(isCancelUUCP) {
			
			if(executionContext.get("isAWPInvoked")) {
				
				OrderUtility.updateAWPRefund(OrderUtility.getWirelineGroups(order))
				transactionHistory.add(CommonUtility.getMap("StartTime", TransformationService.getXmlDateTime(),
					"EndTime", TransformationService.getXmlDateTime(),"api","",
					"success",true,"status","","subStatus",'UUCP_REFUND_REQUIRED',"ReferenceId",null));

			}
		}
		else {
			def eucpcResponseXml = exchange.properties.executionContext.eucpcResponse
			def slurper = new XmlSlurper()
			def EUCPCResponse = slurper.parseText(eucpcResponseXml)
			def EUCPCRes = EUCPCResponse.Body.ExecuteUnifiedCreditPolicyCheckResponse
			
			Map<String,Object>uucpcUpdatedOrder = handleResponse(order,uucpResponseXml,EUCPCRes)
			executionContext.put("isUUCPPass",true)
			println("updated Order is"+uucpcUpdatedOrder);
			exchange.in.body = uucpcUpdatedOrder
			addTransactionHistory(exchange,null)
			
		}
		
		//addTransactionHistory(exchange,null)
	}
	
	def handleResponse(def order, def uucpResponseXml, def EUCPCRes) {
		
		def policyStatus = uucpResponseXml.Body.UpdateUnifiedCreditPolicyResponse.PolicyUpdateResults.policyStatus.text()
		def group=order.Groups.Group
		
//		if(policyStatus != "EX") {
			def securityType = EUCPCRes?.ProductDetails?.AffiliateDetails?.LineItemsDetails?.Security.securityType.flatten()
			
			def advancePaymentLineItemDetails = EUCPCRes?.ProductDetails?.AffiliateDetails?.LineItemsDetails.find {li -> li.Security.securityType.contains(WirelineConstants.SECURITY_TYPE_ADVPAY)}
			//def advancePayment = EUCPCRes?.ProductDetails?.AffiliateDetails?.LineItemsDetails.findAll {li -> li.Security.securityType.contains(WirelineConstants.SECURITY_TYPE_ADVPAY)}.collect{it.Security}
			
			def nrfLineItemDetails = EUCPCRes?.ProductDetails?.AffiliateDetails?.LineItemsDetails.find {li -> li.Security.securityType.contains(WirelineConstants.SECURITY_TYPE_NRF)}
			//def nrf = EUCPCRes?.ProductDetails?.AffiliateDetails?.LineItemsDetails.findAll {li -> li.Security.securityType.contains(WirelineConstants.SECURITY_TYPE_NRF)}.collect{it.Security}
			
			def noSecurityLineItemDetails = EUCPCRes?.ProductDetails?.AffiliateDetails?.LineItemsDetails.find {li -> li.Security.securityType == WirelineConstants.SECURITY_TYPE_NOSEC}
			//def noSecurity = EUCPCRes?.ProductDetails?.AffiliateDetails?.LineItemsDetails.findAll {li -> li.Security.securityType == WirelineConstants.SECURITY_TYPE_NOSEC}.collect{it.Security}

			if(securityType.contains(WirelineConstants.SECURITY_TYPE_ADVPAY) || securityType.contains(WirelineConstants.SECURITY_TYPE_NRF)) {

				for(def grpCounter=0;grpCounter<group.size();grpCounter++) {
					
					def losgStatus=group[grpCounter].GroupCharacteristics.LoSGCharacteristics.LoSGStatus.Status
					def losgSubstatus=group[grpCounter].GroupCharacteristics.LoSGCharacteristics.LoSGStatus.SubStatus
					
					if(group[grpCounter].GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status != WirelineConstants.LOSG_STATUS_CANCELED) {
						
						def losgSeqNo = group[grpCounter]?.GroupCharacteristics?.LoSGCharacteristics?.LoSGSequenceNumber
						def prodLnItmId = Integer.parseInt(productLineItemId.text())
						
						if(losgSeqNo==advancePaymentLineItemDetails?.productLineItemId && losgSeqNo == nrfLineItemDetails?.productLineItemId) {
							group[grpCounter].GroupCharacteristics.LoSGCharacteristics.LoSGStatus.Status=WirelineConstants.LOSGSTATUS_PENDING
							group[grpCounter].GroupCharacteristics.LoSGCharacteristics.LoSGStatus.SubStatus=WirelineConstants.LOSGSUBSTATUS_ADVANCE_PAYMENT_AND_NRF_REQUIRED
						}
						else if(losgSeqNo==noSecurityLineItemDetails?.productLineItemId) {
							group[grpCounter].GroupCharacteristics.LoSGCharacteristics.LoSGStatus.Status=WirelineConstants.LOSGSTATUS_SYS_PROCESSING
							group[grpCounter].GroupCharacteristics.LoSGCharacteristics.LoSGStatus.SubStatus=WirelineConstants.LOSGSUBSTATUS_NO_SECURITY_FEE_REQUIRED
						}
						else if(losgSeqNo==nrfLineItemDetails?.productLineItemId) {
							group[grpCounter].GroupCharacteristics.LoSGCharacteristics.LoSGStatus.Status=WirelineConstants.LOSGSTATUS_PENDING
							group[grpCounter].GroupCharacteristics.LoSGCharacteristics.LoSGStatus.SubStatus=WirelineConstants.LOSGSUBSTATUS_NON_REFUNDABLE_FEE_REQUIRED
						}
						else if(losgSeqNo==advancePaymentLineItemDetails?.productLineItemId) {
							group[grpCounter].GroupCharacteristics.LoSGCharacteristics.LoSGStatus.Status=WirelineConstants.LOSGSTATUS_PENDING
							group[grpCounter].GroupCharacteristics.LoSGCharacteristics.LoSGStatus.SubStatus=WirelineConstants.LOSGSUBSTATUS_ADVANCE_PAYMNET_REQUIRED
						}else {
							group[grpCounter].GroupCharacteristics.LoSGCharacteristics.LoSGStatus.Status=WirelineConstants.LOSGSTATUS_PENDING
							group[grpCounter].GroupCharacteristics.LoSGCharacteristics.LoSGStatus.SubStatus=WirelineConstants.LOSGSUBSTATUS_NO_SECURITY_FEE_REQUIRED
						}
					}
				}
//			} 
		} 
			
		order?.CreditPolicy?.UUCPStatus = "true"
		return order
	}
}