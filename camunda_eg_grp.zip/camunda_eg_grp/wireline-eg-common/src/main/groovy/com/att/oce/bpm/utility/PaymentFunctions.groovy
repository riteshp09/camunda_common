package com.att.oce.bpm.utility

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.common.WirelineTransformationService;

import groovy.json.JsonSlurper
import org.apache.camel.Exchange
import org.json.JSONObject
import org.springframework.stereotype.Component
import com.att.oce.bpm.utility.OrderUtility

@Component('paymentFunctions')
class PaymentFunctions /*extends WirelineTransformationService*/ {

	String url;

	/*
	 * This function will do the transformation for ATG Create Order service
	 * @param exchange of type Camel Exchange
	 * */
	public static def getPaymentRefforAutoPay(def Order){

		def LineItemList=Order.LineItems?.LineItem
		def PaymentOptionRef
		
		for(def i=0;i<LineItemList?.size();i++){
			def LineItemMap=LineItemList?.get(i)

			if(LineItemMap?.SystemName == 'AUTO_PAYMENT' ){
				PaymentOptionRef=LineItemMap?.Payments?.Payment?.get(0)?.PaymentOptionRef
				break
			}
		}
		return PaymentOptionRef
		
	}
	
	public static def getPaymentRefforAutoPayId(def Order){
				def LineItem_AutoPay =getPaymentRefforAutoPay(Order)// payment 1
				
				def PaymentOptionList=Order.PaymentOptions?.PaymentOption
				
		def PaymentOptionRefId
		for(def i=0;i<PaymentOptionList?.size();i++){
			def PaymentOptionMap=PaymentOptionList?.get(i)
			//def PaymentOptionId = PaymentOptionMap.Id
			
			if(LineItem_AutoPay != null && PaymentOptionMap?.Id == LineItem_AutoPay ){
				PaymentOptionRefId=PaymentOptionMap?.Id
			}
		}
	return PaymentOptionRefId
	}

	public static def getPaymentRefforAdvancePay(def Order){
		def LineItemList=Order.LineItems?.LineItem

		def PaymentOptionRefId
		
		for(def i=0;i<LineItemList?.size();i++){
			def LineItemMap=LineItemList?.get(i)

			if(LineItemMap?.SystemName == 'ADVANCE_PAYMENT' || LineItemMap?.SystemName == 'CREDIT_MANAGEMENT_FEE' ){
				
				PaymentOptionRefId=LineItemMap.Payments.Payment.get(0).PaymentOptionRef
			}
		}
		return PaymentOptionRefId
}
	
	
	public static def getPaymentRefforAdvancePayId(def Order){
		def LineItem_AdvancePay =getPaymentRefforAdvancePay(Order)
		def PaymentOptionList=Order.PaymentOptions?.PaymentOption
		def PaymentOptionRefId
		
		for(def i=0;i<PaymentOptionList?.size();i++){
			def PaymentOptionMap=PaymentOptionList?.get(i)
			def PaymentOptionId = PaymentOptionMap?.Id
	
			if(LineItem_AdvancePay!= null && PaymentOptionId == LineItem_AdvancePay ){
				PaymentOptionRefId=PaymentOptionId
			}
		}
		return PaymentOptionRefId
	}
	
	public static def doesOrderhaveAutopay(def Order){
		def PaymentOptionList=Order.PaymentOptions?.PaymentOption

		for(def i=0;i<PaymentOptionList?.size();i++){
			def PaymentOptionMap=PaymentOptionList?.get(i)
			
			if(PaymentOptionMap?.AutoBillIndicator == 'Y' ){
				return true
			}
			else
			return false
		}
	}
	
	
}

	

