package com.att.oce.transformation

import com.att.oce.bpm.common.WirelineTransformationService;
import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.error.OceErrorHandler
import com.att.oce.config.components.GlobalProperties
import java.text.DecimalFormat
import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import com.att.oce.bpm.common.WirelineTransformationService
import com.att.oce.bpm.common.WirelineConstants
import org.camunda.bpm.engine.delegate.JavaDelegate;
import com.att.oce.bpm.utility.OrderUtility

@Component('EUCPCRequestTransformation')
class EUCPCRequestTransformation  extends WirelineTransformationService  {

	static Logger log = LoggerFactory.getLogger(EUCPCRequestTransformation.class)

	@Override String getApiName(){
		return 'ExecuteUnifiedCreditPolicyCheck';
	}

	public String getApiUrn() {
		return "urn:csi:services:icas:ExecuteUnifiedCreditPolicyCheck.jws";
	}


	public void transform(Exchange exchange){
		println ('ExecuteUnifiedCreditPolicyCheckRequestTransformation.transform')
		int index = 0
		exchange.properties.order = exchange.in.body.order
		def order = exchange.in.body.order
		exchange.properties.executionContext  = exchange.in.body.executionContext

		def account = order?.Accounts?.Account[index]
		def nameRef = account?.BillingInfo[index]?.NameRef
		def accountName = OrderUtility.getName(order,nameRef)
		def orderContactName = OrderUtility.getName(order,order?.OrderContact?.NameRef)
		def uverseAcc = OrderUtility.getUverseAcount(order)
		def addressDetails = getAddress(order, uverseAcc)
		def producttype = determineProductTypes(order)
		def customerDetails = getCustomerorderNumber(order)
		def affiliateDetails = getAffiliateDetails(order)
		def billingIndicator = getBillDeliveryMethod(uverseAcc)
		def preferredLanguages = getCustomerPreferredLanguage(order)
		def lineItemAttributesDetails = getLineItemAttributesDetails(order)
		def quantityAttributesValue = lineItemAttributesDetails.QuantityAttributesValue
		def productSkuvalue = lineItemAttributesDetails.ProductSkuvalue
		def numberOfLineItemAttributes = lineItemAttributesDetails.numberOfLineItemAttributes

		def msgHeader = createMessageHeader(order)
		def eucpcRequest = [ messageHeader : msgHeader,
			ExecuteUnifiedCreditPolicyCheckRequest : [
				affiliateId: producttype?.affiliateId,
				salesChannel: order?.OrderSource?.Channel,
				salesChannelType: order.OrderSource?.ClientType,
				sourceApplicationId: WirelineConstants.SOURCE_APPLICATION_ID,
				requestorCorrelationId: order.CustomerOrderNumber,
				CustomerDetails:[
					NameDetails: [
						FirstNameInfo:accountName?.FirstName,
						LastNameInfo:accountName?.LastName
					],
					AddressDetails:[
						customerCity: (addressDetails?.ParsedAddress!=null) ? addressDetails?.ParsedAddress?.City : addressDetails?.UnparsedAddress?.City,
						customerState: (addressDetails?.ParsedAddress!=null) ? addressDetails?.ParsedAddress?.State : addressDetails?.UnparsedAddress?.State,
						customerZipCode:(addressDetails?.ParsedAddress!=null) ? addressDetails?.ParsedAddress?.Zip : addressDetails?.UnparsedAddress?.Zip,
						customerAddressStreetNumber: (addressDetails?.ParsedAddress!=null) ? addressDetails?.ParsedAddress?.StreetNumber : addressDetails?.UnparsedAddress?.StreetNumber,
						customerAddressStreetDirection: getCustAddStreetDir(order, addressDetails, uverseAcc),
						customerAddressStreetName: (addressDetails?.ParsedAddress!=null) ? addressDetails?.ParsedAddress?.StreetName : addressDetails?.UnparsedAddress?.StreetName,
						customerAddressStreetType: (addressDetails?.ParsedAddress!=null) ? addressDetails?.ParsedAddress?.StreetType : addressDetails?.UnparsedAddress?.StreetType,
						customerAddressLine1: getCustAddressLine1(order, addressDetails, uverseAcc),
						customerAddressLine2: getCustAddressLine2(order, addressDetails, uverseAcc)
					],
					OtherDetails:[
						customerPreferredLanguageOption: preferredLanguages?.CustomerPreferredLanguage,
						paperlessBillingIndicator:billingIndicator,
						ssn:order.Accounts.Account[index]?.BillingInfo[index]?.Authentication?.SSN,
						dob:order.Accounts.Account[index]?.BillingInfo[index]?.Authentication?.DOB,
						businessName:order.Accounts?.Account[index]?.BusinessAccountName,
						emailAddress:order?.OrderContact?.PrimaryEmailAddress,
						contactPhone:orderContactName?.PrimaryContactPhone[index]?.PhoneNumber,
						contactPhoneType:orderContactName?.PrimaryContactPhone[index]?.ContactPhoneType
					]
				],

				ProductDetails:[
					numberOfAffiliates: affiliateDetails?.numberOfAffiliatesCount,
					AffiliateDetails:[
						affiliateCode: producttype?.affiliateId,
						productType: WirelineConstants.UVERSE_PRODUCT_TYPE,
						numberOfLineItems: affiliateDetails?.numberOfLineItems,
						LineItemsDetails:[
							actionType: WirelineConstants.ACTION_TYPE,
							productLineItemId:'PLI001',
							customerActivityType1: affiliateDetails?.customerActivityType1,
							numberOfLineItemAttributes: lineItemAttributesDetails?.numberOfLineItemAttributes,
							LineItemQuantityAttributeDetails:[
								AttributeCode: WirelineConstants.QUANTITY_ATTRIBUTE_CODE,
								AttributeValue: lineItemAttributesDetails?.QuantityAttributesValue
							],
							LineItemProductAttributeDetails:[
								AttributeCode: WirelineConstants.PRODUCT_SKU_ATTRIBUTE_CODE,
								AttributeValue: WirelineConstants.PRODUCT_SKU_ATTRIBUTE_VALUE
							],
							LineItemOptionalFeatureAttributeDetails:[
								AttributeCode: WirelineConstants.OPTIONAL_FEATURE_ATTRIBUTE_CODE,
								AttributeValue: WirelineConstants.OPTIONAL_FEATURE_SKU_ATTRIBUTE_VALUE
							],
							LineItemProductCategoryAttributeDetails:[
								AttributeCode: lineItemAttributesDetails?.attributeCode,
								AttributeValue: lineItemAttributesDetails?.attributeValue
							],
							customerActivityType2: WirelineConstants.CUSTOMER_ACTIVITY_TYPE2,
							customerActivityType3: WirelineConstants.CUSTOMER_ACTIVITY_TYPE3
						],

					],
				],

				businessOrResidenceCode: OrderUtility.isSMB(order) ? WirelineConstants.BUSINESS_ORRESIDENCE_CODE : "RES",
				customerAccountTypes: getCustomerAccountTypes(order),
				dealerCode: producttype?.dealearCode,
				ban:order.Accounts?.Account[index]?.BillingAccountNumber,
				accountType:customerDetails?.AccountType,
				accountSubType:order.Accounts?.Account[index]?.AccountSubType,
				casOrderNumber: order.Accounts?.Account[index]?.CreditCheck?.ApplicationNumber,
				unifiedCreditTransactionId:customerDetails?.applicationNumber,
				market:order.Accounts?.Account[index]?.Market,
				subMarket:order.Accounts?.Account[index]?.SubMarket,
				fanName:order.B2Bs?.B2B[index]?.B2BFANBusinessName,
				fan:order.B2Bs?.B2B[index]?.B2BFAN
			]
		]

		exchange.out.body = eucpcRequest
		//println(' >>>>>>>>>>>>>>>>>>>>>>>>>>>>>'+eucpcRequest)
		setCSIHttpHeaders(exchange)
		exchange.out.headers.put("CamelHttpUri",resolveURN(getApiUrn(),null))
		exchange.properties.put("OceCSIApiName","ExecuteUnifiedCreditPolicyCheck")
		println('ExecuteUnifiedCreditPolicyCheck.transform done')
	}

	public void processResponse(Exchange exchange)throws APIFailedException {
		int index=0
		def order = exchange.properties.order
		def executionContext = exchange.properties.executionContext
		def eucpcResponseXml = new XmlSlurper().parseText(exchange.in.body)
		def eucpcResponse = exchange.in.body;

		executionContext.put("eucpcResponse", eucpcResponse)
		//println "RESPONSE" + eucpcResponse

		log.debug(exchange.in.body)
		if (eucpcResponseXml.Body.Fault.size() > 0){
			def apie = new APIFailedException(
					api : getApiName(),
					code : eucpcResponseXml.Body.Fault.detail.CSIApplicationException.Response.code,
					codeDescription : eucpcResponseXml.Body.Fault.detail.CSIApplicationException.Response.description,
					subCode : eucpcResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code,
					subCodeDescription : eucpcResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
					)
			executionContext.put("LOSGStatus", "IN_QUEUE")
			addTransactionHistory(exchange,apie)
			throw apie
		}
		Map<String,Object>eucpcUpdatedOrder = updateOrder(order,eucpcResponseXml)
		//println("updated Order is"+eucpcUpdatedOrder);
		exchange.in.body = eucpcUpdatedOrder
		order = exchange.in.body
		addTransactionHistory(exchange,null)
		//return order
	}

	def  determineProductTypes(order){
		Map<String,Object> groupTransactionLogs = new HashMap<String, Object>();
		def affiliateId
		String dealearCode
		String result

		result=  order.Groups?.Group[0]?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
		dealearCode = order.Groups?.Group[0]?.GroupCharacteristics?.LoSGCharacteristics?.DealerCode;
		if(result.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_IPTV)||result.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_INTERNET)
		|| result.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_VOIP)) {
			affiliateId = WirelineConstants.UVERSE_AFFILIATE_ID;
		}  else {
			affiliateId = WirelineConstants.MOBILITY_AFFILIATE_ID;
		}

		if(dealearCode == null) {
			dealearCode = order.AgentCode
		}

		groupTransactionLogs.put("affiliateId",affiliateId);
		groupTransactionLogs.put("dealearCode",dealearCode);

		return groupTransactionLogs
	}


	def getCustomerorderNumber(order) {
		Map<String,Object> transactionLogs = new HashMap<String, Object>();
		List details = new ArrayList()

		int index = 0
		String CustomerAccountType;
		String AccountType
		def accountList = order.Accounts?.Account
		def CreditCheck
		def SubMarket
		def Market
		def ApplicationNumber
		def AccountSubType
		def ban

		for(def i=0;i<accountList.size();i++){
			def accountMap=accountList.get(0)
			CreditCheck = accountMap?.CreditCheck
			SubMarket = accountMap?.SubMarket
			Market = accountMap?.Market
			AccountSubType = accountMap?.AccountSubType
			ban = accountMap?.BillingAccountNumber
			AccountType = accountMap?.AccountType

			//Validate customerAccountTypes
			if(accountMap?.EnterpriseType == "CON") {
				CustomerAccountType = WirelineConstants.ENTERPRISETYPE_CON;
			} else if(accountMap?.EnterpriseType == WirelineConstants.ENTERPRISE_TYPE_IRU){
				CustomerAccountType = WirelineConstants.ENTERPRISETYPE_IRU;
			} else if(accountMap?.EnterpriseType == WirelineConstants.INDIVIDUAL) {
				CustomerAccountType = WirelineConstants.ENTERPRISETYPE_INDIVIDUAL;
			} else {
				CustomerAccountType = WirelineConstants.ENTERPRISETYPE_DEFAULT;
			}

			if(CreditCheck.ApplicationNumber != null){
				ApplicationNumber = CreditCheck?.ApplicationNumber;
			} else {
				ApplicationNumber = CreditCheck?.CCMTransactionID;
			}

			//Validate AccountType
			if(AccountType.equalsIgnoreCase(WirelineConstants.INDIVIDUAL)) {
				AccountType = WirelineConstants.INDIVIDUAL_ACCOUNT_TYPE
			} else if(AccountType.equalsIgnoreCase(WirelineConstants.BUSINESS)) {
				AccountType = WirelineConstants.BUSINESS_ACCOUNT_TYPE
			} else if(AccountType.equalsIgnoreCase(WirelineConstants.GOVERNMENT)) {
				AccountType = WirelineConstants.GOVERNMENT_ACCOUNT_TYPE
			} else if(AccountType.equalsIgnoreCase(WirelineConstants.SPECIAL)) {
				AccountType = WirelineConstants.SPECIAL_ACCOUNT_TYPE
			}

			transactionLogs.put("CustomerAccountType", CustomerAccountType);
			transactionLogs.put("applicationNumber", ApplicationNumber);
			transactionLogs.put("Market", Market);
			transactionLogs.put("subMarket", SubMarket);
			transactionLogs.put("AccountSubType", AccountSubType);
			transactionLogs.put("ban", ban);
			transactionLogs.put("AccountType", AccountType);
		}

		return transactionLogs
	}


	def getAffiliateDetails(orderMap){
		Map<String,Object> transactionLogs = new HashMap<String, Object>();

		String ProductCategory
		String LoSGType
		String customerActivityType
		String ProductCategoryAttribute
		def UverseArtifactCount=0
		def MobilityArtifactCount=0
		def numberOfAffiliatesCount=0

		def groupList=orderMap.Groups?.Group
		//Getting the LOSG count
		def losgCount=0
		def ProductCategoryCount=0
		for(def i=0;i<groupList.size();i++){
			def groupMap=groupList.get(0)
			ProductCategory = groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
			LoSGType = groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType

			//numberOfLineItems
			if(LoSGType.equalsIgnoreCase(WirelineConstants.LoSGType_NEW) || LoSGType.equalsIgnoreCase(WirelineConstants.LOSGTYPE_CHANGE)){
				losgCount++
			}
			if( ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_IPTV) || ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_INTERNET)
			|| ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_VOIP)) {
				ProductCategoryCount++
			}

			//ProductCategoryAttributes
			if( ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_IPTV)) {
				ProductCategoryAttribute = WirelineConstants.PRODUCTCATEGORY_IPTV
			} else if(ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_INTERNET)) {
				ProductCategoryAttribute = WirelineConstants.PRODUCTCATEGORY_INTERNET
			} else if( ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_VOIP)) {
				ProductCategoryAttribute = WirelineConstants.PRODUCTCATEGORY_VOIP
			}

			//numberOfAffiliates
			if((ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_IPTV) || ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_INTERNET)
			|| ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_VOIP)) && (ProductCategory.equalsIgnoreCase(WirelineConstants.ProductCategory_WIRELESS))) {
				UverseArtifactCount++
				MobilityArtifactCount++
				numberOfAffiliatesCount = UverseArtifactCount+MobilityArtifactCount
			} else if(ProductCategory.equalsIgnoreCase(WirelineConstants.ProductCategory_WIRELESS))	{

				numberOfAffiliatesCount = WirelineConstants.UVERSE_GROUP_AFFILIATES_COUNT
			} else if(ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_IPTV) || ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_INTERNET)
			|| ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_VOIP)) {
				numberOfAffiliatesCount = WirelineConstants.UVERSE_GROUP_AFFILIATES_COUNT
			}


			//customerActivityType1
			if((LoSGType.equalsIgnoreCase(WirelineConstants.LoSGType_NEW) || LoSGType.equalsIgnoreCase(WirelineConstants.LOSGTYPE_CHANGE))
			&& (ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_IPTV) || ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_INTERNET)
			|| ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_VOIP)) && (orderMap.MoveInfo != null)) {
				customerActivityType = WirelineConstants.UVERSE_CUSTOMER_ACTIVITY_TYPE
			} else if((LoSGType.equalsIgnoreCase(WirelineConstants.LoSGType_NEW) || LoSGType.equalsIgnoreCase(WirelineConstants.LOSGTYPE_CHANGE))
			&& (ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_IPTV) || ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_INTERNET)
			|| ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_VOIP)) && (orderMap.MoveInfo == null)) {
				customerActivityType = WirelineConstants.UVERSE_CUSTOMER_ACTIVITY_TYPE1
			}
			transactionLogs.put("numberOfLineItems", losgCount+ProductCategoryCount);
			transactionLogs.put("customerActivityType1", customerActivityType);
			transactionLogs.put("ProductCategoryAttribute", ProductCategoryAttribute);
			transactionLogs.put("numberOfAffiliatesCount", numberOfAffiliatesCount);
		}
		return transactionLogs
	}


	/*
	 * This function will return UVERSE account from Accounts in a list
	 * @param - order object
	 * */

	def getUverseAccount(def order){
		def accountList = order.Accounts?.Account

		//Loading the Accounts in a list which has AccountType as UVERSE
		def accounts = new ArrayList()
		for(def i=0;i<accountList.size();i++){
			def accountMap = accountList.get(i)
			if(accountMap?.AccountCategory == WirelineConstants.ACCOUNTCATEGORY_UVERSE_ACCOUNT){
				accounts.add(accountMap)
			}
		}
		return accounts
	}


	/*
	 * This function will return address from order of corresponding Account
	 * @param - order object,UVERSE Account object
	 * */
	def getAddress(def order, def uverseAcc){
		def addressMap;
		//def addressDetails
		List<String> Addresses = order?.Addresses?.Address
		if(Addresses && uverseAcc?.BillingInfo && uverseAcc?.BillingInfo[0]?.AddressRef){
			for(def address in Addresses) {
				if(address.Id == uverseAcc?.BillingInfo[0]?.AddressRef) {
					addressMap=address
					break
				}
			}
		}
		/*		if(addressMap?.ParsedAddress != null) {
		 addressDetails = addressMap?.ParsedAddress
		 } else {
		 addressDetails = addressMap?.UnparsedAddress
		 }*/
		return addressMap
	}

	def getAddressServiceLoc(def order, def uverseAcc){
		def addressMap;
		def addressMapBill;
		def addressDetails
		List<String> Addresses = order?.Addresses?.Address
		if(Addresses && uverseAcc?.ServiceLocationRef){
			for(def address in Addresses) {
				if(address.Id == uverseAcc?.ServiceLocationRef) {
					addressMap=address
					break
				}
			}
		}
		if(Addresses && uverseAcc?.BillingInfo && uverseAcc?.BillingInfo[0]?.AddressRef){
			for(def address in Addresses) {
				if(address.Id == uverseAcc?.BillingInfo[0]?.AddressRef) {
					addressMapBill=address
					break
				}
			}
		}
		if(addressMap?.ParsedAddress != null) {
			addressDetails = addressMap?.ParsedAddress
		} else {
			addressDetails = addressMapBill?.UnparsedAddress
		}
		return addressDetails
	}

	def getCustAddStreetDir(def order, def addressDetails, def uverseAcc){
		def wirelessGroups = order.Groups.Group.findAll{g -> (g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "NEW" || g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "AL") && g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="WIRELESS" &&
			(g?.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod == "DF" || g?.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod == "C2S")}
		def wirelineGroups = order.Groups.Group.findAll{g -> (g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "NEW" || g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "CHANGE" || g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "NO_CHANGE") &&
			(g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="INTERNET" || g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="IPTV" || g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="VOIP")}
		def addressServiceLoc = getAddressServiceLoc(order, uverseAcc)
		def customerAddressStreetDirection

		if(!(wirelessGroups.isEmpty()) && wirelineGroups.isEmpty()){
			customerAddressStreetDirection = (addressDetails?.ParsedAddress!=null) ? addressDetails?.ParsedAddress?.Direction : addressDetails?.UnparsedAddress?.Direction
		}
		else{
			customerAddressStreetDirection = addressServiceLoc?.Direction
		}
		return customerAddressStreetDirection
	}
	
	def getCustAddressLine1(def order, def addressDetails, def uverseAcc){
		def wirelessGroups = order.Groups.Group.findAll{g -> (g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "NEW" || g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "AL") && g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="WIRELESS" &&
			(g?.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod == "DF" || g?.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod == "C2S")}
		def wirelineGroups = order.Groups.Group.findAll{g -> (g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "NEW" || g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "CHANGE" || g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "NO_CHANGE") &&
			(g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="INTERNET" || g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="IPTV" || g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="VOIP")}
		def addressServiceLoc = getAddressServiceLoc(order, uverseAcc)
		def customerAddressLine1

		if(!(wirelessGroups.isEmpty()) && wirelineGroups.isEmpty()){
			customerAddressLine1 = addressDetails?.UnparsedAddress?.AddressLine1
		}
		else{
			customerAddressLine1 = addressServiceLoc?.AddressLine1
		}
		return customerAddressLine1
	}
	
	
	def getCustAddressLine2(def order, def addressDetails, def uverseAcc){
		def wirelessGroups = order.Groups.Group.findAll{g -> (g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "NEW" || g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "AL") && g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="WIRELESS" &&
			(g?.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod == "DF" || g?.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod == "C2S")}
		def wirelineGroups = order.Groups.Group.findAll{g -> (g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "NEW" || g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "CHANGE" || g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "NO_CHANGE") &&
			(g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="INTERNET" || g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="IPTV" || g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="VOIP")}
		def addressServiceLoc = getAddressServiceLoc(order, uverseAcc)
		def customerAddressLine1

		if(!(wirelessGroups.isEmpty()) && wirelineGroups.isEmpty()){
			customerAddressLine1 = addressDetails?.UnparsedAddress?.AddressLine2
		}
		else{
			customerAddressLine1 = addressServiceLoc?.AddressLine2
		}
		return customerAddressLine1
	}

	/*
	 * This function will return billDeliveryMethod from Account
	 * @param - Account of order Map object
	 * */

	def getBillDeliveryMethod(def account){
		String billDeliveryMethod = account?.BillingDeliveryPreference

		if(billDeliveryMethod != null){
			if(billDeliveryMethod.equalsIgnoreCase(WirelineConstants.BillingDeliveryPreference_PAPER)) {
				billDeliveryMethod = "N"
			}else {
				billDeliveryMethod = "Y"
			}
		}
		return billDeliveryMethod
	}

	def getCustomerPreferredLanguage(def order) {
		Map<String,Object> transactionLogs = new HashMap<String, Object>();

		int index = 0
		def accountList = order.Accounts?.Account
		String CustomerPreferredLanguage
		for(def i=0;i<accountList.size();i++){
			def accountMap=accountList.get(index)
			CustomerPreferredLanguage = accountMap?.SpokenLanguagePreference
			if(CustomerPreferredLanguage.equalsIgnoreCase(WirelineConstants.SPOKEN_LANGUAGE_ENGLISH)) {
				CustomerPreferredLanguage = WirelineConstants.CUSTOMER_PREFERRED_LANGUAGE_EN
			} else if(CustomerPreferredLanguage.equalsIgnoreCase(WirelineConstants.SPOKEN_LANGUAGE_SPANISH)) {
				CustomerPreferredLanguage = WirelineConstants.CUSTOMER_PREFERRED_LANGUAGE_ES
			}
			transactionLogs.put("CustomerPreferredLanguage" ,CustomerPreferredLanguage);
		}
		return transactionLogs
	}

	/*
	 * This function will returns LineItemAttributesDetails from order
	 * @param - order object
	 * */

	def getLineItemAttributesDetails(def order) {
		Map<String,Object> transactionLogs = new HashMap<String, Object>();

		String ProductCategory
		def LineItemlist=order?.LineItems?.LineItem
		def LineItemCount=LineItemlist.size();
		def ProductType
		def ProductSkuvalue
		def optionoalSkuvalue
		def QuantityCount = 0
		def productSKUCount = 0
		def optionalProductSKUCount=0
		def productCategoryAttributesCount=0
		def attributeCode
		def attributeValue

		for(def i=0;i<LineItemCount;i++)
		{
			def lineItem=LineItemlist.get(i)
			ProductType = lineItem.ProductType
			def ProductSku = lineItem.ProductSku
			def groupMap = order.Groups.Group[i]

			if((lineItem?.HardGood != null) && (lineItem?.HardGood?.HardGoodType=="DVR" ||lineItem?.HardGood?.HardGoodType=="STB" ))
			{
				if(lineItem?.Quantity != null) {
					QuantityCount++
				}
			}

			if(lineItem?.ProductSku != null && lineItem?.ProductType == "PLAN") {
				ProductSkuvalue = "true"
				productSKUCount++
			}

			if(lineItem?.ProductType == "OPTIONAL_FEATURE") {
				optionoalSkuvalue = "true"
				optionalProductSKUCount++

			}
			if(groupMap!= null && groupMap?.GroupCharacteristics?.LoSGCharacteristics != null){
				ProductCategory = groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
				if(ProductCategory != null && (ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_IPTV) || ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_INTERNET)
				|| ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_VOIP))) {
					productCategoryAttributesCount++
				}
			}

			if(ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_IPTV)){
				attributeCode = WirelineConstants.PRODUCTCATEGORY_IPTV
				attributeValue = WirelineConstants.PRODUCTCATEGORY_IPTV
			} else if (ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_INTERNET)) {
				attributeCode = WirelineConstants.PRODUCTCATEGORY_INTERNET
				attributeValue = WirelineConstants.PRODUCTCATEGORY_INTERNET
			} else if(ProductCategory.equalsIgnoreCase(WirelineConstants.PRODUCTCATEGORY_VOIP)) {
				attributeCode = WirelineConstants.PRODUCTCATEGORY_VOIP
				attributeValue = WirelineConstants.PRODUCTCATEGORY_VOIP
			}

			transactionLogs.put("QuantityAttributesValue",QuantityCount)
			transactionLogs.put("ProductSkuvalue",ProductSkuvalue)
			transactionLogs.put("numberOfLineItemAttributes",QuantityCount+productSKUCount+optionalProductSKUCount+productCategoryAttributesCount)
			transactionLogs.put("attributeCode",attributeCode)
			transactionLogs.put("attributeValue",attributeValue)
		}
		return transactionLogs
	}

	def getCustomerAccountTypes(def order) {
		def custAccType
		def accountList = order?.Accounts?.Account
		//def uverseAcc = OrderUtility.getUverseAcount(order)

		for(def i=0;i<accountList.size();i++){
			def accountMap=accountList.get(i)
			if(order.OrderSource.Channel == WirelineConstants.CHANNEL_SMB){
				if(accountMap?.B2BRef!=null){
					def b2bList = order?.B2Bs?.B2B
					for(def j=0;j<b2bList.size();j++){
						def b2bMap = b2bList.get(j)
						if(b2bMap?.Id==accountMap?.B2BRef && (b2bMap?.BusinessType!=null) ){
							if(b2bMap?.BusinessType.toLowerCase() == "PARTNERSHIP".toLowerCase()) {
								custAccType = "T0019"
							}
							else if(b2bMap?.BusinessType.toLowerCase() == "SoleProprietorship".toLowerCase()){
								custAccType = "T0018"
							}
						}
					}
				}
			}
			else if(order.OrderSource.Channel != WirelineConstants.CHANNEL_SMB){
				if(accountMap?.EnterpriseType=="CON"){
					custAccType = "T0016"
				}
				else if(accountMap?.EnterpriseType=="IRU" || accountMap?.EnterpriseType=="INDIVIDUAL"){
					custAccType = "T0001"
				}
				else{
					custAccType = "T0017"
				}
			}
		}
		return custAccType;
	}

	def updateOrder(order,eucpcResponseXml) {
		String UnifiedPolicyTransactionId
		String PolicyStatus
		String PolicyStatusReason
		String Code

		if (eucpcResponseXml instanceof String)
			eucpcResponseXml = new XmlSlurper().parseText(eucpcResponseXml)

		def eucpcResponse = eucpcResponseXml.Body.ExecuteUnifiedCreditPolicyCheckResponse

		updatePostEUCPCResponse(order, eucpcResponse)
		postEUCPCGroups(order, eucpcResponse)
		PostEUCPCLineItems(order, eucpcResponse)

		return order
	}

	def updatePostEUCPCResponse(def order, def eucpcResponse){
		String unifiedPolicyTransactionId = eucpcResponse?.unifiedPolicyTransactionId
		if(unifiedPolicyTransactionId!=null && !(unifiedPolicyTransactionId.isEmpty())){
			order.CreditPolicy.put("CreditPolicyTransactionId", unifiedPolicyTransactionId)
		}
		return order
	}

	def postDownpayment(def order, def eucpcResponse){
		def postDwnpay = false
		def productLineItemId = eucpcResponse?.ProductDetails?.AffiliateDetails?.LineItemsDetails.find{ li -> li?.Security?.action == "AD" &&  li?.Security?.securityType == "DWNPAY"}?.productLineItemId
		//def prodlineItem = Integer.parseInt(productLineItemId.text())
		def losgId = order?.Groups?.Group.findAll{ls -> ls?.GroupCharacteristics?.LoSGCharacteristics?.LoSGSequenceNumber == productLineItemId.text()}
		def lineItemDWNPAY = order?.LineItems?.LineItem.findAll{li -> li?.GroupRefs?.GroupRef == losgId?.Id}
		for(def lineItem in lineItemDWNPAY){
			if(lineItem?.ContractDetails?.DownPayment != null){
				def securityAmt = eucpcResponse?.ProductDetails?.AffiliateDetails?.LineItemsDetails.find{ li -> li?.Security?.action == "AD" &&  li?.Security?.securityType == "DWNPAY"}?.Security?.securityAmount.text()
				BigDecimal big = new BigDecimal(securityAmt);
				if( (lineItem?.ContractDetails?.DownPayment) >= big  ){
					postDwnpay = true
				}
			}
		}
		return postDwnpay
	}

	def pendingDepositLineItem(def order, def eucpcResponse){
		def groups = order.Groups.Group.findAll{g -> g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status != WirelineConstants.LOSG_STATUS_CANCELED && g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory!="MISC"}
		for(def group in groups){
			def productLineItemId = eucpcResponse?.ProductDetails?.AffiliateDetails?.LineItemsDetails.find{ li -> li?.Security?.action == "AD" &&  li?.Security?.securityType == "DWNPAY"}?.productLineItemId
			if(group?.GroupCharacteristics?.LoSGCharacteristics!=null && (group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGSequenceNumber == productLineItemId.text())){
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status = "PENDING"
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = "DOWN_PAYMENT_REQUIRED"
			}
			else if(group?.GroupCharacteristics?.LoSGCharacteristics!=null){
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status = "PENDING"
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = "NO_SECURITY_FEE_REQUIRED"
			}
		}
		return order
	}

	def pendingPayinFull(def order, def eucpcResponse){
		def groups = order.Groups.Group.findAll{g -> g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status != WirelineConstants.LOSG_STATUS_CANCELED && g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory!="MISC"}
		for(def group in groups){
			def productLineItemId = eucpcResponse?.ProductDetails?.AffiliateDetails?.LineItemsDetails.find{ li -> li?.Security?.action == "AD" &&  li?.Security?.securityType == "PIF"}?.productLineItemId
			if(group?.GroupCharacteristics?.LoSGCharacteristics!=null && (group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGSequenceNumber == productLineItemId.text())){
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status = "PENDING"
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = "PAY_IN_FULL_REQUIRED"
				group?.GroupCharacteristics?.LoSGCharacteristics?.CreditPolicySecurityType = "PIF"
			}
			else if(group?.GroupCharacteristics?.LoSGCharacteristics!=null){
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status = "PENDING"
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = "NO_SECURITY_FEE_REQUIRED"
			}
		}
		return order
	}

	def postEUCPCnoPending(def order, def eucpcResponse){
		def postDownpayment = postDownpayment(order, eucpcResponse)
		def groups = order.Groups.Group.findAll{g -> g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status != WirelineConstants.LOSG_STATUS_CANCELED && g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory!="MISC"}
		for(def group in groups){
			def productDwnpay = eucpcResponse?.ProductDetails?.AffiliateDetails?.LineItemsDetails.find{ li -> li?.Security?.action == "AD" &&  li?.Security?.securityType == "DWNPAY"}?.productLineItemId
			def productNRF = eucpcResponse?.ProductDetails?.AffiliateDetails?.LineItemsDetails.find{ li -> li?.Security?.action == "AD" &&  li?.Security?.securityType == "NRF"}?.productLineItemId
			def productAdvpay = eucpcResponse?.ProductDetails?.AffiliateDetails?.LineItemsDetails.find{ li -> li?.Security?.action == "AD" &&  li?.Security?.securityType == "ADVPAY"}?.productLineItemId
			def productNosec = eucpcResponse?.ProductDetails?.AffiliateDetails?.LineItemsDetails.find{ li -> li?.Security?.action == "AD" &&  li?.Security?.securityType == "NOSEC"}?.productLineItemId

			if(group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGSequenceNumber == productDwnpay.text()){
				if(postDownpayment==true){
					group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status = "SYS_PROCESSING"
					group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = "EXECUTE_UNIFIED_CREDIT_POLICY_PASS"
				}
				else{
					group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status = "PENDING"
					group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = "DOWN_PAYMENT_REQUIRED"
				}
			}
			else if(group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGSequenceNumber == productNRF.text()){
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status = "SYS_PROCESSING"
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = "NON_REFUNDABLE_FEE_REQUIRED"
			}
			else if(group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGSequenceNumber == productAdvpay.text()){
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status = "SYS_PROCESSING"
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = "ADVANCE_PAYMENT_REQUIRED"
			}
			else if(group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGSequenceNumber == productNosec.text()){
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status = "SYS_PROCESSING"
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = "EXECUTE_UNIFIED_CREDIT_POLICY_PASS"
			}
			else{
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status = "SYS_PROCESSING"
				group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = "EXECUTE_UNIFIED_CREDIT_POLICY_PASS"
			}
		}
		return order
	}

	def postEUCPCGroups(def order, def eucpcResponse){
		def productDwnpay = eucpcResponse?.ProductDetails?.AffiliateDetails?.LineItemsDetails.find{ li -> li?.Security?.action == "AD" &&  li?.Security?.securityType == "DWNPAY"}?.productLineItemId.text()
		def productPIF = eucpcResponse?.ProductDetails?.AffiliateDetails?.LineItemsDetails.find{ li -> li?.Security?.action == "AD" &&  li?.Security?.securityType == "PIF"}?.productLineItemId.text()
		def postDownpayment = postDownpayment(order, eucpcResponse)

		if(productDwnpay!=null && !(productDwnpay.isEmpty()) && (postDownpayment==false)){
			pendingDepositLineItem(order, eucpcResponse)
		}
		else if(productPIF!=null && !(productPIF.isEmpty())){
			pendingPayinFull(order, eucpcResponse)
		}
		else{
			postEUCPCnoPending(order, eucpcResponse)
		}
		return order
	}

	def PostEUCPCWLSWLNLineItems(def order, def lineItems, def eucpcResponse){
		def UpdatedLineItems = postEUCPCWlsLineItems(order, lineItems, eucpcResponse)
		def newLineItems = postEUCPCWlnLineItems(order, UpdatedLineItems, eucpcResponse)

		return newLineItems
	}

	def postEUCPCWlsLineItemsforDownPay(def order, def lineItems, def eucpcResponse){

		for(def lineItem in lineItems) {
			def prodLineItemId = eucpcResponse?.ProductDetails?.AffiliateDetails.find {af -> af.affiliateCode == "MT"}?.LineItemsDetails?.productLineItemId
			def losgSeqNum = order.Groups?.Group.findAll{ln -> ln.Id.contains(lineItem?.GroupRefs?.GroupRef)}?.GroupCharacteristics?.LoSGCharacteristics?.LoSGSequenceNumber
			if(losgSeqNum.contains(prodLineItemId.text())){
				if(lineItem?.ContractDetails?.DownPayment != null){
					def securityAmt = eucpcResponse?.ProductDetails?.AffiliateDetails?.LineItemsDetails.find{sa -> sa?.Security?.action == "AD" &&  sa?.Security?.securityType == "DWNPAY"}?.Security?.securityAmount.text()
					BigDecimal secamt = new BigDecimal(securityAmt);
					if(lineItem?.ContractDetails?.DownPayment <= secamt){
						def amtFinanced = (lineItem?.ContractDetails?.TotalSalePrice) - secamt
						def installamount = amtFinanced.div(lineItem?.ContractDetails?.ContractLength)
						lineItem?.ContractDetails?.AmountFinanced = amtFinanced
						lineItem?.ContractDetails?.DownPayment = secamt
						lineItem?.ContractDetails?.InstallmentAmount = new DecimalFormat("#.##").format(installamount)
						lineItem?.Status = "Payment Required"
					}
				}
			}
		}
		return lineItems
	}

	def postEUCPCWlsLineItemsforAdvPay(def order, def lineItems, def eucpcResponse){
		def lineItemsDetails = eucpcResponse?.ProductDetails?.AffiliateDetails.find {af -> af.affiliateCode == "MT"}?.LineItemsDetails
		for(def lineItemsDetail in lineItemsDetails){
			if(lineItemsDetail?.Security?.action == "AD" &&  lineItemsDetail?.Security?.securityType == "ADVPAY" && (lineItemsDetail?.productLineItemId!=null)){

				def groupId = order?.Groups?.Group.find{gi -> gi.GroupCharacteristics?.LoSGCharacteristics?.LoSGSequenceNumber == lineItemsDetail?.productLineItemId.text()}?.Id
				def lineItem =
						[
							Id : "LIADVPAY"+(lineItemsDetail?.productLineItemId.text()),
							ProductCode : "NOT_AVAILABLE",
							BillingCode : "NOT_AVAILABLE",
							ProductType : "MISC_CHARGE",
							DisplayName : "Advance_Payment",
							SystemName : "ADVANCE_PAYMENT",
							Action : "ADD",
							Price : [
								Amount : lineItemsDetail?.Security?.securityAmount,
								CurrencyType : "USD",
								PriceType : "DueNow",
								Total : lineItemsDetail?.Security?.securityAmount
							],
							Status : "Payment Required",
							GroupRefs : [
								GroupRef : groupId==null ? "" : groupId
							]
						]
				lineItems.add(lineItem)
			}
		}
		return lineItems
	}

	def postEUCPCWlsLineItems(def order, def lineItems, def eucpcResponse){
		def UpdatedLineItems = postEUCPCWlsLineItemsforDownPay(order, lineItems, eucpcResponse)
		def newLineItems = postEUCPCWlsLineItemsforAdvPay(order, UpdatedLineItems, eucpcResponse)

		return newLineItems
	}

	def postEUCPCWlnLineItems(def order, def lineItems, def eucpcResponse){
		def lineItemsDetails = eucpcResponse?.ProductDetails?.AffiliateDetails.find {af -> af.affiliateCode == "LS"}?.LineItemsDetails
		for(def lineItemsDetail in lineItemsDetails){
			if(lineItemsDetail?.Security?.action == "AD" &&  lineItemsDetail?.Security?.securityType == "ADVPAY" && lineItemsDetail?.productLineItemId){
				def groupId = order?.Groups?.Group.find{gi -> gi.GroupCharacteristics?.LoSGCharacteristics?.LoSGSequenceNumber == lineItemsDetail?.productLineItemId.text()}?.Id
				def lineItem =
						[
							Id : "LIADVPAY"+(lineItemsDetail?.productLineItemId.text()),
							ProductCode : "NOT_AVAILABLE",
							BillingCode : "NOT_AVAILABLE",
							ProductType : "MISC_CHARGE",
							DisplayName : "Advance_Payment",
							SystemName : "ADVANCE_PAYMENT",
							Action : "ADD",
							Price : [
								Amount : lineItemsDetail?.Security?.securityAmount,
								CurrencyType : "USD",
								PriceType : "DueNow",
								Total : lineItemsDetail?.Security?.securityAmount
							],
							Status : "Payment Required",
							GroupRefs : [
								GroupRef : groupId==null ? "" : groupId
							]
						]
				lineItems.add(lineItem)
			}
			else if(lineItemsDetail?.Security?.action == "AD" &&  lineItemsDetail?.Security?.securityType == "NRF" && lineItemsDetail?.productLineItemId){
				def groupId = order?.Groups?.Group.find{gi -> gi.GroupCharacteristics?.LoSGCharacteristics?.LoSGSequenceNumber == lineItemsDetail?.productLineItemId.text()}?.Id
				def lineItem =
						[
							Id : "LINRF"+(lineItemsDetail?.productLineItemId.text()),
							ProductCode : "NOT_AVAILABLE",
							BillingCode : "NOT_AVAILABLE",
							ProductType : "MISC_CHARGE",
							DisplayName : "Non_Refundable_Fee",
							SystemName : "NON_REFUNDABLE_FEE",
							Action : "ADD",
							Price : [
								Amount : lineItemsDetail?.Security?.securityAmount,
								CurrencyType : "USD",
								PriceType : "DueToday",
								Total : lineItemsDetail?.Security?.securityAmount
							],
							Status : "Payment Required",
							GroupRefs : [
								GroupRef : groupId==null ? "" : groupId
							]
						]
				lineItems.add(lineItem)
			}
		}
		return lineItems
	}

	def PostEUCPCLineItems(def order, def eucpcResponse){
		def wirelessGroups = order.Groups.Group.findAll{g -> (g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "NEW" || g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "AL") && g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="WIRELESS" &&
			(g?.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod == "DF" || g?.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod == "C2S")}
		def wirelineGroups = order.Groups.Group.findAll{g -> (g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "NEW" || g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "CHANGE" || g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == "NO_CHANGE") &&
			(g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="INTERNET" || g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="IPTV" || g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory=="VOIP")}
		def lineItems
		if(!(wirelessGroups.isEmpty()) && !(wirelineGroups.isEmpty())){
			lineItems = PostEUCPCWLSWLNLineItems(order, order.LineItems.LineItem, eucpcResponse)
			order.LineItems.LineItem = lineItems
		}
		else if(!(wirelessGroups.isEmpty()) && wirelineGroups.isEmpty()){
			lineItems = postEUCPCWlsLineItems(order, order.LineItems.LineItem, eucpcResponse)
			order.LineItems.LineItem = lineItems
		}
		else if(wirelessGroups.isEmpty() && !(wirelineGroups.isEmpty())){
			lineItems = postEUCPCWlnLineItems(order, order.LineItems.LineItem, eucpcResponse)
			order.LineItems.LineItem = lineItems
		}
		else{
			order
		}
		return order
	}

}
