package com.att.oce.transformation

import com.att.oce.bpm.common.WirelineTransformationService
import com.att.oce.bpm.error.APIFailedException
import org.slf4j.LoggerFactory
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.springframework.stereotype.Component
import com.att.oce.bpm.utility.OrderUtility

@Component('inquireTransportProductAvailabilityTransformation')
class InquireTransportProductAvailabilityTransformation  extends WirelineTransformationService {
	
	String url;
	//static Logger log = LoggerFactory.getLogger("InitiateUnifiedServiceOrderRequestTransformation.class")
	@Override
	public String getApiName()
	{
		return 'InquireTransportProductAvailability';
	}
	
	public String getApiUrn() {
		return 'urn:csi:services:qual:InquireTransportProductAvailability.jws';
	}

	public void transform(Exchange exchange)
	{
		exchange.properties.order = exchange.in.body.order
		exchange.properties.executionContext  = exchange.in.body.executionContext
		exchange.properties.fedIndicator = false;

		def apiURN = getApiUrn()
		def apiUrl = super.resolveURN(apiURN, null)
		exchange.properties.apiURN = apiURN
		exchange.properties.apiUrl = apiUrl
		
		def uverseAccount = OrderUtility.getUverseAcount(exchange.properties.order)
		exchange.properties.put("referenceId",uverseAccount?.Id)

		def order  =	exchange.in.body.order

		def msgHeader = createITPAMessageHeader(order)
		def itpaRequest = prepareRequest(order,msgHeader,exchange)
		setAuditLogProperties(exchange,false)
		exchange.out.body = itpaRequest
		setCSIHttpHeaders(exchange)
		exchange.out.headers.put("CamelHttpUri",apiUrl
				/*"https://csi-tst-q22.it.att.com:22443/Services/com/cingular/csi/qual/InquireTransportProductAvailability.jws"*/)
		exchange.properties.put("OceCSIApiName",getApiName())
		println('InquireTransportProductAvailabilityTransformation.transform done')
	}

	/**
	 * @param order
	 * @param msgHeader
	 * @return
	 */
	def prepareRequest(order,msgHeader, exchange)
	{
		def UverseAcc= OrderUtility.getUverseAcount(order)
		exchange.properties.put("referenceId",UverseAcc.Id)
		println(UverseAcc)
		def Addresslist=order.Addresses.Address
		println(Addresslist)
		def addId
		def pa

		if(UverseAcc!=null && UverseAcc.ServiceLocationRef != null)
		{
			def AddressRef = UverseAcc.ServiceLocationRef
			println(AddressRef)
			for(def i=0;i<Addresslist.size();i++)
			{
				def AddressMap=Addresslist.get(i)

				if(AddressMap.Id == AddressRef)
				{
					addId=AddressMap.AddressId
					println(addId)
					pa= AddressMap.ParsedAddress
					println("pa is::"+pa)
				}
			}
		}
		def itpaRequest = [
			messageHeader : msgHeader,
			ITPARequest:
			[
				UverseServiceAddress : pa,
				AddressId : addId
			]
		]
		//  println('ITPA req>>>>>'+itpaRequest.ITPARequest.UverseServiceAddress)
		// println('ITPA req>>>>>'+itpaRequest.ITPARequest.UverseServiceAddress.AddressType)
		// println('ITPA req>>>>>'+itpaRequest.ITPARequest.UverseServiceAddress.Country)
		//println('ITPA req>>>>>'+itpaRequest.ITPARequest.UverseServiceAddress.City)
		//println('ITPA req>>>>>'+itpaRequest.ITPARequest.UverseServiceAddress.County)
		// println('ITPA req>>>>>'+itpaRequest.ITPARequest.UverseServiceAddress.StreetName)
		// println('ITPA req>>>>>'+itpaRequest.ITPARequest.UverseServiceAddress.StreetType)
		//println('ITPA req>>>>>'+itpaRequest.ITPARequest.UverseServiceAddress.Zip)
		//println('ITPA req>>>>>'+itpaRequest.ITPARequest.UverseServiceAddress.State)
		// println('ITPA req>>>>>'+itpaRequest.ITPARequest.UverseServiceAddress.HouseNumber)


		//println(' pARSED ADDRESS>>>>>'+itpaRequest.ITPARequest.UverseServiceAddress.ParsedAddress)
		println('Address id>>>>>'+itpaRequest.ITPARequest.AddressId)
		return itpaRequest
	}

	public void processResponse(Exchange exchange) throws APIFailedException
	{
		println('ITPA Response :: ' + exchange.in.body)
		println('InquireTransportProductAvailabilityTransformation.processResponse done')

		def order = exchange.properties.order
		def executionContext = exchange.properties.executionContext

		def itpaResponseXml = new XmlSlurper().parseText(exchange.in.body)
		def itpaResponse = exchange.in.body;

		executionContext.put("itpaResponse", itpaResponse)
		println ("RESPONSE" + itpaResponseXml)

		if (itpaResponseXml.Body.Fault.toString().size()>0){
			def e = new APIFailedException();
			e.api = getApiName()
			e.code = itpaResponseXml.Body.Fault.detail.CSIApplicationException.Response.code
			e.codeDescription = itpaResponseXml.Body.Fault.detail.CSIApplicationException.Response.description
			e.subCode = itpaResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code
			e.subCodeDescription = itpaResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
			addTransactionHistory(exchange,e);
			throw e
		}
		else
		{
			String code = itpaResponseXml.Body.InquireTransportProductAvailabilityResponse.ProductLSDTVW.ResultResponse.code
			
			if(code && code == "2008900000003") {
				def e = new APIFailedException();
				e.api = getApiName()
				e.code = code
				e.codeDescription = itpaResponseXml.Body.InquireTransportProductAvailabilityResponse.ProductLSDTVW.ResultResponse.description
				e.subCode = code
				e.subCodeDescription = itpaResponseXml.Body.InquireTransportProductAvailabilityResponse.ProductLSDTVW.ResultResponse.description
				addTransactionHistory(exchange,e);
				throw e
			}
			addTransactionHistory(exchange,null);
		}
		//return exchange.in.body
	}

	public void printRequest(Exchange exchange)
	{
		println("****************REquest is****************************"+exchange.in.body)
	}
}



