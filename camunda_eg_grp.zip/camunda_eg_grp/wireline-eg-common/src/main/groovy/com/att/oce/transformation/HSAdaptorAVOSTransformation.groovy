package com.att.oce.transformation

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.utility.OrderUtility
import org.camunda.bpm.engine.impl.util.json.XML
import org.camunda.bpm.engine.impl.util.json.JSONObject
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.error.OceErrorHandler
import com.att.oce.config.components.GlobalProperties
import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component

@Component('hsAdaptorAVOSTransformation') 
class HSAdaptorAVOSTransformation extends TransformationService {
	
	static Logger log = LoggerFactory.getLogger(HSAdaptorAVOSTransformation.class)
	
	@Override String getApiName(){
		return 'HSAdaptorAVOS';
	}
	
	/**
	 * 
	 * @param exchange
	 */
	public void transform(Exchange exchange){
		log.debug('HSAdaptorAVOSTransformation.transform')
		int index = 0
		
		def xmlOrder = exchange.in.body.xmlOrder
		
		 exchange.out.body = xmlOrder
		 //setCSIHttpHeaders(exchange)
		 exchange.out.headers.put("CamelHttpUri",resolveURN('urn:avos:services:HSAdaptorProcessPort',''))
		 exchange.properties.put("OceCSIApiName","HSAdaptorAVOS")

		 log.debug('HSAdaptorAVOSTransformation.transform done')
	}
	
	/**
	 * Processes the response received from AVOS.
	 */
	def processResponse(Exchange exchange) throws Exception {
	     log.debug('HSAdaptorAVOSTransformation.processResponse')
		 //println('HSAdaptor AVOS Response XML :: ' + exchange.in.body)
		 
		 def hsAdaptorAvosResponseJSON = OrderUtility.convertXmlToJson(exchange.in.body)
		 
		 //println('HSAdaptor AVOS Response converted to JSON :: ' + hsAdaptorAvosResponseJSON)
		 //println('HSAdaptorAVOSTransformation.processResponse done')
		 
		 log.debug('HSAdaptorAVOSTransformation.processResponse done')
		 return exchange.in.body
	}
}
