package com.att.oce.transformation

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.error.OceErrorHandler
import com.att.oce.config.components.GlobalProperties
import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import com.att.oce.bpm.common.WirelineTransformationService
import com.att.aft.dme2.internal.jetty.util.StringUtil;
import com.att.oce.bpm.common.WirelineConstants

@Component('UpdateAccountConsentRequestTransformation') 
class UpdateAccountConsentRequestTransformation extends WirelineTransformationService  {

	static Logger log = LoggerFactory.getLogger(UpdateAccountConsentRequestTransformation.class)
	String url;
	
	@Override String getApiName(){
		return 'UpdateAccountConsent';
	}
	
	public String getApiUrn() {
		return "urn:csi:services:cmp:UpdateAccountConsent.jws";
	}
	
	public void transform(Exchange exchange){
		log.info('UpdateAccountConsentRequestTransformation.transform')
		int index = 0
		exchange.properties.order = exchange.in.body.order
		exchange.properties.executionContext  = exchange.in.body.executionContext
		
		def order = exchange.in.body.order
		def accountDeatils= getUpdateAccountDetails(order)
		
		def msgHeader = createMessageHeader(order)
		def uacRequest = [ messageHeader : msgHeader,
		UpdateAccountConsentRequest : [
			partnerName: WirelineConstants.PARTNER_NAME,
			consentItem: WirelineConstants.CONSENT_ITEM,
			serviceFamily: WirelineConstants.SERVICE_FAMILY,
			serviceType: WirelineConstants.SERVICE_TYPE,
			Election:[
				AccountDetails:[
					serviceNumber : accountDeatils?.PhoneNumber
					],
				electionCode:accountDeatils?.electionCode,
				electionDate:order?.SubmitedDate
				],
			AssociatedAccount:[
				accountNumber: accountDeatils?.billingAccountNumber,
				accountServiceType: accountDeatils?.accountServiceType
				]
			]
		]
	
		exchange.out.body = uacRequest
		log.debug('uacRequest >>>>>>>>>>>>>>>>>>>>>>>>>>>>>'+uacRequest)
		setCSIHttpHeaders(exchange)
		exchange.out.headers.put("CamelHttpUri",resolveURN(getApiUrn(),url))
		exchange.properties.put("OceCSIApiName","UpdateAccountConsent")
		exchange.properties.put('apiURN','urn:csi:services:cmp:UpdateAccountConsent.jws')
		log.info('UpdateAccountConsent.transform done')
	}
	
	public void processResponse(Exchange exchange)throws APIFailedException {
		log.debug('UpdateAccountConsentRequestTransformation.processResponse')
		int index=0
		def order = exchange.properties.order
		def uacResponseXml = new XmlSlurper().parseText(exchange.in.body)
		boolean value = true
		log.debug(exchange.in.body)
		if (uacResponseXml.Body.Fault.size() > 0){
			def apie = new APIFailedException(
				api : getApiName(),
				code : uacResponseXml.Body.Fault.detail.CSIApplicationException.Response.code,
				codeDescription : uacResponseXml.Body.Fault.detail.CSIApplicationException.Response.description,
				subCode : uacResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code,
				subCodeDescription : uacResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
			)
			addTransactionHistory(exchange,apie)
			exchange.out.body = order
			value = false
			Map<String,Object> updatedUACResponse = updateOrder(order,uacResponseXml,value)
		}
		Map<String,Object> updatedUACResponse = updateOrder(order,uacResponseXml,value)
		log.debug('Update order is>>>>>>>>>>>>>>>>>>>>>>>>>'+updatedUACResponse)
		exchange.in.body = updatedUACResponse
		addTransactionHistory(exchange,null)
		//return exchange.in.body
	}
	
	
	 def getUpdateAccountDetails(order) {
		def accountList = order?.Accounts?.Account
		List<String> Names =  order?.Names?.Name
		def nameList
		def primaryContactPhone
		def additionalContactPhone
		String primaryContactPhoneNumber
		String primaryContactConsentSelection
		String additionalContactPhoneNumber
		String additionalContactConsentSelection

		//Getting the account in a list
		def account = new ArrayList()
		Map<String,Object> transactionLogs = new HashMap<String, Object>();
		int index = 0
		
		for(def i=0;i<accountList?.size();i++){
			def accountMap=accountList?.get(i)
			if(accountMap?.AccountCategory == WirelineConstants.ACCOUNTCATEGORY_UVERSE_ACCOUNT &&
				accountMap?.AccountSubCategory == WirelineConstants.AccountSubCategory_NEW) {
			def accountNumber = accountMap?.billingAccountNumber
				transactionLogs.put("billingAccountNumber",accountNumber);
			}
				if(accountMap?.AccountCategory == WirelineConstants.ACCOUNTCATEGORY_MOBILITY_ACCOUNT ) {
				def accountServiceType = 'M'
					transactionLogs.put("accountServiceType",accountServiceType);
				} else if (accountMap?.AccountCategory == WirelineConstants.ACCOUNTCATEGORY_UVERSE_ACCOUNT){
				def accountServiceType = 'U'
				transactionLogs.put("accountServiceType",accountServiceType);
				}
				log.debug('Data in account>>>>>>>>>>>>>>>>'+transactionLogs)
		} 

		for(def i=0;i<Names.size();i++) {
			nameList = Names.get(i)
		
			primaryContactPhoneNumber = nameList?.PrimaryContactPhone[index]?.PhoneNumber
			primaryContactConsentSelection = nameList?.PrimaryContactPhone[index]?.ConsentDetails?.ConsentDetail?.get(0)?.ConsentSelection
			
			additionalContactPhoneNumber = nameList?.AdditionalContactPhone[index]?.PhoneNumber
			additionalContactConsentSelection = nameList?.AdditionalContactPhone[index]?.ConsentDetails?.ConsentDetail?.get(0)?.ConsentSelection
			
			if(primaryContactPhoneNumber != null ) {
			transactionLogs.put("PhoneNumber",primaryContactPhoneNumber);
			} else {
			transactionLogs.put("PhoneNumber",additionalContactPhoneNumber);
		}
			if(primaryContactConsentSelection != null) {
			  if(primaryContactConsentSelection.equalsIgnoreCase("OPT_IN")) {
				primaryContactConsentSelection = "I";
				transactionLogs.put("electionCode", primaryContactConsentSelection);
			} else if(primaryContactConsentSelection.equalsIgnoreCase("OPT-OUT")){
			   primaryContactConsentSelection = "D";
			   transactionLogs.put("electionCode", primaryContactConsentSelection);
			}
			
			} else if(additionalContactConsentSelection != null) {
			   if( additionalContactConsentSelection.equalsIgnoreCase("OPT_IN")) {
				 additionalContactConsentSelection = "I";
				 transactionLogs.put("electionCode", additionalContactConsentSelection);
			} else if(additionalContactConsentSelection.equalsIgnoreCase("OPT-OUT")){
			     additionalContactConsentSelection = "D";
				 transactionLogs.put("electionCode", additionalContactConsentSelection);
			}
			}
	}
		return transactionLogs
	}
	
	
	def updateOrder(def order,def uacResponseXml,boolean value){
		def losgs = new ArrayList()
		def primaryContactPhone
		def additionalContactPhone
		String NameRef;
		String code;
		List orderTaskList = new ArrayList();
		def primaryContactPhoneConsentDetail
		def additionalContactPhoneConsentDetail
	
		if(order.OrderContact) {
			NameRef = order.OrderContact?.NameRef

			List<String> Names =  order?.Names?.Name
			for (name in Names)
			{
				if(name?.Id == NameRef)
				{
					if( name?.PrimaryContactPhone) {

						if(value){
							primaryContactPhone = name?.PrimaryContactPhone?.ConsentDetails
							for(def i=0;i<primaryContactPhone?.size();i++) {
								primaryContactPhoneConsentDetail = primaryContactPhone[i];
								primaryContactPhoneConsentDetail.put("IsConsentUpdatedInCAPM","Y" );
							}

							additionalContactPhone =  name?.AdditionalContactPhone?.ConsentDetails
							for(def i=0;i<additionalContactPhone?.size();i++) {
								additionalContactPhoneConsentDetail = additionalContactPhone[i];
								additionalContactPhoneConsentDetail.put("IsConsentUpdatedInCAPM","Y" );
							}
							
						} else {
							primaryContactPhone = name?.PrimaryContactPhone?.ConsentDetails
							for(def i=0;i<primaryContactPhone?.size();i++) {
								primaryContactPhoneConsentDetail = primaryContactPhone[i];
								primaryContactPhoneConsentDetail.put("IsConsentUpdatedInCAPM","N" );
							}

							additionalContactPhone =  name?.AdditionalContactPhone?.ConsentDetails
							for(def i=0;i<additionalContactPhone?.size();i++) {
								additionalContactPhoneConsentDetail = additionalContactPhone[i];
								additionalContactPhoneConsentDetail.put("IsConsentUpdatedInCAPM","N" );
							}
							
							if(order.Groups && order.Groups?.Group){
								for(def group in order.Groups.Group) {
									if(group?.GroupCharacteristics && group?.GroupCharacteristics?.LoSGCharacteristics && group?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus){
										def loSGCharacteristics = group?.GroupCharacteristics?.LoSGCharacteristics
										loSGCharacteristics?.LoSGStatus.put("Status",WirelineConstants.LOSGSTATUS_IN_QUEUE);
										loSGCharacteristics?.LoSGStatus.put("SubStatus",WirelineConstants.LOSGSUBSTATUS_UPDATE_ACCOUNT_CONSENT_FAIL)
									}
								}
							}
						}
					
					}
				}

			}

		}
		return order
	}
	
}