package com.att.oce.bpm.utility

import groovy.util.slurpersupport.GPathResult

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.impl.util.json.JSONObject
import org.camunda.bpm.engine.impl.util.json.XML
import org.springframework.stereotype.Component

import com.att.oce.bpm.common.OceConstants
import com.att.oce.bpm.common.TransformationService;
import com.att.oce.bpm.common.WirelineConstants
import com.att.oce.bpm.common.util.CommonUtility
import com.att.oce.bpm.common.util.ErrorBean
import com.att.oce.bpm.error.APIFailedException

@Component("orderUtility")
class OrderUtility {

	/*
	 * This function will return the List of LoSG's present in the given order
	 */
	static def getLosgsFromOrder(orderMap) {
		def groupList = orderMap.Groups.Group

		//Getting the LOSGs in a list
		def losgs = new ArrayList()
		for(def i=0;i<groupList.size();i++){
			def groupMap=groupList.get(i)
			if(groupMap.Type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE ){
				losgs.add(groupMap)
			}
		}
		return losgs
	}

	/*
	 * This function will return the count of number of LoSG's present in the given order
	 */
	static def getLosgCount(orderMap){

		def groupList=orderMap.Groups.Group

		//Getting the LOSG count
		def losgCount=0
		for(def i=0;i<groupList.size();i++){
			def groupMap=groupList.get(i)

			if(groupMap.Type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE ){
				losgCount++
			}
		}
		return losgCount
	}

	/*
	 * This function will take a LOSG as argument
	 * returns true if the LOSG is in terminal status, else false
	 */
	static def isTerminalLOSGStatus(losg){
		def terminalStatus = new ArrayList<String>()
		terminalStatus.add("COMPLETED")
		terminalStatus.add("CANCELED")


		def isTerminalStatus = false
		if(losg.Type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE
		&& contains(terminalStatus,losg.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status)){
			isTerminalStatus = true
		}

		return isTerminalStatus
	}

	/*
	 * This function will take a List as first argument and String to search as second argument
	 * returns true if search string is found in the list, else false
	 */
	static def contains(list, name) {
		for (String item : list) {
			if (item.equals(name)) {
				return true;
			}
		}
		return false;
	}

	/*
	 * This function will return the Group's which are not in terminal status
	 */
	static def getNonTerminalLoSGs(order){
		def groupList = order.Groups.Group
		def nonTerminalLosgs = new ArrayList()

		for(def i=0;i<groupList.size();i++)	{
			def losg = groupList.get(i)

			if(isTerminalLOSGStatus(losg) == false ){
				nonTerminalLosgs.add(losg)
			}
		}

		return nonTerminalLosgs
	}

	/**
	 * This function will convert the provided JSON Map into XML String
	 *
	 */
	static def convertJsonToXml(Map<String,Object> jsonMap){

		def jsonObject = new JSONObject(jsonMap)
		def xmlString = XML.toString(jsonObject)
		return xmlString
	}

	/**
	 * This function will convert the provided XML String into JSON object.
	 *
	 */
	static def convertXmlToJson(String xmlSting){

		int textIndent = 2
		JSONObject jsonObj = XML.toJSONObject(xmlSting)
		jsonObj.toString(textIndent)
		return jsonObj
	}

	/*
	 * This function will construct the APIFailedException object
	 * @param csiAPIResponse GPathResult
	 * @param apiName String
	 * @return exception APIFailedException
	 */
	static def getAPIExceptionForCSI(GPathResult csiApiResponse,String apiName){
		APIFailedException exception = new APIFailedException()
		exception.api = apiName
		exception.code = csiApiResponse.Body.Fault?.detail?.CSIApplicationException?.Response?.code
		exception.codeDescription = csiApiResponse.Body.Fault?.detail?.CSIApplicationException?.Response?.description
		exception.subCode = csiApiResponse.Body.Fault?.detail?.CSIApplicationException?.ServiceProviderEntity?.ServiceProviderRawError?.code
		exception.subCodeDescription = csiApiResponse.Body.Fault?.detail?.CSIApplicationException?.ServiceProviderEntity?.ServiceProviderRawError?.description
		return exception
	}

	static def getAPIExceptionWithSubCode(String code,String subCode,String notes, String apiName){
		APIFailedException exception = new APIFailedException()
		exception.api = apiName
		exception.code = code
		exception.subCode = subCode
		if(notes != null){
			exception.codeDescription = notes
			exception.subCodeDescription = notes
		}
		return exception
	}

	/*
	 * This function will construct the APIFailedException object
	 * @param code String
	 * @param apiName String
	 * @return exception APIFailedException
	 */
	static def getAPIException(String code,String apiName){
		def codeDescription
		if(code == OceConstants.SUCCESS_CODE_0){
			codeDescription = OceConstants.SUCCESS
		}else if (code == OceConstants.ERROR_CODE_200){
			codeDescription = OceConstants.ERROR
		}else{
			codeDescription = OceConstants.NOT_APPLICABLE
		}

		APIFailedException exception = new APIFailedException()
		exception.api = apiName
		exception.code = code
		exception.codeDescription = codeDescription

		return exception
	}

	static def getAPIExceptionWithSubCode(String code,String subCode,String apiName){

		APIFailedException exception = new APIFailedException()
		exception.api = apiName
		exception.code = code
		exception.subCode = subCode
		exception.codeDescription = OceConstants.SUCCESS
		exception.subCodeDescription = OceConstants.SUCCESS

		return exception
	}

	/**
	 * This method returns true if PMO_IND is present as true for UverseAccount else returns false.
	 * @param orderMap
	 * @return
	 */
	static def isPMOHSAutomation(orderMap) {

		println('OrderUtility.isPMOHSAutomation start')
		//Getting the Account as List
		def isPMOIndicator = false
		def uverseAccount = getUverseAcount(orderMap)
		//println('UverseAccount>>>'+uverseAccount)

		def additionalDetails = uverseAccount?.AdditionalDetails
		//println('AdditionalDetails>>>'+additionalDetails)

		if(uverseAccount != null && additionalDetails != null) {
			//Getting the AdditionalDetail as List
			def AdditionalDetailList = additionalDetails.AdditionalDetail
			//println('AdditionalDetail List>>>'+AdditionalDetailList)
			if(AdditionalDetailList != null) {
				for(def additionalDetailcounter=0;additionalDetailcounter<AdditionalDetailList.size();additionalDetailcounter++) {
					def aditionalDetailMap = AdditionalDetailList.get(additionalDetailcounter)
					//println('AdditionalDetail>>>'+aditionalDetailMap)

					if(aditionalDetailMap != null && aditionalDetailMap.Code ==  OceConstants.PMO_IND_CODE && aditionalDetailMap.Value == 'true') {

						isPMOIndicator = true
					}
				}
			}
		}

		println('OrderUtility.isPMOHSAutomation end')
		return isPMOIndicator
	}

	static def getUverseAcount(orderMap) {
		def accountList = orderMap.Accounts.Account

		for(def i=0;i<accountList.size();i++){
			def accountMap=accountList.get(i)
			if(accountMap.AccountCategory == OceConstants.ACCOUNTCATEGORY_UVERSE_ACCOUNT ){
				return accountMap;
			}
		}
		return null;
	}

	/* This method returns the groupId of Uverse Groups */
	def static getUverseGroupsId(Order)
	{
		def groupList= Order.Groups.Group

		ArrayList<String> uverseGroupIds = new ArrayList<String>();
		for(def group in groupList)
		{
			def productTypes = group.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
			if(productTypes && (productTypes.contains('IPTV')
			|| productTypes.contains('INTERNET')
			|| productTypes.contains('VOIP')
			|| group.GroupCharacteristics.PackageCharacteristics)
			&& group.GroupCharacteristics.LoSGCharacteristics.ProductCategory != 'PACKAGE' )
			{
				uverseGroupIds.add(group.Id)
			}
		}
		return uverseGroupIds
	}

	static def getUverseLineItemPaymentOptRefs(order) {
		def uverseGroup = getUverseGroupsId(order);
		return  order.LineItems.LineItem.findAll { li -> uverseGroup.intersect(li.GroupRefs.GroupRef )}.collect{it.Payments?.Payment?.PaymentOptionRef}.flatten().minus(null)
	}

	static def getAddOnSolutionAccount(order) {
		def accountList = order.Accounts.Account

		for(def i=0;i<accountList.size();i++){
			def accountMap=accountList.get(i)
			if(accountMap.AccountCategory == WirelineConstants.ACCOUNTCATEGORY_ADDON_SOLUTIONS_ACCOUNT ){
				return accountMap;
			}
		}
		return null;
	}

	static def getWirelineAccount(order) {
		def accountList = order.Accounts.Account

		for(def i=0;i<accountList.size();i++){
			def accountMap=accountList.get(i)
			if(accountMap.AccountCategory == WirelineConstants.ACCOUNTCATEGORY_WIRELINE ){
				return accountMap;
			}
		}
		return null;
	}

	static def getDTVAccount(order) {
		def accountList = order.Accounts.Account

		for(def i=0;i<accountList.size();i++){
			def accountMap=accountList.get(i)
			if(accountMap.AccountCategory == WirelineConstants.ACCOUNTCATEGORY_DTV ){
				return accountMap;
			}
		}
		return null;
	}

	def static updateLoSGStatusForAccount(order, accountId, status, subStatus){
		def loSGStatus= [:];

		order.Groups.Group.each{ losg ->
			if(losg.GroupCharacteristics.LoSGCharacteristics &&
			losg.GroupCharacteristics.LoSGCharacteristics.AccountRef == accountId){
				def losgStatus = [Status:status, SubStatus:subStatus]
				losg.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",losgStatus)
			}
		}
		return order
	}

	/*def static isCUSAEligible(order) {
	 def productTypes = determineProductTypes(order)
	 def checkUverseAccount = checkForNEWUverseAccount(order)
	 if (checkUverseAccount == 'NEW_UVERSE_ACCOUNT_WITHOUT_BAN' &&
	 (productTypes?.contains('INTERNET~NEW') || productTypes?.contains('IPTV~NEW') || productTypes?.contains('DIRECTV~NEW')))
	 return true;
	 else
	 return false;
	 }*/

	def static determineProductTypes(order){
		List<String> productTypes = new ArrayList<String>();

		order.Groups.Group.each{ losg ->
			if(losg.GroupCharacteristics?.LoSGCharacteristics){
				def result = losg.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory + '~' + losg.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
				productTypes.add(result);
			}
		}
		return productTypes
	}


	def static checkForNEWUverseAccount(order){
		def uverseAccount = getUverseAcount(order);
		if(uverseAccount?.AccountSubCategory == "NEW" && uverseAccount?.BillingAccountNumber != null ) {
			return uverseAccount.BillingAccountNumber
		} else {
			return 'NEW_UVERSE_ACCOUNT_WITHOUT_BAN'
		}
	}

	def static creditCheckAndCreditClassValidations(order) {
		def uverseAccount = getUverseAcount(order)
		List errors = new ArrayList();

		if(uverseAccount?.AccountSubCategory == "NEW") {
			def UVCCRan = uverseAccount?.CreditCheck.CCRan
			def CreditClass = uverseAccount?.CreditCheck?.CreditClass
			if(UVCCRan != null && !UVCCRan) {
				ErrorBean error = new ErrorBean('HSError01','Unable to Run Credit Check')
				errors.add(error);
			} else {
				if(CreditClass == null) {
					ErrorBean error = new ErrorBean('HSError01','Credit Class required to create Unified Account is Missing')
					errors.add(error);
				}
			}
		}
		return errors
	}

	def static isSMB(order) {
		return order.OrderSource.Channel=="SMB-WEB-CENTER"
	}

	def static isCDEHS(order) {
		return order.OrderSource.Channel=="CDE-HS"
	}

	def static isUverseAccount(order) {
		def accountList = order.Accounts.Account

		for(def i=0;i<accountList.size();i++){
			def accountMap=accountList.get(i)
			if(accountMap.AccountCategory == OceConstants.ACCOUNTCATEGORY_UVERSE_ACCOUNT ){
				return true;
			}
		}
		return false;
	}

	def static consentCheck(order) {
		def contactRef = order.OrderContact.NameRef

		def name = getName(order, contactRef);

		def primaryPhoneCheck = (name.PrimaryContactPhone?.PhoneNumber != null
				&& name.PrimaryContactPhone?.ConsentDetails?.ConsentDetail?.ConsentType != null
				&& name.PrimaryContactPhone?.ConsentDetails?.ConsentDetail?.ConsentCategory != null
				&& name.PrimaryContactPhone?.ConsentDetails?.ConsentDetail?.ConsentSelection)

		def altPhoneCheck = (name.AdditionalContactPhone?.PhoneNumber != null
				&& name.AdditionalContactPhone?.ConsentDetails?.ConsentDetail?.ConsentType != null
				&& name.AdditionalContactPhone?.ConsentDetails?.ConsentDetail?.ConsentCategory != null
				&& name.AdditionalContactPhone?.ConsentDetails?.ConsentDetail?.ConsentSelection)

		def uverseAccount = getUverseAcount(order)
		def uverseBANCheck = (uverseAccount?.AccountSubCategory == "NEW")

		def consentCount = (name.PrimaryContactPhone?.ConsentDetails?.ConsentDetail?.size() > 0
				&& name.AdditionalContactPhone?.ConsentDetails?.ConsentDetail?.size() > 0)

		return consentCount && ((primaryPhoneCheck || altPhoneCheck ) && uverseBANCheck)

	}

	def static getName(order, nameRef) {
		def nameList = order.Names.Name

		for(def i=0;i<nameList.size();i++){
			def nameMap=nameList.get(i)
			if(nameMap.Id == nameRef ){
				return nameMap;
			}
		}
		return null;
	}

	def static isUverseBillingAccountExist(order) {
		def uverseAccount =  getUverseAcount(order)

		return (uverseAccount != null && uverseAccount?.BillingAccountNumber !=null)
	}

	def static getModifyorNewUverseServiceQualificationRef(order) {
		def GroupList = order.Groups.Group
		def LosgChar =[]
		for(def i=0;i<GroupList.size();i++){
			def GroupMap=GroupList.get(i)
			if(GroupMap.GroupCharacteristics?.LoSGCharacteristics!= null && (GroupMap.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == OceConstants.LoSGType_NEW
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == OceConstants.LOSGTYPE_CHANGE
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == OceConstants.LOSGTYPE_NO_CHANGE)
			&& (GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_IPTV
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_INTERNET
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_VOIP
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_DTV)){

				if(GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ServiceQualificationRef != null)
					LosgChar.add(GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ServiceQualificationRef)
			}
		}
		return LosgChar
	}

	/**
	 * Method to evaluate the precondition before calling API
	 * @param order
	 * @return
	 */

	def static isAWPPEnable(order) {
		println('AddwireLinepaymnetPlan.preCondition <-- Entering')
		println('AddwireLinepaymnetPlan.preCondition:')

		def lineItemList = order.LineItems.LineItem
		for(def i =0;i<lineItemList.size();i++){
			def lineItem = lineItemList.get(i)

			if(lineItem != null && lineItem.SystemName != null) {
				if(lineItem.SystemName == OceConstants.LINEITEM_DISPLAY_NAME_AUTO_PAY) {
					return true;
				}  else {
					return false;
				}
			}
		}
	}

	def static getGroupByAccountId(order, accountId) {
		def group
		order.Groups.Group.each { grp ->
			if(grp.GroupCharacteristics?.LoSGCharacteristics?.AccountRef == accountId)
				group= grp;
		}
		return group;
	}

	static def hasMultipleAuthorizedBillingDetails(def order) {
		int count = 0;
		def channle = order.OrderSource?.Channel
		def uverseAccount = getUverseAcount(order)
		if(channle == OceConstants.CHANNEL_SMB && uverseAccount) {
			def group = getGroupByAccountId(order, uverseAccount.Id)
			def pc = group.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
			if(pc == 'INTERNET'
			|| pc == OceConstants.PRODUCTCATEGORY_IPTV
			|| pc == OceConstants.PRODUCTCATEGORY_VOIP) {

				uverseAccount.BillingInfo?.each { bd ->
					if(bd.BillingType == "AUTHORIZED") {
						count++
					}
				}

			}
		}
		if(count > 1)
			return true
		else
			return false
	}

	def static getEUCPCAccount(orderMap) {
		def eucpcAcc = false
		def accountList = orderMap.Accounts.Account

		for(def i=0;i<accountList.size();i++){
			def accountMap=accountList.get(i)
			if(accountMap.B2BRef!=null){
				def b2bList = orderMap.B2Bs.B2B
				for(def j=0;j<b2bList.size();j++){
					def b2bMap = b2bList.get(j)
					if(b2bMap?.Id==accountMap.B2BRef && (b2bMap?.BusinessType!=null) ){
						if(b2bMap?.BusinessType.toLowerCase() in ["LLC".toLowerCase() ,"Corporation".toLowerCase()]) {
							eucpcAcc = false
						}
						else {
							eucpcAcc = true
						}
					}
				}
			}
		}
		return eucpcAcc;
	}

	def static isEUCPCEnable(order) {

		println('ExecuteUnifiedCreditPolicyCheck.preCondition <-- Entering')
		println('ExecuteUnifiedCreditPolicyCheck.preCondition:')

		def isEUCPCflag = false
		def isCrsmonflag = false
		def eucpcAcc = getEUCPCAccount(order)
		if(order.CreditPolicy != null) {

			if((order.CreditPolicy?.CRSMOnFlag == "true") && (order.CreditPolicy?.CreditPolicyTransactionId == null)) {
				isCrsmonflag = true;
			}else {
				isCrsmonflag = false;
			}
		}

		if(order?.OrderSource?.Channel=="SMB-WEB-CENTER" && eucpcAcc==true && isCrsmonflag==true) {
			isEUCPCflag = true;
		}
		else if(order?.OrderSource?.Channel!="SMB-WEB-CENTER" && isCrsmonflag==true) {
			isEUCPCflag = true;
		}
		println('ExecuteUnifiedCreditPolicyCheck.preCondition --> Exiting'+isCrsmonflag);
		println('ExecuteUnifiedCreditPolicyCheck.preCondition --> Exiting'+isEUCPCflag);
		return isEUCPCflag
	}


	def static getWirelessGroups(def Order) {

		def groupList= Order.Groups.Group

		ArrayList<String> wirelessGroupIds = new ArrayList<String>();
		for(def group in groupList)
		{
			def ProductCategory = group.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
			def LoSGType = group.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
			def FulfillmentMethod = group.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod

			if((LoSGType == OceConstants.LoSGType_NEW) && (ProductCategory == OceConstants.PRODUCTCATEGORY_WIRELESS) &&
			(FulfillmentMethod == OceConstants.FULFILLMENT_METHOD_DF || FulfillmentMethod == OceConstants.FULFILLMENT_METHOD_C2S )) {
				wirelessGroupIds.add(group)
			}
		}

		return wirelessGroupIds
	}

	//	def static getWirelineGroups(def Order){
	//
	//		def groupList= Order.Groups.Group
	//
	//		ArrayList<String> uverseGroupIds = new ArrayList<String>();
	//		for(def group in groupList)
	//		{
	//			def ProductCategory = group.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
	//			def LoSGType = group.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
	//
	//			if((LoSGType == OceConstants.LoSGType_NEW || LoSGType == OceConstants.LOSGTYPE_CHANGE
	//				|| LoSGType == OceConstants.LOSGTYPE_NO_CHANGE) && (ProductCategory == OceConstants.PRODUCTCATEGORY_IPTV
	//				|| ProductCategory == OceConstants.PRODUCTCATEGORY_INTERNET || ProductCategory == OceConstants.PRODUCTCATEGORY_VOIP))
	//			{
	//				uverseGroupIds.add(group.Id)
	//			}
	//		}
	//
	//		return uverseGroupIds;
	//	}

	def static getWirelineGroups(def Order){

		def groupList= Order.Groups.Group

		def groups = []
		for(def group in groupList)
		{
			def ProductCategory = group.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
			def LoSGType = group.GroupCharacteristics?.LoSGCharacteristics?.LoSGType

			if((LoSGType == OceConstants.LoSGType_NEW || LoSGType == OceConstants.LOSGTYPE_CHANGE
			|| LoSGType == OceConstants.LOSGTYPE_NO_CHANGE) && (ProductCategory == OceConstants.PRODUCTCATEGORY_IPTV
			|| ProductCategory == OceConstants.PRODUCTCATEGORY_INTERNET || ProductCategory == OceConstants.PRODUCTCATEGORY_VOIP))
			{
				groups.add(group)
			}
		}

		return groups;
	}

	def static isCreditPolicyUUCP(def order){
		if(order.CreditPolicy != null) {
			if((order.CreditPolicy?.CRSMOnFlag == "true" && order.CreditPolicy?.CreditPolicyTransactionId != null) &&
			(order.CreditPolicy?.UUCPStatusIndicator == "false")) {
				return true
			} else {
				return false
			}
		}
	}

	def static isCreditPolicyUUCPCancel(def order){
		if(order.CreditPolicy != null) {
			if(order.CreditPolicy?.CRSMOnFlag == "true" && order.CreditPolicy?.CreditPolicyTransactionId != null){
				return true
			} else {
				return false
			}
		}
	}

	def static isCancelledGroupPresent(def  Order){

		def isCancelGroup = false
		def groupList= Order.Groups.Group
		for(def group in groupList)
		{
			def LoSGStatus = group.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status
			if(LoSGStatus == OceConstants.LOSGSTATUS_CANCELLED) {
				isCancelGroup = true
				break
			}
		}

		return isCancelGroup
	}

	/*
	 * This function will return address from order of corresponding AddressRef
	 * @param - order Map object,AddressRef
	 * */
	def getAddress(order,addressRef){
		def addressMap;
		List<String> addresses = order.Addresses.Address

		for(def address in addresses) {
			if(address.Id == addressRef) {
				return address
			}
		}
		return null
	}

	/*static def getDTVAccount(order){
	 def accountList = order.Accounts.Account
	 //Loading the Accounts in a list which has AccountType as DTV
	 for(def i=0;i<accountList.size();i++){
	 def accountMap = accountList.get(i)
	 if(accountMap.AccountCategory == WirelineConstants.ACCOUNTCATEGORY_DTV_ACCOUNT){
	 return accountMap
	 }
	 }
	 return null
	 }*/



	static def updateErrorList(order,executionContext,errorBeanList,status,subStatus, referenceId) {

		def errorList = (List<ErrorBean>)executionContext.get('errorList')

		def isFault = false
		if(errorList == null) {
			errorList = new ArrayList<ErrorBean>()
		}

		if(errorBeanList != null && errorBeanList.size() > 0) {
			errorList.addAll(errorBeanList)
			//updating the errorList in executionContext
			executionContext.put('errorList',errorList)
			isFault = true
		}



		//updating s/SS in Transaction History
		def transactionHistory = executionContext.get("transactionHistory")

		if( transactionHistory == null){
			transactionHistory = new ArrayList<Map<String,Object>>()
		}

		if(status && subStatus) {
			/*transactionHistory.add(CommonUtility.getMap("time",new Date(),
			 "status",status,
			 "subStatus",subStatus,'ReferenceId',(referenceId != null) ? referenceId : order.CustomerOrderNumber));*/

			if(referenceId == null) {
				if(executionContext.get("referenceId")) {
					referenceId = executionContext.get("referenceId")
				} else {
					referenceId = order.CustomerOrderNumber
				}
			}

			transactionHistory.add(CommonUtility.getMap("StartTime", TransformationService.getXmlDateTime(),
					"EndTime", TransformationService.getXmlDateTime(),"api","",
					"success",isFault,"status",status,"subStatus",subStatus,"ReferenceId",referenceId));
		}

		executionContext.put("LOSGStatus", "IN_QUEUE")
		executionContext.put("transactionHistory",transactionHistory);
	}

	/**
	 * Updates order with Error
	 * @param order
	 * @param executionContext
	 * @return
	 */
	static def updateErrorInOrder(order,executionContext) {
		Map<List> orderErrMap = new HashMap<List>()
		List errors = new ArrayList();
		def errorList = (List<ErrorBean>)executionContext.get('errorList')
		def error
		if(errorList != null) {
			errorList.forEach{
				e ->

				def reference = e.getNackRef()
				if(reference != null) {
					error = [ErrorCode:e.getErrorCode(),ErrorDescription:e.getErrorDescription(),Reference:[Type:reference.getType(),IdRef:reference.getIdRef()]]
				}
				else {
					error = [ErrorCode:e.getErrorCode(),ErrorDescription:e.getErrorDescription()]
				}

				errors.add(error)
			};
			orderErrMap.put("Error",errors)
			order.put("Errors",orderErrMap)
		}
		return order
	}

	def static existModifyorNewUverseLosgChar(order) {
		def GroupList = order.Groups.Group
		def losgChar =[]
		for(def i=0;i<GroupList.size();i++){
			def GroupMap=GroupList.get(i)
			if(GroupMap.GroupCharacteristics?.LoSGCharacteristics!= null && (GroupMap.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == OceConstants.LoSGType_NEW
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == OceConstants.LOSGTYPE_CHANGE
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == OceConstants.LOSGTYPE_NO_CHANGE)
			&& (GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_IPTV
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_INTERNET
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_VOIP
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_DTV)){

				if(GroupMap.GroupCharacteristics?.LoSGCharacteristics != null)
					losgChar.add(GroupMap.GroupCharacteristics?.LoSGCharacteristics)
			}
		}
		return !(losgChar.empty)
	}

	def static isWirelessUnifyPresentInOrder(order) {
		def GroupList = order.Groups?.Group
		for(def i=0;i<GroupList.size();i++){
			def GroupMap=GroupList.get(i)
			if(GroupMap.GroupCharacteristics?.LoSGCharacteristics!= null &&
			GroupMap.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == OceConstants.LoSGType_UNIFY
			&& GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_WIRELESS){

				return true
			}
		}
		return false
	}

	def static isWirelessProductExist(order) {
		def GroupList = order.Groups?.Group
		for(def i=0;i<GroupList.size();i++){
			def GroupMap=GroupList.get(i)
			if(GroupMap.GroupCharacteristics?.LoSGCharacteristics!= null &&
			GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_WIRELESS){
				return true
			}
		}
		return false
	}

	static def checkPaymenteCollected(order) {
		def paymentOptRef = getUverseLineItemPaymentOptRefs(order);
		def paymentHandler = null

		if(paymentOptRef) {
			paymentHandler = order.PaymentOptions?.PaymentOption.findAll { po -> paymentOptRef.contains(po.Id) }.collect{it}.minus(null).flatten()
		}

		return (paymentHandler && paymentHandler.size > 0) ? true : false
	}

	static def determineFlowType(order) {

		def productCombination = order?.AdditionalDetails?.AdditionalDetail.findAll{ ad -> ad.Code.contains('PRODUCT_COMBINATION')}.collect{it.Value}.flatten().minus(null)
		def prodCombination
		if(productCombination.size!= 0)
		{
			prodCombination = productCombination?.get(0)
		}
		else
		{
			prodCombination = productCombination
		}
		//def prodCombination = productCombination?.get(0)
		//StringTokenizer token = new StringTokenizer(productCombination.get(0), ':')
		def isUverseAcc = false
		def isDTVAcc = false
		def isWirelessAcc = false

		isUverseAcc = prodCombination?.contains(WirelineConstants.PRODUCTCATEGORY_INTERNET) ||
				prodCombination?.contains(WirelineConstants.PRODUCTCATEGORY_VOIP) ||
				prodCombination?.contains(WirelineConstants.PRODUCTCATEGORY_IPTV)

		isDTVAcc = prodCombination?.contains(WirelineConstants.PRODUCTCATEGORY_DTV)
		isWirelessAcc = prodCombination?.contains(WirelineConstants.PRODUCTCATEGORY_WIRELESS)

		if(isUverseAcc && !isDTVAcc && !isWirelessAcc) {

			return WirelineConstants.FLOWTYPE_STANDALONEUV
		}
		else if(isDTVAcc && !isUverseAcc && !isWirelessAcc) {
			return WirelineConstants.FLOWTYPE_STANDALONEDTV
		}
		else if((isDTVAcc || isUverseAcc) && existModifyorNewUverseLosgChar(order)) {

			return WirelineConstants.FLOWTYPE_BUNDLED
		}
		else if(isWirelessUnifyPresentInOrder(order)) {

			return WirelineConstants.FLOWTYPE_UNIFY
		}

		return WirelineConstants.FLOWTYPE_UNKNOWN
	}

	static def isUverseProductGroupExist(order) {
		//grp -> WirelineConstants.UVERSE_PRODUCT_CATEGORIES.contains(grp.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory)
		boolean flag = false;
		def uverseGroup
		def uverseAccount = getUverseAcount(order)

		if(uverseAccount) {
			uverseGroup = order.Groups.Group.findAll {
				grp -> grp.GroupCharacteristics?.LoSGCharacteristics?.AccountRef == uverseAccount.Id
			}.collect{it}.flatten().minus(null)

		}
		return (uverseAccount && uverseGroup && uverseGroup.size() > 0)
	}

	static def getOwnerAddressRef(order) {
		def uverseAcc = getUverseAcount(order)
		def ref = uverseAcc?.BillingInfo.find{ bi -> bi.BillingType == 'OWNER'}.AddressRef
		println("Address Ref :: " + ref)
	}

	static def getUverseGroups(Order)
	{
		def groupList= Order.Groups.Group

		ArrayList<String> uverseGroups = new ArrayList<String>();
		for(def group in groupList)
		{
			if(group.GroupCharacteristics.LoSGCharacteristics?.ProductCategory)
			{
				def productTypes = group.GroupCharacteristics.LoSGCharacteristics?.ProductCategory
				if((productTypes.contains('IPTV')
				|| productTypes.contains('INTERNET')
				|| productTypes.contains('VOIP')
				|| productTypes.contains('DIRECTV')
				|| group.GroupCharacteristics.PackageCharacteristics)
				&& group.GroupCharacteristics.LoSGCharacteristics.ProductCategory != 'PACKAGE' )
				{
					uverseGroups.add(group)
				}
			}

		}
		return uverseGroups
	}

	def static isEligibleForCWP(order) {
		def paymentOpt = getPaymentOptionForAdvancePay(order)
		def preAuthId = getPreAuthorizationCode(paymentOpt)

		def newUverseLoSGChars = order.Groups.Group.GroupCharacteristics?.LoSGCharacteristics.findAll {
			losg -> losg?.LoSGType == "NEW" && WirelineConstants.UVERSE_PRODUCT_CATEGORIES.contains(losg?.ProductCategory) }.collect{it}.flatten().minus(null)

		if(newUverseLoSGChars != null && newUverseLoSGChars.size() > 0
		&& paymentOpt != null && preAuthId != null){
			return true
		} else {
			return false
		}
	}

	def static getPaymentOptionForAdvancePay(order) {

		def paymentoption
		def lineitem = order.LineItems.LineItem.find{dd -> dd.SystemName == WirelineConstants.SYSTEM_ADVANCE_PAYMENT ||
			dd.SystemName == WirelineConstants.SYSTEM_CREDIT_MANAGEMENT_FEE}
		if(lineitem) {
			def paymentoptionref = lineitem.Payments?.Payment?.PaymentOptionRef
			paymentoption = order.PaymentOptions?.PaymentOption?.find{pay -> paymentoptionref?.contains(pay.Id)}
		}
		return paymentoption
	}

	def static getPreAuthorizationCode(paymentOpt) {
		def AuthorizationCode = paymentOpt?.PaymentMethod?.CAPM?.PreAuthDetail?.AuthorizationCode
		if(AuthorizationCode && AuthorizationCode != WirelineConstants.AUTHCODE_DUMMY)
		{
			return AuthorizationCode
		}
		else
		{
			return null
		}
	}

	def static getPaymentSourceSystem(order) {
		def paymentoption = getPaymentOptionForAdvancePay(order)
		def sourceSystem = paymentoption?.PaymentMethod?.CAPM?.PreAuthDetail?.SourceSystem
		if(sourceSystem)
		{
			return sourceSystem
		}
		else
		{
			return WirelineConstants.PAYMENT_SOURCE_SYSTEM_HARDROCK
		}
	}


	def static getPaymentSourceLocation(order) {
		def paymentoption = getPaymentOptionForAdvancePay(order)
		def sourceLocation = paymentoption?.PaymentMethod?.CAPM?.PreAuthDetail?.SourceLocation
		if(sourceLocation)
		{
			return sourceLocation
		}
		else
		{
			return WirelineConstants.PAYMENT_SOURCE_LOCATION_CS

		}
	}

	def static getPaymentSourceUser(order) {
		def paymentoption = getPaymentOptionForAdvancePay(order)
		def sourceUser = paymentoption?.PaymentMethod?.CAPM?.PreAuthDetail?.SourceUser
		if(sourceUser)
		{
			return sourceUser
		}
		else
		{
			return WirelineConstants.PAYMENT_SOURCE_USER_HARDROCK
		}
	}

	def static getAccountType(paymentOption) {

		def accountType = paymentOption?.PaymentMethod?.ACH?.BankAccountDetails?.AccountType

		if(accountType == 'CHECKING') {
			return 'C'
		}
		else if(accountType == 'SAVINGS') {
			return 'S'
		}

		return ''
	}

	/*This method defines Dispatch Type*/
	static def dispatchType(def orderMap)
	{
		def dispatchVar
		if(orderMap?.IsSingleDispatchEligible==true)
		{
			dispatchVar = WirelineConstants.DISPATCH_SINGLE
		}
		else
		{
			dispatchVar = WirelineConstants.DISPATCH_DUAL
		}
		return dispatchVar
	}

	/*This method checks for Standalone order*/
	static boolean checkforStandaloneOrder(def orderMap)
	{
		def uverseLosgsCount=0
		def dtvLosgsCount=0
		def losgs = new ArrayList()
		def productCategory = new ArrayList()
		def losgType = new ArrayList()
		losgs = getLosgsFromOrder(orderMap)
		productCategory = losgs?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
		losgType = losgs?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
		if(losgType.contains(WirelineConstants.LOSGTYPE_NEW) && (productCategory.contains(WirelineConstants.PRODUCTCATEGORY_INTERNET ) ||
		productCategory.contains(WirelineConstants.PRODUCTCATEGORY_IPTV) || productCategory.contains(WirelineConstants.PRODUCTCATEGORY_VOIP)) )
		{
			uverseLosgsCount++
		}
		if(losgType.contains(WirelineConstants.LOSGTYPE_NEW) && productCategory.contains(WirelineConstants.PRODUCTCATEGORY_DTV) )
		{
			dtvLosgsCount++
		}
		if(uverseLosgsCount>0 && dtvLosgsCount==0 )
		{
			true
		}
		else if(dtvLosgsCount>0 && uverseLosgsCount==0)
		{
			true
		}
		else
		{
			false
		}
	}

	static def determineUverseOrder(def orderMap)
	{
		def productType
		def losgs = new ArrayList()
		def productCategory = new ArrayList()
		losgs = getLosgsFromOrder(orderMap)
		boolean standaloneOrder = checkforStandaloneOrder(orderMap)
		productCategory = losgs?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
		def uverseAcc = getUverseAcount(orderMap)
		if(standaloneOrder==false)
		{
			if((productCategory.contains(WirelineConstants.PRODUCTCATEGORY_INTERNET) || productCategory.contains(WirelineConstants.PRODUCTCATEGORY_IPTV) ||
			productCategory.contains(WirelineConstants.PRODUCTCATEGORY_VOIP)) || uverseAcc)
			{
				productType = WirelineConstants.PRODUCT_TYPE_UVERSE
			}
		}
		return productType
	}

	static def determineDTVOrder(def orderMap)
	{
		def productType
		def losgs = new ArrayList()
		def productCategory = new ArrayList()
		losgs = getLosgsFromOrder(orderMap)
		boolean standaloneOrder = checkforStandaloneOrder(orderMap)
		productCategory = losgs?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
		if((standaloneOrder==false) && (productCategory.contains(WirelineConstants.PRODUCTCATEGORY_DTV)) )
		{
			productType = WirelineConstants.PRODUCT_TYPE_DTV
		}
		return productType
	}

	static def removeEmptyObjects(def myList){
		def removeList = []
		for(def obj:myList){
			obj = 	(obj)
			if(obj.keySet().size() == 0){
				removeList.add(obj)
			}
		}
		for(def i : removeList){
			myList.remove(i)
		}
		return myList
	}

	static def removeEmptyFields(def map){
		def keylist = map.keySet()
		def remKeyList = []
		for(def key: keylist){
			if(map.get(key) == null || map.get(key) == '' || map.get(key) == []){
				remKeyList.add(key)
			}else{
				if(map.get(key) instanceof List){
					removeEmptyObjects(map.get(key))
				}else if(map.get(key) instanceof Map){

				}
			}
		}
		for(def j: remKeyList){
			map.remove(j)
		}
		return map
	}

	static def getOrderingContext(){
		return ['salesChannel' : WirelineConstants.SALES_CHANNEL,
			'applicationId' :  WirelineConstants.APP_ID ]
	}

	static def getCustomerData(def order,def creditRisk){
		def uverseAcc = getUverseAcount(order)
		return [creditRiskClass :  creditRisk,
			customerSubType : uverseAcc.AccountSubType,
			ban : uverseAcc.BillingAccountNumber]
	}

	static def throwBPMNError(Exception e, order, executionContext) throws BpmnError {
		e.printStackTrace()
		List<ErrorBean> errList = new ArrayList<ErrorBean>();
		//				errList.add(new ErrorBean(WirelineConstants.SYS_ERROR,'OCE_WIRELINE_EG_APPLICATION_ERROR'))
		updateErrorList(order,executionContext,errList,WirelineConstants.LOSG_STATUS_IN_QUEUE,WirelineConstants.LOSG_MANUAL_PROVISIONING_REQUIRED,null)
		throw new BpmnError(WirelineConstants.BPMN_ERR_WLERR001, (e.getMessage()!=null) ? e.getMessage() : WirelineConstants.SYS_ERROR)
	}

	static def getAllComponentDetailsAsList(def componentDetails, ComponentDetails){

		for (def  compD : ComponentDetails){
			componentDetails.add(compD)
			if(compD.ComponentDetails){
				getAllComponentDetailsAsList(componentDetails, compD.ComponentDetails)
			}


		}
		return componentDetails
	}

	static def isUverGroupStatusInQueue(order) {
		boolean flag = false
		def uverseAcc = getUverseAcount(order)
		println("isUverGroupStatusInQueue :: Uverse Account Id : " + uverseAcc.Id)

		def groupList= order.Groups.Group
		for(def group in groupList)
		{
			if(group.GroupCharacteristics.LoSGCharacteristics &&
			group.GroupCharacteristics.LoSGCharacteristics.AccountRef == uverseAcc.Id){
				println("isUverGroupStatusInQueue :: losg.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status : " + group.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status)
				if( group.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status == WirelineConstants.LOSG_STATUS_IN_QUEUE) {
					flag = true
					break
				}
			}
		}

		return flag
	}

	static def getPaymentOptionForAutoPay(def order) {

		def paymentoption
		def lineitem = order?.LineItems?.LineItem.find{dd -> dd.SystemName == WirelineConstants.LINEITEM_DISPLAY_NAME_AUTO_PAY}
		def paymentoptionref = lineitem?.Payments?.Payment?.PaymentOptionRef
		paymentoption = order?.PaymentOptions?.PaymentOption.find{pay -> paymentoptionref?.contains(pay.Id)}

		return paymentoption
	}

	def static checkForUverseAccount(order){
		def uverseAccount = getUverseAcount(order);
		if(uverseAccount?.BillingAccountNumber != null ) {
			return true
		} else {
			return false
		}
	}

	def static checkForRefund(order) {

		boolean isRefund = false
		//		List<String> wirelineGroupIds = getWirelineGroups(order)

		def partialCancelGroup = order?.Groups?.Group.findAll{g -> WirelineConstants.UVERSE_PRODUCT_CATEGORIES.contains(g?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory) &&
			g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status == 'CANCELED'}.collect{it}.flatten().minus(null)

		if(order?.OrderStatus?.Status == 'CANCELED' || order?.OrderStatus?.Status == 'SUBMITTED') {

			if(order?.PaymentOptions?.PaymentOption?.CollectedInOtherSystem.contains("true") || order?.LineItems?.LineItem?.Price?.PriceType.contains('DueNow')) {

				updateAWPRefund(order?.Groups?.Group)
				isRefund = true
			}
		}
		else if(partialCancelGroup) {

			if(!order?.PaymentOptions?.PaymentOption?.PaymentHandler?.flatten().empty || order?.PaymentOptions?.PaymentOption?.CollectedInOtherSystem.contains("true")) {

				updateAWPRefund(partialCancelGroup)
				isRefund = true
			}
		}

		return isRefund

	}

	def static updateAWPRefund(groups) {

		for(def groupMap:groups) {

			def losgSubStatus = groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus

			if(groupMap?.Type == 'LINE_OF_SERVICE' && losgSubStatus) {

				groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = losgSubStatus+"_REFUND_REQUIRED"
			}
		}
	}

	def static sassignCompleteStatusInOrder(order){

		def LOSGroups = order.Groups
		def convergeIndicator = order.Accounts.Account.find{acc -> acc.AccountCategory == 'ACCOUNTCATEGORY_MOBILITY_ACCOUNT'}?.UnifiedAccount?.ConvergedBillingIndicator
		convergeIndicator = !convergeIndicator ? 'Y' : convergeIndicator
		for(def grp : order.Groups.Group){
			if(grp.Type == 'LINE_OF_SERVICE' && grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGType !='REWARDS/GIFT'){
				if(grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGType != 'NO_CHANGE'){
					if(grp.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory in ['IPTV','INTERNET','VOIP']){
						grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status = 'SUBMITTED'
						grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = 'AUTO_COMPLETE'
					}else if(grp.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == 'WIRELESS' && grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == 'UNIFY'){
						grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status = convergeIndicator == 'Y' ? 'SUBMITTED': 'IN_QUEUE'
						grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = convergeIndicator == 'Y' ? 'UNIFY_AUTO_COMPLETE-WIRELESS_COMPLETE': 'UNIFY_AUTO_COMPLETE-WIRELESS_FAILED'
					}else if(grp.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == 'DIRECTV' && isCDEHS(order)){
						if(grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == 'UNIFY'){
							grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status = grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status ==  'IN_QUEUE'?  'IN_QUEUE':'SUBMITTED'
							grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = 'UNIFY_AUTO_COMPLETE'+grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus
						}else{
							grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status = 'SUBMITTED'
							grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus = 'AUTO_COMPLETE'
						}
					}
				}
			}
		}
	}

	def static updateCompleteStatus(def order,def executionContext){
		sassignCompleteStatusInOrder(order)
		def transactionHistory = executionContext.get("transactionHistory")

		if( transactionHistory == null){
			transactionHistory = new ArrayList<Map<String,Object>>()
		}

		transactionHistory.add(CommonUtility.getMap("StartTime", TransformationService.getXmlDateTime(),
				"EndTime", TransformationService.getXmlDateTime(),"api","",
				"success",true,"status","","subStatus","","ReferenceId",null));

		executionContext.put("transactionHistory",transactionHistory);
	}

	static def getOrderType(order) {

		def Ordertype = order.OrderType

		if(Ordertype == 'CREATE') {
			return true
		}
		else if(Ordertype == 'MODIFY') {
			return false
		}

		return ''
	}

	static def getLegacyDTVAccount(order) {
		def Account = order.Accounts?.Account?.find{cc ->cc.AccountCategory ==  WirelineConstants.ACCOUNTCATEGORY_DTV}
		return Account

	}

	static def getNewUverseLOSGcharacteristics(order) {
		def LOSGcharacteristics = order.Groups.Group.findAll{ ee -> (ee.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == WirelineConstants.LoSGType_NEW
			&& WirelineConstants.UVERSE_PRODUCT_INT_IPTV.contains(ee.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory))}.collect{it}.flatten().minus(null)
		return LOSGcharacteristics

	}

	static def getNewWirelineLOSGs(order) {
		def NewWirelineLOSGs = order.Groups.Group.findAll{ ee -> (ee.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == WirelineConstants.LoSGType_NEW
			&& WirelineConstants.UVERSE_PRODUCT_INT_IPTV_DTV.contains(ee.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory))}.collect{it}.flatten().minus(null)
		return NewWirelineLOSGs

	}

	/*def static getWirelineGroups(def groupMap){
	 def ProductCategory = groupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
	 def LoSGType = groupMap.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
	 def FulfillmentMethod = groupMap.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod
	 if((LoSGType == OceConstants.LoSGType_NEW || LoSGType == OceConstants.LOSGTYPE_CHANGE
	 || LoSGType == OceConstants.LOSGTYPE_NO_CHANGE) && (ProductCategory == OceConstants.PRODUCTCATEGORY_IPTV
	 || ProductCategory == OceConstants.PRODUCTCATEGORY_INTERNET || ProductCategory == OceConstants.PRODUCTCATEGORY_VOIP))  {
	 return true
	 } else {
	 return false
	 }
	 }*/

	/*def static getWirelessGroups(def groupMap) {
	 def ProductCategory = groupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
	 def LoSGType = groupMap.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
	 def FulfillmentMethod = groupMap.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod
	 if((LoSGType == OceConstants.LoSGType_NEW || LoSGType == OceConstants.LOSGTYPE_AL) && (ProductCategory == OceConstants.PRODUCTCATEGORY_WIRELESS) &&
	 (FulfillmentMethod == OceConstants.FULFILLMENT_METHOD_DF || FulfillmentMethod == OceConstants.FULFILLMENT_METHOD_C2S )) {
	 return true
	 } else {
	 return false
	 }
	 }*/


	/*def static getCreditPolicyUUCP(def order){
	 if(order.CreditPolicy != null) {
	 if((order.CreditPolicy?.CRSMOnFlag == "true" || order.CreditPolicy?.CreditPolicyTransactionId != null) &&
	 (order.CreditPolicy?.UUCPStatusIndicator == "false")) {
	 return true
	 } else {
	 return false
	 }
	 }
	 }
	 def static getCreditPolicyUUCPCancel(def order){
	 if(order.CreditPolicy != null) {
	 if(order.CreditPolicy?.CRSMOnFlag == "true" || order.CreditPolicy?.CreditPolicyTransactionId != null){
	 return true
	 } else {
	 return false
	 }
	 }
	 }*/

	/*def static isLoSGTypeCancelled(def  groupMap){
	 def LoSGType = groupMap.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
	 if(LoSGType == OceConstants.LOSGSTATUS_CANCELLED) {
	 return true
	 } else {
	 return false
	 }
	 }*/
	def static isUUCPEnable(order) {
		println('UpdateUnifiedCreditPolicy.preCondition <-- Entering')
		println('UpdateUnifiedCreditPolicy.preCondition:')
		def groupList = order.Groups.Group
		def ProductCategory
		def LoSGType
		def FulfillmentMethod
		def WirelessGroups
		def WirelineGroups
		def CreditPolicyUUCP
		def CreditPolicyUUCPCancel
		def isCancelled
		for(def i=0;i<groupList.size();i++){
			def groupMap=groupList.get(i)
			ProductCategory = groupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
			LoSGType = groupMap.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
			FulfillmentMethod = groupMap.GroupCharacteristics?.LoSGCharacteristics?.FulfillmentMethod
			WirelessGroups = getWirelessGroups(groupMap)
			WirelineGroups = getWirelineGroups(groupMap)
			CreditPolicyUUCP = getCreditPolicyUUCP(order)
			CreditPolicyUUCPCancel = getCreditPolicyUUCPCancel(order)
			isCancelled = isLoSGTypeCancelled(groupMap)

			if(CreditPolicyUUCP || (isCancelled && CreditPolicyUUCPCancel)) {
				if(WirelessGroups || WirelineGroups) {
					return true
				} else {
					return false
				}
			} else {
				return false
			}
		}
	}
	def static checkChangeNo_ChangeUverseLOSG(order) {
		def GroupList = order.Groups.Group
		def LosgChar =[]
		for(def i=0;i<GroupList.size();i++){
			def GroupMap=GroupList.get(i)
			if(GroupMap.GroupCharacteristics?.LoSGCharacteristics!= null && (GroupMap.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == OceConstants.LOSGTYPE_CHANGE
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == OceConstants.LOSGTYPE_NO_CHANGE)
			&& (GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_IPTV
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_INTERNET
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_VOIP
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_DTV)){

				LosgChar.add(GroupMap.GroupCharacteristics?.LoSGCharacteristics)
			}
		}
		return LosgChar
	}

	def static getNewUverseServiceQualificationRef(order) {
		def GroupList = order.Groups.Group
		def LosgChar =[]
		for(def i=0;i<GroupList.size();i++){
			def GroupMap=GroupList.get(i)
			if(GroupMap.GroupCharacteristics?.LoSGCharacteristics!= null && (GroupMap.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == OceConstants.LoSGType_NEW)
			&& (GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_IPTV
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_INTERNET
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_VOIP
			|| GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == OceConstants.PRODUCTCATEGORY_DTV)){

				if(GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ServiceQualificationRef != null)
					LosgChar.add(GroupMap.GroupCharacteristics?.LoSGCharacteristics?.ServiceQualificationRef)
			}
		}
		return LosgChar
	}
	static def getcheckForWirelineProvideFlow(order) {

		def UverseAccount = getUverseAcount(order)
		def LegacyDTVAccount = getLegacyDTVAccount(order)
		def NewUverseLOSGcharacteristics = getNewUverseLOSGcharacteristics(order)
		def NewWirelineLOSGs = getNewWirelineLOSGs(order)
		def provideLoSGType
		if(UverseAccount.AccountSubCategory == WirelineConstants.AccountSubCategory_NEW && LegacyDTVAccount && NewUverseLOSGcharacteristics) {
			provideLoSGType=true
		} else if(UverseAccount.AccountSubCategory == WirelineConstants.AccountSubCategory_NEW && NewWirelineLOSGs) {
			provideLoSGType=true
		} else {
			provideLoSGType=false }

	}


	static def getcheckForWirelineModifyFlow(order) {
		def modifyUverse = getUverseAcount(order)
		def WireLineProductCategory = order.Groups?.Group?.findAll{ee ->WirelineConstants.UVERSE_PRODUCT_CATEGORIES.contains(ee.GroupCharacteristics?.
			LoSGCharacteristics?.ProductCategory)}.collect{it}.flatten().minus(null)
		def LegacyDTVAccount = getLegacyDTVAccount(order)
		def modifyLoSGType
		if(WirelineConstants.WIRELINE_PRODUCT_TYPE.contains(WireLineProductCategory.LoSGType).collect{it}.flatten().minus(null)) {
			modifyLoSGType = true
		} else {
			modifyLoSGType = false
		}
		def isUverseModifyAccount
		if(modifyUverse.AccountSubCategory == WirelineConstants.AccountSubCategory_EXISTING && LegacyDTVAccount==null && modifyLoSGType) {
			isUverseModifyAccount = true
		} else {
			isUverseModifyAccount = false
		}
		return isUverseModifyAccount

	}

	static def getconstructWirelineFlowChecks(order){
		def checkForWirelineProvideFlow = getcheckForWirelineProvideFlow(order)
		def checkForWirelineModifyFlow = getcheckForWirelineModifyFlow(order)
		if (checkForWirelineProvideFlow) {
			return WirelineConstants.EXISTING_WL_NEW_FMO_WIRELINE
		} else if (checkForWirelineModifyFlow) {
			return WirelineConstants.EXISTING_WL_MODIFY_FMO_WIRELINE
		} else {
			pritnln("fallout")
		}
	}

}
