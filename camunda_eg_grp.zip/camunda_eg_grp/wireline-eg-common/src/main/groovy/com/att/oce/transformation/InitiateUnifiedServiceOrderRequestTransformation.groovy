package com.att.oce.transformation

import org.apache.camel.Exchange
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import org.springframework.beans.factory.annotation.Autowired
import com.att.oce.bpm.common.WirelineProperties
import com.att.oce.bpm.common.WirelineTransformationService
import com.att.oce.bpm.utility.OrderUtility
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.common.WirelineConstants
import org.camunda.bpm.engine.delegate.BpmnError
import com.att.oce.bpm.common.util.ErrorBean
import java.util.List
import java.util.ArrayList



@Component('csiIUSOUnifiedServiceOrderRequest')
class InitiateUnifiedServiceOrderRequestTransformation  extends WirelineTransformationService{
	
		@Autowired
		WirelineProperties props;
		  String url;
	  
		static Logger log = LoggerFactory.getLogger("InitiateUnifiedServiceOrderRequestTransformation.class")
		
		@Override
		public String getApiName(){
			return 'InitiateUnifiedServiceOrder';
		}
		
		public String getApiUrn() {
			return 'urn:csi:services:qual:InitiateUnifiedServiceOrder.jws';
		}
		
		/**
		 * @param exchange
		 */
		public void transform(Exchange exchange)
		{
			
			exchange.properties.order = exchange.in.body.order
			exchange.properties.executionContext  = exchange.in.body.executionContext
			exchange.properties.fedIndicator = false;
			
			def apiURN = getApiUrn()
			def apiUrl = super.resolveURN(apiURN, null)
			exchange.properties.apiURN = apiURN
			exchange.properties.apiUrl = apiUrl
		  
			println ('IUSORequestTransformation.transform')
			
			int index = 0
			def order = exchange.in.body.order
			println('ORDER :: ' + order)
			def executionContext = exchange.in.body.executionContext
			if(!executionContext.conversationId || executionContext.conversationId.isEmpty())
				executionContext.conversationId = 'oce~CNG-CSI~a68f6bf6-36d7-481c-88b4-eaf0e22ec483'
			def msgHeader = OrderUtility.removeEmptyFields(createUnifiedMessageHeader(order,executionContext.conversationId))
			def iusoRequest = prepareRequest(order,msgHeader,executionContext)
			
			setAuditLogProperties(exchange,false)
			exchange.out.body = iusoRequest
			setCSIHttpHeaders(exchange)
			exchange.out.headers.put("CamelHttpUri",apiUrl)
			exchange.properties.put("OceCSIApiName",getApiName())
			exchange.properties.executionContext  = exchange.in.body.executionContext
			println('csiIUSOUnifiedServiceOrderRequest.transform done')
		}
		
		def prepareRequest(order,msgHeader,executionContext)
		{
			def AddressRef
			def addId
			def Addresslist=order.Addresses.Address
			println(Addresslist)
			def UverseAcc= OrderUtility.getUverseAcount(order)
			println(UverseAcc)
			if(UverseAcc!=null && UverseAcc.ServiceLocationRef != null)
			{
				AddressRef = UverseAcc.ServiceLocationRef
				println(AddressRef)
				for(def AddressMap : Addresslist)
					{
						if(AddressMap.Id == AddressRef)
						{
							addId=AddressMap.AddressId
						}
					}
				}
			if(addId == null)
			{
				def iusaResp = executionContext.get(inquireUnifiedServiceAccountResponse)
				def iusaResponse= new XmlSlurper().parseText(iusaResp)
 
				def mapAdd = iusaResponse.Body.InquireUnifiedServiceAccountResponse.CustomerIdDetailsByOrgId.MapAddressesExt
				println(mapAdd)
 
				def addressId= mapAdd.findAll{tt-> tt.type.equals ('ServiceFSP')}.collect{it.amnqAddressId}.flatten().minus(null)
				println(addressId)
 
				addId=addressId
			}
 
 
			return [ messageHeader :msgHeader ,
						csiIUSOInitiateUnifiedServiceOrderRequest : [
							 AddressId : addId,
							 CustomerSubType : WirelineConstants.IUSO_CUSTOMER_SUBTYPE,
							 productType : WirelineConstants.IUSO_PRODUCT_TYPE
					 ]
				]
  
		}
		
		public void processResponse(Exchange exchange) throws APIFailedException
		{
		   def order = exchange.properties.order
		   def executionContext = exchange.properties.executionContext
			
			def initiateUnifiedServiceOrderResponse = exchange.in.body
			println('IUSO Response :: ' + initiateUnifiedServiceOrderResponse)
			
			executionContext.put("iusoResponse", initiateUnifiedServiceOrderResponse)
			def iusoResponse = new XmlSlurper().parseText(initiateUnifiedServiceOrderResponse)
			//println("response in xml format ==================================================="+iusoResponse)
			if (iusoResponse.Body.Fault.size()>0)
			{
				def e = new APIFailedException();
				e.api = getApiName()
				e.code = iusoResponse.Body.Fault.detail.CSIApplicationException.Response.code
				e.codeDescription = iusoResponse.Body.Fault.detail.CSIApplicationException.Response.description
				e.subCode = iusoResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code
				e.subCodeDescription = iusoResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
				addTransactionHistory(exchange,e)
				throw e
			}
			else
			{
			//addTransactionHistory(exchange,null)
			}
			if(!executionContext.conversationId || executionContext.conversationId.isEmpty())
				executionContext.conversationId = iusoResponse.Header.MessageHeader.TrackingMessageHeader.conversationId.text()
			executionContext.put("iusoProcessCompletionIndicator",iusoResponse.Body.InitiateUnifiedServiceOrderResponse.processCompleteIndicator.text())
			validateIUSOResponse(order,executionContext,iusoResponse.Body.InitiateUnifiedServiceOrderResponse)
			println('csiIUSOUnifiedServiceOrderRequest.processResponse done')
			
			//return initiateUnifiedServiceOrderResponse
	   }
	 
	def validateIUSOResponse(order,executionContext, iusoRes)
	{
		List<ErrorBean> errors = new ArrayList<ErrorBean>();
		println("iusoRes is:: "+iusoRes)
		//List errors = new ArrayList();
		println("validateIUSOResponse is working")
		
		def prodCategory=order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.ProductCategory
		println(prodCategory)
		def serviceNT = "Service is not available for-"
		
		if(prodCategory.contains(WirelineConstants.PRODUCTCATEGORY_DTV))
		{
			def dtvOffSvc = iusoRes.UnifiedServicesProduct.ServiceOfferingFromLocation.OfferingService.find { os -> os.serviceCode.text() == WirelineConstants.SERVICECODE_DTV}.collect{it}
			if(dtvOffSvc) {
				def indicator = dtvOffSvc.serviceAvailableIndicator.get(0)
				if(indicator != 'true')
				{
					ErrorBean error = new ErrorBean("HSFMOError01",serviceNT + WirelineConstants.SERVICECODE_DTV)
//					def error = ["ErrorDescription": serviceNT + WirelineConstants.SERVICECODE_DTV]
					errors.add(error)
				}
			}
			else
			{
				ErrorBean error = new ErrorBean("HSFMOError01","SERVICE MISMATCH OCCURRED.MSGS= Order["+ WirelineConstants.SERVICECODE_DTV + " =  Available] IUSO[{" + WirelineConstants.SERVICECODE_DTV + "}=  Not Available]")
				//def error = ["ErrorDescription": 'SERVICE MISMATCH OCCURRED.MSGS= Order['+ WirelineConstants.SERVICECODE_DTV + '=  Available] IUSO[{' + WirelineConstants.SERVICECODE_DTV + '}=  Not Available]']
				errors.add(error)
			}
		}

		if(prodCategory.contains(WirelineConstants.PRODUCTCATEGORY_INTERNET))
		{
			def internetOffSvc = iusoRes.UnifiedServicesProduct.ServiceOfferingFromLocation.OfferingService.find { os -> os.serviceCode.text() == WirelineConstants.HSIA_PRODUCTCODE}.collect{it}
			if(internetOffSvc)
			{
				def indicator = internetOffSvc.serviceAvailableIndicator.get(0)
				if(indicator != 'true'){
					ErrorBean error = new ErrorBean("HSFMOError01",serviceNT + WirelineConstants.SERVICECODE_INTERNET)
					//def error = ["ErrorDescription": serviceNT + WirelineConstants.SERVICECODE_INTERNET]
					errors.add(error)
				}
			}
			else
			{
				ErrorBean error = new ErrorBean("HSFMOError01","SERVICE MISMATCH OCCURRED.MSGS= Order["+ WirelineConstants.SERVICECODE_INTERNET + "=  Available] IUSO[{" + WirelineConstants.SERVICECODE_INTERNET + "}=  Not Available]")
				//def error = ["ErrorDescription": 'SERVICE MISMATCH OCCURRED.MSGS= Order['+ WirelineConstants.SERVICECODE_INTERNET + '=  Available] IUSO[{' + WirelineConstants.SERVICECODE_INTERNET + '}=  Not Available]']
				errors.add(error)
			}
		}
		
		if(prodCategory.contains(WirelineConstants.PRODUCTCATEGORY_VOIP))
		{
			def voipOffSvc = iusoRes.UnifiedServicesProduct.ServiceOfferingFromLocation.OfferingService.find{ os -> os.serviceCode.text() == WirelineConstants.SERVICECODE_VOIP}.collect{it}
			if(voipOffSvc)
			{
				def indicator = voipOffSvc.serviceAvailableIndicator.get(0)
				if(indicator != 'true'){
					ErrorBean error = new ErrorBean("HSFMOError01",serviceNT + WirelineConstants.SERVICECODE_VOIP)
					//def error = ["ErrorDescription": serviceNT + WirelineConstants.SERVICECODE_VOIP]
					errors.add(error)
				}
			}
			else
			{
				ErrorBean error = new ErrorBean("HSFMOError01","SERVICE MISMATCH OCCURRED.MSGS= Order["+ WirelineConstants.SERVICECODE_VOIP + "=  Available] IUSO[{" + WirelineConstants.SERVICECODE_VOIP + "}=  Not Available]")
				//def error = ["ErrorDescription": 'SERVICE MISMATCH OCCURRED.MSGS= Order['+ WirelineConstants.SERVICECODE_VOIP + '=  Available] IUSO[{' + WirelineConstants.SERVICECODE_VOIP + '}=  Not Available]']
				errors.add(error)
			}
		}
		if(!errors.isEmpty()){
			
			println("Error for IUSO::"+errors)
			def uverseAcc = OrderUtility.getUverseAcount(order)
			
			OrderUtility.updateErrorList(order,executionContext,errors, WirelineConstants.LOSG_STATUS_IN_QUEUE,
				WirelineConstants.LOSG_MANUAL_PROVISIONING_REQUIRED,uverseAcc?.Id)
			
			throw new BpmnError("HSFMOError01");
		}
		//println("Order with Error tags::"+errors)
		
		
	}
}