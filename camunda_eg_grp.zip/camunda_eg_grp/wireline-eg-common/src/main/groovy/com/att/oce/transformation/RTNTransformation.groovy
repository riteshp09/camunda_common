package com.att.oce.transformation

import org.springframework.stereotype.Component;
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import com.att.oce.bpm.common.WirelineConstants;
import com.att.oce.bpm.common.WirelineTransformationService
import com.att.oce.bpm.error.APIFailedException;
import org.apache.camel.Exchange
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

@Component('rtnTransformation')
class RTNTransformation  extends  WirelineTransformationService{
	static Logger log = LoggerFactory.getLogger(RTNTransformation.class)
	
	String url;
	
	@Override String getApiName()
	{
		return 'ReserveTelephoneNumbers';
	}
	
	public String getApiUrn() {
		return "urn:csi:services:wirelinedb:ReserveTelephoneNumbers.jws";
	}
	
	/*
	 * Method to gather data to frame the outbound request for a given API
	 * @param uri
	 * @param exchange
	 * @return
	 */
	public void transform(Exchange exchange){
		log.info('rtnTransformation.transform <-- Entering')
		/*Setting values for Camel Header*/
		setCSIHttpHeaders(exchange)
		//need to reset for rtn
		exchange.out.headers.put("CamelHttpUri",resolveURN(getApiUrn(),url))
		exchange.properties.put("OceCSIApiName","ReserveTelephoneNumbers")
		
		exchange.properties.executionContext  = exchange.in.body.executionContext
		def executionContext = exchange.in.body.executionContext
		
		def mappingData = executionContext.mappingData
		def order = exchange.in.body.order
		exchange.properties.put("order",order)
		exchange.properties.put("voipGroup",exchange.in.body.voipGroup)
		println('Testing JSONOUTPUT: Body:' + JsonOutput.toJson(mappingData))
		//def addressReq = exchange.in.body.Address -- uncomment this when testing from Camunda
		
		log.debug('rtnTransformation.transform: mappingData --> :' + mappingData)

		/*to retain the original arguments */
		
		
		/*Setting Values required for SOAP Body*/
		
		def reserveTelephoneNumbersRequest = ['portType' : WirelineConstants.PORT_TYPE,
		'billingAccountNumber' : mappingData.billingAccountNumber,
		 'tarCode' : mappingData.tarCode,
		 'telephoneNumber' : mappingData.telephoneNumber,
		 'salesChannel' : mappingData.salesChannel]

		def soapRequest = ['messageHeader' : createMessageHeader(order,executionContext.conversationId),
			'reserveTelephoneNumbersRequest' : reserveTelephoneNumbersRequest]

		soapRequest = removeKeysWithoutValues(soapRequest);
		println('rtnTransformation.transform: Body:' + soapRequest)
		println('rtnTransformation.transform --> Exiting')
		exchange.out.body = soapRequest
	}

	/*
	 * Method to Process the response back from the API
	 * @param exchange
	 * @return
	 */
	public void processResponse(Exchange exchange){
		def reserveTelephoneNumbersResponse = exchange.in.body
		println('rtnTransformation.processResponse --> entering'+reserveTelephoneNumbersResponse)
		def rtnResponse = new XmlSlurper().parseText(reserveTelephoneNumbersResponse)
		
		if (rtnResponse.Body.Fault.size()>0){
			def e = new APIFailedException();
			e.api = getApiName()
			e.code = rtnResponse.Body.Fault.detail.CSIApplicationException.Response.code
			e.codeDescription = rtnResponse.Body.Fault.detail.CSIApplicationException.Response.description
			e.subCode = rtnResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code
			e.subCodeDescription = rtnResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
			addTransactionHistory(exchange,e)
			exchange.out.body = order
			throw e
		}
		
		def body = rtnResponse.Body.ReserveTelephoneNumbersResponse
		def order =  exchange.properties.order
		def voipGrp = exchange.properties.voipGroup
		voipGrp.GroupCharacteristics?.LoSGCharacteristics?.VOIPLOSChars?.ReservedTelephoneNumber = 
						body.ReservationDetails?.CVOIP?.telephoneNumber?.text()
		order.Groups.Group.each{ grp ->
			if(grp.Id == voipGrp.Id){
				grp.putAt('GroupCharacteristics',voipGrp.GroupCharacteristics)
				println('RTNVOIPGroup1 :::'+grp)
			}
			println('RTNVOIPGroup2 :::'+grp)
		}
		println('After Update Order :::'+order)
		println("Exiting RTN Successfully")
//		return order
	}
}
