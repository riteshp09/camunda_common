package com.att.oce.transformation

import org.camunda.bpm.engine.delegate.DelegateExecution
import org.camunda.bpm.engine.delegate.JavaDelegate
import org.springframework.stereotype.Component;;
import com.att.oce.bpm.common.WirelineConstants;

@Component("preValidateAddresss")
class PreValidateAddress implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		
	   println('ValidateAddressTransformation.preCondition <-- Entering')
	   //println('ValidateAddressTransformation.preCondition: Validating preCondition for Address ID: ' + addressId)
	   def order = execution.getVariable("order");
	   boolean result = false;
	   def validateAddressIgnore = WirelineConstants.API_NAME_VALIDATE_ADDRESS + '_IGNORE'
	   boolean isValidateAddressIgnore = order.Groups.Group.any { g -> g.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus == validateAddressIgnore}
	   if(!isValidateAddressIgnore){
		   isValidateAddressIgnore = (order.OrderSource.Channel == WirelineConstants.DEMOBILITY)? true : false;
		   
	   }
	   
	   def addressList = []
	   if(!isValidateAddressIgnore){
		   order.Addresses.Address.each { ad-> if(!('ValidatedAddress' in ad.AdditionalDetails?.AdditionalDetail?.Code   && ad.AdditionalDetails?.AdditionalDetail?.Value.intersect(['true',true])))
			   addressList.add(ad)
			   println('ValidateAddress preCondition: isValidateAddress: ' + ad.Id)
			   println('ValidateAddress preCondition: isValidateAddress: ' + ad.AdditionalDetails?.AdditionalDetail?.Value)
			   println('ValidateAddress preCondition: isValidateAddress: ' + ad.AdditionalDetails?.AdditionalDetail?.Code)
		   }
		   
		   /*boolean isChannelDEMobility = (order.orderSource.channel == OceConstants.DEMOBILITY)? true : false;
		   log.debug('ValidateAddressTransformation.preCondition: isChannelDEMobility: ' + isChannelDEMobility)
		   if(isValidateAddress && isChannelDEMobility){ result = true}*/
	   }
	   
	   
	   execution.setVariable("isValidateAddressIgnore", isValidateAddressIgnore)
	   execution.setVariable("addressList", addressList)	
	   print('addressList>>'+addressList)   
	   /*log.debug('ValidateAddressTransformation.preCondition:' + result)
	   log.info('ValidateAddressTransformation.preCondition --> Exiting')
	   return result;*/
	}

}
