package com.att.oce.transformation

import org.springframework.stereotype.Component;
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import com.att.oce.bpm.common.WirelineConstants;
import com.att.oce.bpm.common.WirelineTransformationService

import com.att.oce.bpm.error.APIFailedException;
import org.apache.camel.Exchange
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

@Component('iatnTransformation')
class IATNTransformation  extends  WirelineTransformationService{
	static Logger log = LoggerFactory.getLogger(IATNTransformation.class)
	
	String url;
	
	@Override String getApiName()
	{
		return 'InquireAvailableTelephoneNumber';
	}
	
	public String getApiUrn() {
		return "urn:csi:services:switch:InquireAvailableTelephoneNumbers.jws";
	}
	
	/*
	 * Method to gather data to frame the outbound request for a given API
	 * @param uri
	 * @param exchange
	 * @return
	 */
	public void transform(Exchange exchange){
		log.info('iatnTransformation.transform <-- Entering')
		/*Setting values for Camel Header*/
		setCSIHttpHeaders(exchange)
		//need to reset for iatn
		def executionContext = exchange.in.body.executionContext
		exchange.out.headers.put("CamelHttpUri",resolveURN(getApiUrn(),url))
		exchange.properties.put("OceCSIApiName","InquireAvailableTelephoneNumbers")
		def order = exchange.in.body.order
		def acc = order.Accounts.Account.find{ac -> ac.AccountCategory == 'UVERSE_ACCOUNT'}
		
		def uverse_address = order.Addresses.Address.find{ad -> ad.Id == acc?.ServiceLocationRef}
		
		def mappingData =  ['billingAccountNumber' : acc.BillingAccountNumber, 
							'tarCode' : uverse_address?.ParsedAddress?.TarCode ,
							'salesChannel': 'WEB',
							'rateCenterCode': uverse_address?.ParsedAddress?.RateCenterCode ,
							'state': uverse_address?.ParsedAddress?.State ]
		
		println('Testing JSONOUTPUT: Body:' + mappingData)
				
		log.debug('iatnTransformation.transform: mappingData --> :' + mappingData)

		def inquireAvailableTelephoneNumbersRequest = ['portType' : WirelineConstants.PORT_TYPE,
		 'quantityRequested' : 1,	
		 'billingAccountNumber' : mappingData.billingAccountNumber,
		 'rateCenterCode' : mappingData.rateCenterCode,
		 'state' : mappingData.state,
		 'salesChannel' : mappingData.salesChannel]

		def soapRequest = ['messageHeader' : createMessageHeader(order,executionContext.conversationId),
			'inquireAvailableTelephoneNumbersRequest' : inquireAvailableTelephoneNumbersRequest]
		exchange.properties.put('mappingData',mappingData)
		soapRequest = removeKeysWithoutValues(soapRequest);
		println('iatnTransformation.transform: Body:' + soapRequest)
		println('iatnTransformation.transform --> Exiting')
		exchange.out.body = soapRequest
	}

	/*
	 * Method to Process the response back from the API
	 * @param exchange
	 * @return
	 */
	public void processResponse(Exchange exchange){
		println('iatnTransformation.processResponse <-- Entering')
		
		/* Initialize */
		def executionContext = exchange.properties.executionContext
		def inquireAvailableTelephoneNumbersResponse = exchange.in.body		
		println('iatnTransformation.processResponse: Response XML :' + inquireAvailableTelephoneNumbersResponse)
		def iatnResponse = new XmlSlurper().parseText(inquireAvailableTelephoneNumbersResponse)
		
		if (iatnResponse.Body.Fault.size()>0){
			def e = new APIFailedException();
			e.api = getApiName()
			e.code = iatnResponse.Body.Fault.detail.CSIApplicationException.Response.code
			e.codeDescription = iatnResponse.Body.Fault.detail.CSIApplicationException.Response.description
			e.subCode = iatnResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code
			e.subCodeDescription = iatnResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
			addTransactionHistory(exchange,e)
			exchange.out.body = order
			throw e
		}
				
		/* Updating the execution context */
		executionContext.put('IATN.pass', 'SUCCESS')
		def body = iatnResponse.Body.InquireAvailableTelephoneNumbersResponse
		println('CSIVA :::'+body)		
		def mappingData = exchange.properties.mappingData
		mappingData.telephoneNumber = body?.ResultSet?.availableNumber?.text()
		executionContext.put("mappingData", mappingData)
		exchange.properties.put('executionContext',executionContext)
		removeKeysWithoutValues(mappingData)
		addTransactionHistory(exchange,null)
		println('iatnTransformation.processResponse --> Exiting')
//		return mappingData;
	}
	

}
