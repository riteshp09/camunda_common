package com.att.oce.bpm.utility

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.common.WirelineTransformationService;

import groovy.json.JsonSlurper
import org.apache.camel.Exchange
import org.json.JSONObject
import org.springframework.stereotype.Component
import com.att.oce.bpm.utility.OrderUtility
import com.att.oce.bpm.common.WirelineConstants

@Component('voipFunctions')
class VoipFunctions /*extends WirelineTransformationService*/ {



	/*
	 * This function will do the transformation for ATG Create Order service
	 * @param exchange of type Camel Exchange
	 * */
	public static def isVOIPOrderExists(def Order){
		def isVoipExist = false
		def groupList=Order.Groups?.Group
		println(groupList)
		
		isVoipExist = groupList.GroupCharacteristics?.LoSGCharacteristics?.any{losg -> losg?.LoSGType in [WirelineConstants.LoSGType_NEW,WirelineConstants.LOSGTYPE_CHANGE,WirelineConstants.LOSGTYPE_NO_CHANGE] && losg?.ProductCategory == WirelineConstants.PRODUCTCATEGORY_VOIP} 
		return isVoipExist

	}

	public static def getVOIPLineCountInOrder(def Order){
		if(isVOIPOrderExists(Order)){
			def groupList=Order.Groups?.Group
			def VOIPCount=0
			for(def i=0;i<groupList?.size();i++){
				def groupMap=groupList?.get(i)

				if((groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == WirelineConstants.LoSGType_NEW
				|| groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == WirelineConstants.LOSGTYPE_CHANGE
				|| groupMap?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType == WirelineConstants.LOSGTYPE_NO_CHANGE)
				&& (groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == WirelineConstants.PRODUCTCATEGORY_VOIP)){
					VOIPCount++
				}
			}
			return VOIPCount
		}
	}

	public static def getVoipPrimaryGrpRef(def Order){

		def groupList=Order.Groups?.Group
		def GroupPrimId

		for(def i=0;i<groupList?.size();i++){
			def groupMap=groupList?.get(i)
			if(groupMap?.GroupCharacteristics?.LoSGCharacteristics!= null){
				if(groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == WirelineConstants.PRODUCTCATEGORY_VOIP
				&& groupMap?.GroupCharacteristics?.LoSGCharacteristics?.IsPrimary){
					GroupPrimId = groupMap?.Id
				}
			}
		}
		return GroupPrimId

	}

	public static def getVoipAdditionalGrpRef(def Order){

		def groupList=Order.Groups?.Group
		def GroupAddId

		for(def i=0;i<groupList?.size();i++){
			def groupMap=groupList?.get(i)
			if(groupMap?.GroupCharacteristics?.LoSGCharacteristics!= null){
				if(groupMap?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory == WirelineConstants.PRODUCTCATEGORY_VOIP
				&& !groupMap?.GroupCharacteristics?.LoSGCharacteristics.IsPrimary){
					GroupAddId=groupMap?.Id
				}
			}
		}
		return GroupAddId
	}



}



