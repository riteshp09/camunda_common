package com.att.oce.transformation

import com.att.oce.bpm.common.WirelineTransformationService
import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.common.WirelineConstants;
import com.att.oce.bpm.common.util.ErrorBean
import org.camunda.bpm.engine.delegate.BpmnError
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.error.OceErrorHandler
import com.att.oce.config.components.GlobalProperties
import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import com.att.oce.bpm.utility.OrderUtility
import java.text.SimpleDateFormat
import groovy.time.TimeCategory
import java.util.Calendar;
import java.util.Date;
import org.joda.time.DateTime;

@Component('inquireUnifiedServiceAppointmentsTransformation')
class InquireUnifiedServiceAppointmentsTransformation extends WirelineTransformationService {

	String url;
	static Logger log = LoggerFactory.getLogger(InquireUnifiedServiceAppointmentsTransformation.class)

	@Override String getApiName(){
		return 'InquireUnifiedServiceAppointments';
	}

	public String getApiUrn() {
		return "urn:csi:services:oms:InquireUnifiedServiceAppointments.jws";
	}

	/*Check Product Type of Standalone Order*/
	def checkforStandaloneProduct(def order)
	{
		boolean standaloneOrder = OrderUtility.checkforStandaloneOrder(order)
		def losgs = new ArrayList()
		def productCategory = new ArrayList()
		def losgType = new ArrayList()
		losgs = OrderUtility.getLosgsFromOrder(order)
		productCategory = losgs?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
		losgType = losgs?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
		def uverseLosgsCount=0
		def dtvLosgsCount=0
		def productType

		if(standaloneOrder)
		{
			if(losgType.contains(WirelineConstants.LOSGTYPE_NEW) && (productCategory.contains(WirelineConstants.PRODUCTCATEGORY_INTERNET) ||
			productCategory.contains(WirelineConstants.PRODUCTCATEGORY_IPTV) || productCategory.contains(WirelineConstants.PRODUCTCATEGORY_VOIP)))
			{
				uverseLosgsCount++
			}
			if(losgType.contains(WirelineConstants.LOSGTYPE_NEW) && productCategory.contains(WirelineConstants.PRODUCTCATEGORY_DTV) )
			{
				dtvLosgsCount++
			}
		}
		if(uverseLosgsCount>0)
		{
			productType = WirelineConstants.PRODUCT_TYPE_UVERSE
		}
		else if(dtvLosgsCount>0)
		{
			productType = WirelineConstants.PRODUCT_TYPE_DTV
		}
		return productType
	}

	/*	This function will return all the  Offer Id's in the payload under package group */	
	def getOfferIds(order)
	{
		def groupList = order.Groups.Group
		def codes = new ArrayList()
		for(def i=0;i<groupList.size();i++)
		{
			def groupMap=groupList.get(i)
			if(groupMap?.Type == "PACKAGE" )
			{
				if(groupMap?.GroupCharacteristics?.PackageCharacteristics?.Category=="OFFER")
				{
					codes.add(groupMap?.GroupCharacteristics?.PackageCharacteristics?.Code)
				}
			}
		}
		return codes
	}

	public void transform(Exchange exchange){
		println ('InquireUnifiedServiceAppointmentsTransformation.transform')
		int index = 0
		exchange.properties.order = exchange.in.body.order
		exchange.properties.executionContext  = exchange.in.body.executionContext
		def order = exchange.properties.order
		def executionContext = exchange.properties.executionContext

		/*IUSPDResponse variable is the response from IUSPD API*/
		//def xmlPayload = new File("D:/rk00330305/ATT/1705release/camunda_entertainment_group/wireline-eg/wireline-eg-bpmn/src/test/resources/data/IUSPDResponse.xml").text
		def iuspdResponse = executionContext.iuspdResp
		def slurper = new XmlSlurper()
		def IUSPDResponse = slurper.parseText(iuspdResponse)
		def iuspdRes = IUSPDResponse.Body.InquireUnifiedServiceProductDetailsResponse

		def dtvChange
		def uverseChange
		def dtvNew
		def uverseNew
		def dispatchType = OrderUtility.dispatchType(order)
		def offerIds = new ArrayList()
		offerIds = getOfferIds(order)
		def uverseOfferId
		if(offerIds.contains(WirelineConstants.OFFERID_UVERSE))
		{
			uverseOfferId = WirelineConstants.OFFERID_UVERSE
		}
		else
		{
			uverseOfferId = null
		}
		def dtvOfferId
		if(offerIds.contains(WirelineConstants.OFFERID_DTV))
		{
			dtvOfferId = WirelineConstants.OFFERID_DTV
		}
		else
		{
			dtvOfferId = null
		}

		List<String> ProductType = new ArrayList<String>();
		ProductType.add(checkforStandaloneProduct(order))
		ProductType.add(OrderUtility.determineUverseOrder(order))
		ProductType.add(OrderUtility.determineDTVOrder(order))

		List<String> losgtypes = new ArrayList<String>();
		List<String> prodcats = new ArrayList<String>();
		def losgs = new ArrayList()
		losgs = OrderUtility.getLosgsFromOrder(order)
		losgtypes = losgs?.GroupCharacteristics?.LoSGCharacteristics?.LoSGType
		prodcats = losgs?.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
		def uverseAcc = OrderUtility.getUverseAcount(order)
		exchange.properties.referenceId = uverseAcc.Id

		if(losgtypes && prodcats)
		{
			if(prodcats.contains(WirelineConstants.PRODUCTCATEGORY_DTV) && losgtypes.contains(WirelineConstants.LOSGTYPE_CHANGE) &&
			(dispatchType==WirelineConstants.DISPATCH_SINGLE || ProductType.contains(WirelineConstants.PRODUCT_TYPE_DTV)) )
			{
				def productId = iuspdRes?.UnifiedServiceProductDetails?.AssignedProducts.findAll{a-> a?.ProductConfiguration?.productOfferingId==dtvOfferId}.collect{it?.ProductConfiguration?.productId}.flatten().minus(null)
				dtvChange = productId[index]
			}

			if((losgtypes.contains(WirelineConstants.LOSGTYPE_CHANGE) || losgtypes.contains(WirelineConstants.LOSGSTATUS_NO_CHANGE) || (uverseAcc.AccountSubCategory==WirelineConstants.ACCOUNTSUBCATEGORY_EXISTING) ) &&
			(prodcats.contains(WirelineConstants.PRODUCTCATEGORY_INTERNET) || prodcats.contains(WirelineConstants.PRODUCTCATEGORY_VOIP) || prodcats.contains(WirelineConstants.PRODUCTCATEGORY_IPTV) ) &&
			(dispatchType==WirelineConstants.DISPATCH_SINGLE || ProductType.contains(WirelineConstants.PRODUCT_TYPE_UVERSE)) )
			{
				def productId = iuspdRes?.UnifiedServiceProductDetails?.AssignedProducts.findAll{a-> a?.ProductConfiguration?.productOfferingId==uverseOfferId}.collect{it?.ProductConfiguration.productId}.flatten().minus(null)
				uverseChange = productId[index]
			}

			if(prodcats.contains(WirelineConstants.PRODUCTCATEGORY_DTV) && losgtypes.contains(WirelineConstants.LOSGTYPE_NEW) &&
			(dispatchType==WirelineConstants.DISPATCH_SINGLE || ProductType.contains(WirelineConstants.PRODUCT_TYPE_DTV)))
			{
				dtvNew = dtvOfferId
			}

			if((!(losgtypes.contains(WirelineConstants.LOSGTYPE_CHANGE) || losgtypes.contains(WirelineConstants.LOSGSTATUS_NO_CHANGE) ) || losgtypes.contains(WirelineConstants.LOSGTYPE_NEW) ) &&
			(prodcats.contains(WirelineConstants.PRODUCTCATEGORY_INTERNET) || prodcats.contains(WirelineConstants.PRODUCTCATEGORY_VOIP) || prodcats.contains(WirelineConstants.PRODUCTCATEGORY_IPTV) ) &&
			(dispatchType==WirelineConstants.DISPATCH_SINGLE || ProductType.contains(WirelineConstants.PRODUCT_TYPE_UVERSE)) )
			{
				uverseNew = uverseOfferId
			}
		}


		def nameRefs = order.SchedulingInfos?.SchedulingInfo?.NameRef ? order.SchedulingInfos?.SchedulingInfo?.NameRef : OrderUtility.getUverseAcount(order)?.BillingInfo?.NameRef
		def scheduleName = order.Names.Name.find{name -> name.Id in nameRefs}
		
		def msgHeader = createUnifiedMessageHeader(order,executionContext.conversationId)
		def iusappRequest = [
			messageHeader : msgHeader,
			InquireUnifiedServiceAppointmentsRequest : [
				OrderingContext : [
					salesChannel : WirelineConstants.SALES_CHANNEL,
					applicationId : WirelineConstants.APPLICATION_ID
				],
				AvailableAppointmentsDetails : [
					Contact : [
						method : order?.OrderContact?.PreferredContactMethod,
						lastName : scheduleName?.FirstName,
						firstName : scheduleName?.LastName,
						email : order?.OrderContact?.PrimaryEmailAddress,
						phoneType : scheduleName?.PrimaryContactPhone[index]?.ContactPhoneType,
						phoneNumber : scheduleName?.PrimaryContactPhone[index]?.PhoneNumber,
						alternatePhoneType : (scheduleName?.AdditionalContactPhone) ? scheduleName?.AdditionalContactPhone[index]?.ContactPhoneType : null,
						alternatePhoneNumber : (scheduleName?.AdditionalContactPhone) ? scheduleName?.AdditionalContactPhone[index]?.PhoneNumber : null
					],
					OrderAction : [
						shipToType : WirelineConstants.SHIP_TO_TYPE
					],
					assignedProductId : dtvChange,
					assignedProductId1 : uverseChange,
					productOfferingId : dtvNew,
					productOfferingId1 : uverseNew
				]
			]
		]
		exchange.out.body = iusappRequest
		log.debug("Request formed"+iusappRequest)
		setCSIHttpHeaders(exchange)
		exchange.out.headers.put("CamelHttpUri", resolveURN(getApiUrn(), url))
		exchange.properties.put("OceCSIApiName", getApiName())
		log.debug('InquireUnifiedServiceAppointmentsTransformation.transform done')
	}

	public void processResponse(Exchange exchange) throws APIFailedException {
		log.debug('InquireUnifiedServiceAppointmentsTransformation.processResponse')
		def order = exchange.properties.order
		def executionContext = exchange.properties.executionContext
		def iusappResponseXml = new XmlSlurper().parseText(exchange.in.body)
		def iusappResponse = iusappResponseXml.Body.InquireUnifiedServiceAppointmentsResponse
		executionContext.put("iusappResponse", exchange.in.body)
		
		log.debug(exchange.in.body)
		if (iusappResponseXml.Body.Fault.size() > 0){
			def apie = new APIFailedException(
					api : getApiName(),
					code : iusappResponseXml.Body.Fault?.detail?.CSIApplicationException?.Response.code,
					codeDescription : iusappResponseXml.Body.Fault?.detail?.CSIApplicationException?.Response.description,
					subCode : iusappResponseXml.Body.Fault?.detail?.CSIApplicationException?.ServiceProviderEntity?.ServiceProviderRawError.code,
					subCodeDescription : iusappResponseXml.Body.Fault?.detail?.CSIApplicationException?.ServiceProviderEntity?.ServiceProviderRawError.description
					)
			addTransactionHistory(exchange,apie)
			exchange.out.body = order
			throw apie
		}
		addTransactionHistory(exchange,null)
		Map<String,Object>iusappUpdatedOrder = updateOrder(order, iusappResponse, executionContext)
		log.debug("updated Order is"+iusappUpdatedOrder);
		exchange.in.body = iusappUpdatedOrder

		if(executionContext?.Appointments == null){
			def uverseAcc = OrderUtility.getUverseAcount(order)
			List<ErrorBean> errList = new ArrayList<ErrorBean>();
			errList.add(new ErrorBean('ER000001','AppointmentNotFound'))
			OrderUtility.updateErrorList(order,executionContext,errList,'IN_QUEUE','IUSAP_FAIL', uverseAcc?.Id)
			
			throw new BpmnError("APP001");
		}

		//return exchange.in.body
	}

	def mapUverse(def IUSPDRes)
	{
		def var
		if(IUSPDRes?.UnifiedServiceProductDetails?.ProductsInNewOffer?.productOfferingId == WirelineConstants.OFFERID_UVERSE ||
		IUSPDRes?.UnifiedServiceProductDetails?.AssignedProducts?.ProductConfiguration?.productOfferingId == WirelineConstants.OFFERID_UVERSE)
		{
			var = true
		}
		else
		{
			var = false
		}
		return var
	}

	def mapDTV(def IUSPDRes)
	{
		def var
		if(IUSPDRes?.UnifiedServiceProductDetails?.ProductsInNewOffer?.productOfferingId == WirelineConstants.OFFERID_DTV ||
		IUSPDRes?.UnifiedServiceProductDetails?.AssignedProducts?.ProductConfiguration?.productOfferingId == WirelineConstants.OFFERID_DTV)
		{
			var = true
		}
		else
		{
			var = false
		}
		return var
	}

	def getSchedulingInfoRef(def order, def ProductType)
	{
		def schedulingRef

		if(OrderUtility.dispatchType(order) == WirelineConstants.DISPATCH_SINGLE)
		{
			schedulingRef = order?.SchedulingInfos?.SchedulingInfo?.Id
		}
		else
		{
			def groupList=order.Groups.Group
			if(ProductType.contains(WirelineConstants.PRODUCT_TYPE_UVERSE))
			{
				schedulingRef  = groupList?.GroupCharacteristics?.LoSGCharacteristics.findAll {a -> a?.ProductCategory==WirelineConstants.PRODUCTCATEGORY_IPTV || a?.ProductCategory==WirelineConstants.PRODUCTCATEGORY_INTERNET || a?.ProductCategory==WirelineConstants.PRODUCTCATEGORY_VOIP}.collect{it?.SchedulingInfoRef}.flatten().minus(null)
			}
			else if(ProductType.contains(WirelineConstants.PRODUCT_TYPE_DTV))
			{
				schedulingRef  = groupList?.GroupCharacteristics?.LoSGCharacteristics.findAll {a -> a?.ProductCategory==WirelineConstants.PRODUCTCATEGORY_DTV}.collect{it?.SchedulingInfoRef}.flatten().minus(null)
			}
		}

		return schedulingRef
	}

	def isAppointmentMatchFoundinIUSAPResp(def order, def iusappResponse, def ProductType)
	{
		int index = 0
		def schedulingRef = getSchedulingInfoRef(order, ProductType)
		def installationType = order?.SchedulingInfos?.SchedulingInfo.findAll{a -> a?.Id==schedulingRef[0]}.collect{it?.InstallType}.flatten().minus(null)
		def appointmentsList=iusappResponse?.AvailableAppointmentsDetails?.ProductAvailableAppointments?.Appointments
		def appointmentsCount=appointmentsList.size();
		def startCalendarDate=iusappResponse?.AvailableAppointmentsDetails?.ProductAvailableAppointments?.startCalendarDate.text()
		def calenderType = iusappResponse?.AvailableAppointmentsDetails?.ProductAvailableAppointments?.calendarType.text()
		def result
		if( (appointmentsCount>0 && appointmentsList[index].availableStartTime) || startCalendarDate)
		{
			if(installationType[index] == WirelineConstants.TYPE_TECH)
			{
				if(installationType[index]==calenderType)
				{
					result = determineFMOAppointmentStartDate(order, iusappResponse, ProductType)
				}
			}
			else
			{
				result = determineFMOAppointmentStartDate(order, iusappResponse, ProductType)
			}

		}
		println("isAppointmentMatchFoundinIUSAPResp"+result)
		return result
	}

	def determineFMOAppointmentStartDate(def order, def iusappResponse, def ProductType)
	{
		def calenderType = iusappResponse.AvailableAppointmentsDetails?.ProductAvailableAppointments?.calendarType.text()
		def schedulingRef
		def groupList=order.Groups.Group
		def nextDate

		if(ProductType.contains(WirelineConstants.PRODUCT_TYPE_UVERSE))
		{
			schedulingRef = groupList?.GroupCharacteristics?.LoSGCharacteristics.findAll {a -> a?.ProductCategory==WirelineConstants.PRODUCTCATEGORY_IPTV || a?.ProductCategory==WirelineConstants.PRODUCTCATEGORY_INTERNET || a?.ProductCategory==WirelineConstants.PRODUCTCATEGORY_VOIP}.collect{it?.SchedulingInfoRef}.flatten().minus(null)
		}
		else if(ProductType.contains(WirelineConstants.PRODUCT_TYPE_DTV))
		{
			schedulingRef = groupList?.GroupCharacteristics?.LoSGCharacteristics.findAll {a -> a?.ProductCategory==WirelineConstants.PRODUCTCATEGORY_DTV}.collect{it?.SchedulingInfoRef}
		}

		def schedulingInfos = order?.SchedulingInfos?.SchedulingInfo.findAll {a-> a?.Id==schedulingRef[0]}
		def scheduleByDayAndTime = schedulingInfos?.ScheduleByDayAndTime

		if(calenderType==WirelineConstants.TYPE_TECH)
		{
			if(order?.SchedulingInfos?.SchedulingInfo && order?.SchedulingInfos?.SchedulingInfo?.ScheduleAsSoonAsPossible && order?.SchedulingInfos?.SchedulingInfo?.ScheduleAsSoonAsPossible==true)
			{
				nextDate = determineNextAvailableDate(order, iusappResponse, "true")
			}
			else
			{
				if(scheduleByDayAndTime?.AnyDayOfTheWeek)
				{
					def timeSlot = scheduleByDayAndTime?.AnyDayOfTheWeek
					nextDate = determineNxtAvailableDateForAnyDayParentfunction(order, iusappResponse, "true", timeSlot)
				}
				else
				{
					if(scheduleByDayAndTime?.Monday)
					{
						def timeSlot = scheduleByDayAndTime?.Monday
						nextDate = determineNxtAvailableDateUsingDayParentfunction(order, iusappResponse, "true", timeSlot, "2")
					}
					else
					{
						if(scheduleByDayAndTime?.Tuesday)
						{
							def timeSlot = scheduleByDayAndTime?.Tuesday
							nextDate = determineNxtAvailableDateUsingDayParentfunction(order, iusappResponse, "true", timeSlot, "3")
						}
						else
						{
							if(scheduleByDayAndTime?.Wednesday)
							{
								def timeSlot = scheduleByDayAndTime?.Wednesday
								nextDate = determineNxtAvailableDateUsingDayParentfunction(order, iusappResponse, "true", timeSlot, "4")
							}
							else
							{
								if(scheduleByDayAndTime?.Thursday)
								{
									def timeSlot = scheduleByDayAndTime?.Thursday
									nextDate = determineNxtAvailableDateUsingDayParentfunction(order, iusappResponse, "true", timeSlot, "5")
								}
								else
								{
									if(scheduleByDayAndTime?.Friday)
									{
										def timeSlot = scheduleByDayAndTime?.Friday
										nextDate = determineNxtAvailableDateUsingDayParentfunction(order, iusappResponse, "true", timeSlot, "6")
									}
									else
									{
										if(scheduleByDayAndTime?.Saturday)
										{
											def timeSlot = scheduleByDayAndTime?.Saturday
											nextDate = determineNxtAvailableDateUsingDayParentfunction(order, iusappResponse, "true", timeSlot, "7")
										}
										else
										{
											if(scheduleByDayAndTime?.Sunday)
											{
												def timeSlot = scheduleByDayAndTime?.Sunday
												nextDate = determineNxtAvailableDateUsingDayParentfunction(order, iusappResponse, "true", timeSlot, "1")
											}
											else
											{
												if(!schedulingInfos?.ActualSchedule==null && schedulingInfos?.ActualSchedule)
												{
													nextDate = determineActualAppointmentDate(order, iusappResponse)
												}
												else
												{
													nextDate = determineNextAvailableDate(order, iusappResponse, "true")
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		else
		{
			if(!(iusappResponse.AvailableAppointmentsDetails?.ProductAvailableAppointments?.startCalendarDate)==null)
			{
				nextDate = (iusappResponse.AvailableAppointmentsDetails?.ProductAvailableAppointments?.startCalendarDate.substring(0,10)+"T00:00:00").join()
			}
		}
		println("determineFMOAppointmentStartDate"+nextDate)
		return nextDate.toString()
	}

	def determineNextAvailableDate(def order, def iusappResponse, def bufferOn)
	{
		int timeBuffer
		def appointmentDates = new ArrayList()
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd")
		def dates = iusappResponse.AvailableAppointmentsDetails?.ProductAvailableAppointments
		def firstAppointmentDate

		if( bufferOn=="true" )
		{
			timeBuffer = 24
		}
		else
		{
			timeBuffer = 0
		}

		if(bufferOn == "true")
		{
			for(def startDate in dates?.Appointments)
			{
				def submittedDate =  order.SubmitedDate
				String ast = startDate?.availableStartTime
				DateTime astdt = new DateTime(ast)
				DateTime dt = new DateTime(submittedDate)
				DateTime sdt = dt.plusHours(timeBuffer)

				if(astdt.toString() > sdt.toString())
				{
					appointmentDates.add(astdt)
				}
			}
		}
		else
		{
			for(def startDate in dates?.Appointments)
			{
				Date date = new Date(startDate?.availableStartTime)
				if(sdf(startDate?.availableStartTime) >= (sdf(order?.SubmitedDate)) )
				{
					appointmentDates.add(date)
				}
			}
		}
		firstAppointmentDate = appointmentDates?.reverse().last()
		println("determineNextAvailableDate"+firstAppointmentDate.toString())
		return firstAppointmentDate.toString()
	}

	def determineNxtAvailableDateForAnyDayParentfunction(def order, def iusappResponse, def bufferOn, def timeSlot)
	{
		def timeSlotFormatCheck
		def startDate
		def tempStartDate
		def finalStartDate

		if(timeSlot=="AM" || timeSlot=="PM" || timeSlot=="ALL_DAY" || timeSlot=="AM_PM" )
		{
			timeSlotFormatCheck = true
		}
		else
		{
			timeSlotFormatCheck = false
		}
		startDate = determineNxtAvailableDateForAnyDay(order, iusappResponse, bufferOn, timeSlot)
		if(!startDate==null)
		{
			tempStartDate = startDate
		}
		else
		{
			if(timeSlotFormatCheck)
			{
				if(timeSlot=="AM")
				{
					tempStartDate = determineNxtAvailableDateForAnyDay(order, iusappResponse, bufferOn, "PM")
				}
				else if(timeSlot=="PM")
				{
					tempStartDate = determineNxtAvailableDateForAnyDay(order, iusappResponse, bufferOn, "AM")
				}
				else
				{
					tempStartDate = startDate
				}
			}
			else
			{
				tempStartDate = startDate
			}
		}
		if(!tempStartDate==null)
		{
			finalStartDate = tempStartDate
		}
		else
		{
			finalStartDate = determineNextAvailableDate(order, iusappResponse, bufferOn)
		}
		println("determineNxtAvailableDateForAnyDayParentfunction"+finalStartDate.toString())
		return finalStartDate.toString()
	}

	def determineNxtAvailableDateForAnyDay(def order, def iusappResponse, def bufferOn, def timeSlot)
	{
		def timeSlotFormatCheck
		int timeBuffer
		def appointmentDates = new ArrayList()
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd")
		def dates = iusappResponse.AvailableAppointmentsDetails?.ProductAvailableAppointments
		def startDuration
		def endDuration
		def result

		if( bufferOn=="true" )
		{
			timeBuffer = 24
		}
		else
		{
			timeBuffer = 0
		}

		if(timeSlot=="AM" || timeSlot=="PM" || timeSlot=="ALL_DAY" || timeSlot=="AM_PM" )
		{
			timeSlotFormatCheck = true
		}

		if(timeSlotFormatCheck)
		{
			startDuration = ""
			endDuration = ""
		}
		else
		{
			startDuration = convert12hrto24hr(timeSlot)
			endDuration = convert12hrto24hr(timeSlot)
		}
		for(def startDate in dates.Appointments)
		{
			def submittedDate =  order?.SubmitedDate
			String ast = startDate?.availableStartTime
			DateTime astdt = new DateTime(ast)
			DateTime dt = new DateTime(submittedDate)
			DateTime sdt = dt.plusHours(timeBuffer)
			if(astdt.toString() > sdt.toString())
			{
				if(timeSlotFormatCheck==true)
				{
					def nextDate = determineNxtAvailableAppoinmentDateUsingDayType1(ast, timeSlot)
					appointmentDates.add(nextDate)
				}
				else
				{
					if((ast.substring(11,13))==startDuration && (startDate?.availableEndTime.substring(11,13))==endDuration)
					{
						appointmentDates.add(astdt)
					}
				}
			}
		}
		result = appointmentDates.reverse().last()
		println("determineNxtAvailableDateForAnyDay"+result.toString())
		return result.toString()
	}

	def determineNxtAvailableAppoinmentDateUsingDayType1(def date, def timeSlot)
	{
		def result
		def appointmentDate = date.substring(11,13)

		if(timeSlot == "AM")
		{
			if(appointmentDate < "12")
			{
				result = date
			}
		}
		else
		{
			if(timeSlot == "PM")
			{
				if(appointmentDate >= "12")
				{
					result = date
				}
			}
			else
			{
				result = date
			}
		}
		println("determineNxtAvailableAppoinmentDateUsingDayType1"+result.toString())
		return result.toString()
	}

	def determineNxtAvailableDateUsingDayParentfunction(def order, def iusappResponse, def bufferOn, def timeSlot, def day)
	{
		def timeSlotFormatCheck
		def endDate
		def tempStartDate
		def finalStartDate
		def result

		if(timeSlot=="AM" || timeSlot=="PM" || timeSlot=="ALL_DAY" || timeSlot=="AM_PM")
		{
			timeSlotFormatCheck = true
		}
		def startDate = determineNxtAvailableDateUsingDay(order, iusappResponse, bufferOn, timeSlot, day)
		if(startDate)
		{
			tempStartDate = startDate
		}
		else
		{
			if(timeSlotFormatCheck)
			{
				if(timeSlot == "AM")
				{
					tempStartDate = determineNxtAvailableDateUsingDay(order, iusappResponse, bufferOn, "PM", day)
				}
				else if(timeSlot == "AM")
				{
					tempStartDate = determineNxtAvailableDateUsingDay(order, iusappResponse, bufferOn, "AM", day)
				}
				else
				{
					tempStartDate = startDate
				}
			}
			else
			{
				tempStartDate = startDate
			}
		}
		if(tempStartDate)
		{
			finalStartDate = tempStartDate
		}
		else
		{
			finalStartDate = determineNextAvailableDate(order, iusappResponse, bufferOn)
		}
		println("determineNxtAvailableDateUsingDayParentfunction"+finalStartDate.toString())
		return finalStartDate.toString()
	}

	def determineNxtAvailableDateUsingDay(def order, def iusappResponse, def bufferOn, def timeSlot, def day)
	{
		def timeBuffer
		def timeSlotFormatCheck
		def startDuration
		def endDuration
		def appointmentDates = new ArrayList()
		def dates = iusappResponse.AvailableAppointmentsDetails?.ProductAvailableAppointments
		def result

		if(bufferOn=="true")
		{
			timeBuffer = 24
		}
		else
		{
			timeBuffer = 0
		}
		if(timeSlot=="AM" || timeSlot=="PM" || timeSlot=="ALL_DAY" || timeSlot=="AM_PM")
		{
			timeSlotFormatCheck = true
		}
		if(timeSlotFormatCheck)
		{
			startDuration = ""
			endDuration = ""
		}
		else
		{
			startDuration = convert12hrto24hr(timeSlot)
			endDuration = convert12hrto24hr(timeSlot)
		}

		for(def startDate in dates.Appointments)
		{
			def submittedDate =  order?.SubmitedDate
			String ast = startDate?.availableStartTime
			DateTime astdt = new DateTime(ast)
			DateTime dt = new DateTime(submittedDate)
			DateTime sdt = dt.plusHours(timeBuffer)

			if(astdt.toString() > sdt.toString())
			{
				def dayofweek = determineDayOfWeek(ast)
				if(dayofweek == day)
				{
					if(timeSlotFormatCheck)
					{
						def nextDate = determineNxtAvailableAppoinmentDateUsingDayType1(ast, timeSlot)
						appointmentDates.add(nextDate)
					}
					else
					{
						if((ast.substring(11,13))==startDuration && (startDate.availableEndTime.substring(11,13))==endDuration)
						{
							appointmentDates.add(astdt)
						}
					}
				}
			}
		}
		result = appointmentDates?.reverse().last()
		println("determineNxtAvailableDateUsingDay"+result.toString())
		return result.toString()
	}

	def determineDayOfWeek(def startDate)
	{
		String appointment = startDate.substring(0,10)
		SimpleDateFormat regularDateFormat = new SimpleDateFormat("yyyy-MM-dd")
		Date date = regularDateFormat.parse(appointment)
		Calendar calendar = Calendar.getInstance()
		calendar.setTime(date)
		println("day of week: " + calendar.get(Calendar.DAY_OF_WEEK))
		def result = calendar.get(Calendar.DAY_OF_WEEK).toString()
		return result
	}

	def convert12hrto24hr(String time)
	{
		String timeSlot
		String hoursin24
		String result
		if(time.length()==3)
		{
			timeSlot = "0"+time
		}
		else
		{
			if(time.length()>4)
			{
				if((time.replace(" ", "").substring(0,time.indexOf(':')).length()) == 2)
				{
					timeSlot = time.replace(" ", "")
				}
				else
				{
					timeSlot = "0"+time.replace(" ", "")
				}
			}
			else
			{
				timeSlot = time
			}
		}
		if(timeSlot.contains("AM"))
		{
			if(timeSlot.substring(0,2) == "12")
			{
				hoursin24 = "00"
			}
			else
			{
				hoursin24 = timeSlot.substring(0,2)
			}
		}
		else
		{
			if(timeSlot.substring(0,2) == "12")
			{
				hoursin24 = "12"
			}
			else
			{
				int value = 12
				int timeS = timeSlot.substring(0,2).toInteger()
				hoursin24 = value+timeS
			}
		}
		if(time.length()>4)
		{
			result = hoursin24+":"+timeSlot.substring(3,5)
		}
		else
		{
			result = hoursin24
		}
		println("convert12hrto24hr"+result.toString())
		return result.toString()
	}

	def converttodatetime(def variable)
	{
		String var = variable
		DateTime result = new DateTime(var)
		return result
	}

	def determineActualAppointmentDate(def order, def iusappResponse)
	{
		def result
		int bufferTime = 720
		def groupList=order.Groups.Group
		def schedulingInfoList=order?.SchedulingInfos?.SchedulingInfo
		def schedulingRef  = groupList?.GroupCharacteristics?.LoSGCharacteristics.findAll {a -> a?.ProductCategory==WirelineConstants.PRODUCTCATEGORY_IPTV || a?.ProductCategory==WirelineConstants.PRODUCTCATEGORY_INTERNET || a?.ProductCategory==WirelineConstants.PRODUCTCATEGORY_VOIP}.collect{it?.SchedulingInfoRef}.flatten().minus(null)
		def actualSchedule =  schedulingInfoList?.findAll {a -> a?.Id==schedulingRef[0]}.collect{it?.ActualSchedule}.flatten().minus(null)
		def appointmentStartDuration = convert12hrto24hr(actualSchedule?.StartTime)
		def appointmentEndDuration = convert12hrto24hr(actualSchedule?.EndTime)
		def appointmentStartDate = actualSchedule?.SelectedAppointmentDate+"T"+appointmentStartDuration+":00"
		String startDate = appointmentStartDate?.join()
		def appointmentEndDate = actualSchedule?.SelectedAppointmentDate+"T"+appointmentEndDuration+":00"
		String endDate = appointmentEndDate?.join()
		def appointments = iusappResponse.AvailableAppointmentsDetails?.ProductAvailableAppointments?.Appointments

		if(converttodatetime(appointments[0]?.availableStartTime)==converttodatetime(startDate) && converttodatetime(appointments[0]?.availableEndTime)==converttodatetime(endDate))
		{
			result = startDate
		}
		else
		{
			for(def date in appointments)
			{
				DateTime dt = converttodatetime(startDate)
				DateTime ast = dt.plusHours(bufferTime)
				if(converttodatetime(date?.availableStartTime) > dt && converttodatetime(date?.availableStartTime) <= ast)
				{
					if((date?.availableStartTime.substring(11,19) == (appointmentStartDuration+":00").join()) && (date?.availableEndTime.substring(11,19) == (appointmentEndDate+":00").join() ) )
					{
						result = date?.availableStartTime
					}
				}
			}
		}
		println("determineActualAppointmentDate"+result.toString())
		return result.toString()
	}

	def constructAppointmentInfo(def offerId, def startDateTime, def endDateTime, def calenderType, def comment, def context)
	{
		def startDate = startDateTime.substring(0, startDateTime.indexOf('T'))
		def startTime = startDateTime.substring(11, 19)
		def endTime = endDateTime.substring(11, 19)
		def App =
				[
					"SelectedAppointmentDate": startDate,
					"SelectedAppointmentTime": startTime,
					"StartTime": startTime,
					"EndTime": endTime,
					"ProductOfferingId": offerId,
					"CalenderType": calenderType,
					"appointmentComments": comment
				]

		if(context?.Appointments!=null){
			def Apps = context?.Appointments
			def Appointments = [Apps]
			for(def i=0;i<Apps.size();i++){
				Appointments.add(App)
			}
			context.put("Appointments", Appointments)
		}
		else{
			def Appointments = new ArrayList()
			Appointments.add(App)
			context.put("Appointments", Appointments)
		}
	}

	def updateOrder(def order, def iusappResponse, def executionContext){
		log.debug('InquireUnifiedServiceAppointmentsTransformation.updateOrder')

		def dispatchType= OrderUtility.dispatchType(order)
		List<String> ProductType = new ArrayList<String>();
		ProductType.add(checkforStandaloneProduct(order))
		ProductType.add(OrderUtility.determineUverseOrder(order))
		ProductType.add(OrderUtility.determineDTVOrder(order))
		def schedulingInfoList=order?.SchedulingInfos?.SchedulingInfo
		def schedule
		def workId
		def apptMatchFound = isAppointmentMatchFoundinIUSAPResp(order,iusappResponse, ProductType)
		String startDate
		String endDate
		def productOfferingId
		def appointmentInfo

		if(apptMatchFound)
		{
			startDate = determineFMOAppointmentStartDate(order, iusappResponse, ProductType)
			def eDate = iusappResponse.AvailableAppointmentsDetails?.ProductAvailableAppointments?.Appointments.findAll{a -> a?.availableStartTime.text()==startDate }.collect{it?.availableEndTime.text()}.flatten().minus(null)
			if(eDate)
			{
				endDate = eDate
			}
			else
			{
				endDate = startDate
			}
			String calenderType = iusappResponse.AvailableAppointmentsDetails?.ProductAvailableAppointments?.calendarType.text()
			if(ProductType.contains(WirelineConstants.PRODUCT_TYPE_UVERSE))
			{
				productOfferingId = WirelineConstants.OFFERID_UVERSE
			}
			else if(ProductType.contains(WirelineConstants.PRODUCT_TYPE_DTV))
			{
				productOfferingId = WirelineConstants.OFFERID_DTV
			}
			else
			{
				productOfferingId = ""
			}

			def comment
			def schedulingInfo = schedulingInfoList.find { si -> si?.AdditionalDetails?.AdditionalDetail?.Code?.contains('InstallationBusinessName') }
			if(schedulingInfo?.AppointmentComment) {
				if(order.OrderSource.Channel == WirelineConstants.CHANNEL_SMB) {
					comment = schedulingInfoList?.AppointmentComment+'|'+schedulingInfo.AdditionalDetails?.AdditionalDetail?.flatten().find{add -> add?.Code == 'InstallationBusinessName'}?.Value
				}
				else{
					comment = schedulingInfoList?.AppointmentComment
				}
			}
			constructAppointmentInfo(productOfferingId, startDate.toString(), endDate.toString(), calenderType, comment, executionContext)
			println("******appointmentInfo*******"+executionContext.Appointments)
		}

		log.debug('InquireUnifiedServiceAppointmentsTransformation.updateOrder  done')
		return order
	}

}
