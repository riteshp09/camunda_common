package com.att.oce.bpm.utility

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.common.WirelineTransformationService;

import groovy.json.JsonSlurper
import org.apache.camel.Exchange
import org.json.JSONObject
import org.springframework.stereotype.Component
import com.att.oce.bpm.utility.OrderUtility
import com.att.oce.bpm.common.QualificationConfigConstants
import com.att.oce.bpm.common.OceConstants
import com.att.oce.bpm.common.util.ErrorBean
import com.att.oce.bpm.error.APIFailedException

@Component('wirelineUtility')
class WirelineUtility /*extends WirelineTransformationService*/ {
	
	public def handleQualificationError(order, errorList, executionContext) {
		order = assignFalloutStatus(order, errorList)
		prepeareErrorLsit(order,errorList,executionContext)
		return order
	}
	/*
	 * This function will do the transformation for ATG Create Order service
	 * @param exchange of type Camel Exchange
	 * */
	public  def assignFalloutStatus(def Order, List errorList){

		def groupList=Order.Groups.Group
		def GroupAddId
		def loSGStatus
		def QualConfig = QualificationConfigConstants.QUALIFICATION_CONFIG

		for(def i=0;i<groupList.size();i++){
			def groupMap=groupList.get(i)

			if(errorList.size() == 0) {
				groupMap.GroupCharacteristics.LoSGCharacteristics?.put("IsQualifiedForAutomation",true)
			}
			else {
				groupMap.GroupCharacteristics.LoSGCharacteristics?.put("IsQualifiedForAutomation",false)

				if(groupMap.Type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE && groupMap.GroupCharacteristics.LoSGCharacteristics?.LoSGType != "REWARDS/GIFT"){

					if(groupMap.GroupCharacteristics.LoSGCharacteristics!= null){
						if(groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType == OceConstants.LOSG_STATUS_NO_CHANGE){

						}
						else{
							if((groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType == OceConstants.LOSGTYPE_NEW
							|| groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType == OceConstants.LOSGTYPE_CHANGE)
							&& (groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory != OceConstants.PRODUCTCATEGORY_DTV))
							{
								if(errorList.contains("CheckLPMInfoExists")){
									//update transaction for latest losg status.
									def qualConfig = QualificationConfigConstants.QUALIFICATION_CONFIG.get("CheckLPMInfoExists")
									loSGStatus = [Status: qualConfig.getStatus() , SubStatus:qualConfig.getSubStatus()]
									groupMap.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",loSGStatus)
								}
								else if(errorList.contains("CheckAutopayLPMTermsConditions")){
									//update transaction for latest losg status.
									def qualConfig = QualificationConfigConstants.QUALIFICATION_CONFIG.get("CheckAutopayLPMTermsConditions")
									loSGStatus = [Status: qualConfig.getStatus() , SubStatus:qualConfig.getSubStatus()]
									groupMap.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",loSGStatus)
								}
								else if(errorList.contains("MorethanOnePaymentOptionForAutopay")){
									//update transaction for latest losg status.
									def qualConfig = QualificationConfigConstants.QUALIFICATION_CONFIG.get("MorethanOnePaymentOptionForAutopay")
									loSGStatus = [Status: qualConfig.getStatus() , SubStatus:qualConfig.getSubStatus()]
									groupMap.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",loSGStatus)
								}
								else if(errorList.contains("CheckACHDetailsExists")){
									//update transaction for latest losg status.
									def qualConfig = QualificationConfigConstants.QUALIFICATION_CONFIG.get("CheckACHDetailsExists")
									loSGStatus = [Status: qualConfig.getStatus() , SubStatus:qualConfig.getSubStatus()]
									groupMap.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",loSGStatus)
								}
								else if(errorList.contains("checkCAPMProfileName")){
									//update transaction for latest losg status.
									def qualConfig = QualificationConfigConstants.QUALIFICATION_CONFIG.get("checkCAPMProfileName")
									loSGStatus = [Status: qualConfig.getStatus() , SubStatus:qualConfig.getSubStatus()]
									groupMap.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",loSGStatus)
								}
								else if(errorList.contains("DateOfBirthExist")){
									//update transaction for latest losg status.
									def qualConfig = QualificationConfigConstants.QUALIFICATION_CONFIG.get("DateOfBirthDoesNotExist")
									loSGStatus = [Status: qualConfig.getStatus() , SubStatus:qualConfig.getSubStatus()]
									groupMap.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",loSGStatus)
								}
								else if(errorList.contains("AuthenticationQuestionExist")){
									//update transaction for latest losg status.
									def qualConfig = QualificationConfigConstants.QUALIFICATION_CONFIG.get("AuthenticationQuestionDoesNotExist")
									loSGStatus = [Status: qualConfig.getStatus() , SubStatus:qualConfig.getSubStatus()]
									groupMap.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",loSGStatus)
								}
								else
								{
									if(groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory == OceConstants.PRODUCTCATEGORY_IPTV
									|| groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory == OceConstants.PRODUCTCATEGORY_INTERNET
									|| groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory == OceConstants.PRODUCTCATEGORY_VOIP){
										loSGStatus = [Status: OceConstants.LOSG_STATUS_IN_QUEUE , SubStatus: OceConstants.LOSGSUBSTATUS_MANUAL_PROV_REQUIRED]
										// TBD for AWP and AWPP
									}
									else{
										loSGStatus = [Status: OceConstants.LOSG_STATUS_IN_QUEUE , SubStatus: OceConstants.LOSGSUBSTATUS_MANUAL_PROV_REQUIRED]

									}
									groupMap.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",loSGStatus)

								}


							}
							else if(groupMap.GroupCharacteristics.LoSGCharacteristics.ProductCategory == OceConstants.PRODUCTCATEGORY_DTV)
							{
								if(groupMap.GroupCharacteristics.LoSGCharacteristics.LoSGType == OceConstants.LOSGTYPE_UNIFY){
									loSGStatus = [Status: OceConstants.LOSG_STATUS_IN_QUEUE , SubStatus: "UNIFY_FAILED"]
									groupMap.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",loSGStatus)
								}
								else{
									//TBD single dispatch logic
								}
							}
						}
					}
				}
			}
		}
		println("Order after assignLosgStauts " + Order)
		return Order;
	}

	public def prepeareErrorLsit(def Order, List errList,executionContext) {
//		Map<List> orderErrMap = new HashMap<List>()
		List<ErrorBean> errBeanList = new ArrayList<ErrorBean>();

		for(def i=0;i<errList.size();i++) {
			def key = errList.get(i);
			def QualConfig = QualificationConfigConstants.QUALIFICATION_CONFIG.get(key);
			ErrorBean err = new ErrorBean(QualConfig.getCode(), QualConfig.getComment());
			errBeanList.add(err)
			//QualificationConfig config = QualificationConfigConstants.QUALIFICATION_CONFIG.get(key);
			/*def error = [ErrorCode:QualConfig.getCode(),ErrorDescription:QualConfig.getComment()]
			errors.add(error)*/
		}
		
		if(errBeanList.size() > 0) {
			executionContext.put("LOSGStatus", "IN_QUEUE")
			OrderUtility.updateErrorList(Order,executionContext,errBeanList,OceConstants.LOSG_STATUS_IN_QUEUE,OceConstants.LOSGSUBSTATUS_MANUAL_PROV_REQUIRED,Order.CustomerOrderNumber)
		}
		
//		orderErrMap.put("Error",errors)
//		Order.put("Errors",orderErrMap)
		
//		return Order
	}
}


