package com.att.oce.transformation;

import org.apache.camel.Exchange
import org.camunda.bpm.engine.delegate.BpmnError
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component

import com.att.oce.bpm.common.WirelineConstants;
import com.att.oce.bpm.common.WirelineTransformationService
import com.att.oce.bpm.common.util.ErrorBean;
import com.att.oce.bpm.error.APIFailedException;
import com.att.oce.bpm.utility.OrderUtility;

@Component('addWirelinePaymentTransformation') 
class AddWirelinePaymentTransformation extends WirelineTransformationService {
	
	String url;
	static Logger log = LoggerFactory.getLogger(AddWirelinePaymentTransformation.class)
	
	@Override String getApiName(){
		return 'AddWirelinePayment';
	}
	
	public boolean preCondition(order){
		log.debug('AddWirelinePayment.preCondition')
		def paymentRef = OrderUtility.getPaymentOptionForAdvancePay(order)
	
		if (paymentRef != null)
			return true
		else
			return false
	}
	
	public String getApiUrn() {
		return 'urn:csi:services:pam:AddWirelinePayment.jws';
	}
	
	public void transform(Exchange exchange){
		
		println ('AddWirelinePaymentTransformsation.transform')
		def order = exchange.in.body.order
		def executionContext = exchange.properties.executionContext
		
		exchange.properties.order = exchange.in.body.order
		def uverseAcc = OrderUtility.getUverseAcount(order)
		exchange.properties.referenceId = uverseAcc.Id
		
		def msgHeader = createCustomerCarePaymentMessageHeader((Map<String,Object>)exchange.in.body.order)
		
		//def paymentOption = exchange.in.body.AWPPaymentOptions
		def paymentOption = OrderUtility.getPaymentOptionForAdvancePay(order)
		def systemNames = WirelineConstants.AWP_SYSTEM_NAMES
		def priceTypes = WirelineConstants.AWP_PRICE_TYPES
		
		def groups = order.Groups.Group.findAll{g -> g?.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.Status != WirelineConstants.LOSG_STATUS_CANCELED}
		def paymentLineItems = order.LineItems.LineItem.findAll{l ->
								!l.GroupRefs.GroupRef.intersect(groups.Id).isEmpty() &&
								l.ProductType == WirelineConstants.PRODUCTTYPE_MISC_CHARGE &&
								systemNames.contains(l.SystemName) &&
								l.Payments.Payment.PaymentOptionRef.contains(paymentOption.Id) &&
								priceTypes.contains(l.Price.PriceType)
								}
		println('paymentLineItems' +paymentLineItems)
		
		def awpRequest = [
							messageHeader: msgHeader,
							addWirelinePaymentRequest : [
								
								sourceSystem: OrderUtility.getPaymentSourceSystem(order),
								sourceLocation: OrderUtility.getPaymentSourceLocation(order),
								sourceUser: OrderUtility.getPaymentSourceUser(order),
								paymentItems: getPaymentItems(order,paymentLineItems),
								paymentMethod: getPaymentMethod(paymentOption, paymentLineItems)
								
							]
						]
		
		exchange.properties.put('order',order)
		exchange.properties.put("referenceId",uverseAcc?.Id)
		exchange.properties.put('apiURN', getApiUrn())
		exchange.properties.put("fedIndicator",false);
		//exchange.properties.put("executionContext",executionContext )
		setAuditLogProperties(exchange,false)
		exchange.out.body = awpRequest
		setCSIHttpHeaders(exchange)
		exchange.out.headers.put("CamelHttpUri",resolveURN(getApiUrn(),null))
		exchange.properties.put("OceCSIApiName",getApiName())
			
		log.debug('AddWirelinePaymentTransformation.transform done')
	}
	
		/**
	 *
	 * @param paymentLineItems
	 * @return
	 */
	def getPaymentItems(order,paymentLineItems) {
		
		def paymentItems = []
		def paymentItemCategory
		 
		for(def lineItem:paymentLineItems) {
			
			def groupIds = lineItem.GroupRefs.GroupRef
			def accountRef = order.Groups?.Group.findAll{g -> groupIds.contains(g.Id)}.collect{it.GroupCharacteristics?.LoSGCharacteristics?.AccountRef}.flatten().minus(null)
			def account = order?.Accounts?.Account.find{acc -> accountRef.contains(acc.Id)}
			
			def market = order.Groups.Group.findAll{g -> groupIds.contains(g.Id)}.collect{it.GroupCharacteristics?.LoSGCharacteristics?.Market}.minus(null)
			def portTelephoneNumber = order.Groups.Group.findAll{g -> groupIds.contains(g.Id)}.collect{it.GroupCharacteristics?.LoSGCharacteristics?.NumberPortInfo?.PortTelephoneNumber}.minus(null)
			def paymentType
			def transactionId
			
			if(lineItem.ProductType == WirelineConstants.PRODUCTTYPE_MISC_CHARGE && 
				lineItem.SystemName == WirelineConstants.LINEITEM_SYSTEM_NAME_DEPOSIT_FEE) {
				
				paymentItemCategory = WirelineConstants.PAYMENT_ITEM_CAT_DEP
				
			}
			else {
				
				paymentItemCategory = WirelineConstants.PAYMENT_ITEM_CAT_APMT
			}
			
			if(lineItem?.ProductType == WirelineConstants.PRODUCTTYPE_MISC_CHARGE && 
				(lineItem?.SystemName == WirelineConstants.SYSTEM_ADVANCE_PAYMENT || lineItem?.SystemName == WirelineConstants.NON_REFUNDABLE_FEE)
				&& order?.CreditPolicy?.CreditPolicyTransactionId) {
				
				transactionId = order.CreditPolicy?.CreditPolicyTransactionId
			}
				
			if(lineItem.ProductType == WirelineConstants.PRODUCTTYPE_MISC_CHARGE && lineItem.SystemName == WirelineConstants.SYSTEM_ADVANCE_PAYMENT) {
				
				paymentType = WirelineConstants.PAYMENT_TYPE_ADVPMT
			}
			else if(lineItem.ProductType == WirelineConstants.PRODUCTTYPE_MISC_CHARGE && lineItem.SystemName == WirelineConstants.NON_REFUNDABLE_FEE) {
				
				paymentType = WirelineConstants.PAYMENT_TYPE_NRF
			}
			
			def paymentItem = [
								amount: lineItem.Price.Amount,
								monetaryUnit: WirelineConstants.ADD_WIRELINE_PAYMENT_MONETARYUNIT,
								paymentItemCategory: paymentItemCategory,
								submittedAccountId: account?.BillingAccountNumber,
								provider: 'CNG',
								system: 'CNG',
								systemDivision: market ? market.get(0) : null,
								invoiceNumber: lineItem?.SystemName == WirelineConstants.SYSTEM_DTV_SECURITY_FEE ? 'DTVFEES' : null,
								preAssignedServiceHandle: portTelephoneNumber ? portTelephoneNumber : null,
								transactionId: transactionId,
								paymentType: paymentType
							  ]
			
			paymentItems.add(paymentItem)
			
		}
		
		return [PaymentItems: paymentItems]
	}
	
	/**
	 *
	 */
	def getPaymentMethod(paymentOption, paymentLineItems) {
		
		def PreAuthPayment = paymentOption?.PaymentMethod?.CAPM?.PreAuthDetail
		def CAPMPayment = paymentOption?.PaymentMethod?.CAPM
		def CreditCardPayment = paymentOption?.PaymentMethod?.CreditCard
		def paymentMethod
		
		if(PreAuthPayment) {
			
			paymentMethod = [
				PreAuthorizationProfile :[
											sourceSystem : PreAuthPayment?.SourceSystem,
											sourceLocation: PreAuthPayment?.SourceLocation,
											sourceUser: PreAuthPayment?.SourceUser,
											preAuthorizationId: PreAuthPayment?.AuthorizationCode,
											amount: paymentOption?.PaymentMethod?.CAPM?.TotalAmount,
											monetaryUnit: WirelineConstants.ADD_WIRELINE_PAYMENT_MONETARYUNIT
										 ]
				
							]
		}
		else if(CAPMPayment && CAPMPayment?.ProfileSourceSystem && CAPMPayment?.ProfileOwnerId) {
			
			paymentMethod = [
				PaymentProfile :[
									sourceSystem : paymentOption?.CAPMConfig?.SourceSystem,
									sourceLocation: paymentOption?.CAPMConfig?.SourceLocation,
									profileName: CAPMPayment?.ProfileSourceSystem,
									profileOwnerId: CAPMPayment?.ProfileOwnerId,
									merchantId: paymentOption?.CAPMConfig?.MerchantID ? paymentOption?.CAPMConfig?.MerchantID : WirelineConstants.ADD_WIRELINE_PAYMENT_MERCHANTID_ORDERGWCon,
									amount: paymentLineItems?.Price?.Amount.sum(),
									monetaryUnit: WirelineConstants.ADD_WIRELINE_PAYMENT_MONETARYUNIT
								 ]
				
							]
		}
		else if(CAPMPayment && CAPMPayment?.CreditCardNumber && CAPMPayment?.creditCardHolderName) {
			
			def ccType
				switch(CAPMPayment?.CreditCardType) {
					
					case 'AMERICAN_EXPRESS' : ccType = WirelineConstants.ORDER_EQUIPMENT_CREDITCARD_TYPE_AE
						  break;
					case 'DISCOVER' : ccType = WirelineConstants.ORDER_EQUIPMENT_CREDITCARD_TYPE_DISC
						 break;
					case 'MASTERCARD' : ccType = WirelineConstants.ORDER_EQUIPMENT_CREDITCARD_TYPE_MC
						 break;
					case 'DINER\'S_CLUB' : ccType = WirelineConstants.ORDER_EQUIPMENT_CREDITCARD_TYPE_DINE
						 break;
					default: ccType = CAPMPayment?.CreditCardType
				}
				
				def expirationDate = paymentOption?.PaymentMethod?.CAPM?.ExpirationYearMonth
				println('length is - '+expirationDate.length())
				def ExpirationYearMonth = expirationDate.substring(2,4)+expirationDate.substring(5,7)
				
			paymentMethod = [
				CreditCard :[
									method: 'CREDITCARD',
									creditCardNumber: CAPMPayment?.CreditCardNumber,
									cardName: CAPMPayment?.creditCardHolderName,
									cardExpirationDate: ExpirationYearMonth,
									creditCardType: ccType,
									zipCode: CAPMPayment?.CardBillingZipCode,
									merchantId: paymentOption?.CAPMConfig?.MerchantID,
									amount: paymentLineItems?.Price?.Amount.sum(),
									monetaryUnit: WirelineConstants.ADD_WIRELINE_PAYMENT_MONETARYUNIT
								 ]
				
							]
			
		}
		
		else if(CreditCardPayment && !(CreditCardPayment?.PreAuthDetail?.AuthorizationCode)) {
			
			def ccType
			
			switch(CreditCardPayment?.CreditCardType) {
				
				case 'AMERICAN_EXPRESS' : ccType = WirelineConstants.ORDER_EQUIPMENT_CREDITCARD_TYPE_AE
					 break;
				case 'DISCOVER' : ccType = WirelineConstants.ORDER_EQUIPMENT_CREDITCARD_TYPE_DISC
					 break;
				case 'MASTERCARD' : ccType = WirelineConstants.ORDER_EQUIPMENT_CREDITCARD_TYPE_MC
					 break;
				case 'DINER\'S_CLUB' : ccType = WirelineConstants.ORDER_EQUIPMENT_CREDITCARD_TYPE_DINE
					 break;
				default: ccType = CreditCardPayment?.CreditCardType
			}
			def expirationDate = paymentOption?.PaymentMethod?.CreditCard?.ExpirationYearMonth
			def ExpirationYearMonth = expirationDate.substring(2,4)+expirationDate.substring(5,7)
			paymentMethod = [
				CreditCard :[
									method: 'CREDITCARD',
									creditCardNumber: CreditCardPayment?.CreditCardNumber,
									cardName: CreditCardPayment?.creditCardHolderName,
									cardExpirationDate: ExpirationYearMonth,
									creditCardType: ccType,
									zipCode: CreditCardPayment?.CardBillingZipCode,
									merchantId: 'Consumer',
									amount: paymentLineItems?.Price?.Amount.sum(),
									monetaryUnit: WirelineConstants.ADD_WIRELINE_PAYMENT_MONETARYUNIT
								 ]
				
							]
			
			
		}
		
		else if(CreditCardPayment && CreditCardPayment?.PreAuthDetail?.AuthorizationCode) {
			
			paymentMethod = [
				PreAuthorizationProfile :[
											sourceSystem : CreditCardPayment?.PreAuthDetail?.SourceSystem,
											sourceLocation: CreditCardPayment?.PreAuthDetail?.SourceLocation,
											sourceUser: CreditCardPayment?.PreAuthDetail?.SourceUser,
											preAuthorizationId: CreditCardPayment?.PreAuthDetail?.AuthorizationCode,
											amount: CreditCardPayment?.PaymentAmount,
											monetaryUnit: WirelineConstants.ADD_WIRELINE_PAYMENT_MONETARYUNIT
										 ]
				
							]
		}
		
		else if(paymentOption?.PaymentMethod?.ACH) {
			
			def ach = paymentOption?.PaymentMethod?.ACH
			
			paymentMethod = [
				Check :[
											checkTypeIndicator : 'CHECK',
											method: 'ACH',
											accountType: OrderUtility.getAccountType(paymentOption),
											routingNumber: ach?.BankAccountDetails?.RoutingNumber,
											accountNumber: ach?.BankAccountDetails?.AccountNumber,
											accountName: ach?.BankAccountDetails?.AccountHolderName,
											businessAccount: 'false',
											amount: ach?.PaymentAmount,
											monetaryUnit: WirelineConstants.ADD_WIRELINE_PAYMENT_MONETARYUNIT
										 ]
				
							]
		}
		
		return paymentMethod
	}
	
	public void processResponse(Exchange exchange) throws APIFailedException
	{
		def order = exchange.properties.order
		def executionContext = exchange.properties.executionContext
		
		def awpResponseXml = new XmlSlurper().parseText(exchange.in.body)
		log.debug(exchange.in.body)
		
		if (awpResponseXml.Body.Fault.size() > 0){
			def apie = new APIFailedException(
				api : getApiName(),
				code : awpResponseXml.Body.Fault.detail.CSIApplicationException.Response.code,
				codeDescription : awpResponseXml.Body.Fault.detail.CSIApplicationException.Response.description,
				subCode : awpResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code,
				subCodeDescription : awpResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
			)
			addTransactionHistory(exchange,apie)
			exchange.out.body = order
			throw apie
		}
		println('awpResponseXml = '+awpResponseXml)
		def paymentHandle = awpResponseXml.Body.AddWirelinePaymentResponse.Payment.paymentHandle.toString()
		println('paymentHandle = '+paymentHandle)
		executionContext.put("paymentHandle",paymentHandle)
		addTransactionHistory(exchange,null)
   }
	
	
	def getCountOfAdvPymtOption(order)
	{
		def paymentOption = order.PaymentOptions?.PaymentOption
		def systemNames = WirelineConstants.AWP_SYSTEMS_NAMES
		def uverseGroupsId = getUverseGroupsId(order)
		def uverseLineItems = order.LineItems?.LineItem?.findAll { li -> uverseGroupsId.intersect(li.GroupRefs.GroupRef )}.collect{it}.flatten().minus(null)
		def advPymtLineItem = uverseLineItems.findAll { li -> systemNames.contains(li.SystemName)}.collect{it.Payments?.Payment?.PaymentOptionRef}.flatten().minus(null)
		//def countOfPymtOptRef = paymentOption.findAll { po -> po.intersect(advPymtLineItemId)}.collect{ it.Payments?.Payment?.PaymentOptionRef}.flatten().minus(null).size()
		
		def countOfPymtOptRef = order.PaymentOptions?.PaymentOption.findAll { po -> advPymtLineItem.contains (po.Id) }.collect{it}.flatten().minus(null)
		def count = countOfPymtOptRef.size()
		println('count of PymtOptRef is  = '+count)
		
		return count
	}
	
	def getUverseGroupsId(Order)
	{
		def groupList= Order.Groups.Group

		ArrayList<String> uverseGroupIds = new ArrayList<String>();
		for(def group in groupList)
		{
			def productTypes = group.GroupCharacteristics?.LoSGCharacteristics?.ProductCategory
			if(productTypes && (productTypes.contains('IPTV')
			|| productTypes.contains('INTERNET')
			|| productTypes.contains('VOIP')
			|| group.GroupCharacteristics.PackageCharacteristics)
			&& group.GroupCharacteristics.LoSGCharacteristics.ProductCategory != 'PACKAGE' )
			{
				uverseGroupIds.add(group.Id)
			}
		}
		return uverseGroupIds
	}
	
	def updatePaymentoptions(order,executionContext)
	{
		for(def groups in order.Groups.Group)
		{
			if(groups.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus)
			{
				if(groups.GroupCharacteristics.LoSGCharacteristics.LoSGStatus.SubStatus == 'CREDIT_POLICY_ACCEPTED')
				{
					order.PaymentOptions.PaymentOption.put("CollectedInOtherSystem",true)
				}
			}
		}
		executionContext.put("AWPSkipped",true)
	}
	
	def getCancelledLosgs(order,executionContext)
	{
		def cancelledGroups = order.Groups.Group?.findAll { grp -> grp.GroupCharacteristics?.LoSGCharacteristics?.LoSGStatus?.SubStatus == 'CANCELED'}.collect{it}.flatten().minus(null)
		executionContext.put("cancelledGroups",cancelledGroups)
		return cancelledGroups
	}
	
	public void updateExecutionContextAWPInvoked(executionContext) 
	{
		executionContext.put("AWPInvoked",true)

	}
	
	def getAWPPymtOption(order)
	{
		def paymentOption = order.PaymentOptions?.PaymentOption
		def systemNames = WirelineConstants.AWP_SYSTEMS_NAMES
		def uverseGroupsId = getUverseGroupsId(order)
		def uverseLineItems = order.LineItems?.LineItem?.findAll { li -> uverseGroupsId.intersect(li.GroupRefs.GroupRef )}.collect{it}.flatten().minus(null)
		def advPymtLineItem = uverseLineItems.findAll { li -> systemNames.contains(li.SystemName)}.collect{it.Payments?.Payment?.PaymentOptionRef}.flatten().minus(null)
		def PymtOptRef = order.PaymentOptions?.PaymentOption.findAll { po -> advPymtLineItem.contains (po.Id) }.collect{it}.flatten().minus(null)
		
		return PymtOptRef
	}
	
	def mapPaymentHandler(loopCounter,executionContext,order)
	{
		println('Payment Handler')
		def paymentOption = order.PaymentOptions?.PaymentOption
		def systemNames = WirelineConstants.AWP_SYSTEMS_NAMES
		def uverseGroupsId = getUverseGroupsId(order)
		def uverseLineItems = order.LineItems?.LineItem?.findAll { li -> uverseGroupsId.intersect(li.GroupRefs.GroupRef )}.collect{it}.flatten().minus(null)
		def advPymtLineItem = uverseLineItems.findAll { li -> systemNames.contains(li.SystemName)}.collect{it.Payments?.Payment?.PaymentOptionRef}.flatten().minus(null)
		def PymtOptRef = order.PaymentOptions?.PaymentOption.findAll { po -> advPymtLineItem.contains (po.Id) }.collect{it}.flatten().minus(null)
		
		def paymentHandle = executionContext.get("paymentHandle")
		
		PymtOptRef[loopCounter].put("PaymentHandler",paymentHandle)
	}
	
	def updateErrorlistforAWP(executionContext,order)
	{
		def uverseAccount = OrderUtility.getUverseAcount(order)
		List<ErrorBean> errList = new ArrayList<ErrorBean>();
		
		if(executionContext.get("AWPInvoked") || executionContext.get("AWPSkipped"))
		{
			errList.add(new ErrorBean('300','No Uverse Account'))
			OrderUtility.updateErrorList(order,executionContext,errList,WirelineConstants.LOSGSTATUS_IN_QUEUE,WirelineConstants.LOSG_MANUAL_PROVISIONING_REQUIRED,uverseAccount.Id)
		}
		else
		{
			errList.add(new ErrorBean('300','AWP Fail'))
			OrderUtility.updateErrorList(order,executionContext,errList,WirelineConstants.LOSGSTATUS_IN_QUEUE,WirelineConstants.LOSG_MANUAL_PROVISIONING_REQUIRED,uverseAccount.Id)
		}
	}
	
	
	
}