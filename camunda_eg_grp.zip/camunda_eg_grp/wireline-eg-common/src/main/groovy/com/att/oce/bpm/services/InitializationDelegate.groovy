package com.att.oce.bpm.services;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource

import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate
import org.camunda.bpm.engine.history.HistoricProcessInstance;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.springframework.stereotype.Component;
import com.att.oce.config.components.GlobalProperties
import com.att.oce.bpm.common.OceConstants
import com.att.oce.bpm.common.WirelineConstants;
import com.att.oce.bpm.common.WirelineProperties;;

@Component('initDelegate')
class InitializationDelegate implements JavaDelegate {

	@Resource
	protected GlobalProperties globalConfig;
	
	@Resource
	protected WirelineProperties wirelineProperties;
	
	public def updateLoSGStatus(def order) {
		
		def loSGStatus = [ Status : "SYS_RECEIVED",
						   SubStatus : "NEW"
						 ]
		def miscLosGStatus = [ Status : "SUBMITTED",
						   SubStatus : "AUTO_COMPLETE"
						 ]
		order.Groups.Group.each{ losg ->
							if(losg.GroupCharacteristics && losg.GroupCharacteristics.LoSGCharacteristics){
									if(losg.GroupCharacteristics.LoSGCharacteristics.ProductCategory == 'MISC'){
										losg.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",miscLosGStatus)
									}else{
										losg.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",loSGStatus)
									}
								}
						   }
		return order
	}
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		def order = (HashMap<String, Object>) execution.getVariable("order");
		
		//If the request comes from FUSE with Order Key
		if(!order.CustomerOrderNumber && order.Order.CustomerOrderNumber){
			order = order.Order
		}
		//setting salesCode for SMB-WEB-CENTER
		def channel = order.OrderSource.Channel
		if(WirelineConstants.CHANNEL_SMB.equals(channel)) {
			order.SalesCode=wirelineProperties.getPropertyStringValue("smb.salesCode")
		}
		
		def skipFraud = (wirelineProperties.getPropertyBooleanValue("fraud.skip")) ? wirelineProperties.getPropertyBooleanValue("fraud.skip") : true
		boolean skipPriceMatch = ("on".equalsIgnoreCase(wirelineProperties.getPropertyStringValue("ProceMatch.Switch"))) ? false : true
		
		def updatedOrder = updateLoSGStatus(order)
		def internalApiLog = new LinkedHashMap<String, LinkedHashMap<String, String>>();
		def executionContext = new LinkedHashMap<String, Object>();  //(HashMap<String, Object>) execution.getVariable("executionContext");	
			
		executionContext.put("CUSTOMER_ORDER_NUMBER",order.CustomerOrderNumber)
		executionContext.put("retryExhausted", false);
		executionContext.put("skipPriceMatch",skipPriceMatch)
//		executionContext.put("banCacheRetryAttemptscompleted", 0);
//		executionContext.put("banCacheRetryInterval", "PT"+wirelineProperties.banCacheRetryInitialInterval+"S");
		execution.setVariable("order",updatedOrder)
		execution.setVariable("CustomerOrderNumber", order.CustomerOrderNumber)
		execution.setVariable("executionContext",executionContext)
		execution.setVariable("internalApiLog", internalApiLog)
		execution.setVariable("skipFraud", skipFraud)
		
//		execution.setVariable("wscTimer",wirelineProperties.getPropertyStringValue("wsc.timer"))
		
		if( order.PRCTicketNumber && order.Accounts.Account[0].AccountSubCategory == OceConstants.ACCOUNTSUBCATEGORY_NEW ){
			execution.setVariable("KEY_"+order.PRCTicketNumber,order.PRCTicketNumber+order.Accounts.Account[0].AccountSubCategory)
		}
		
	}

}
