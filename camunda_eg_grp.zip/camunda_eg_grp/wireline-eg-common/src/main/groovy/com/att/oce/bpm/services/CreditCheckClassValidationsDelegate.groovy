package com.att.oce.bpm.services

import java.util.ArrayList
import java.util.Date;
import java.util.Map;

import org.camunda.bpm.engine.delegate.BpmnError
import org.camunda.bpm.engine.delegate.DelegateExecution
import org.camunda.bpm.engine.delegate.JavaDelegate
import org.springframework.stereotype.Component

import com.att.oce.bpm.common.WirelineConstants;
import com.att.oce.bpm.common.util.CommonUtility
import com.att.oce.bpm.common.util.ErrorBean;
import com.att.oce.bpm.utility.OrderUtility;

@Component('creditCheck')
class CreditCheckClassValidationsDelegate implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {

		def order =  execution.getVariable("order");
		def executionContext =  execution.getVariable("executionContext")
		
		def errors = OrderUtility.creditCheckAndCreditClassValidations(order)
		def isMultipleAuthorizedBilling = OrderUtility.hasMultipleAuthorizedBillingDetails(order)

		if(!errors.isEmpty())
		{
			/*for(error in errors)
			{
				ErrorBean bean = new ErrorBean(error.ErrorCode, error.)
				error.put("ErrorDescription",ErrorDescription)
			}
			errorList.put("Error",errors)
			Order.put("Errors",errorList)
			
			execution.setVariable("order", order);
			executionContext.put("LOSGStatus", "IN_QUEUE")
			execution.setVariable("executionContext",executionContext);*/
			OrderUtility.updateErrorList(order,executionContext,errors, WirelineConstants.LOSG_STATUS_IN_QUEUE, 
				WirelineConstants.LOSG_MANUAL_PROVISIONING_REQUIRED,order.CustomerOrderNumber)
			
			throw new BpmnError("CRC001");
			
		} else if(isMultipleAuthorizedBilling) {
			
			/*def transactionHistory = executionContext.get("transactionHistory");
			
			if( transactionHistory != null){
				transactionHistory.add(CommonUtility.getMap("time",new Date(),
						"status",WirelineConstants.LOSG_STATUS_IN_QUEUE ,
						"subStatus", WirelineConstants.LOSGSUBSTATUS_MULTIPLE_AUTHORIZED_USERS));
			} else {
				transactionHistory = new ArrayList<Map<String,Object>>();
				transactionHistory.add(CommonUtility.getMap("time",new Date(),
						"status",WirelineConstants.LOSG_STATUS_IN_QUEUE,
						"subStatus",WirelineConstants.LOSGSUBSTATUS_MULTIPLE_AUTHORIZED_USERS));
			}
			
			executionContext.put("LOSGStatus", "IN_QUEUE")
			executionContext.put("transactionHistory",transactionHistory);
			execution.setVariable("executionContext",executionContext);*/
		
			OrderUtility.updateErrorList(order,executionContext,null, 
				WirelineConstants.LOSG_STATUS_IN_QUEUE, WirelineConstants.LOSGSUBSTATUS_MULTIPLE_AUTHORIZED_USERS, order.CustomerOrderNumber)
			
			throw new BpmnError("CRC001");
		}

	}

}
