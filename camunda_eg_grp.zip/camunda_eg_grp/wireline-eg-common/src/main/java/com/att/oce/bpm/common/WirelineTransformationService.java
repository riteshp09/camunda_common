package com.att.oce.bpm.common;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.camunda.bpm.dmn.engine.DmnDecisionRuleResult;
import org.camunda.bpm.dmn.engine.DmnDecisionTableResult;
import org.camunda.bpm.engine.delegate.BpmnError;

import com.att.oce.bpm.common.TransformationService;
import com.att.oce.bpm.error.APIFailedException;
import com.att.oce.bpm.utility.OrderUtility;

public abstract class WirelineTransformationService extends TransformationService{
	private static String HTTP_METHOD_POST = "POST";
	private static String HTTP_CONTENT_TYPE_JSON = "application/json";
	private static String HTTP_CONTENT_TYPE_XML = "text/xml";

	@Resource
	protected WirelineProperties wirelineProperties;

	protected Map<String,Object> createMessageHeader(Map<String,Object> order) {
		return getMap( "trackingMessageHeader",getMap( 
				"version" , wirelineProperties.getPropertyStringValue("csi.version") /*globalConfig.csiVersion*/,
				"messageId" , order.get("RequestId").toString()+order.get("CustomerOrderNumber").toString()+java.util.UUID.randomUUID().toString(),
				"originatorId" , globalConfig.csiOriginatorId,
				"conversationId","oce~CNG-CSI~528de683-f198-4dcf-aec0-d7bab1161e66",
				"dateTimeStamp" , getXmlDateTime()),
				"securityMessageHeader" , getMap(
						"userName" , globalConfig.csiOceUserName,
						"userPassword" , globalConfig.csiOcePassword),
				"sequenceMessageHeader" , getMap(
						"sequenceNumber" , 1,
						"totalInSequence" , 1)
				);
	}

	protected Map<String,Object> createMessageHeaderOCE(Map<String,Object> order) {
		return getMap( "trackingMessageHeader",getMap( 
				"version" , globalConfig.csiVersion,
				"messageId" , order.get("RequestId").toString()+order.get("CustomerOrderNumber").toString()+java.util.UUID.randomUUID().toString(),
				"originatorId" , globalConfig.csiOriginatorId,
				"dateTimeStamp" , getXmlDateTime()),
				"securityMessageHeader" , getMap(
						"userName" , globalConfig.csiOceUserName,
						"userPassword" , globalConfig.csiOcePassword),
				"sequenceMessageHeader" , getMap(
						"sequenceNumber" , 1,
						"totalInSequence" , 1)
				);
	}
	protected void setATGHttpHeaders(Exchange exchange,boolean update){
		exchange.getIn().getHeaders().put("CamelHttpMethod",HTTP_METHOD_POST);
		exchange.getIn().getHeaders().put("Accept",HTTP_CONTENT_TYPE_JSON);
		exchange.getIn().getHeaders().put("Content-Type",HTTP_CONTENT_TYPE_XML);
	}

	/*@SuppressWarnings({ "unchecked", "rawtypes" })
	public void addTransactionHistory(Map executionContext,APIFailedException e){
		if (!executionContext.containsKey("transactionHistory"))
			executionContext.put("transactionHistory",new ArrayList<Map<String,Object>>());
		Map<String,Object> apires = super.getAPIConfig(e, null, false);

		List<Map<String,Object>> transactionHistory = (List<Map<String,Object>>) executionContext.get("transactionHistory");
		transactionHistory.add(getMap("time",new Date(),"api",getApiName(),
				"success",(e == null),"status",apires.get("status"),"subStatus",apires.get("subStatus")));

	}*/



	/*protected Map<String,Object> getAPIConfig(APIFailedException e){
		DmnDecisionTableResult results = dmnEngine
				.evaluateDecisionTable(apiResultDecisions, getMap("api",getApiName(),"code",e == null?"0":e.getCode(),"subCode",e == null?"0":e.getSubCode()));
		DmnDecisionRuleResult result = results.getFirstResult();
		if (result.size() == 0){
			results = dmnEngine
					.evaluateDecisionTable(apiResultDecisions, getMap("api",getApiName(),"code",e == null?"0":e.getCode(),"subCode",null));
		}
		if (result.size() == 0){
			results = dmnEngine
					.evaluateDecisionTable(apiResultDecisions, getMap("api",getApiName(),"code",null,"subCode",null));
		}
		return result;
	}*/

	protected Map<String,Object> createMessageHeader(Map<String,Object> order, String conversationId) {
		return getMap( "trackingMessageHeader",getMap( 
				"version" , wirelineProperties.getPropertyStringValue("csi.version"),
				"messageId" , order.get("RequestId").toString()+order.get("CustomerOrderNumber").toString()+java.util.UUID.randomUUID().toString(),
				"originatorId" , globalConfig.csiOriginatorId,
				"infrastructureVersion",wirelineProperties.getPropertyStringValue("csi.unified.infrastructureVersion"),
				"conversationId",conversationId,
				"applicationName",wirelineProperties.getPropertyStringValue("csi.unified.applicationName"),
				"timeToLive",wirelineProperties.getPropertyStringValue("csi.unified.timeToLive"),
				"dateTimeStamp" , getXmlDateTime()),
				"securityMessageHeader" , getMap(
						"userName" , globalConfig.csiOceUserName,
						"userPassword" , globalConfig.csiOcePassword),
				"sequenceMessageHeader" , getMap(
						"sequenceNumber" , 1,
						"totalInSequence" , 1)
				);
	}

	protected Map<String,Object> createUnifiedMessageHeader(Map<String,Object> order, String conversationId) {
		return getMap( "trackingMessageHeader",getMap( 
				"version" , wirelineProperties.getPropertyStringValue("csi.unified.version"),
				"messageId" , order.get("RequestId").toString()+order.get("CustomerOrderNumber").toString()+java.util.UUID.randomUUID().toString(),
				"originatorId" , globalConfig.csiOriginatorId,
				"infrastructureVersion",wirelineProperties.getPropertyStringValue("csi.unified.infrastructureVersion"),
				"conversationId",conversationId,
				"applicationName",wirelineProperties.getPropertyStringValue("csi.unified.applicationName"),
				"timeToLive",wirelineProperties.getPropertyStringValue("csi.unified.timeToLive"),
				"dateTimeStamp" , getXmlDateTime()),
				"securityMessageHeader" , getMap(
						"userName" , globalConfig.csiOceUserName,
						"userPassword" , globalConfig.csiOcePassword),
				"sequenceMessageHeader" , getMap(
						"sequenceNumber" , 1,
						"totalInSequence" , 1)
				);
	}

	protected Map<String,Object> createCustomerCarePaymentMessageHeader(Map<String,Object> order) {
		return getMap( "trackingMessageHeader",getMap( 
				"version" , wirelineProperties.getPropertyStringValue("csi.cusomercarepayment.version"),
				"messageId" , order.get("RequestId").toString()+order.get("CustomerOrderNumber").toString()+java.util.UUID.randomUUID().toString(),
				"originatorId" , globalConfig.csiOriginatorId,
				"infrastructureVersion",wirelineProperties.getPropertyStringValue("csi.cusomercarepayment.infrastructureVersion"),
				"conversationId","oce~CNG-CSI~528de683-f198-4dcf-aec0-d7bab1161e66",
				"applicationName",wirelineProperties.getPropertyStringValue("csi.cusomercarepayment.applicationName"),
				"timeToLive",wirelineProperties.getPropertyStringValue("ttl"),
				"dateTimeStamp" , getXmlDateTime()),
				"securityMessageHeader" , getMap(
						"userName" , globalConfig.csiOceUserName,
						"userPassword" , globalConfig.csiOcePassword),
				"sequenceMessageHeader" , getMap(
						"sequenceNumber" , 1,
						"totalInSequence" , 1)
				);
	}
	
	protected Map<String,Object> createITPAMessageHeader(Map<String,Object> order){
		
		return getMap( "trackingMessageHeader",getMap( 
				"version" , wirelineProperties.getPropertyStringValue("itpa.version"),
				"messageId" , order.get("RequestId").toString()+order.get("CustomerOrderNumber").toString()+java.util.UUID.randomUUID().toString(),
				"originatorId" , globalConfig.csiOriginatorId,
				"infrastructureVersion",wirelineProperties.getPropertyStringValue("csi.cusomercarepayment.infrastructureVersion"),
				"conversationId","oce~CNG-CSI~528de683-f198-4dcf-aec0-d7bab1161e66",
				"applicationName",wirelineProperties.getPropertyStringValue("itpa.appName"),
				"timeToLive",wirelineProperties.getPropertyStringValue("ttl"),
				"dateTimeStamp" , getXmlDateTime()),
				"securityMessageHeader" , getMap(
						"userName" , globalConfig.csiOceUserName,
						"userPassword" , globalConfig.csiOcePassword),
				"sequenceMessageHeader" , getMap(
						"sequenceNumber" , 1,
						"totalInSequence" , 1)
				);
		
	}

	public void transformWrapper(Exchange exchange) {

		Map<String,Object> order  = (Map<String, Object>) ((Map<String, Object>) exchange.getIn().getBody()).get("order");
		Map<String,Object> executionContext = (Map<String, Object>) exchange.getProperties().get("executionContext");

		exchange.getProperties().put("order", ((Map<?,?>)exchange.getIn().getBody()).get("order"));
		exchange.getProperties().put("executionContext",  ((Map<?,?>)exchange.getIn().getBody()).get("executionContext"));
		exchange.getProperties().put("fedIndicator", false);

		String apiUrl = resolveURN(getApiUrn(), null);
		exchange.getProperties().put("apiURN",getApiUrn());
		exchange.getProperties().put("apiUrl",apiUrl);
		
		Map<String, Object> uverseAccount = (Map<String, Object>) OrderUtility.getUverseAcount(order);
		if(uverseAccount != null)
			executionContext.put("referenceId", uverseAccount.get("Id"));
		else
			executionContext.put("referenceId", order.get("CustomerOrderNumber"));
		

		try {
			transform(exchange);
			setAuditLogProperties(exchange,false);
		}
		catch(Exception e) {
			OrderUtility.throwBPMNError(e, order, executionContext);
		}

		//System.out.println("transformWrapper end.............................");

	}

	public void processResponseWrapper(Exchange exchange) throws APIFailedException,BpmnError {

		//System.out.println("processResponseWrapper start.............................");
		Map<String,Object> order  = (Map<String, Object>) exchange.getProperties().get("order");
		Map<String,Object> executionContext = (Map<String, Object>) exchange.getProperties().get("executionContext");
		//System.out.println("Order:::"+order);
		//System.out.println("EC:::"+executionContext);
		try {
			processResponse(exchange);
		}catch(APIFailedException apie) {
			throw apie;
		} catch(Exception e) {
			OrderUtility.throwBPMNError(e, order, executionContext);
		}
	}

	public abstract void transform(Exchange exchange);
	public abstract void processResponse(Exchange exchange) throws APIFailedException;
	public abstract String getApiUrn();
}
