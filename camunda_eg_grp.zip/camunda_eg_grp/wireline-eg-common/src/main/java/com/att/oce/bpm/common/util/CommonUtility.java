package com.att.oce.bpm.common.util;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class CommonUtility {
	
	public static String formatDate(String date, String dateFromat) {
		String formattedDate = String.valueOf(date);
		try {
			long longDate = Long.valueOf(date);
			Date dt = new Date(longDate);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSz");
			formattedDate = sdf.format(dt);
			formattedDate = formattedDate.substring(0, 19)+ "Z";
		} catch (NumberFormatException nfe) {
			formattedDate = formattedDate.substring(0, 19)+ "Z";
		}catch (Exception e) {
			e.printStackTrace();
		}
		return formattedDate;
	}
	
	public static Map<String,Object> getMap(Object... arguments){
		Map<String,Object> map = new HashMap<String, Object>();
		for(int i=0;i<arguments.length;i+=2){
			map.put(arguments[i].toString(), arguments[i+1]);
		}
		return map;
	}
	
	public String getFileContent(String fileName) throws IOException {
		InputStream stream = getClass().getClassLoader().getResourceAsStream(fileName);
		
		byte[] data = new byte[stream.available()];
		stream.read(data);
		
		/*BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder out = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			out.append(line);
		}
		
		is.close();
		reader.close();*/
		
		return new String(data);
	}

}
