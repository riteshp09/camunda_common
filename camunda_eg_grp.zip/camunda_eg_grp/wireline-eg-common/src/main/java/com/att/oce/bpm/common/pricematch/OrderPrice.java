package com.att.oce.bpm.common.pricematch;

import java.io.Serializable;

public class OrderPrice implements Cloneable,Serializable{
	
	String pricePlanCode;
	String actualPrice;
    String chargeType;
    String baseOfferId;
	String promSalesType;
	String systemName;
	String quantity;
	String ignorePricePlanCode;
	String match;
	
	public String getPricePlanCode() {
		return pricePlanCode;
	}
	public void setPricePlanCode(String pricePlanCode) {
		this.pricePlanCode = pricePlanCode;
	}
	public String getActualPrice() {
		return actualPrice;
	}
	public void setActualPrice(String actualPrice) {
		this.actualPrice = actualPrice;
	}
	public String getChargeType() {
		return chargeType;
	}
	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}
	public String getBaseOfferId() {
		return baseOfferId;
	}
	public void setBaseOfferId(String baseOfferId) {
		this.baseOfferId = baseOfferId;
	}
	public String getPromSalesType() {
		return promSalesType;
	}
	public void setPromSalesType(String promSalesType) {
		this.promSalesType = promSalesType;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getIgnorePricePlanCode() {
		return ignorePricePlanCode;
	}
	public void setIgnorePricePlanCode(String ignorePricePlanCode) {
		this.ignorePricePlanCode = ignorePricePlanCode;
	}
	public String getMatch() {
		return match;
	}
	public void setMatch(String match) {
		this.match = match;
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	
}
