package com.att.oce.bpm.common;

import org.springframework.context.EmbeddedValueResolverAware;
import org.springframework.stereotype.Component;
import org.springframework.util.StringValueResolver;

@Component
public class WirelineProperties implements EmbeddedValueResolverAware {
	
	private StringValueResolver resolver;
	
	private String parsePropertyName(String name) {
		return "${" + name + "}";
	}
	
	public String getPropertyStringValue(String propertyName)
	{
		return resolver.resolveStringValue(parsePropertyName(propertyName));
	}
	
	public boolean getPropertyBooleanValue(String name) {
		return Boolean.parseBoolean(resolver.resolveStringValue(parsePropertyName(name)));
	}
	
	public int getPropertyIntegerValue(String name) {
		return Integer.parseInt(resolver.resolveStringValue(parsePropertyName(name)));
	}

	public void setEmbeddedValueResolver(StringValueResolver resolver)
	{
		this.resolver = resolver;
	}

}
