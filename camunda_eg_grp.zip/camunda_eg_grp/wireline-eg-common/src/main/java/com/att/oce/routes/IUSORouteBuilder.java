package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.InitiateUnifiedServiceOrderRequestTransformation;

@Component("iusoRouteBuilder")
public class IUSORouteBuilder extends RouteBuilder{
	
	

		@Override
		public void configure() throws Exception
		{
			from("direct:csi:iuso")
			.routeId("IUSOId")
			.bean(InitiateUnifiedServiceOrderRequestTransformation.class,"transformWrapper")
			.to("velocity:///vm/IUSO.vm")
			.wireTap("direct:auditlog:request")
			.to("https://headeruri?throwExceptionOnFailure=false")
			.convertBodyTo(String.class)
			.wireTap("direct:auditlog:response")
			.bean(InitiateUnifiedServiceOrderRequestTransformation.class,"processResponseWrapper");
		}

	}

