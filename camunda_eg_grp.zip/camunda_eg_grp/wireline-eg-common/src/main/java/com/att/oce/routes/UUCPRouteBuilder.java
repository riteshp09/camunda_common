package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.RouteBuilderDefinition;
import org.springframework.stereotype.Component;

import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.AddWirelinePaymentPlanTransformsation;
import com.att.oce.transformation.UUCPTransformation;

@Component("UUCPRouteBuilder")
public class UUCPRouteBuilder extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		from("direct:uucp")
		.routeId("UUCPId")
		.bean(UUCPTransformation.class,"transformWrapper")
		.to("velocity:///vm/UUCP.vm")
		.wireTap("direct:auditlog:request")
		.to("https://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.wireTap("direct:auditlog:response") 
		.bean(UUCPTransformation.class,"processResponseWrapper");
		
	}

}
