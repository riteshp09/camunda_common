package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;

import org.springframework.stereotype.Component;
import org.apache.camel.builder.RouteBuilder;
import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.IATNTransformation;




@Component("iatnRouteBuilder")
public class IATNRouteBuilder extends RouteBuilder{

	@Override
	public void configure() throws Exception {		
		from("direct:csi:inquireTN")
		.bean(IATNTransformation.class,"transformWrapper")
		.to("velocity://vm/IATN.vm")
		.wireTap("direct:auditlog:request")
		.to("http://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.wireTap("direct:auditlog:response")
		.bean(IATNTransformation.class,"processResponseWrapper")
		.setId("iatnRouteBuilder");
				
	}

}
