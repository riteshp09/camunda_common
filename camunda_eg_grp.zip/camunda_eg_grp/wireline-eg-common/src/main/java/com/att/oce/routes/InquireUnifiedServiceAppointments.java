package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;


import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.InquireUnifiedServiceAppointmentsTransformation;

@Component("IUSAppRouteBuilder")
public class InquireUnifiedServiceAppointments extends RouteBuilder {

	@Override
	public void configure() throws Exception
	{
		from("direct:csi:iusapp")
		.routeId("IUSAppId")
		.bean(InquireUnifiedServiceAppointmentsTransformation.class,"transformWrapper")
		.to("velocity:///vm/IUSApp.vm")
		.wireTap("direct:auditlog:request")
		.to("https://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.wireTap("direct:auditlog:response")
		.bean(InquireUnifiedServiceAppointmentsTransformation.class,"processResponseWrapper");
	}
	
}


