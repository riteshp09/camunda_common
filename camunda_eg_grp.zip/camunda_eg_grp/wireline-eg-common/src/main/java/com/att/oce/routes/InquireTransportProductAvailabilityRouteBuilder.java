package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.InquireTransportProductAvailabilityTransformation;


@Component("inquireTransportProductAvailabilityRouteBuilder")
public class InquireTransportProductAvailabilityRouteBuilder extends RouteBuilder{
	@Override
	public void configure() throws Exception {
		
		from("direct:csi:ITPA")
		.routeId("itpaId")
		.bean(InquireTransportProductAvailabilityTransformation.class,"transformWrapper")
		.to("velocity:///vm/ITPA.vm")
		.wireTap("direct:auditlog:request")
		.to("https://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.wireTap("direct:auditlog:response")
		.bean(InquireTransportProductAvailabilityTransformation.class,"processResponseWrapper");
		
	}
	
}




