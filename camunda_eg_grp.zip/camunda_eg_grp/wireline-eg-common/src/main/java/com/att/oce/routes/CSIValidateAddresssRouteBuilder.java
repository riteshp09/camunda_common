package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;

import org.springframework.stereotype.Component;
import org.apache.camel.builder.RouteBuilder;
import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.CSIValidateAddressTransformation;


@Component("csiValidateAddresssRouteBuilder")
public class CSIValidateAddresssRouteBuilder extends RouteBuilder{

	@Override
	public void configure() throws Exception {		
		from("direct:csi:validateAddress")
		.bean(CSIValidateAddressTransformation.class,"transformWrapper")
		.to("velocity:///vm/AddressValidation.vm")
		.wireTap("direct:auditlog:request")
		.to("https://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.wireTap("direct:auditlog:response")
		.bean(CSIValidateAddressTransformation.class,"processResponseWrapper")
		.setId("csiValidateAddresssRouteBuilder");
				
	}

}
