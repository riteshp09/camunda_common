package com.att.oce.bpm.common;

public class QualificationConfig {
	
	String name;
	String status;
	String subStatus;
	String comment;
	String code;
	
	public QualificationConfig(String name, String status, String subStatus, String comment, String code) {
		this.name = name;
		this.status = status;
		this.subStatus = subStatus;
		this.comment = comment;
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public String getStatus() {
		return status;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public String getComment() {
		return comment;
	}

	public String getCode() {
		return code;
	}
	
	

}
