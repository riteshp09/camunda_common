package com.att.oce.bpm.common.pricematch;

import java.io.Serializable;

public class OMSPricePlan implements Serializable{
	
	String catalogID;
	String pricePlanCode;
	String chargeCodeType;
	String chargeCodeReference;
	String actualPrice;
	String currency;
	String eligibleForNRC;
	String minNumOfInstallment;
	String maxNumOfInstallment;
	String promotioncode;
	String promSaleType;
	String baseOfferId;
	String match;
	
	
	public String getCatalogID() {
		return catalogID;
	}
	public void setCatalogID(String catalogID) {
		this.catalogID = catalogID;
	}
	public  String getPricePlanCode() {
		return pricePlanCode;
	}
	public void setPricePlanCode( String pricePlanCode) {
		this.pricePlanCode = pricePlanCode;
	}
	public String getChargeCodeType() {
		return chargeCodeType;
	}
	public void setChargeCodeType(String chargeCodeType) {
		this.chargeCodeType = chargeCodeType;
	}
	public String getChargeCodeReference() {
		return chargeCodeReference;
	}
	public void setChargeCodeReference(String chargeCodeReference) {
		this.chargeCodeReference = chargeCodeReference;
	}
	public String getActualPrice() {
		return actualPrice;
	}
	public void setActualPrice(String actualPrice) {
		this.actualPrice = actualPrice;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getEligibleForNRC() {
		return eligibleForNRC;
	}
	public void setEligibleForNRC(String eligibleForNRC) {
		this.eligibleForNRC = eligibleForNRC;
	}
	public String getMinNumOfInstallment() {
		return minNumOfInstallment;
	}
	public void setMinNumOfInstallment(String minNumOfInstallment) {
		this.minNumOfInstallment = minNumOfInstallment;
	}
	public String getMaxNumOfInstallment() {
		return maxNumOfInstallment;
	}
	public void setMaxNumOfInstallment(String maxNumOfInstallment) {
		this.maxNumOfInstallment = maxNumOfInstallment;
	}
	public String getPromotioncode() {
		return promotioncode;
	}
	public void setPromotioncode(String promotioncode) {
		this.promotioncode = promotioncode;
	}
	public String getPromSaleType() {
		return promSaleType;
	}
	public void setPromSaleType(String promSaleType) {
		this.promSaleType = promSaleType;
	}
	public String getBaseOfferId() {
		return baseOfferId;
	}
	public void setBaseOfferId(String baseOfferId) {
		this.baseOfferId = baseOfferId;
	}
	public String getMatch() {
		return match;
	}
	public void setMatch(String match) {
		this.match = match;
	}

}
