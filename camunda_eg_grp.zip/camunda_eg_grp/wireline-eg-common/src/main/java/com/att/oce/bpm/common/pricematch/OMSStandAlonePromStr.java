package com.att.oce.bpm.common.pricematch;

import java.io.Serializable;

public class OMSStandAlonePromStr implements Serializable{
	
	String productSpecificationPricingId;
	String parentProductId;
	String parentOperationExtension;
	String parentProductSpecificationContainmentId;
	String promSaleType;
	String status;
	String baseOfferId;
	String billingId;
	String baseOfferInstanceId;
	String promType;
	public String getProductSpecificationPricingId() {
		return productSpecificationPricingId;
	}
	public void setProductSpecificationPricingId(String productSpecificationPricingId) {
		this.productSpecificationPricingId = productSpecificationPricingId;
	}
	public String getParentProductId() {
		return parentProductId;
	}
	public void setParentProductId(String parentProductId) {
		this.parentProductId = parentProductId;
	}
	public String getParentOperationExtension() {
		return parentOperationExtension;
	}
	public void setParentOperationExtension(String parentOperationExtension) {
		this.parentOperationExtension = parentOperationExtension;
	}
	public String getParentProductSpecificationContainmentId() {
		return parentProductSpecificationContainmentId;
	}
	public void setParentProductSpecificationContainmentId(String parentProductSpecificationContainmentId) {
		this.parentProductSpecificationContainmentId = parentProductSpecificationContainmentId;
	}
	public String getPromSaleType() {
		return promSaleType;
	}
	public void setPromSaleType(String promSaleType) {
		this.promSaleType = promSaleType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getBaseOfferId() {
		return baseOfferId;
	}
	public void setBaseOfferId(String baseOfferId) {
		this.baseOfferId = baseOfferId;
	}
	public String getBillingId() {
		return billingId;
	}
	public void setBillingId(String billingId) {
		this.billingId = billingId;
	}
	public String getBaseOfferInstanceId() {
		return baseOfferInstanceId;
	}
	public void setBaseOfferInstanceId(String baseOfferInstanceId) {
		this.baseOfferInstanceId = baseOfferInstanceId;
	}
	public String getPromType() {
		return promType;
	}
	public void setPromType(String promType) {
		this.promType = promType;
	}
	
	
}