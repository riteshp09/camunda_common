package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;
import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.CancelWirelinePaymentTransformation;

@Component("cwpRouteBuilder")
public class CWPRouteBuilder  extends RouteBuilder {

	@Override
	public void configure() throws Exception
	{
		from("direct:csi:CWP")
		.routeId("CWPId")
		.bean(CancelWirelinePaymentTransformation.class,"transform")
		.to("velocity:///vm/CWP.vm")
		.bean(CancelWirelinePaymentTransformation.class,"pringBody")
		//.bean(AuditLogHelper.class,"logRequest")
		.wireTap("direct:auditlog:request")
		.to("https://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		//.bean(AuditLogHelper.class, "logResponse")
		.wireTap("direct:auditlog:response")
		.bean(CancelWirelinePaymentTransformation.class,"pringBody")
		.bean(CancelWirelinePaymentTransformation.class,"processResponse");
	}

}

	
	

