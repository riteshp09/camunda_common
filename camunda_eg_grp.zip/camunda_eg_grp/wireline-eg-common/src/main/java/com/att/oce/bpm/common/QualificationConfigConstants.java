package com.att.oce.bpm.common;

import java.util.HashMap;
import java.util.Map;

public class QualificationConfigConstants {
	
	public static Map<String, QualificationConfig> QUALIFICATION_CONFIG = new HashMap<>(); 
	
	static {
		QUALIFICATION_CONFIG.put("checkForBAN", new QualificationConfig(
				"checkForBAN", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Account number does not exists", "300"));
		
		QUALIFICATION_CONFIG.put("checkForPreferredNetworkType", new QualificationConfig(
				"checkForPreferredNetworkType", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Preferred Network type does not exist", "303"));
				
		QUALIFICATION_CONFIG.put("checkForDelinquentAccount", new QualificationConfig(
				"checkForDelinquentAccount", "PENDING", "OUTSTANDING_BALANCE", "Attention Required - User has a delinquent account", "304"));
				
		QUALIFICATION_CONFIG.put("checkForNewVOIPRequest", new QualificationConfig(
				"checkForNewVOIPRequest", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Automation Disqualification - Manual provisioning required for VOIP orders", "305"));
				
		QUALIFICATION_CONFIG.put("checkForScheduleAppointment", new QualificationConfig(
				"checkForScheduleAppointment", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Customer comments exists for appointment", "306"));
				
		QUALIFICATION_CONFIG.put("checkForTitanExistingIndForProvideOrder", new QualificationConfig(
				"checkForTitanExistingIndForProvideOrder", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Automation Disqualification  – Product Unification already exists for this customer at the current address", "307"));
				
		QUALIFICATION_CONFIG.put("checkForTitanPendingIndForProvideOrder", new QualificationConfig(
				"checkForTitanPendingIndForProvideOrder", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Automation Disqualification  – Product Unification  pending for this customer at the current address", "308"));
				
		QUALIFICATION_CONFIG.put("checkForMerchantID", new QualificationConfig(
				"checkForMerchantID", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Merchant ID is missing", "309"));
				
		QUALIFICATION_CONFIG.put("checkForCAPMID", new QualificationConfig(
				"checkForCAPMID", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - CAPM ID is missing refer to credit policy token to obtain credit card details", "310"));
				
		QUALIFICATION_CONFIG.put("checkForCreditRisk", new QualificationConfig(
				"checkForCreditRisk", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Credit risk (high) is identified", "311"));
				
		QUALIFICATION_CONFIG.put("checkForAdvancedPayment", new QualificationConfig(
				"checkForAdvancedPayment", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error – Advanced payments is required", "312"));
			
		QUALIFICATION_CONFIG.put("checkForServiceAddress", new QualificationConfig(
				"checkForServiceAddress", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Service address is missing", "313"));
				
		QUALIFICATION_CONFIG.put("MorethanOnePaymentOptionForAutopay", new QualificationConfig(
				"MorethanOnePaymentOptionForAutopay", "PENDING", "CREDIT_CARD_INFO_NEEDED", "Data Error - Order contains more than one autopay method/options", "315"));
				
				
		QUALIFICATION_CONFIG.put("AnyGigaOrdersfallout", new QualificationConfig(
				"AnyGigaOrdersfallout", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Order contains Gigapower indicator", "316"));
				
				
		QUALIFICATION_CONFIG.put("CheckACHDetailsExists", new QualificationConfig(
				"CheckACHDetailsExists", "PENDING", "BANK_INFO_NEEDED", "Data Error - ACH Bank details are missing", "317"));
				
				
		QUALIFICATION_CONFIG.put("PortingAddress1NotVerfied", new QualificationConfig(
				"PortingAddress1NotVerfied", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Porting Address for Line 1 is not verified", "318"));
				
				
		QUALIFICATION_CONFIG.put("PortingAddress2NotVerfied", new QualificationConfig(
				"PortingAddress2NotVerfied", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Porting Address for Line 2 is not verified", "319"));
				
				
		QUALIFICATION_CONFIG.put("PortingEligibilityLine1RespDoesnotExists", new QualificationConfig(
				"PortingEligibilityLine1RespDoesnotExists", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Port Eligibility response for Line 1 missing", "320"));
				
				
		QUALIFICATION_CONFIG.put("PortingEligibilityLine2RespDoesnotExists", new QualificationConfig(
				"PortingEligibilityLine2RespDoesnotExists", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Port Eligibility response for Line 2 missing", "321"));
				
				
		QUALIFICATION_CONFIG.put("PortingAddressNotSame", new QualificationConfig(
				"PortingAddressNotSame", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Porting Address not same", "322"));
				
				
		QUALIFICATION_CONFIG.put("PortingAccountsNotSame", new QualificationConfig(
				"PortingAccountsNotSame", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Porting Accounts not same", "323"));
				
				
		QUALIFICATION_CONFIG.put("AnchorCTNDoesNotExistForPackageWithWireless", new QualificationConfig(
				"AnchorCTNDoesNotExistForPackageWithWireless", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Anchor CTN is missing in a package that has wireless", "324"));
				
				
		QUALIFICATION_CONFIG.put("ShippingAddressNotVerified", new QualificationConfig(
				"ShippingAddressNotVerified", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Shipping Address Not verified", "325"));
				
				
		QUALIFICATION_CONFIG.put("ConflictingServicesCouldNotBeCompleted", new QualificationConfig(
				"ConflictingServicesCouldNotBeCompleted", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Conflicting services check could not be verified/validated.", "326"));
				
				
		QUALIFICATION_CONFIG.put("AutopayCouldNotbeDeterminedForHighRiskCustomer", new QualificationConfig(
				"AutopayCouldNotbeDeterminedForHighRiskCustomer", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - High risk customer Autopay status could not be validated/verified", "327"));
				
				
		QUALIFICATION_CONFIG.put("AutopayStatusCouldNotbeDeterminedForHighRiskCustomer", new QualificationConfig(
				"AutopayStatusCouldNotbeDeterminedForHighRiskCustomer", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "High risk customer AutoBill status could not be validated/verified", "328"));
				
				
		QUALIFICATION_CONFIG.put("checkCAPMProfileName", new QualificationConfig(
				"checkCAPMProfileName", "PENDING", "CREDIT_CARD_INFO_NEEDED", "Data Error - CAPM Profile name is not created in the buyflow", "329"));
				
				
		QUALIFICATION_CONFIG.put("checkForChannel", new QualificationConfig(
				"checkForChannel", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Sales Channel is missing", "330"));
				
				
		QUALIFICATION_CONFIG.put("checkForApplication", new QualificationConfig(
				"checkForApplication", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Application Name is missing", "331"));
				
		QUALIFICATION_CONFIG.put("checkForOfferId", new QualificationConfig(
				"checkForOfferId", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Offer ID is missing", "332"));
				
		QUALIFICATION_CONFIG.put("checkForAutoPayment", new QualificationConfig(
				"checkForAutoPayment", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Autopay is not currently supported in unification automation flow", "333"));
				
		QUALIFICATION_CONFIG.put("CheckLPMInfoExists", new QualificationConfig(
				"CheckLPMInfoExists", "PENDING", "AUTOPAY_PAYMENT_METHOD_REQUIRED", "Data Error - Last payment method reference number is missing", "334"));
				
		QUALIFICATION_CONFIG.put("CheckAutopayLPMTermsConditions", new QualificationConfig(
				"CheckAutopayLPMTermsConditions", "PENDING", "AUTOPAY_PAYMENT_METHOD_REQUIRED", "Data Error - Autopay LastPaymentMethod T&amp;C version is missing", "335"));//confusion
				
		QUALIFICATION_CONFIG.put("checkIsRealTimeCalendar", new QualificationConfig(
				"checkIsRealTimeCalendar", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Market not eligible for Gigapower automation", "336"));
				
		QUALIFICATION_CONFIG.put("checkIsPOTSAvailable", new QualificationConfig(
				"checkIsPOTSAvailable", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Existing POTS on order", "337"));
				
		QUALIFICATION_CONFIG.put("checkIsDSLAvailable", new QualificationConfig(
				"checkIsDSLAvailable", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Existing DSL on order", "338"));
				
		
		QUALIFICATION_CONFIG.put("TotalAllowanceMismatch", new QualificationConfig(
				"TotalAllowanceMismatch", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Data Error - Total Data Allowance mismatch found", "339"));
		
		QUALIFICATION_CONFIG.put("AppointmentMatchNotFound", new QualificationConfig(
				"AppointmentMatchNotFound", "IN_QUEUE", "MANUAL_PROVISIONING_REQUIRED", "Appointment match not found", "340"));

		QUALIFICATION_CONFIG.put("CreditCardExists", new QualificationConfig(
				"CreditCardExists", "PENDING", "CREDIT_CARD_INFO_NEEDED", "Data Error - Online - Credit Card Info Needed", "300"));

		QUALIFICATION_CONFIG.put("SalesChannelDoesNotExist", new QualificationConfig(
				"SalesChannelExist", "IN_QUEUE", "MANUAL_PROVISIONG_REQUIRED", "Data Error - Online - Sales Channel not found", "300"));
		
		QUALIFICATION_CONFIG.put("SafeScanVerification", new QualificationConfig(
				"SafeScanVerification", "IN_QUEUE", "MANUAL_PROVISIONG_REQUIRED", "Data Error - Safe Scan Not Verified", "300"));

		QUALIFICATION_CONFIG.put("BillingSystemIndicator", new QualificationConfig(
				"BillingSystemIndicator", "IN_QUEUE", "MANUAL_PROVISIONG_REQUIRED", "Data Error - Billing system indicator is missing", "300"));
		
		QUALIFICATION_CONFIG.put("ProgrammingChangeWithInstallTrue", new QualificationConfig(
				"ProgrammingChangeWithInstallTrue", "IN_QUEUE", "MANUAL_PROVISIONG_REQUIRED", "Data Error - Online - DTV Programming Change with Install", "300"));
	
		QUALIFICATION_CONFIG.put("MultipleInstallmentTermsTrue", new QualificationConfig(
				"MultipleInstallmentTermsTrue", "IN_QUEUE", "MANUAL_PROVISIONG_REQUIRED", "Data Error - Online - Multiple Installment Terms", "300"));

		QUALIFICATION_CONFIG.put("AuthenticationQuestionDoesNotExist", new QualificationConfig(
				"AuthenticationQuestionExist", "PENDING", "CREDIT_INFO_NEEDED", "Data Error - Authentication Question is missing", "300"));
		
		QUALIFICATION_CONFIG.put("DateOfBirthDoesNotExist", new QualificationConfig(
				"DateOfBirthExist", "PENDING", "CREDIT_INFO_NEEDED", "Data Error - Date of Birth is missing", "300"));	
		
		QUALIFICATION_CONFIG.put("DTVReferralExists", new QualificationConfig(
				"DTVReferralExists", "IN_QUEUE", "MANUAL_PROVISIONG_REQUIRED", "Data Error - Online - DTV Referral Account number Missing", "300"));	

		QUALIFICATION_CONFIG.put("MultipleInstallmentBilling", new QualificationConfig(
				"MultipleInstallmentBilling", "IN_QUEUE", "MANUAL_PROVISIONG_REQUIRED", "Order contains multiple installment billing terms", "300"));

		QUALIFICATION_CONFIG.put("InvalidBillingMarketCode", new QualificationConfig(
				"InvalidBillingMarketCode", "QUAL_ERR300", "MANUAL_PROVISIONG_REQUIRED", "Invalid Billing Market Code", ""));		

		QUALIFICATION_CONFIG.put("ServiceAddress for the Order is not available", new QualificationConfig(
				"ServiceAddress for the Order is not available", "IN_QUEUE", "MANUAL_PROVISIONG_REQUIRED", "ServiceAddress for the Order is not available", "300"));
	}

}
