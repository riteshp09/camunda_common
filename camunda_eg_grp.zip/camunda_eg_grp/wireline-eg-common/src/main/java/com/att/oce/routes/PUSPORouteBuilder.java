package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;

import org.springframework.stereotype.Component;
import org.apache.camel.builder.RouteBuilder;
import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.CSIValidateAddressTransformation;
import com.att.oce.transformation.PUSPOTransformation;


@Component("puspoRouteBuilder")
public class PUSPORouteBuilder extends RouteBuilder{

	@Override
	public void configure() throws Exception {		
		from("direct:csi:puspo")
		.bean(PUSPOTransformation.class,"transformWrapper")
		.to("velocity:///vm/PUSPO.vm")
		.wireTap("direct:auditlog:request")
		.to("https://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.wireTap("direct:auditlog:response")
		.bean(PUSPOTransformation.class,"processResponseWrapper")
		.setId("puspoRouteBuilder");
				
	}

}
