package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.EUCPCRequestTransformation;

@Component("EUCPCRouteBuilder")
public class EUCPCRouteBuilder extends RouteBuilder{

	@Override
	public void configure() throws Exception
	{
		from("direct:eucpc")
		.routeId("EUCPCId")
		.bean(EUCPCRequestTransformation.class,"transformWrapper")
		.to("velocity:///vm/EUCPC.vm")
		.wireTap("direct:auditlog:request")
		.to("https://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.wireTap("direct:auditlog:response")
		.bean(EUCPCRequestTransformation.class,"processResponseWrapper");
	}
	
	
}
