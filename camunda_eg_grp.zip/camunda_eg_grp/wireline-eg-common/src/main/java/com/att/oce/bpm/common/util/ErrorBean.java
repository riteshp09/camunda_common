package com.att.oce.bpm.common.util;

import java.io.Serializable;

public class ErrorBean implements Serializable{

	private String errorCode;
	private String errorDescription;
	private NackRef nackRef;
	
	
	
	public ErrorBean(String errorCode, String errorDescription, String type, String idRef) {
		super();
		this.errorCode = errorCode;
		this.errorDescription = errorDescription;
		this.nackRef = new NackRef(type, idRef);
	}
	
	public ErrorBean(String errorCode, String errorDescription) {
		super();
		this.errorCode = errorCode;
		this.errorDescription = errorDescription;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	public NackRef getNackRef() {
		return nackRef;
	}
	public void setNackRef(NackRef nackRef) {
		this.nackRef = nackRef;
	}
	
}
