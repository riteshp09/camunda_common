package com.att.oce.routes;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.RTNTransformation;


@Component("rtnRouteBuilder")
public class RTNRouteBuilder extends RouteBuilder {

	@Override
	public void configure() throws Exception {		
		from("direct:csi:reserveTN")		
		.bean(RTNTransformation.class,"transformWrapper")
		.to("velocity://vm/RTN.vm")
		.wireTap("direct:auditlog:request")
		.to("http://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.wireTap("direct:auditlog:response")
		.bean(RTNTransformation.class,"processResponseWrapper")
		.setId("rtnRouteBuilder");
				
	}

}
