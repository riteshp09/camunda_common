package com.att.oce.bpm.common.util;

import java.io.Serializable;

public class NackRef implements Serializable {
	
	String type;
	String idRef;
	String system;
	
	
	public NackRef(String type, String idRef) {
		super();
		this.type = type;
		this.idRef = idRef;
	}
	
	public NackRef(String type, String idRef, String system) {
		super();
		this.type = type;
		this.idRef = idRef;
		this.system = system;
	}

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getIdRef() {
		return idRef;
	}
	public void setIdRef(String idRef) {
		this.idRef = idRef;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
}