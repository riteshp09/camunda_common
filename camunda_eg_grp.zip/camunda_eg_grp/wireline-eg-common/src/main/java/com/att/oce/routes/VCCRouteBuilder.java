package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.att.oce.transformation.InquireUnifiedServiceAccountRequestTransformation;
import com.att.oce.transformation.ValidateCreditCardTransformation;

@Component("vccRouteBuilder")
public class VCCRouteBuilder extends RouteBuilder {

	@Override
	public void configure() throws Exception
	{
		from("direct:csi:vcc")
		.routeId("VCCId")
		.bean(ValidateCreditCardTransformation.class,"transformWrapper")
		.to("velocity:///vm/VCC.vm")
		.wireTap("direct:auditlog:request")
		.to("https://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.wireTap("direct:auditlog:response") 
		.bean(ValidateCreditCardTransformation.class,"processResponseWrapper");
	}

}
