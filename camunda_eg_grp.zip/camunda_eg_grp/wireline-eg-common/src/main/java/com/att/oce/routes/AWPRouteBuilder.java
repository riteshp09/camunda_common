package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.att.oce.transformation.AddWirelinePaymentTransformation;

@Component("AWPRouteBuilder")
public class AWPRouteBuilder extends RouteBuilder {
	@Override
	public void configure() throws Exception
	{
		from("direct:csi:awp")
		.routeId("AWPId")
		.bean(AddWirelinePaymentTransformation.class,"transformWrapper")
		.to("velocity:///vm/AWP.vm")
		.wireTap("direct:auditlog:request")
		.to("https://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.wireTap("direct:auditlog:response")
		.bean(AddWirelinePaymentTransformation.class,"processResponseWrapper");
	}
}
