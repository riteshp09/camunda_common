package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.InquireAccountProfileTransformation;

@Component("exampleRouteBuilder")
public class ExampleRouteBuilder extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		from("direct:csi:iapx")
		.routeId("exampleId")
		.bean(InquireAccountProfileTransformation.class,"transform")
		.to("velocity:///vm/InquireAccountProfile.vm")
		.bean(AuditLogHelper.class,"logRequest")
		.to("https://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.bean(AuditLogHelper.class,"logResponse")
		.bean(InquireAccountProfileTransformation.class,"processResponse");
	}

}
