package com.att.oce.bpm.common;

import java.util.List;

import edu.emory.mathcs.backport.java.util.Arrays;

public class WirelineConstants {

	public static String SUCCESS_CODE_01 = "01";
	public static String SUCCESS_CODE_02 = "02";
	public static String SUCCESS_CODE_03 = "03";
	public static String SUCCESS_CODE_04 = "04";
	public static String SUCCESS_CODE_05 = "05";
	public static String NOTES = "Notes";

	public static String SUCCESS_CODE_02_NOTES = "Account creation comes with Deposit / Down Payment required.";
	public static String SUCCESS_CODE_02_NO_BAN = "Add Account is successful but BAN information is missing in the response.";

	public static final String HTTP_CONTENT_TYPE_JSON = "application/json";
	public static final String HTTP_METHOD_GET = "GET";
	public static final String HTTP_METHOD_POST = "POST";
	public static final String HTTP_CONTENT_TYPE_XML = "text/xml";

	public static String LOSG_STATUS_CANCELED = "CANCELED";
	public static String LOSG_STATUS_COMPLETED = "COMPLETED";
	public static String LOSG_STATUS_SYS_PROCESSING = "SYS_PROCESSING";
	public static String LOSG_STATUS_SYS_RECEIVED = "SYS_RECEIVED";
	public static String LOSG_STATUS_IN_QUEUE = "IN_QUEUE";

	public static String ORDER_STATUS_COMPLETED = "COMPLETED";

	public static String CHANNEL_CRU_MOB = "CRU-MOBILITY";
	public static final String CHANNEL_SMB = "SMB-WEB-CENTER";

	public static String REQUEST_TYPE_SCR = "SCR";

	public static String GROUP_TYPE_LINE_OF_SERVICE = "LINE_OF_SERVICE";
	public static String GROUP_TYPE = "LINE_OF_SERVICE";

	public static String ACTIONTYPE_TRANSFER_BAN_CHANGES = "TRANSFER_BAN_CHANGES";
	public static String ACTIONTYPE_CCAR_DEENROLLMENT = "CCAR_DEENROLLMENT";
	public static String ACTIONTYPE_UPDATE_SUBSCRIBER = "UPDATE_SUBSCRIBER";

	public static String VMA_MODE = "BSV";

	public static String PRODUCTTYPE_PLAN = "PLAN";

	public static String API_NAME_INQUIRE_CONNECTED_DEVICE_SUMMARY = "InquireConnectedDeviceSummary";
	public static String API_NAME_MOVE_MOBILE_SUBSCRIBER = "MoveMobileSubscriber";
	public static String API_NAME_FRAUD_VALIDATION_SERVICE = "FraudValidation";
	public static String API_NAME_ADD_ACCOUNT = "AddAccount";
	public static String API_NAME_UPDATE_ACCOUNT_PROFILE = "UpdateAccountProfile";
	public static String ACTION_A = "A";
	public static String ACTION_R = "R";
	public static String OFFER_TYPE_G = "G";

	public static String SUCCESS_CODE_0 = "0";
	public static String ERROR_CODE_200 = "200";
	public static String ERROR_CODE_300 = "300";
	public static String ERROR_CODE_400 = "400";
	public static String ERROR_CODE_900 = "900";
	public static String ERROR_CODE_100 = "100";

	public static String CORPORATION = "Corporation";
	public static String PARTNERSHIP = "Partnership";
	public static String SOLE_OWNERSHIP = "Sole Ownership";
	public static String SMALL_BUSINESS_PERSONAL_LIABILITY = "Small Business Personal Liability";

	public static String BUSINESSTYPE_C = "C";
	public static String BUSINESSTYPE_P = "P";
	public static String BUSINESSTYPE_S = "S";
	public static String BUSINESSTYPE_B = "B";

	public static String BUSINESS = "BUSINESS";
	public static String EXCP_CTRL = "EXCP-CTRL";
	public static String GOVERNMENT = "GOVERNMENT";
	public static String INDIVIDUAL = "INDIVIDUAL";
	public static String SPECIAL = "SPECIAL";
	public static String TARGET_BAN = "TARGET BAN FOR SLB (CANNOT HAVE SUBSCRIPTIONS)";
	public static String TELCO_RESELLER = "TELCO RESELLER";

	public static String ACCOUNTTYPE_B = "B";
	public static String ACCOUNTTYPE_E = "E";
	public static String ACCOUNTTYPE_G = "G";
	public static String ACCOUNTTYPE_I = "I";
	public static String ACCOUNTTYPE_S = "S";
	public static String ACCOUNTTYPE_T = "T";
	public static String ACCOUNTTYPE_C = "C";

	public static String DECISIONCODE_CA = "CA";
	public static String DECISIONCODE_AR = "AR";
	public static String DECISIONCODE_PA = "PA";

	public static String SUCCESS = "Sucess";
	public static String ERROR = "Error";
	public static String NOT_APPLICABLE = "NA";

	public static String CreditStatus_APPROVED = "APPROVED";
	public static String CreditStatus_REVIEW = "REVIEW";
	public static String CreditStatus_PENDING = "PENDING";
	public static String LoSGType_NEW = "NEW";
	public static String ProductCategory_WIRELESS = "WIRELESS";
	public static String billDeliveryMethod_X = "X";
	public static String billDeliveryMethod_P = "P";
	public static String BillingDeliveryPreference_PAPERLESS = "PAPERLESS";
	public static String BillingDeliveryPreference_PAPER = "PAPER";
	public static String billingMedia_XM = "XM";
	public static String openChannel_R = "R";
	public static String billingSystemId_T = "T";
	public static String creditApplicationType_NAT = "NAT";
	public static String creditApplicationType_MAJ = "MAJ";
	public static String Attention_Test = "Test";
	public static boolean fieldIndicator_true = true;
	public static String addressType_S = "S";

	public static String CHANNEL_CRU_MOBILITY = "CRU_MOBILITY";
	// public static String REQUEST_TYPE_SCR="SCR";
	// public static String LOSGTYPE_CHANGE ="CHANGE";
	public static String ACTIONTYPE_TRANSFER_BAN = "TRANSFER_BAN";
	// public static String
	// ACTIONTYPE_TRANSFER_BAN_CHANGES="TRANSFER_BAN_CHANGES";
	public static String ACTIONTYPE_REASSIGN_FAN = "REASSIGN_FAN";
	public static String ACTIONTYPE_REASSIGN_FAN_CHANGES = "REASSIGN_FAN_CHANGES";
	public static String AccountSubCategory_NEW = "NEW";
	public static String LoSGStatus_Status_CANCELED = "CANCELED";
	public static String LoSGStatus_Status_COMPLETED = "COMPLETED";
	public static String CamelHttpUri = "CamelHttpUri";
	public static String OceCSIApiName = "OceCSIApiName";

	public static String AccountSubCategory_EXISTING = "EXISTING";

	public static String ACCOUNT = "Account";
	public static String CREDITSTATUS_APPROVED = "APPROVED";
	public static String CREDITSTATUS_REVIEW = "REVIEW";
	public static String CREDITSTATUS_PENDING = "PENDING";
	public static String BILLDELIVERYMETHOD_X = "X";
	public static String BILLDELIVERYMETHOD_P = "P";
	public static String BILLINGDELIVERYPREFERENCE_PAPERLESS = "PAPERLESS";
	public static String BILLINGDELIVERYPREFERENCE_PAPER = "PAPER";
	public static String BILLINGMEDIA_XM = "XM";
	public static String OPENCHANNEL_R = "R";
	public static String BILLINGSYSTEMID_T = "T";
	public static String CREDITAPPLICATIONTYPE_NAT = "NAT";
	public static String CREDITAPPLICATIONTYPE_MAJ = "MAJ";
	public static boolean FIELDINDICATOR_TRUE = true;
	public static String ADDRESSTYPE_S = "S";
	public static String BILLING_CYCLE_0 = "0";
	// public static String API_NAME_ADD_ACCOUNT="AddAccount";
	// public static String CHANNEL_CRU_MOBILITY = "CRU_MOBILITY";
	public static String OCE_CSI_API_NAME = "OceCSIApiName";
	public static String BILLING_ACCOUNT_NUMBER = "BillingAccountNumber";
	public static String DEPOSIT_AMOUNT = "DepositAmount";
	public static String CCMTRANSACTION_ID = "CCMTransactionID";
	public static String CREDIT_CLASS = "CreditClass";
	public static String CREDITSTATUS = "CreditStatus";
	public static String ADD_ACCOUNT_GUID = "AddAccountGUID";
	public static String REASON_CODE = "ReasonCode";
	public static String CREDIT_CHECK = "creditCheck";

	// IMSP - Constants
	public static String IMSP_MODE = "D";

	// Constants
	public static final String STRING_ZERO = "0";
	public static final String STRING_EMPTY = "";

	public static final String STRING_YES = "YES";
	public static final String STRING_NO = "NO";
	public static final String STRING_CANCEL = "CANCEL";
	public static final String STRING_FALSE = "false";
	public static final String STRING_TRUE = "true";
	public static final String SOURCE_SYSTEM_HARDROCK = "HARDROCK";
	public static final String QualificationLevel = "";
	/* Group Type Enumerations */
	public static final String GROUPTYPE_BUNDLE = "BUNDLE";
	public static final String GROUPTYPE_PACKAGE = "PACKAGE";
	public static final String CATEGORY_OFFER = "OFFER";
	public static final String GROUPTYPE_SHARED_PLAN = "SHARED_PLAN";
	public static final String GROUPTYPE_INCLUDED = "INCLUDED";
	public static final String GROUPTYPE_LINE_OF_SERVICE = "LINE_OF_SERVICE";
	public static final String GROUPTYPE_SUBORDINANT = "SUBORDINANT";
	/* Contract Type Enumerations */
	public static final String CONTRACTTYPE_SHARED = "SHARED";
	public static final String CONTRACTTYPE_LEASE = "LEASE";
	public static final String CONTRACTTYPE_INSTALLMENT = "INSTALLMENT";
	public static final String CONTRACTTYPE_NOCOMMIT = "NOCOMMIT";
	public static final String CONTRACTTYPE_REGULAR = "REGULAR";
	public static final String ORDER_EQUIPMENT_NEW_CONTRACTYPE_REGULAR = "REGULAR";
	/* Upgrade Type Enumerations */
	public static final String UPGRADETYPE_REGULAR = "REGULAR";
	public static final String UPGRADETYPE_EARLY = "EARLY";
	public static final String UPGRADETYPE_SHARED = "SHARED";
	/* OfferCategory Enumerations */
	public static final String OFFERCATEGORY_STANDARD_STD = "STD";
	public static final String OFFERCATEGORY_IPHONE_IPH = "IPH";
	public static final String OFFERCATEGORY_NEXT_NE = "NE";
	public static final String OFFERCATEGORY_INSTALLMENT_PLAN_IP = "IP";
	public static final String OFFERCATEGORY_EARLY_STANDARD_E_STD = "E_STD";
	public static final String OFFERCATEGORY_EARLY_IPHONE_E_IPH = "E_IPH";
	public static final String OFFERCATEGORY_SHARED_UPGRADE_SHR = "SHR";
	public static final String OFFERCATEGORY_SP = "SP";
	public static final String OFFERCATEGORY_EIP = "EIP";
	public static final String OFFERCATEGORY_E_EIP = "E_EIP";
	public static final String DIRECT_FULLFILMENT = "DF";
	public static final String ACTIVATION_FULLFILMENT = "ACTIVATION";
	/* Contract Extended Enumerations */
	public static final String CONTRACTEXTENDED_FAILURE = "FAILURE";
	public static final String CONTRACTEXTENDED_PENDING = "PENDING";
	public static final String CONTRACTEXTENDED_SUCCESS = "SUCCESS";
	public static final String CONTRACTEXTENDED_NOT_REQUIRED = "NOT_REQUIRED";
	/* Relationship Enumerations */
	public static final String RELATIONSHIP_DONOR = "DONOR";
	public static final String RELATIONSHIP_RECIPIENT = "RECIPIENT";
	/* HardGoodType Enumerations */
	public static final String HARDGOODTYPE_DEVICE = "DEVICE";
	public static final String HARDGOODTYPE_SIM = "SIM";
	public static final String HARDGOODTYPE_COLLATERAL = "COLLATERAL";
	public static final String HARDGOODTYPE_ACCESS = "ACCESSORY";
	public static final String HARDGOODTYPE_ACCESSORY = "ACCESSORY";
	/* LoSG Type Enumerations */
	public static final String LOSGTYPE_CHANGE = "CHANGE";
	public static final String LOSGTYPE_UP = "UP";
	public static final String LOSGTYPE_NEW = "NEW";
	public static final String LOSGTYPE_UNIFY = "UNIFY";
	public static final String LOSGTYPE_AL = "AL";
	public static final String LOSGTYPE_ALF = "ALF";
	public static final String LOSGTYPE_ACC = "ACC";
	public static final String LOSGTYPE_DEVICE = "DEVICE";
	/* LoSG Status Enumerations */
	public static final String LOSGSTATUS_CANCELED = "CANCELED";
	/* Post Production Enhancement - OCE-180-0080 */
	public static final String LOSGSTATUS_SYS_HOLD = "SYS_HOLD";
	public static final String LOSGSTATUS_CANCELLED = "CANCELLED";
	public static final String LOSGSTATUS_COMPLETED = "COMPLETED";
	/* Product Type Enumerations */
	public static final String PRODUCTTYPE_OPTIONAL_FEATURE = "OPTIONAL_FEATURE";
	public static final String PRODUCTTYPE_HARDGOOD = "HARDGOOD";
	public static final String PRODUCTTYPE_MISC_CHARGE = "MISC_CHARGE";
	public static final String PRODUCTTYPE_PDP = "PDP";
	public static final String PRODUCTTYPE_INCLUDED_FEATURE = "INCLUDED_FEATURE";
	public static final String SYSTEMNAME_NONCOMPLIANCEFEE = "NON_COMPLIANCE_FEE";
	public static final String DISPLAYNAME_SHIPPINGFEE = "SHIPPING_FEE";
	public static final String SYSTEMNAME_ACTIVATION_FEE = "ACTIVATION_FEE";
	/* Product Category Enumerations */
	public static final String PRODUCTCATEGORY_WIRELESS = "WIRELESS";
	/* Action Code Enumerations */
	public static final String ACTION_ADD = "ADD";
	public static final String ACTION_REMOVE = "REMOVE";
	public static final String ACTION_NO_CHANGE = "NO_CHANGE";
	/* Line Item Action Code Enumerations */
	public static final String LINEITEM_ACTION_ADD = "ADD";
	public static final String LINEITEM_ACTION_REMOVE = "REMOVE";
	public static final String LINEITEM_STATUS_CANCELED = "CANCELED";
	/* Billing Deliver Preference Enumerations */
	public static final String BILLDELIVERY_PAPERLESS = "PAPERLESS";
	public static final String BILLDELIVERY_PAPER = "PAPER";
	/* DoNotMailBillIndicatorInfo from Cingular Data model Enumerations */
	/*
	 * Print and Hold = P, No Bill Printed = X, No Bill Presented Online = E,N =
	 * Bill will be printed.
	 */
	public static final String DONOTMAILBILLINDICATORINFO_PRINT_HOLD = "P";
	public static final String DONOTMAILBILLINDICATORINFO_NO_PRINT = "X";
	public static final String DONOTMAILBILLINDICATORINFO_NO_ONLINE = "E";
	public static final String DONOTMAILBILLINDICATORINFO_BILL_PRINT = "N";
	/* BillingMedia , XM indicates Paperless and PA for Paper */
	public static final String UAP_BillingMedia_Paperless = "XM";
	public static final String UAP_BillingMedia_Paper = "PA";
	/* Activate On Fulfillment */
	public static final String OE_ACTIVATE_ON_FULFILLMENT_UPGRADE = "U";
	public static final String OE_ACTIVATE_ON_FULFILLMENT_NEW = "A";
	public static final String OE_ACTIVATE_ON_FULFILLMENT_DONORSIM = "W";
	/* EnterPrise Preferences */
	public static final String ENTERPRISE_TYPE_IRU = "IRU";
	/* OE Language Preferences */
	public static final String OE_LANG_PREF_ENGLISH = "E";
	/* Default Sales Channel used for OCE */
	public static final String IEUCE_SALES_CHANNEL = "S9";
	/* Billing System Id for Telegence */
	public static final String UAP_BillingSystemId = "T";
	/* IsParked for Upgrade Equipment success */
	public static final boolean IS_PARKED_true = true;
	/* IsCrossUpgrade for SharedUpgrade */
	public static final boolean Boolean_TRUE = true;
	public static final boolean Boolean_FALSE = false;
	public static final boolean Boolean_Value_TRUE = true;
	/* Defaults for Add Note API */
	public static final String ADD_NOTES_AccountType_Billing = "Billing";
	public static final String ADD_NOTES_NoteType_CSM = "CSM";
	public static final String ADD_NOTES_Priority_Regular = "R";
	/* Defaults for Upgrade Equipment API */
	public static final String UPGRADE_EQUIPMENT_BillingSystemId_TLG = "T";
	public static final String UPGRADE_EQUIPMENT_ActivateUpgrade = "activate.upgrade";
	public static final String UPGRADE_EQUIPMENT_Park_Agreement = "parkType.ParkAgreement";
	public static final String UPGRADE_EQUIPMENT_Park_Equipment = "parkType.ParkEquipmentImeiTypeDF";
	public static final String UPGRADE_EQUIPMENT_IgnoreWarningMessageIndicator = "ignore.warning.message.indicator";
	public static final String UPGRADE_EQUIPMENT_ReasonCode_EARLY = "reason.Code.Early";
	public static final String UPGRADE_EQUIPMENT_ReasonCode_REGULAR = "reason.Code.Regular";
	public static final String UPGRADE_EQUIPMENT_ContractCode_EARLY = "contract.Code.Early";
	public static final String UPGRADE_EQUIPMENT_ContractCode_REGULAR = "contract.Code.Regular";
	public static final String UPGRADE_EQUIPMENT_TermsConditionStatus_WAIT = "terms.Conditions.Waiting";
	public static final String UPGRADE_EQUIPMENT_TYPE = "EquipmentTypeUE.";
	public static final String UPGRADE_EQUIPMENT_ContractFreeParkingIndicator_true = "contract.Free.Parking.Indicator";
	public static final String UPGRADE_EQUIPMENT_NewSalesChannel_S9 = "newSalesChannel";
	public static final String API_UPGRADE_EQUIPMENT = "UpgradeEquipment";
	public static final String API_UPGRADE_EQUIPMENT_SIM = "UpgradeEquipmentContractFree";
	public static final String API_VALIDATEADDRESS = "ValidateAddress";
	/* Prefixes for Order Data Model to CSI Enum translation */
	public static final String ODM_ACCOUNT_TYPE = "AccountType.";
	public static final String ODM_CREDIT_CARD_TYPE = "CreditCardType.";
	public static final String ODM_ADDRESS_TYPE = "AddressType.";
	public static final String GROUP_PLAN_TYPE_FMLY_TALK = "FAMILY_TALK";
	public static final String GROUP_PLAN_TYPE_MOBL_SHARE = "MOBILE_SHARE";
	public static final String OFFER_TYPE_GROUP = "G";
	public static final String OFFER_TYPE_PLAN = "P";
	public static final String OFFER_TYPE_U = "U";
	public static final String RETRY_SUFFIX = ".retry";
	public static final String IGNORE_SUFFIX = "_IGNORE";
	public static final String MANUAL_SUFFIX = "_MANUAL";
	public static final String MANUAL_DONE_SUFFIX = ".manual.done";
	public static final String ERROR_API_NAME = "error.handler.apiname";
	public static final String API_UPDATE_ACCOUNT_PROFILE = "UpdateAccountProfile";
	public static final String API_UPDATE_SHARE_DATA_GROUP_PROFILE = "UpdateSharedDataGroupProfile";
	public static final String API_UPDATE_SUBSCRIBER_PROFILE = "UpdateSubscriberProfile";
	public static final String CANCEL_EQUIPMENT_UPGRADE_MODE = "R";
	public static final String CANCEL_EQUIPMENT_UPGRADE_CANCEL_REASON_CODE = "SEE0";
	public static final String CANCEL_EQUIPMENT_UPGRADE_SALES_CHANNEL = "S9";
	public static final String USP_ACTION_ADD = "A";
	public static final String USP_ACTION_REMOVE = "R";
	public static final String USP_ADDRESS_TYPE = "S";
	public static final String USP_FIELD_INDICATOR = "true";
	public static final String USP_CONTACTPHONETYPE_WORK = "WORK_PHONE";
	public static final String USP_CONTACTPHONETYPE_HOME = "HOME_PHONE";
	public static final String USP_CONTACTPHONETYPE_CELL = "CELL_PHONE";
	public static final String USP_COMPLEX_DISCOUNT_INDICATOR = "true";
	public static final String USP_ADDITIONAL_DETAILS_CODE = "AdjustmentCode";
	public static final String USP_ADDITIONAL_DETAILS_CODE_TYPE = "Type";
	public static final String USP_ADDITIONAL_DETAILS_CODE_VALUE = "BOP3";
	public static final String USP_ADDITIONAL_DETAILS_CODE_NEXTPROMO_VALUE = "NEXTPROMO";
	public static final String USP_ADDITIONAL_DETAILS_CODE_PROMO = "IS_PROMO_APPLIED";
	public static final String USP_ADDITIONAL_DETAILS_CODE_VALUE_BOOLEAN_TRUE = "TRUE";
	public static final String USP_ADDITIONAL_DETAILS_CODE_VALUE_BOOLEAN_FALSE = "FALSE";
	/* Plan related Data */
	public static final String ISP_RECUR_CHARGE = ".recurringCharge";
	public static final String ISP_SINGLE_USER_CODE = ".singleUserCode";
	public static final String ISP_GRP_PLAN_CODE = ".groupPlanCode";
	public static final String ISP_GRP_PRIMARY_SUBSCRIBER = ".primarySubscriber";
	public static final String REMOVE_OFERING_CODE_G = "G";
	/* Defaults for Order Equipment API */
	public static final String ORDERSTATUS_TO_BE_SHIPPED = "P";
	public static final String MINIMUM_NUMBER_OF_MONTHS = "0";
	public static final String ORDER_EQUIPMENT_LOCATIONID_EMPTY = "K004";
	public static final String ORDER_EQUIPMENT_LOCATIONID_DF_NON_LNP = "K034";
	public static final String ORDER_EQUIPMENT_LOCATIONID_DF_LNP = "K036";
	public static final String ORDER_EQUIPMENT_LIABILITY_TYPE = "CORPORATE";
	public static final String ORDER_EQUIPMENT_LIABILITY_TYPE_CORPORATE = "CORPORATE";
	public static final String ORDER_EQUIPMENT_EXTERNAL_ORDER_SOURCE = "EST";
	public static final String ORDER_EQUIPMENT_EXTERNAL_ORDER_SOURCE_CORPORATE = "PRE";
	public static final String ORDER_EQUIPMENT_EXTERNAL_ORDER_SOURCE_SALES = "EBM";
	public static final String ORDER_EQUIPMENT_OPERATORID = "ESTORE";
	public static final String ORDER_EQUIPMENT_OPERATORID_CORPORATE = "OCE";
	public static final String ORDER_EQUIPMENT_ADDRESSTYPE = "S";
	public static final String ORDER_EQUIPMENT_FIELD_INDICATOR = "false";
	public static final String ORDER_EQUIPMENT_PRIMARY_ADDRESS_INDICATOR = "true";
	public static final String ORDER_EQUIPMENT_NO_PAYMENT_INDICATOR = "true";
	public static final String ORDER_EQUIPMENT_SERVICE_CONTRACT_BUNDLING_Y = "true";
	public static final String ORDER_EQUIPMENT_SERVICE_CONTRACT_BUNDLING_N = "false";
	public static final String ORDER_EQUIPMENT_SERVICE_CONTRACT_BUNDLING = "true";
	public static final String ORDER_EQUIPMENT_SERVICE_CONTRACT_BUNDLING_NOCOMMIT = "false";
	public static final String ORDER_EQUIPMENT_SERVICE_CONTRACT_BUNDLING_YES = "Y";
	public static final String ORDER_EQUIPMENT_SERVICE_CONTRACT_BUNDLING_NO = "N";
	public static final String ORDER_EQUIPMENT_CREDITCARD_BILLINGADDRESS_ADDRESSTYPE = "S";
	public static final String ORDER_EQUIPMENT_NO_ADDRESS_VALIDATION = "false";
	public static final String ORDER_EQUIPMENT_CREDITDEBITINDICATOR_CREDIT_CARD = "8";
	public static final String ORDER_EQUIPMENT_OVERRIDE_BILLING_ZIPCHECK = "0";
	public static final String ORDER_EQUIPMENT_OVERRIDE_BILLING_ZIPCHECK_TRUE = "1";
	public static final String ORDER_EQUIPMENT_RECORD_FORMAT_ECOMMERCE = "H";
	public static final String ORDER_EQUIPMENT_COUNTRY = "US";
	public static final String ORDER_EQUIPMENT_COUNTRY_PR = "PR";
	public static final String ZERO_AMOUNT = "0.0";
	public static final float TAX_LIMIT = 0.0f;
	public static final String ORDER_EQUIPMENT_NOPAYMENT_INDICATOR = "true";
	public static final String ORDER_EQUIPMENT_ORDER_WAREHOUSE = "ZMDC";
	public static final String ORDER_EQUIPMENT_LINETYPE_UPGRADE = "U";
	public static final String ORDER_EQUIPMENT_LINETYPE_NEW = "S";
	public static final String ORDER_EQUIPMENT_MODE_WITH_TRADEIN = "E";
	public static final String ORDER_EQUIPMENT_MODE_WITHOUT_TRADEIN = "C";
	public static final String ORDER_EQUIPMENT_UPGRADE = "U";
	public static final String ORDER_EQUIPMENT_NEW = "S";
	public static final String ORDER_EQUIPMENT_LANGUAGEPREFERENCE_ENGLISH = "E";
	public static final String ORDER_EQUIPMENT_TERMSCONDITIONSTATUS = "W";
	public static final String ORDER_EQUIPMENT_PRECONDITION_SUBSTATUS = "UPGRADE_EQUIPMENT_PASS";
	public static final String ORDER_EQUIPMENT_PRECONDITION_SUBSTATUS_SIM = "UPGRADE_EQUIPMENT_SIM_PASS";
	public static final String ORDER_EQUIPMENT_CLAIMINDICATOR_TRUE = "true";
	public static final String ORDER_EQUIPMENT_RETURNQUANTITY = "-1";
	public static final String ORDER_EQUIPMENT_PRIMARYSUBSCRIBER = "false";
	public static final String ORDER_EQUIPMENT_PRIMARYSUBSCRIBER_F = "false";
	public static final String ORDER_EQUIPMENT_PRIMARYSUBSCRIBER_T = "true";
	public static final String ORDER_EQUIPMENT_OFFERTYPE = "G";
	public static final String ORDER_EQUIPMENT_CONTACTPHONETYPE_HOME = "HOME_PHONE";
	public static final String ORDER_EQUIPMENT_CONTACTPHONETYPE_WORK = "WORK_PHONE";
	public static final String ORDER_EQUIPMENT_CONTACTPHONETYPE_CELL = "CELL_PHONE";
	public static final String ORDER_EQUIPMENT_CONTACTPHONETYPE_OTHER = "OTHER";
	public static final String ORDER_EQUIPMENT_ACCOUNT_CATEGORY = "MOBILITY_ACCOUNT";
	public static final String ORDER_EQUIPMENT_CREDITCARD_TYPE_AE = "AE";
	public static final String ORDER_EQUIPMENT_CREDITCARD_TYPE_DISC = "DISC";
	public static final String ORDER_EQUIPMENT_CREDITCARD_TYPE_MC = "MASTERCARD";
	public static final String ORDER_EQUIPMENT_CREDITCARD_TYPE_DINE = "DINE";
	public static final String ORDER_EQUIPMENT_PARTNERCODE = "CitibankAquisition";
	public static final String ORDER_EQUIPMENT_ORDERSTATUS_PENDING = "P";
	public static final String ORDER_EQUIPMENT_ACTIVATE_ON_FULFILLMENT_UPGRADE = "U";
	public static final String ORDER_EQUIPMENT_CROSS_UPGRADE_INDICATOR = "true";
	public static final String ORDER_EQUIPMENT_CROSS_PRINT_CONTRACT = "false";
	public static final String ORDER_EQUIPMENT_PRIMARY_SUBSCRIBER = "false";
	public static final String ORDER_EQUIPMENT_PRINT_CONTRACT = "false";
	public static final String ORDER_EQUIPMENT_DUE_AMOUNT = "0.00";
	public static final String ORDER_EQUIPMENT_SHIPPING_STATE_CA = "CA";
	public static final String ORDER_EQUIPMENT_SHIPPING_STATE_NV = "NV";
	public static final String ORDER_EQUIPMENT_SHIPPING_STATE_MA = "MA";
	public static final String ORDER_EQUIPMENT_SHIPPING_STATE_LA = "LA";
	public static final String SYSTEMNAME_SHIPPINGFEE = "SHIPPING_FEE";
	public static final String ORDER_EQUIPMENT_PROFILE_DETAILS_LOCATION = "CS";
	public static final String ORDER_EQUIPMENT_PROFILE_DETAILS_SYSTEM = "HARDROCK";
	public static final String ORDER_EQUIPMENT_IS_SAVED_PROFILE_TRUE = "true";
	public static final String ORDER_EQUIPMENT_SAVE_PROFILE_INDICATOR_TRUE = "true";
	public static final String ORDER_EQUIPMENT_SAVE_PROFILE_INDICATOR_FALSE = "false";
	public static final String ORDER_EQUIPMENT_IS_GIFT_CARD_TRUE = "true";
	public static final String ORDER_EQUIPMENT_SALES_REPRESENTATIVE = "Z0066";
	/* Defaults for IIO API */
	public static final String DUPLICATE_FEATURE_CODE_F = "F";
	public static final String SOC_RELATION_CODE_I = "I";
	public static final String IIO_MODE = "AEC";
	/* Defaults for CWP API */
	public static final String SOURCE_SYSTEM_ORDERGW = "HARDROCK";
	public static final String SOURCE_LOCATION_CS = "CS";
	public static final String SOURCE_USER_OCE = "OCE";
	/* NEW constants */
	
	public static final String CONFLICT_FLAG = "true";
	
	/* Account Category Enumerations */
	public static final String ACCOUNTCATEGORY_MOBILITY_ACCOUNT = "MOBILITY_ACCOUNT";
	public static final String ACCOUNTCATEGORY_UNIFIED_ACCOUNT = "UNIFIED_ACCOUNT";
	public static final String ACCOUNTCATEGORY_WIRELINE_ACCOUNT = "WIRELINE_ACCOUNT";
	public static final String ACCOUNTCATEGORY_UVERSE_ACCOUNT = "UVERSE_ACCOUNT";
	/* Account SubCategory Enumerations */
	public static final String ACCOUNTSUBCATEGORY_NEW = "NEW";
	public static final String ACCOUNTSUBCATEGORY_EXISTING = "EXISTING";
	public static final String ACCOUNT_PAYMENTARRANGEMENT_POSTPAID = "POSTPAID";
	public static final String ACCOUNT_PAYMENTARRANGEMENT_PREPAID = "PREPAID";
	public static final String LINEITEM_HARDGOOD_EQUIPMENT_GPRS = "GPRS";
	public static final String LINEITEM_HARDGOOD_EQUIPMENT_GPRS_G = "G";
	public static final String LINEITEM_HARDGOOD_EQUIPMENT_GPRS_E = "E";
	/* Credit Type Enumerations */
	public static final String PAYMENT_CREDIT_TYPE_AE = "AE";
	public static final String PAYMENT_CREDIT_TYPE_DISC = "DISC";
	public static final String PAYMENT_CREDIT_TYPE_MC = "MC";
	public static final String PAYMENT_CREDIT_TYPE_DINE = "DINE";
	/* Payment method enumerations */
	public static final String PAYMENT_METHOD_CREDIT_CARD = "CreditCard";
	/* Equipment Type Enumerations */
	public static final String EQUIPMENT_TYPE_GPRS = "G";
	public static final String EQUIPMENT_TYPE_EDGE = "E";
	public static final String LINEITEM_SYSTEM_NAME_DEPOSIT_FEE = "DEPOSIT_FEE";
	public static final String LINEITEM_DISPLAY_NAME_AUTO_PAY = "AUTO_PAYMENT";
	/* Payment Source System,User,Location Enumerations */
	public static final String PAYMENT_SOURCE_SYSTEM_HARDROCK = "HARDROCK";
	public static final String PAYMENT_SOURCE_SYSTEM_PREMIER = "PREMIER";
	public static final String PAYMENT_SOURCE_USER_HARDROCK="HARDROCK";
	public static final String PAYMENT_SOURCE_USER_OCE = "OCE";
	public static final String PAYMENT_SOURCE_LOCATION_CS = "CS";
	/* OFFER TYPE Enumerations */
	public static final String LINEITEM_OFFER_TYPE_B = "B";
	public static final String LINEITEM_OFFER_TYPE_G = "G";
	/* LOSGSTATUS Enumerations */
	public static final String LOSGSTATUS_SYS_PROCESSING = "SYS_PROCESSING";
	public static final String LOSGSTATUS_PENDING = "PENDING";
	public static final String LOSGSTATUS_IN_QUEUE = "IN_QUEUE";
	public static final String LOSGSTATUS_SUBMITTED = "SUBMITTED";
	public static final String LOSG_MANUAL_PROVISIONING_REQUIRED = "MANUAL_PROVISIONING_REQUIRED";
	/* LOSGSUBGSTATUS Enumerations */
	public static final String LOSGSUBSTATUS_MULTIPLE_AUTHORIZED_USERS = "MULTIPLE_AUTHORIZED_USERS";
	public static final String LOSGSUBSTATUS_ADD_ACCOUNT_VALIDATION_PASS = "ADD_ACCOUNT_VALIDATION_PASS";
	public static final String LOSGSUBSTATUS_ADD_ACCOUNT_DEPOSIT_REQUIRED = "DEPOSIT_REQUIRED";
	public static final String LOSGSUBSTATUS_ADD_ACCOUNT_DEPOSIT_WAIVER_REQUEST = "DEPOSIT_WAIVER_REQUEST";
	public static final String LOSGSUBSTATUS_ADD_ACCOUNT_CREDIT_REVIEW_RULE_REQUIRED = "CREDIT_REVIEW_RULE_REQUIRED";
	public static final String LOSGSUBSTATUS_ADD_ACCOUNT_DOWN_PAYMENT_REQUIRED = "DOWN_PAYMENT_REQUIRED";
	public static final String LOSGSTATUS_CUSTOMER_REQUEST_HUB = "CUSTOMER_REQUEST_HUB";
	public static final String ORDERTYPE_CREATE = "CREATE";
	/* Inquire Port ELigibility Enumerations */
	public static final String INQUIRE_PORT_ELIGIBILTY_BILING_SYSTEM_ID = "TLG";
	public static final String INQUIRE_PORT_ELIGIBILTY_RELAXED_MARKET_COVERAGE_INDICATOR = "true";
	public static final String INQUIRE_PORT_ELIGIBILTY_PASS = "INQUIRE_PORT_ELIGIBLITY_BY_SUBSCRIBER_PASS";
	public static final String INQUIRE_PORT_ELIGIBILTY_SKIPPED = "INQUIRE_PORT_ELIGIBLITY_SKIPPED";
	public static final String INQUIRE_PORT_ELIGIBILTY_PORT_INELIGIBLE = "PORT_INELIGIBLE";
	/* Inquire Port Eumerations */
	public static final String INQUIRE_PORT_DESCRIPTION_6C = "La información del cliente no coincide";
	public static final String INQUIRE_PORT_DESCRIPTION_8A = "El ospBillingAccountNumber, es incorrecto o no se ha indicado";
	public static final String INQUIRE_PORT_DESCRIPTION_8B = "El SSN/businessTaxId es incorrecto o no se ha indicado";
	public static final String INQUIRE_PORT_DESCRIPTION_8C = "La ospBillingAccountPassword es incorrecta o no se ha indicado";
	public static final String INQUIRE_PORT_DESCRIPTION_8D = "El zipCode es incorrecto o no se ha indicado";
	public static final String INQUIRE_PORT_DESCRIPTION_8E = "El nombre es incorrecto o no se ha indicado";
	public static final String INQUIRE_PORT_DESCRIPTION_8F = "El apellido es incorrecto o no se ha indicado";
	public static final String INQUIRE_PORT_DESCRIPTION_8G = "El nombre de la empresa es incorrecto o no se ha indicado";
	/* Add Port Enumerations */
	public static final String ADD_PORT_BILING_SYSTEM_ID = "T";
	public static final String ADD_PORT_DIRECTION = "B";
	public static final String ADD_PORT_TERMS_CONDITION_STATUS = "W";
	public static final String ADD_PORT_REQUEST_LINE_ID = "1";
	public static final String ADD_PORT_FIELD_INDICATOR = "false";
	/* Order Equipment NEW Enumerations */
	public static final String ORDER_EQUIPMENT_NEW_ORDER_STATUS_PREPAID = "P";
	public static final String ORDER_EQUIPMENT_NEW_ORDER_STATUS_OPEN = "O";
	public static final String ORDER_EQUIPMENT_NEW_PORT_STATUS = "A";
	public static final String ORDER_EQUIPMENT_NEW_PRODUCTTYPE = "MISC_CHARGE";
	public static final String ORDER_EQUIPMENT_NO_PAYMENT_INDICATOR_T = "true";
	public static final String ORDER_EQUIPMENT_NEW_SYSTEMNAME = "SHIPPING_FEE";
	public static final String ORDER_EQUIPMENT_NEW_ORDER_DUEAMOUNT = "0.00";
	public static final String ORDER_EQUIPMENT_NEW_ORDER_DUEAMOUNT_CONFIG = "0.00";
	public static final String ORDER_EQUIPMENT_NEW_ACTIVATE_ON_FULL = "Y";
	public static final String ORDER_EQUIPMENT_NEW_LOCATIONID = "K004";
	public static final String ORDER_EQUIPMENT_NEW_LNP_LOCATIONID = "K036";
	public static final String ORDER_EQUIPMENT_NEW_NONLNP_LOCATIONID = "K034";
	public static final String ORDER_EQUIPMENT_NEW_PAYMENTMETHOD_CREDIT = "CreditCard";
	public static final String ORDER_EQUIPMENT_NEW_PAYMENTMETHOD_CAPM = "CAPM";
	public static final String ORDER_EQUIPMENT_NEW_STATE_CA = "CA";
	public static final String ORDER_EQUIPMENT_NEW_STATE_NV = "NV";
	public static final String ORDER_EQUIPMENT_NEW_STATE_LA = "LA";
	public static final String ORDER_EQUIPMENT_NEW_STATE_MA = "MA";
	public static final String ORDER_EQUIPMENT_NEW_PARTNERCODE = "CitibankAquisition";
	public static final String ORDER_EQUIPMENT_NEW_PRICETYPE = "DueToday";
	public static final String ORDER_EQUIPMENT_NEW_SERVICE_CONTRACT_Y = "Y";
	public static final String ORDER_EQUIPMENT_NEW_SERVICE_CONTRACT_N = "N";
	public static final String ORDER_EQUIPMENT_NEW_HARDGOODTYPE_DEVICE = "DEVICE";
	public static final String ORDER_EQUIPMENT_NEW_HARDGOODTYPE_SIM = "SIM";
	public static final String ORDER_EQUIPMENT_NEW_HARDGOODTYPE_COLLATERAL = "COLLATERAL";
	public static final String ORDER_EQUIPMENT_NEW_HARDGOODTYPE_ACCESSORY = "ACCESSORY";
	public static final String ORDER_EQUIPMENT_NEW_LINE_TYPE = "S";
	public static final String ORDER_EQUIPMENT_NEW_ACTIVATE_ON_FULFILLMENT = "Y";
	public static final String ORDER_EQUIPMENT_NEW_LANGUAGE = "E";
	public static final String ORDER_EQUIPMENT_NEW_PRODUCT_CATEGORY = "WIRELESS";
	public static final String ORDER_EQUIPMENT_NEW_RECORD_FORMAT = "H";
	public static final String ORDER_EQUIPMENT_NEW_OPERATORID = "ESTORE";
	public static final String ORDER_EQUIPMENT_NEW_EXTERNAL_ORDER_SOURCE = "EST";
	public static final String ORDER_EQUIPMENT_NEW_ADDRESSTYPE = "S";
	public static final String ORDER_EQUIPMENT_NEW_FIELD_INDICATOR = "false";
	public static final String ORDER_EQUIPMENT_NEW_PRIMARY_ADDRESS_INDICATOR = "true";
	public static final String ORDER_EQUIPMENT_NEW_SERVICE_CONTRACT_BUNDLING = "true";
	public static final String ORDER_EQUIPMENT_NEW_ACCOUNT_TYPE = "I";
	public static final String ORDER_EQUIPMENT_NEW_CREDITCARD_TYPE_AE = "AMERICAN_EXPRESS";
	public static final String ORDER_EQUIPMENT_NEW_CREDITCARD_TYPE_DISC = "DISCOVER";
	public static final String ORDER_EQUIPMENT_NEW_CREDITCARD_TYPE_MC = "MASTERCARD";
	public static final String ORDER_EQUIPMENT_NEW_CREDITCARD_TYPE_DINE = "DINE";
	public static final String ORDER_EQUIPMENT_NEW_CREDIT_DEBIT_INDICATOR = "8";
	public static final String ORDER_EQUIPMENT_NEW_OVERRIDE_BILLING_ZIP_CHECK = "true";
	public static final String ORDER_EQUIPMENT_NEW_ORDER_WAREHOUSE = "ZMDC";
	public static final String ORDER_EQUIPMENT_NEW_LINETYPE = "U";
	public static final String ORDER_EQUIPMENT_NEW_MODE = "C";
	public static final String ORDER_EQUIPMENT_NEW_DEVICE_SUBSCRIBERNUM = "0000000001";
	/* Reserve Subscriber Number Enumerations */
	public static final String RESERVE_SUBSCRIBER_NUMBER_QUANTITY_OF_SUBSCRIBER_NUMBERS = "1";
	/* Add Wireline Payment Enumerations */
	public static final String ADD_WIRELINE_PAYMENT_FLAG = "true";
	public static final String ADD_WIRELINE_PAYMENT_SOUCE_SYSTEM = "DROCK";
	public static final String ADD_WIRELINE_PAYMENT_SOUCE_LOCATION = "CS";
	public static final String ADD_WIRELINE_PAYMENT_SOUCE_USER = "DROCK";
	public static final String ADD_WIRELINE_PAYMENT_MONETARYUNIT = "UNITEDSTATES_DOLLAR";
	public static final String ADD_WIRELINE_PAYMENT_PAYMENT_ITEM_CATEGORY = "APMT";
	public static final String ADD_WIRELINE_PAYMENT_PROVIDER = "LS";
	public static final String ADD_WIRELINE_PAYMENT_SYSTEM = "LS";
	public static final String ADD_WIRELINE_PAYMENT_SOURCE_LOCATION = "CS";
	public static final String ADD_WIRELINE_PAYMENT_ENTERPRISE_TYPE = "CON";
	public static final String ADD_WIRELINE_PAYMENT_MERCHANID = "MYWORLD";
	public static final String ADD_WIRELINE_PAYMENT_DEPOSIT_PAID = "PAID";
	public static final String ADD_WIRELINE_PAYMENT_DEPOSIT_WAIVED = "WAIVED";
	public static final String ADD_WIRELINE_PAYMENT_MERCHANTID_ORDERGWCon = "ORDERGWCon";
	/* Inquire Subscriber Profile Enumerations */
	public static final String INQUIRE_SUBSCRIBER_PROFILE_COMMITMENT_REASON_CODE = "EMR";
	/* Add Note Enumerations */
	public static final String ADD_NOTE_ACCOUNT_TYPE = "Billing";
	public static final String ADD_NOTE_TYPE = "CSM";
	public static final String ADD_NOTE_PRIORITY = "R";
	/* Activate Subscriber Enumerations */
	public static final String WAIVE_ACTIVATION_FEE_REASON_CODE = "ACTSEF";
	/* Add Account Enumerations */
	public static final String ADD_ACCOUNT_BILLING_SYSTEM_ID = "T";
	public static final String ADD_ACCOUNT_ACCOUNTTYPE = "I";
	public static final String ADD_ACCOUNT_BILLING_MEDIA = "XM";
	public static final String ADD_ACCOUNT_OPEN_CHANNEL = "R";
	public static final String ADD_ACCOUNT_BILLING_CYCLE = "0";
	public static final String ADD_ACCOUNT_BILL_DELIVERY_METHOD_PAPERLESS = "X";
	public static final String ADD_ACCOUNT_BILL_DELIVERY_METHOD_PAPER = "P";
	public static final String ADD_ACCOUNT_TAX_EXEMPTION_REQUEST = "false";
	public static final String ADD_ACCOUNT_ADDRESS_TYPE = "S";
	public static final String ADD_ACCOUNT_FIELD_INIDCATOR = "true";
	public static final String ADD_ACCOUNT_ID_TYPE = "DL";
	public static final String ADD_ACCOUNT_CREDIT_APP_TYPE = "CRR";
	public static final String ADD_ACCOUNT_DEPOSIT_LINE_PRODUCT_CODE = "NOT_AVAILABLE";
	public static final String ADD_ACCOUNT_DEPOSIT_LINE_BILLINCODE = "NOT_AVAILABLE";
	public static final String ADD_ACCOUNT_DEPOSIT_LINE_PRODUCT_TYPE = "MISC_CHARGE";
	public static final String ADD_ACCOUNT_DEPOSIT_LINE_DISPLAY_NAME = "DEPOSIT_FEE";
	public static final String ADD_ACCOUNT_DEPOSIT_LINE_ACTION = "ADD";
	public static final String ADD_ACCOUNT_DEPOSIT_LINE_CURRENCY_TYPE = "USD";
	public static final String ADD_ACCOUNT_DEPOSIT_LINE_PRICE_TYPE = "DueToday";
	public static final String ADD_ACCOUNT_DEPOSIT_STATUS = "PAID";
	public static final String ADD_ACCOUNT_COLLECT_PAYMENT_THROUGH_AWP_FLAG = "true";
	public static final String ADD_ACCOUNT_CREDIT_STATUS_AR = "AR";
	public static final String ADD_ACCOUNT_CREDIT_STATUS_PA = "PA";
	public static final String ADD_ACCOUNT_CREDIT_STATUS_REVIEW = "REVIEW";
	public static final String ADD_ACCOUNT_CREDIT_STATUS_PENDING = "PENDING";
	public static final String ADD_ACCOUNT_CREDIT_CLASS = "B";
	public static final String ADD_ACCOUNT_DEPOSIT_SWITCH = "true";
	public static final String ADD_ACCOUNT_DEPOSIT_AMOUNT = "445";
	/* this variable holds the threshold value for confidence */
	public static final long CONFIDENCE_THRESHOLD_VALUE = 80;
	/* Execute credi check api values */
	public static final String CREDIT_STATUS = "UNKNOWN";
	public static final String ECC_BILLING_SYSTEM_ID = "T";
	public static final String ECC_DEPOSIT_LINE_PRODUCT_CODE = "NOT_AVAILABLE";
	public static final String ECC_DEPOSIT_LINE_BILLING_CODE = "NOT_AVAILABLE";
	public static final String ECC_DEPOSIT_LINE_PRODUCT_TYPE = "MISC_CHARGE";
	public static final String ECC_DEPOSIT_LINE_DISPLAY_NAME = "DEPOSIT_FEE";
	public static final String ECC_DEPOSIT_LINE_SYSTEM_NAME = "DEPOSIT_FEE";
	public static final String ECC_DEPOSIT_LINE_ACTION = "ADD";
	public static final String ECC_DEPOSIT_LINE_CURRENCY_TYPE = "USD";
	public static final String ECC_DEPOSIT_LINE_PRICE_TYPE = "DueToday";
	/* UAC related constants */
	public static final String PARTNER_NAME = "OCE";
	public static final String CONSENT_ITEM = "FCC_CBR";
	public static final String SERVICE_FAMILY = "T";
	public static final String SERVICE_TYPE = "CONTACT_NBR";
	public static final String OPT_IN = "I";
	public static final String OPT_OUT = "D";
	public static final String ACCOUNT_SERVICE_TYPE_M = "M";
	/* RCI Related Variables */
	public static final String API_RETREIVE_CONTRACT_IDENTIFIER = "RetrieveContractIdentifier";
	public static final String INSTALLMENT_STATUS_RETRIEVED = "RETRIEVED";
	public static final long INSTALLMENT_PLAN_ID_ZERO = 0;
	public static final String INSTALLMENT_STATUS_ACTIVE = "ACTIVE";
	/* Post Production Enhancement - OCE-180-0060 */
	public static final String INSTALLMENT_STATUS_SWAPPED = "SWAPPED";
	/* CUSA related constants */
	public static final String CUSA_TRANSACTION_ID_UNKNOWN = "Unknown";
	public static final String CUSA_CREDIT_CLASS_HIGH = "HIGH";
	public static final String CUSA_CREDIT_High = "High";
	public static final String CUSA_CREDIT_CLASS_LOW = "LOW";
	public static final String CUSA_CREDIT_Low = "Low";
	public static final String CUSA_CREDIT_CLASS_MEDIUM = "MEDIUM";
	public static final String CUSA_CREDIT_Medium = "Medium";
	public static final String CUSA_CREDIT_CLASS_UNKNOWN = "UNKNOWN";
	public static final String CUSA_CREDIT_Unknown = "Unknown";
	public static final String CUSA_CREDIT_CLASS_E = "E";
	public static final String CUSA_CREDIT_CLASS_A = "A";
	public static final String CUSA_CREDIT_CLASS_B = "B";
	public static final String CUSA_CREDIT_CLASS_J = "J";
	public static final String CUSA_CONTACTPHONE_TYPE = "CELL_PHONE";
	public static final String CUSA_IS_VALID = "V";
	public static final String CUSA_SUBTYPE = "S";
	public static final String CUSA_SMARTMOVES = "N";
	public static final String CUSA_ADDRESS_TYPE_SERVICE = "SERVICE";
	public static final String CUSA_ADDRESS_TYPE_USPS = "USPS";
	public static final String CUSA_SERVICE_MAP_BILLING = "Billing";
	public static final String CUSA_SERVICE_MAP_FSP = "ServiceFSP";
	public static final String CUSA_SERVICE_MAP_SAG = "ServiceSAG";
	public static final String CUSA_SERVICE_MAP_USPS = "ServiceUSPS";
	public static final String CUSA_SYSTEM_IDENTIFIER = "GENERIC";
	public static final String CUSA_PREFERRED_TIME = "Morning";
	public static final String CUSA_ROLE = "LEAD";
	public static final String CUSA_PRODUCTOF_INTEREST = "OTHER";
	public static final String CUSA_PREFERRED_BILL = "DirectBill";
	public static final String CUSA_AFFILIATE = "Lightspeed";
	public static final String CUSA_BILLING_CUSTOMER = "Consumer";
	public static final String CUSA_LANG_PREF = "English";
	public static final String CUSA_BILLINGTYPE_OWNER = "OWNER";
	public static final String CUSA_BILLINGTYPE_AUTHORIZED = "Authorized";
	public static final String CUSA_BUSINESS_PARTNERSHIP = "PARTNERSHIP";
	public static final String CUSA_BUSINESS_LLC = "LLC";
	public static final String CUSA_BUSINESS_CORPORATION = "CORPORATION";
	public static final String CUSA_BUSINESS_SOLE = "Sole Proprietorship";
	public static final String CUSA_ROLE_PRIMARY = "Primary";
	public static final String CUSA_ROLE_PARTNER= "Partner";
	public static final String CUSA_ROLE_AUTHORIZED = "AUTHORIZED";
	/* InflighhtOrders-1605 */
	public static final String B2B_ID = "B2B_01";
	public static final String TC_ID = "TC_";
	public static final String TC_VARIABLE = "0";
	public static final String ORDER_TYPE_UPDATE = "UPDATE";
	public static final String CUSTOMER_ACCOUNT_ID = "CUSTOMER_ACCT_";
	public static final String VERSION_V3 = "V3";
	public static final String VERSION_V7 = "V7";
	public static final String SCHEMAVERSION = "SchemaVersion";
	public static final String GET = "GET";
	/* CRU Wireless Relared Variable */
	public static final String NEW_SALESCHANNEL_S12 = "S12";
	public static final String FAN_MODE_P = "P";
	public static final String IMSA_MARKET_TYPE = "Both";
	public static final String IMSA_REQ_TYPE = "Activation";
	public static final String IMSA_REQ_TYPE_LNP = "Portin";
	public static final String IAD_CATALOG_TYPE = "Global Catalog";
	public static final String IAD_TRANSACTION_TYPE_NEWACTIVATION = "New Activation";
	public static final String IAD_TRANSACTION_TYPE_DEVICEUPGRADE = "Device Upgrade";
	public static final String TRANSACTION_SUBTYPE_PORTIN = "portIn";
	public static final String CRUAccount = "CRU";
	public static final String CRUMobility = "CRU-MOBILITY";
	public static final String LiabilityType_CORPORATE = "CORPORATE";
	public static final String ENTERPRISE_TYPE_CRU = "CRU";
	public static final String ENTERPRISE_TYPE_GBS = "GBS";
	public static final String ENTERPRISE_TYPE_SBA = "SBA";
	public static final String DEMOBILITY = "DE-MOBILITY";
	public static final String PHONETYPE_IPHONE = "Iphone";
	public static final String PHONETYPE_IPAD = "Ipad";
	public static final String PHONETYPE_SMARTPHONE = "SmartPhone";
	public static final String PHONETYPE_FEATUREPHONE = "FeaturePhone";
	public static final String PHONETYPE_BASICPHONE = "BasicPhone";
	public static final String PHONETYPE_TABLET = "Tablet";
	public static final String PHONETYPE_SMARTDEVICE = "SmartDevice";
	public static final String PHONETYPE_BASIC = "Basic";
	public static final String DEVICE_TYPE_D = "D";
	public static final String DEVICE_TYPE_V = "V";
	public static final String WAIVE_UPGRADE_FEE = "waive.upgrade.fee";
	public static final String Application_Premier = "Premier";
	public static final String Status_Parked = "P";
	public static final String Status_Active = "A";
	public static final String PREMIER = "PREMIER";
	public static final String CNG = "CNG";
	public static final String PLAN_TYPE_Recurring = "Recurring";
	public static final String Business = "Business";
	public static final String EXISTING_AUTO_BILL_STATUS_COMPLETE = "COMPLETE";
	public static final String QualificationLevel_UPG = "2999";
	public static final String IOOD_MODE_CommonOrderDetails = "CommonOrderDetails";
	public static final String discountUOM_UE = "A";
	public static final String minimumCommitment_UE = "24";
	public static final String PATH_FORWARD_REVIEW = "REVIEW";
	public static final String PATH_FORWARD_NEXT = "NEXT";
	public static final String UPGRADE_SECURITY_CODE = "BMG";
	public static final String UPGRADE_SECURITY_CODE_HRK = "HRK";
	public static final String ELIGIBILITY_STATUS_A = "A";
	public static final String CONFLICT_TYPE = "CONFLICT_TYPE";
	public static final String CONFLICT_TYPE_F = "DUPLICATE";
	public static final String CONFLICT_TYPE_I = "INCOMPATIBLE";
	/* Country codes */
	public static final String COUNTRY_CODE_US = "US";
	public static final String COUNTRY_CODE_USA = "USA";
	/* ====== Constant for POS Transaction ======= */
	public static final int LOSG_PER_ORDER = 5;
	/* ====== Constants for POC Transactions ======= */
	public static final String RequestType_SCR = "SCR";
	public static final String RequestType_SOR = "SOR";
	public static final String SalesChannel_EBM = "EBM";
	public static final String newEquipmentType = "G";
	/* ====== Action Types for POC Transactions ====== */
	public static final String AT_TRANSFER_BAN = "TRANSFER_BAN";
	public static final String AT_TRANSFER_BAN_CHANGES = "TRANSFER_BAN_CHANGES";
	public static final String AT_REASSIGN_FAN = "REASSIGN_FAN";
	public static final String AT_REASSIGN_FAN_CHANGES = "REASSIGN_FAN_CHANGES";
	public static final String AT_CANCEL_FUTURE_SERVICE = "CANCEL_FUTURE_SERVICE";
	public static final String AT_CHANGE_RATEPLAN_WITH_DEVICE = "CHANGE_RATEPLAN_WITH_DEVICE";
	public static final String AT_CHANGE_RATEPLAN = "CHANGE_RATEPLAN";
	public static final String MOVE_SUBSCRIBER_TIMEOUT_AN = "MOVE_SUBSCRIBER_TIMEOUT";
	public static final String MOVE_SUBSCRIBER_FAIL_AN = "MOVE_SUBSCRIBER_FAIL";
	public static final String ORDER_STATUS_SYS_HOLD = "SYS_HOLD";
	public static final String ORDER_SUBSTATUS_TOBR_STATUS_AWAITED = "TOBR_STATUS_AWAITED";
	public static final String AT_UPDATE_FEATURE_WITH_DEVICE = "UPDATE_FEATURE_WITH_DEVICE";
	public static final String AT_UPDATE_FEATURE = "UPDATE_FEATURE";
	public static final String AT_UPDATE_DEVICE = "UPDATE_DEVICE";
	public static final String AT_UPDATE_PDP = "UPDATE_PDP";
	public static final String AT_UPDATE_SUBSCRIBER = "UPDATE_SUBSCRIBER";
	public static final String AT_CHANGE_CTN = "CHANGE_CTN";
	public static final String AT_SUSPEND_SERVICE = "SUSPEND_SERVICE";
	public static final String AT_REINSTATE_SERVICE = "REINSTATE_SERVICE";
	public static final String AT_TOBR = "TOBR";
	public static final String AT_JOIN_SDG = "JOIN_SDG";
	public static final String AT_CREATE_SDG = "CREATE_SDG";
	public static final String AT_CHANGE_SDG = "CHANGE_SDG";
	public static final String AT_UPDATE_BILLING_ACCOUNT = "UPDATE_BILLING_ACCOUNT";
	/* ===== Constant for AN API call for POS Transaction ======= */
	public static final String ORDER_STATUS_CANCELED = "CANCELED";
	public static final String UPDATE_SUBSCRIBER_PROFILE_FAIL_AN = "UPDATE_SUBSCRIBER_PROFILE_FAIL";
	public static final String UPDATE_SUBSCRIBER_PROFILE_TIMEOUT_AN = "UPDATE_SUBSCRIBER_PROFILE_TIMEOUT";
	public static final String SWAP_EQUIPMENT_FAIL_AN = "SWAP_EQUIPMENT_FAIL";
	public static final String SWAP_EQUIPMENT_TIMEOUT_AN = "SWAP_EQUIPMENT_TIMEOUT";
	public static final String UPDATE_ACCOUNT_PROFILE_FAIL_AN = "UPDATE_ACCOUNT_PROFILE_FAIL";
	public static final String UPDATE_ACCOUNT_PROFILE_TIMEOUT_AN = "UPDATE_ACCOUNT_PROFILE_TIMEOUT";
	public static final String UPDATE_SHARE_DATA_GROUP_FAIL_AN = "UPDATE_SHARE_DATA_GROUP_FAIL";
	public static final String UPDATE_SHARE_DATA_GROUP_TIMEOUT_AN = "UPDATE_SHARE_DATA_GROUP_TIMEOUT";
	/* ===========RPO Related Constants=========== */
	public static final String EQUIPMENT = "Equipment";
	public static final String SERVICE = "Service";
	public static final int QUANTITY = 1;
	/* ===========NPO Related Constants=========== */
	public static final String CANCELLED = "Cancelled";
	/* OrderStatusGroup */
	public static final String ORDERSTATUS_RECEIVED = "RECEIVED";
	public static final String ORDERSTATUS_IN_PROGRESS = "IN_PROGRESS";
	public static final String ORDERSTATUS_ATTENTION_REQUIRED = "ATTENTION_REQUIRED";
	public static final String ORDERSTATUS_CANCELLED = "CANCELED";
	public static final String ORDERSTATUS_COMPLETED = "COMPLETED";
	public static final String ORDERSTATUS_SUBMITTED = "SUBMITTED";
	public static final String ORDERSTATUS_IN_QUEUE = "IN_QUEUE";
	public static final String ORDERSTATUS_PENDING_REVIEW = "PENDING_REVIEW";
	public static final String ORDERSTATUS_ON_HOLD = "ON_HOLD";
	public static final String ORDERSUBSTATUS_INVALID_ORDER = "INVALID_ORDER";
	public static final String OFFER_TYPE = "G";
	/* OrderTypeGroup */
	public static final String PAYMENT_ARRANGEMENT = "PREPAID";
	public static final String PAYMENT_ARRANGEMENT_PREPAID = "PREPAID";
	public static final String PAYMENT_ARRANGEMENT_POSTPAID = "POSTPAID";
	public static final String LNP_ORDER = "LNP";
	public static final String ORDERTYPE_UPDATE = "UPDATE";
	public static final String ORDERTYPE_AMEND = "AMEND";
	public static final String ORDERTYPE_CANCEL = "CANCEL";
	/* LoSGStatusGroup */
	public static final String LOSGSTATUS_SYS_RECEIVED = "SYS_RECEIVED";
	public static final String LOSGSTATUS_SYS_QUEUE = "SYS_QUEUE";
	/* Post Production Enhancement */
	public static final String LOSGSTATUS_REP_PROCESSING = "REP_PROCESSING";
	public static final String LOSGSTATUS_FOLLOWUP_REQUIRED = "FOLLOWUP_REQUIRED";
	public static final String LOSGSTATUS_SHIPPED = "SHIPPED";
	public static final String LOSGSTATUS_ACTIVATED = "ACTIVATED";
	public static final String LOSGSTATUS_NO_CHANGE = "NO_CHANGE";
	public static final String LOSGSTATUS_CHANGE = "CHANGE";
	public static final String LOSGSTATUS_APPROVED = "APPROVED";
	public static final String LOSGSTATUS_DENIED = "DENIED";
	public static final String LOSGSUBSTATUS_SHARED_DATA_PLAN_CHANGED = "SHARED_DATA_PLAN_CHANGED";
	/* Post Production Enhancement - OCE-180-0090 */
	public static final String SHARED_FAMILY_FEATURE_CHANGED = "SHARED_FAMILY_FEATURE_CHANGED";
	/* LoSGSubStatusGroup */
	public static final String LOSGSUBSTATUS_RECEIVED = "RECEIVED";
	public static final String LOSGSUBSTATUS_MANUAL_PROV_REQUIRED = "MANUAL_PROVISIONING_REQUIRED";
	public static final String LOSGSUBSTATUS_RPA_PROV_REQUIRED = "RPA_PROVISIONING_REQUIRED";
	public static final String LOSGSUBSTATUS_BUS_RULE_VALID_FAIL = "BUSINESS_RULE_VALIDATION_FAIL";
	public static final String LOSGSUBSTATUS_BUS_RULE_VALID_PASS = "BUSINESS_RULE_VALIDATION_PASS";
	public static final String LOSGSUBSTATUS_OUTBAL = "OUTSTANDING_BALANCE";
	public static final String LOSGSUBSTATUS_DEBTPAID_CREDITCHECK_FAILED = "DEBTPAID_CREDITCHECK_FAILED";
	public static final String LOSGSUBSTATUS_MILITARY = "MILITARY_DEPLOYMENT";
	public static final String LOSGSUBSTATUS_CRDINFO = "CREDIT_CARD_INFO_NEEDED";
	public static final String LOSGSUBSTATUS_MOG_UPDATE_FAILED = "MOG_UPDATE_FAILED";
	public static final String LOSGSUBSTATUS_MANUPROV = "MANUAL_PROVISIONING_REQUIRED";
	public static final String LOSGSUBSTATUS_WORKING_SERVICE_CONFLICT = "WORKING_SERVICE_CONFLICT";
	public static final String LOSGSUBSTATUS_WSC_CLEARED_INCOMPLETE = "WSC_CLEARED_INCOMPLETE";
	public static final String LOSGSTATUS_WORKING_SERVICE_CANCEL = "CANCELED";
	public static final String LOSGSUBSTATUS_WORKING_SERVICE_NRFC = "XXXX_NRFC";
	public static final String LOSGSUBSTATUS_ADD_NOTES_PASS = "ADD_NOTES_PASS";
	public static final String LOSGSUBSTATUS_CANCELED_IN_STORE = "CANCELED_IN_STORE";
	public static final String LOSGSUBSTATUS_INQUIRE_SUBSCRIBER_PROFILE_PASS = "INQUIRE_SUBSCRIBER_PROFILE_PASS";
	public static final String LOSGSUBSTATUS_INQUIRE_SUBSCRIBER_PROFILE_RECIPIENT_PASS = "INQUIRE_SUBSCRIBER_PROFILE_RECIPIENT_PASS";
	public static final String LOSGSUBSTATUS_INQUIRE_SUBSCRIBER_PROFILE_DONOR_PASS = "INQUIRE_SUBSCRIBER_PROFILE_DONOR_PASS";
	public static final String LOSGSUBSTATUS_INQUIRE_EQUIPMENT_UPGRADE_PASS = "INQUIRE_EQUIPMENT_UPGRADE_PASS";
	public static final String LOSGSUBSTATUS_INQUIRE_COMMON_ORDER_VALIDATION_FAIL = "INQUIRE_COMMON_ORDER_VALIDATION_FAIL";
	public static final String LOSGSUBSTATUS_INQUIRE_COMMON_ORDER_PASS = "INQUIRE_COMMON_ORDER_PASS";
	public static final String LOSGSUBSTATUS_RETRIEVE_CONTRACT_IDENTIFIER_PREFIX = "RETRIEVE_CONTRACT_IDENTIFIER";
	public static final String LOSGSUBSTATUS_RETRIEVE_CONTRACT_IDENTIFIER_SKIPPED = "RETRIEVE_CONTRACT_IDENTIFIER_SKIPPED";
	public static final String LOSGSUBSTATUS_RETRIEVE_CONTRACT_IDENTIFIER_PASS = "RETRIEVE_CONTRACT_IDENTIFIER_PASS";
	public static final String LOSGSUBSTATUS_RETRIEVE_CONTRACT_IDENTIFIER_TIMEOUT = "RETRIEVE_CONTRACT_IDENTIFIER_TIMEOUT";
	public static final String LOSGSUBSTATUS_RETRIEVE_CONTRACT_IDENTIFIER_IGNORE = "RETRIEVE_CONTRACT_IDENTIFIER_IGNORE";
	public static final String LOSGSUBSTATUS_RETRIEVE_CONTRACT_IDENTIFIER_PERFORMED_MANUAL = "RETRIEVE_CONTRACT_IDENTIFIER_MANUAL";
	public static final String LOSGSUBSTATUS_VALIDATE_ADDRESS_PASS = "VALIDATE_ADDRESS_PASS";
	public static final String LOSGSUBSTATUS_VALIDATE_ADDRESS_FAIL_IGNORE = "VALIDATE_ADDRESS_FAIL_IGNORE";
	public static final String LOSGSUBSTATUS_VALIDATE_ADDRESS_TIMEOUT_IGNORE = "VALIDATE_ADDRESS_TIMEOUT_IGNORE";
	public static final String LOSGSUBSTATUS_ADD_PORT_SKIPPED = "ADD_PORT_SKIPPED";
	public static final String LOSGSUBSTATUS_ADD_PORT_VALIDATION_FAIL = "ADD_PORT_VALIDATION_FAIL";
	public static final String LOSGSUBSTATUS_ADD_PORT_PASS = "ADD_PORT_PASS";
	public static final String LOSGSUBSTATUS_ORDER_EQUIPMENT_VALIDATION_FAIL = "ORDER_EQUIPMENT_VALIDATION_FAIL";
	public static final String LOSGSUBSTATUS_ORDER_EQUIPMENT_PASS = "ORDER_EQUIPMENT_PASS";
	public static final String LOSGSUBSTATUS_ORDER_EQUIPMENT_PERFORMED_MANUAL = "ORDER_EQUIPMENT_PERFORMED_MANUAL";
	public static final String LOSGSUBSTATUS_ADD_ACCOUNT_DEPOSIT_WAIVER_REQUIRED = "DEPOSIT_WAIVER_REQUIRED";
	public static final String LOSGSUBSTATUS_ADD_ACCOUNT_DEPOSIT_DECISION_EMO = "DEPOSIT_DECISION_EMO";
	public static final String LOSGSUBSTATUS_ADD_ACCOUNT_DEPOSIT_WAIVER_REQUESTED = "DEPOSIT_WAIVER_REQUESTED";
	public static final String LOSGSUBSTATUS_DEPOSIT_AND_DOWN_PAYMENT_REQUIRED = "DEPOSIT_AND_DOWN_PAYMENT_REQUIRED";
	public static final String LOSGSUBSTATUS_ADD_ACCOUNT_VALIDATION_FAIL = "ADD_ACCOUNT_VALIDATION_FAIL";
	public static final String LOSGSUBSTATUS_ADD_ACCOUNT_FAIL = "ADD_ACCOUNT_FAIL";
	public static final String LOSGSUBSTATUS_ADD_ACCOUNT_SKIPPED = "ADD_ACCOUNT_SKIPPED";
	public static final String LOSGSUBSTATUS_ADD_ACCOUNT_TIMEOUT = "ADD_ACCOUNT_TIMEOUT";
	public static final String LOSGSUBSTATUS_ADD_ACCOUNT_IGNORE = "ADD_ACCOUNT_IGNORE";
	public static final String LOSGSUBSTATUS_ADD_ACCOUNT_MANUAL = "ADD_ACCOUNT_MANUAL";
	public static final String LOSGSUBSTATUS_FRAUD_APPROVED = "FRAUD_APPROVED";
	public static final String LOSGSUBSTATUS_EXECUTE_CREDIT_CHECK_PASS = "EXECUTE_CREDIT_CHECK_PASS";
	public static final String LOSGSUBSTATUS_EXECUTE_CREDIT_CHECK_VALIDATION_FAIL = "EXECUTE_CREDIT_CHECK_VALIDATION_FAIL";
	public static final String LOSGSUBSTATUS_EXECUTE_CREDIT_CHECK_SKIPPED = "EXECUTE_CREDIT_CHECK_SKIPPED";
	public static final String LOSGSUBSTATUS_EXECUTE_CREDIT_CHECK_MANUAL = "EXECUTE_CREDIT_CHECK_MANUAL";
	public static final String LOSGSUBSTATUS_EXECUTE_CREDIT_CHECK_FAIL = "EXECUTE_CREDIT_CHECK_FAIL";
	public static final String LOSGSUBSTATUS_CREDIT_DEPOSIT_MANUAL = "CREDIT_DEPOSIT_MANUAL";
	public static final String LOSGSUBSTATUS_CREDIT_REVIEW = "CREDIT_REVIEW";
	public static final String LOSGSUBSTATUS_CREDIT_REVIEW_APP = "CREDIT_REVIEW_APP";
	public static final String LOSGSUBSTATUS_CREDIT_REVIEW_BAN = "CREDIT_REVIEW_BAN";
	public static final String LOSGSUBSTATUS_ADD_FIBER_SERVICE_ACCOUNT_SKIPPED = "ADD_FIBER_SERVICE_ACCOUNT_SKIPPED";
	public static final String LOSGSUBSTATUS_ADD_FIBER_SERVICE_ACCOUNT_VALIDATION_FAIL = "ADD_FIBER_SERVICE_ACCOUNT_VALIDATION_FAIL";
	public static final String LOSGSUBSTATUS_ADD_FIBER_SERVICE_ACCOUNT_PASS = "ADD_FIBER_SERVICE_ACCOUNT_PASS";
	public static final String LOSGSUBSTATUS_ADD_CONVERGE_BUNDLED_ACCOUNT_PASS = "ADD_CONVERGE_BUNDLED_ACCOUNT_PASS";
	public static final String LOSGSUBSTATUS_ADD_CONVERGE_BUNDLED_ACCOUNT_IGNORE = "ADD_CONVERGE_BUNDLED_ACCOUNT_IGNORE";
	public static final String LOSGSUBSTATUS_ADD_CONVERGE_BUNDLED_ACCOUNT_MANUAL = "ADD_CONVERGE_BUNDLED_ACCOUNT_MANUAL";
	public static final String LOSGSUBSTATUS_ADD_CONVERGE_BUNDLED_ACCOUNT_SKIPPED = "ADD_CONVERGE_BUNDLED_ACCOUNT_SKIPPED";
	public static final String LOSGSUBSTATUS_UPDATE_ACCOUNT_PROFILE_PASS = "UPDATE_ACCOUNT_PROFILE_PASS";
	public static final String LOSGSUBSTATUS_UPDATE_ACCOUNT_PROFILE_SKIPPED = "UPDATE_ACCOUNT_PROFILE_SKIPPED";
	public static final String LOSGSUBSTATUS_UPDATE_ACCOUNT_PROFILE_TIMEOUT_IGNORE = "UPDATE_ACCOUNT_PROFILE_TIMEOUT_IGNORE";
	public static final String LOSGSUBSTATUS_UPDATE_ACCOUNT_PROFILE_FAIL_IGNORE = "UPDATE_ACCOUNT_PROFILE_FAIL_IGNORE";
	public static final String LOSGSUBSTATUS_RESERVE_CONTRACT_IDENTIFIER_SKIPPED = "RESERVE_CONTRACT_IDENTIFIER_SKIPPED";
	public static final String LOSGSUBSTATUS_RESERVE_CONTRACT_IDENTIFIER_PASSED = "RESERVE_CONTRACT_IDENTIFIER_PASSED";
	public static final String LOSGSUBSTATUS_RESERVE_CONTRACT_IDENTIFIER_MANUAL = "RESERVE_CONTRACT_IDENTIFIER_MANUAL";
	public static final String LOSGSUBSTATUS_RESERVE_CONTRACT_IDENTIFIER_TIMEOUT_IGNORE = "RESERVE_CONTRACT_IDENTIFIER_TIMEOUT_IGNORE";
	public static final String LOSGSUBSTATUS_RESERVE_CONTRACT_IDENTIFIER_FAIL_IGNORE = "RESERVE_CONTRACT_IDENTIFIER_FAIL_IGNORE";
	public static final String LOSGSUBSTATUS_ACTIVATE_SUBSCRIBER_FAIL = "ACTIVATE_SUBSCRIBER_FAIL";
	public static final String LOSGSUBSTATUS_ACTIVATE_SUBSCRIBER_TIMEOUT = "ACTIVATE_SUBSCRIBER_TIMEOUT";
	public static final String LOSGSUBSTATUS_ACTIVATE_SUBSCRIBER_IGNORE = "ACTIVATE_SUBSCRIBER_IGNORE";
	public static final String LOSGSUBSTATUS_ADD_NOTES_IGNORE = "ADD_NOTES_IGNORE";
	public static final String LOSGSUBSTATUS_INQUIRE_INCOMPATIBLE_OFFEREING_TIMEOUT_IGNORE = "INQUIRE_INCOMPATIBLE_OFFERING_TIMEOUT_IGNORE";
	public static final String LOSGSUBSTATUS_INQUIRE_INCOMPATIBLE_OFFEREING_FAIL_IGNORE = "INQUIRE_INCOMPATIBLE_OFFERING_FAIL_IGNORE";
	public static final String LOSGSUBSTATUS_INQUIRE_INCOMPATIBLE_OFFEREING_PASS = "INQUIRE_INCOMPATIBLE_OFFERING_PASS";
	public static final String LOSGSUBSTATUS_INQUIRE_INCOMPATIBLE_OFFEREING_SKIPPED = "INQUIRE_INCOMPATIBLE_OFFERING_SKIPPED";
	public static final String LOSGSUBSTATUS_INQUIRE_INCOMPATIBLE_OFFERING_FAIL_IGNORE = "INQUIRE_INCOMPATIBLE_OFFERING_FAIL_IGNORE";
	public static final String LOSGSUBSTATUS_RETRIEVE_CONTRACT_IDENTIFIER_FAIL_IGNORE = "RETRIEVE_CONTRACT_IDENTIFIER_FAIL_IGNORE";
	public static final String LOSGSUBSTATUS_RETRIEVE_CONTRACT_IDENTIFIER_TIMEOUT_IGNORE = "RETRIEVE_CONTRACT_IDENTIFIER_TIMEOUT_IGNORE";
	public static final String LOSGSUBSTATUS_UPDATE_SUBSCRIBER_PROFILE_FAIL_IGNORE = "UPDATE_SUBSCRIBER_PROFILE_FAIL_IGNORE";
	public static final String LOSGSUBSTATUS_UPDATE_SUBSCRIBER_PROFILE_TIMEOUT_IGNORE = "UPDATE_SUBSCRIBER_PROFILE_TIMEOUT_IGNORE";
	public static final String LOSGSUBSTATUS_UPGRADE_EQUIPMENT_TIMEOUT_IGNORE = "UPGRADE_EQUIPMENT_TIMEOUT_IGNORE";
	public static final String LOSGSUBSTATUS_UPGRADE_EQUIPMENT_SKIPPED = "UPGRADE_EQUIPMENT_SKIPPED";
	public static final String LOSGSUBSTATUS_UPGRADE_EQUIPMENT_SIM_PARKING_PASS = "UPGRADE_EQUIPMENT_SIM_PARKING_PASS";
	public static final String LOSGSUBSTATUS_UPGRADE_EQUIPMENT_SIM_PARKING_SKIPPED = "UPGRADE_EQUIPMENT_SIM_PARKING_SKIPPED";
	public static final String LOSGSUBSTATUS_UPGRADE_EQUIPMENT_SIM_PASS = "UPGRADE_EQUIPMENT_SIM_PASS";
	public static final String LOSGSUBSTATUS_UPGRADE_EQUIPMENT_SIM_SKIPPED = "UPGRADE_EQUIPMENT_SIM_SKIPPED";
	public static final String LOSGSUBSTATUS_UPGRADE_EQUIPMENT_SIM_IGNORE = "UPGRADE_EQUIPMENT_SIM_IGNORE";
	public static final String LOSGSUBSTATUS_INQUIRE_SUBSCRIBER_PROFILE_SKIPPED = "INQUIRE_SUBSCRIBER_PROFILE_SKIPPED";
	public static final String LOSGSUBSTATUS_INQUIRE_SUBSCRIBER_PROFILE_TIMEOUT_IGNORE = "INQUIRE_SUBSCRIBER_PROFILE_TIMEOUT_IGNORE";
	public static final String LOSGSUBSTATUS_INQUIRE_SUBSCRIBER_PROFILE_FAIL_IGNORE = "INQUIRE_SUBSCRIBER_PROFILE_FAIL_IGNORE";
	public static final String LOSGSUBSTATUS_UPGRADE_EQUIPMENT_PASS = "UPGRADE_EQUIPMENT_PASS";
	public static final String LOSGSUBSTATUS_UPDATE_COMMON_ORDER_TIMEOUT = "UPDATE_COMMON_ORDER_TIMEOUT";
	public static final String LOSGSUBSTATUS_UPDATE_COMMON_ORDER_SKIP = "UPDATE_COMMON_ORDER_SKIP";
	public static final String LOSGSUBSTATUS_UPDATE_COMMON_ORDER_PASS = "UPDATE_COMMON_ORDER_PASS";
	public static final String LOSGSUBSTATUS_UPDATE_COMMON_ORDER_STATUS_TIMEOUT = "UPDATE_COMMON_ORDER_STATUS_TIMEOUT";
	public static final String LOSGSUBSTATUS_UPDATE_COMMON_ORDER_STATUS_PASS = "UPDATE_COMMON_ORDER_STATUS_PASS";
	public static final String LOSGSUBSTATUS_UPDATE_SHARE_DATA_GROUP_TIMEOUT_IGNORE = "UPDATE_SHARE_DATA_GROUP_TIMEOUT_IGNORE";
	public static final String LOSGSUBSTATUS_UPDATE_SHARE_DATA_GROUP_FAIL_IGNORE = "UPDATE_SHARE_DATA_GROUP_FAIL_IGNORE";
	public static final String LOSGSUBSTATUS_UPDATE_SHARE_DATA_GROUP_PASS = "UPDATE_SHARE_DATA_GROUP_PASS";
	public static final String LOSGSUBSTATUS_UPDATE_SHARE_DATA_GROUP_SKIPPED = "UPDATE_SHARE_DATA_GROUP_SKIPPED";
	public static final String LOSGSUBSTATUS_DTV_IN_PROGRESS = "DTV_IN_PROGRESS";
	public static final String LOSGSUBSTATUS_UNIFY_IN_PROGRESS = "UNIFY_IN_PROGRESS";
	public static final String LOSGSUBSTATUS_PORT_RESOLUTION_REQUIRED = "PORT_RESOLUTION_REQUIRED";
	public static final String LOSGSUBSTATUS_SUBMIT_TO_AUTOMATION = "SUBMIT_TO_AUTOMATION";
	public static final String LOSGSUBSTATUS_UPDATE_PORT_ORDER_ID_PASS = "UPDATE_PORT_ORDER_ID_PASS";
	public static final String LOSGSUBSTATUS_UPDATE_PORT_ORDER_ID_FAIL = "UPDATE_PORT_ORDER_ID_FAIL";
	public static final String LOSGSUBSTATUS_UPDATE_PORT_ORDER_ID_MANUAL = "UPDATE_PORT_ORDER_ID_MANUAL";
	public static final String LOSGSUBSTATUS_UPDATE_PORT_ORDER_ID_TIMEOUT = "UPDATE_PORT_ORDER_ID_TIMEOUT";
	public static final String LOSGSUBSTATUS_ADD_PORT_MANUAL = "ADD_PORT_MANUAL";
	public static final String LOSGSUBSTATUS_UPDATE_SHARE_DATA_GROUP_PERFORMED_MANUAL = "UPDATE_SHARE_DATA_GROUP_PERFORMED_MANUAL";
	public static final String LOSGSUBSTATUS_UPDATE_SUBSCRIBER_PROFILE_PERFORMED_MANUAL = "UPDATE_SUBSCRIBER_PROFILE_PERFORMED_MANUAL";
	public static final String LOSGSUBSTATUS_UPDATE_ACCOUNT_PROFILE_MANUAL = "UPDATE_ACCOUNT_PROFILE_MANUAL";
	public static final String LOSGSUBSTATUS_NO_CHANGE = "NO_CHANGE";
	public static final String API_VALIDATE_ADDRESS = "ValidateAddress";
	public static final String API_VALIDATE_ADDRESS_FOR_STAR = "ValidateAddressForStar";
	public static final String LOSGSUBSTATUS_INQUIRE_PORT_ELIGIBILITY_MANUAL = "INQUIRE_PORT_ELIGIBILITY_MANUAL";
	public static final String LOSGSUBSTATUS_ACTIVATE_SUBSCRIBER_MANUAL = "ACTIVATE_SUBSCRIBER_MANUAL";
	public static final String LOSGSUBSTATUS_INQUIRE_PORT_MANUAL = "INQUIRE_PORT_MANUAL";
	public static final String LOSGSUBSTATUS_INQUIRE_PORT_IGNORE = "INQUIRE_PORT_IGNORE";
	public static final String LOSGSUBSTATUS_INQUIRE_PORT_TIMEOUT_IGNORE = "INQUIRE_PORT_TIMEOUT_IGNORE";
	public static final String LOSGSUBSTATUS_INQUIRE_PORT_PASS = "INQUIRE_PORT_PASS";
	public static final String LOSGSUBSTATUS_CONTRACT_SWAPPED = "CONTRACT_SWAPPED";
	public static final String LOSGSUBSTATUS_FRAUD_VALIDATION_PASSED = "FRAUD_VALIDATION_PASSED";
	public static final String LOSGSUBSTATUS_ADD_PAYMENT_PROFILE_PASS = "ADD_PAYMENT_PROFILE_PASS";
	public static final String LOSGSUBSTATUS_CONTACT_US_CREDITCARD = "CONTACT_US_CREDITCARD";
	public static final String LOSGSUBSTATUS_FRAUD_REVIEW = "FRAUD_REVIEW";
	public static final String LOSGSUBSTATUS_FRAUD_REVIEW_MED = "FRAUD_REVIEW_MED";
	public static final String LOSGSUBSTATUS_INQUIRE_FAN_PROFILE_MANUAL = "INQUIRE_FAN_PROFILE_MANUAL";
	public static final String LOSGSUBSTATUS_INQUIRE_FAN_PROFILE_PASS = "INQUIRE_FAN_PROFILE_PASS";
	public static final String LOSGSUBSTATUS_INQUIRE_FAN_PROFILE_FAIL = "INQUIRE_FAN_PROFILE_FAIL";
	public static final String LOSGSUBSTATUS_INQUIRE_FAN_PROFILE_TIMEOUT = "INQUIRE_FAN_PROFILE_TIMEOUT";
	public static final String LOSGSUBSTATUS_INQUIRE_FAN_PROFILE_VALIDATION_FAIL = "INQUIRE_FAN_PROFILE_VALIDATION_FAIL";
	public static final String LOSGSUBSTATUS_TESTING_ORDER = "TESTING_ORDER";
	public static final String LOSGSUBSTATUS_UPDATE_ACCOUNT_CONSENT_PASS = "UPDATE_ACCOUNT_CONSENT_PASS";
	public static final String LOSGSUBSTATUS_UPDATE_ACCOUNT_CONSENT_FAIL = "UPDATE_ACCOUNT_CONSENT_FAIL";
	public static final String LOSGSUBSTATUS_DTV_WORKING_SERVICE_CONFLICT = "DTV_WORKING_SERVICE_CONFLICT";
	public static final String LOSGSUBSTATUS_MANAGE_OMNI_ORDER_UPDATE_PASS = "MANAGE_OMNI_ORDER_UPDATE_PASS";
	public static final String LOSGSUBSTATUS_MANUAL_SYNC = "MANUAL_SYNC";
	public static final String LOSGSUBSTATUS_WIRELESS_IN_PROGRESS = "WIRELESS_IN_PROGRESS";
	public static final String LOSGSUBSTATUS_RESERVE_PURCHASE_ORDER_PASS = "RESERVE_PURCHASE_ORDER_PASS";
	public static final String LOSGSUBSTATUS_RESERVE_PURCHASE_ORDER_VALIDATION_FAIL = "RESERVE_PURCHASE_ORDER_VALIDATION_FAIL";
	public static final String LOSGSUBSTATUS_RESERVE_PURCHASE_ORDER_SKIPPED = "RESERVE_PURCHASE_ORDER_SKIPPED";
	public static final String LOSGSUBSTATUS_UPDATE_ACCOUNT_CONSENT_MANUAL = "UPDATE_ACCOUNT_CONSENT_MANUAL";
	public static final String LOSGSUBSTATUS_PROCESSED_IN_OTHER_SYSTEM = "PROCESSED_IN_OTHER_SYSTEM";
	public static final String LOSGSUBSTATUS_AWAITING_WIRELESS_AUTOMATION = "AWAITING_WIRELESS_AUTOMATION";
	/* LoSGTypeGroup */
	public static final String LOSGTYPE_NO_CHANGE = "NO_CHANGE";
	public static final String LOSGTYPE_UNLOCK = "UNLOCK";
	public static final String LOSGTYPE_DISCONNECT = "DISCONNECT";
	public static final String LOSGTYPE_AMEND = "AMEND";
	public static final String LOSGTYPE_WINOVER = "WINOVER";
	public static final String LOSGTYPE_WINBACK = "WINBACK";
	/* ProductCategoryGroup */
	public static final String PRODUCTCATEGORY_IPTV = "IPTV";
	public static final String PRODUCTCATEGORY_INTERNET = "INTERNET";
	public static final String PRODUCTCATEGORY_VOIP = "VOIP";
	public static final String PRODUCTCATEGORY_DTV = "DIRECTV";
	public static final String PRODUCTCATEGORY_QVOIP = "QCVOIP";
	public static final String PRODUCTCATEGORY_HSIA = "HSIA";
	public static final String PRODUCTCATEGORY_QHSIA = "QHSIA";
	
	public static final List<String> UVERSE_PRODUCT_CATEGORIES = Arrays.asList(new String[]{
			PRODUCTCATEGORY_IPTV,PRODUCTCATEGORY_INTERNET,PRODUCTCATEGORY_VOIP,PRODUCTCATEGORY_DTV
	}); 
 
	public static final List<String> UVERSE_PRODUCT_INT_IPTV = Arrays.asList(new String[]{ 
			PRODUCTCATEGORY_IPTV,PRODUCTCATEGORY_INTERNET 
	}); 
 
	public static final List<String> UVERSE_PRODUCT_INT_IPTV_DTV = Arrays.asList(new String[]{ 
			PRODUCTCATEGORY_IPTV,PRODUCTCATEGORY_INTERNET,PRODUCTCATEGORY_DTV 
	});
	
	/* AccountCategoryGroup */
	public static final String ACCOUNTCATEGORY_DTV_ACCOUNT = "DTV_ACCOUNT";
	public static final String ACCOUNTTYPE_INDIVIDUAL = "INDIVIDUAL";
	public static final String ACCOUNTTYPE_BUSINESS = "BUSINESS";
	public static final String ENTERPRISE_TYPE_CRU_GBS = "GBS";
	public static final String ENTERPRISE_TYPE_CRU_SBA = "SBA";
	public static final String LIABILITY_TYPE_CORPORATE = "CORPORATE";
	/* AccountSubCategoryGroup */
	public static final String ACCOUNTSUBCATEGORY_PREVIOUS = "PREVIOUS";
	/* GroupTypeGroup */
	/* ProductCodeTypeGroup */
	public static final String PRODUCTCODE_UVDTV = "UVDTV";
	public static final String APPLICATION_MYATTSALES = "MYATTSALES";
	public static final String TASKSTATUS_SUSPENDED = "SUSPENDED";
	public static final String CHILD_UVERSE = "UverseAdaptorService";
	public static final String CHILD_DTV = "DTVFulfillmentService";
	public static final String CHILD_WIRELESS = "NewWirelessService";
	/* ExecutionContextKeyGroup */
	public static final String CONTEXT_KEY_CSI_VERSION = "CSI_VERSION";
	public static final String CONTEXT_KEY_CUSTOMERORDERNUMBER = "CUSTOMERORDERNUMBER";
	public static final String CONTEXT_KEY_REQUESTID = "REQUESTID";
	public static final String CONTEXT_KEY_TTL = "TIME_TO_LIVE";
	public static final String CONTEXT_KEY_CONVERSATIONID = "CONVERSATIONID";
	public static final String CONTEXT_KEY_RETURN_URL = "RETURN_URL";
	// public static final String CHILD_UVERSE = "UverseAdaptorService1605";
	// public static final String CHILD_DTV = "DTVFulfillmentService1605";
	public static final String LINEITEM_PRODUCT_TYPE_OPTIONAL_FEATURE = "OPTIONAL_FEATURE";
	public static final String LINEITEM_PRODUCT_TYPE_PLAN = "PLAN";
	public static final String LINEITEM_PRODUCT_TYPE_MISC_CHARGE = "MISC_CHARGE";
	public static final String LINEITEM_PRODUCT_TYPE_HARDGOOD = "HARDGOOD";
	public static final String LINEITEM_HARDGOOD_TYPE_DEVICE = "DEVICE";
	public static final String LINEITEM_HARDGOOD_TYPE_SIM = "SIM";
	public static final String LINEITEM_SYSTEM_NAME_ACTIVATION_FEE = "ACTIVATION_FEE";
	public static final String LINEITEM_CONTRACT_TYPE_LEASE = "LEASE";
	public static final String LINEITEM_CONTRACT_TYPE_INSTALLMENT = "INSTALLMENT";
	public static final String LINEITEM_CONTRACT_TYPE_REGULAR = "REGULAR";
	public static final String LINEITEM_CONTRACT_TYPE_NOCOMMIT = "NOCOMMIT";
	public static final String LINEITEM_INSTALLMENT_STATUS_RETRIEVED = "Retrieved";
	public static final String LINEITEM_INSTALLMENT_STATUS_RESERVED = "Reserved";
	public static final String LOSGUPGRADETYPE_REGULAR = "REGULAR";
	public static final String LOSGUPGRADETYPE_SHARED = "SHARED";
	public static final String LOSG_OFFERCATEGORY_SHARED_SHR = "SHR";
	public static final String CHANNEL_IRU = "UNLOCK";
	public static final String CHANNEL_CRU = "CRU";
	public static final String CHANNEL_OG = "DE-MOBILITY";
	public static final String CHANNEL_STAR = "CDE-HS";
	public static final String CRU_QUEUETPE = "CRU_UNLOCK";
	public static final String CRU_DEFAULT_QUEUESUBTPE = "UNLOCK_UNVERIFIED";
	public static final String CRU_ONHOLD_QUEUESUBTPE = "ON_HOLD";
	public static final String EC_KEY_POAS_SERVICES = "POAS_SERVICES";
	public static final String EC_KEY_WIRELESS_ACTIVITIES = "WIRELESS_ACTIVITIES";
	public static final String EC_KEY_ACT_FRAUD_REVIEW = "FRAUD_REVIEW";
	public static final String EC_KEY_ACT_ADD_FIBER_SERVICE_ACCOUNT = "ADD_FIBER_SERVICE_ACCOUNT";
	public static final String EC_KEY_ACT_VALIDATE_ADDRESS = "VALIDATE_ADDRESS";
	public static final String EC_KEY_ACT_NACK_VALIDATIONS = "NACK_VALIDATIONS";
	public static final String EC_KEY_ACT_ADD_CONVERGE_BUNDLED_ACCOUNT = "ADD_CONVERGE_BUNDLED_ACCOUNT";
	public static final String EC_KEY_ACTION_REQUIRED = "ACTION_REQUIRED";
	public static final String EC_KEY_SKIP_PARENT_UPDATE = "SKIP_PARENT_UPDATE";
	public static final String EC_VAL_POAS_SERVICES = "FR_VAL_VAD_BAN_CA";
	public static final String EC_VAL_MANUAL_PROVISIONING_REQUIRED = "MANUAL_PROVISIONING_REQUIRED";
	public static final String EC_VAL_CANCELLED = "CANCELLED";
	public static final String EC_VAL_SUCCESS = "Success";
	public static final String EC_VAL_OK = "OK";
	public static final String EC_VAL_NOK = "NOK";
	public static final String EC_KEY_FALLOUT_TIMER = "ORDER_TIMEOUT";
	public static final String REJECTED_RERUN_ERROR_CODES = "534,538";
	public static final String EC_VAL_TRUE = "TRUE";
	public static final String EC_VAL_FALSE = "FALSE";
	public static final String EC_VAL_YES = "Y";
	public static final String EC_VAL_NO = "N";
	public static final String EC_VAL_FALLOUT_TIMER = "P300D";
	public static final String CONTEXT_VAL_CSI_VERSION = "v109";
	public static final String CONTEXT_VAL_CSI_VERSION_97 = "v97";
	public static final String CONTEXT_VAL_CSI_VERSION_98 = "v98";
	public static final String CONTEXT_VAL_CSI_VERSION_v94 = "v94";
	public static final String CONTEXT_VAL_CSI_VERSION_v97 = "v97";
	public static final String CONTEXT_VAL_CSI_VERSION_v98 = "v98";
	public static final String CONTEXT_VAL_CSI_VERSION_v104 = "v104";
	public static final String CONTEXT_VAL_CSI_VERSION_v106 = "v106";
	public static final String CONTEXT_VAL_CSI_VERSION_v109 = "v109";
	public static final String CONTEXT_VAL_CSI_VERSION_v112 = "v112";
	public static final String GROUP_RELATIONSHIP_DONOR = "DONOR";
	public static final String GROUP_RELATIONSHIP_RECIPIENT = "RECIPIENT";
	public static final String LOSGSUBSTATUS_UPDATE_SUBSCRIBER_PROFILE_PASS = "UPDATE_SUBSCRIBER_PROFILE_PASS";
	public static final String LOSGSUBSTATUS_UPDATE_SUBSCRIBER_PROFILE_SKIPPED = "UPDATE_SUBSCRIBER_PROFILE_SKIPPED";
	public static final String FULFILLMENT_METHOD_DF = "DF";
	public static final String FULFILLMENT_METHOD_C2S = "C2S";
	public static final String FULFILLMENT_METHOD_ACTIVATION = "ACTIVATION";
	public static final String API_UPDATE_ACCOUNT_PROFILE_RETRY = "UpdateAccountProfile.retry";
	public static final String API_UPDATE_ACCOUNT_PROFILE_MANUAL = "UpdateAccountProfile.manual.done";
	public static final String API_RETREIVE_CONTRACT_IDENTIFIER_RETRY = "RetrieveContractIdentifier.retry";
	public static final String API_RETREIVE_CONTRACT_IDENTIFIER_MANUAL = "RetrieveContractIdentifier.manual.done";
	public static final String API_INQUIRE_INCOMPATIBLE_OFFERING = "InquireIncompatibleOffering";
	public static final String API_INQUIRE_INCOMPATIBLE_OFFERING_RETRY = "InquireIncompatibleOffering.retry";
	public static final String API_INQUIRE_INCOMPATIBLE_OFFERING_MANUAL = "InquireIncompatibleOffering.manual.done";
	public static final String API_UPDATE_SUBSCRIBER_PROFILE_RETRY = "UpdateSubscriberProfile.retry";
	public static final String API_UPDATE_SUBSCRIBER_PROFILE_MANUAL = "UpdateSubscriberProfile.manual.done";
	public static final String API_INQUIRE_SUBSCRIBER_PROFILE = "InquireSubscriberProfileForUSP";
	public static final String API_INQUIRE_SUBSCRIBER_PROFILE_RETRY = "InquireSubscriberProfileForUSP.retry";
	public static final String API_INQUIRE_SUBSCRIBER_PROFILE_MANUAL = "InquireSubscriberProfileForUSP.manual.done";
	public static final String API_UPDATE_SHARE_DATA_GROUP_PROFILE_CBS = "UpdateSharedDataGroupProfile_CBS";
	public static final String API_UPDATE_SHARE_DATA_GROUP_PROFILE_RETRY = "UpdateSharedDataGroupProfile.retry";
	public static final String API_UPDATE_SHARE_DATA_GROUP_PROFILE_MANUAL = "UpdateSharedDataGroupProfile.manual.done";
	public static final String API_UPGRADE_EQUIPMENT_DONOR_SIM = "UpgradeEquipmentContractFree";
	public static final String API_UPGRADE_EQUIPMENT_RETRY = "UpgradeEquipment.retry";
	public static final String API_UPGRADE_EQUIPMENT_MANUAL = "UpgradeEquipment.manual.done";
	public static final String API_UPGRADE_EQUIPMENT_DONOR_SIM_RETRY = "UpgradeEquipmentContractFree.retry";
	public static final String API_UPGRADE_EQUIPMENT_DONOR_SIM_MANUAL = "UpgradeEquipmentContractFree.manual.done";
	public static final String API_UPGRADE_EQUIPMENT_DONOR_SIM_MANUAL_STATUS = "UPGRADE_EQUIPMENT_SIM_PARKING_MANUAL";
	public static final String API_UPGRADE_EQUIPMENT_MANUAL_STATUS = "UPGRADE_EQUIPMENT_MANUAL";
	public static final String API_UPGRADE_EQUIPMENT_CSI_VERSION = "v112";
	public static final String API_ORDER_EQUIPMENT = "OrderEquipment";
	public static final String API_ORDER_EQUIPMENT_RETRY = "OrderEquipment.retry";
	public static final String API_ORDER_EQUIPMENT_MANUAL = "OrderEquipment.manual.done";
	public static final String API_IEUCE = "InquireEquipmentUpgradeCancellationEligibility";
	public static final String API_IEUCE_RETRY = "InquireEquipmentUpgradeCancellationEligibility.retry";
	public static final String API_IEUCE_MANUAL = "InquireEquipmentUpgradeCancellationEligibility.manual.done";
	public static final String API_INQUIRE_FAN_PROFILE = "InquireFanProfile";
	public static final String API_NPO = "NotifyPurchaseOrder";
	public static final String NOTIFY_PURCHASE_ORDER_COMPLETE = "NOTIFY_PURCHASE_ORDER_COMPLETE";
	public static final String API_UPDATE_SUBSCRIBER_STATUS = "UpdateSubscriberStatus";
	public static final String API_CEU = "CancelEquipmentUpgrade";
	public static final String API_CEU_RETRY = "CancelEquipmentUpgrade.retry";
	public static final String API_CEU_MANUAL = "CancelEquipmentUpgrade.manual.done";
	public static final String API_CWP = "CancelWirelinePayment";
	public static final String API_CWP_SUCCESS = "CWP was success";
	public static final String API_CWP_FAILURE = "CWP was failure";
	public static final String API_APP = "AddPaymentProfile";
	public static final String API_APP_STOREDPROFILE = "AddPaymentProfileStoredProfile";
	public static final String API_APP_CREDITCARD = "AddPaymentProfileCreditCard";
	public static final String API_APP_CLONED = "AddPaymentProfileCloned";
	public static final String YES = "YES";
	public static final String NO = "NO";
	public static final String CANCEL = "CANCEL";
	public static final String ERROR_HANDLER_API_NAME = "error.handler.apiname";
	public static final String ERROR_HANDLER_CODE = "error.handler.errorcode";
	public static final String ERROR_HANDLER_DESC = "error.handler.errordesc";
	public static final String UE_CONTRACT_EXTEND_SUCCESS = "SUCCESS";
	public static final String UE_CONTRACT_EXTEND_FAILURE = "FAILURE";
	public static final String UE_CONTRACT_EXTEND_PENDING = "PENDING";
	public static final String UE_CONTRACT_EXTEND_NOT_REQUIRED = "NOT_REQUIRED";
	public static final String CONTACT_TYPE_HOME_PHONE = "HOME_PHONE";
	public static final String CONTACT_TYPE_WORK_PHONE = "WORK_PHONE";
	public static final String CONTACT_TYPE_CELL_PHONE = "CELL_PHONE";
	public static final String CONTACT_TYPE_OTHER = "OTHER";
	public static final String INQUIRE_MODE_COMMON_ORDER_DETAILS = "CommonOrderDetails";
	public static final String IGNORE = "IGNORE";
	public static final String PRODUCT_COMBINATION = "PRODUCT_COMBINATION";
	public static final String INSTALLMENT_STATUS_RESERVED = "RESERVED";
	public static final String INSTALLMENT_STATUS_RELEASED = "RELEASED";
	public static final String RESERVE_CONTRAT_IDENTIFIER_PASS = "RETRIEVE_CONTRACT_IDENTIFIER_PASS";
	public static final String RESERVE_CONTRAT_IDENTIFIER_SKIP = "RETRIEVE_CONTRACT_IDENTIFIER_SKIPPED";
	public static final String RESERVE_CONTRACT_IDENTIFIER_PASS = "RESERVE_CONTRACT_IDENTIFIER_PASS";
	public static final String RESERVE_CONTRACT_IDENTIFIER_SKIPPED = "RESERVE_CONTRACT_IDENTIFIER_SKIPPED";
	public static final String RETRIEVE_CONTRACT_IDENTIFIER_SKIPPED = "RETRIEVE_CONTRACT_IDENTIFIER_SKIPPED";
	public static final String RETRIEVE_CONTRACT_IDENTIFIER_PASS = "RETRIEVE_CONTRACT_IDENTIFIER_PASS";
	public static final String INQUIRE_PORT_ELIGIBILTY_INELIGIBLE = "PORT_INELIGIBLE";
	public static final String RESERVE_SUBSCRIBER_NUMBER_PASS = "RESERVE_SUBSCRIBER_NUMBER_PASS";
	public static final String RESERVE_SUBSCRIBER_NUMBER_SKIPPED = "RESERVE_SUBSCRIBER_NUMBER_SKIPPED";
	public static final String RESERVE_SUBSCRIBER_NUMBER_SUBMIT_PASS = "RESERVE_SUBSCRIBER_SUBMIT_PASS";
	public static final String ADD_WIRELINE_PAYMENT_PASS = "ADD_WIRELINE_PAYMENT_PASS";
	public static final String ADD_WIRELINE_PAYMENT_SKIPPED = "ADD_WIRELINE_PAYMENT_SKIPPED";
	public static final String INQUIRE_SUBSCRIBER_PROFILE_SKIPPED = "INQUIRE_SUBSCRIBER_PROFILE_SKIPPED";
	public static final String INQUIRE_SUBSCRIBER_PROFILE_PASS = "INQUIRE_SUBSCRIBER_PROFILE_PASS";
	public static final String SERVICE_ACTIVATED = "SERVICE_ACTIVATED";
	public static final String SERVICE_ACTIVATED_MANUAL = "SERVICE_ACTIVATED_MANUAL";
	public static final String ACTIVATE_SUBSCRIBER_PASS = "ACTIVATE_SUBSCRIBER_PASS";
	public static final String ACTIVATE_SUBSCRIBER_SKIPPED = "ACTIVATE_SUBSCRIBER_SKIPPED";
	public static final String ACTIVATE_SUBSCRIBER_IGNORE = "ACTIVATE_SUBSCRIBER_IGNORE";
	public static final String ACTIVATE_SUBSCRIBER_FAIL = "ACTIVATE_SUBSCRIBER_FAIL";
	public static final String EXCEEDED_LEASE_LIMIT = "EXCEEDED_LEASE_LIMIT";
	public static final String ADD_NOTES_PASS = "ADD_NOTES_PASS";
	public static final String ADD_NOTES_SKIPPED = "ADD_NOTES_SKIPPED";
	public static final String API_NAME_ACTIVATE_SUBSCRIBER = "ACTIVATE_SUBSCRIBER";
	public static final String API_NAME_ADD_CONVERGE_BUNDLED_ACCOUNT = "ADD_CONVERGE_BUNDLED_ACCOUNT";
	public static final String API_NAME_ADD_FIBER_SERVICE_ACCOUNT = "ADD_FIBER_SERVICE_ACCOUNT";
	public static final String API_NAME_ADD_NOTES = "AddNotes";
	public static final String API_NAME_ADD_PORT = "ADD_PORT";
	public static final String API_NAME_ADD_WIRELINE_PAYMENT = "ADD_WIRELINE_PAYMENT";
	public static final String API_NAME_CEU = "CEU";
	public static final String API_NAME_CREDIT_CARD_DECLINED = "CREDIT_CARD_DECLINED";
	public static final String API_NAME_EXECUTE_CREDIT_CHECK = "EXECUTE_CREDIT_CHECK";
	public static final String API_NAME_IEUCE = "IEUCE";
	public static final String API_NAME_INQUIRE_COMMON_ORDER = "INQUIRE_COMMON_ORDER";
	public static final String API_NAME_INQUIRE_INCOMPATIBLE_OFFERING = "INQUIRE_INCOMPATIBLE_OFFERING";
	public static final String API_NAME_INQUIRE_PORT = "INQUIRE_PORT";
	public static final String API_NAME_INQUIRE_PORT_ELIGIBILITY = "INQUIRE_PORT_ELIGIBILITY";
	public static final String API_NAME_INQUIRE_SUBSCRIBER_PROFILE = "INQUIRE_SUBSCRIBER_PROFILE";
	public static final String API_NAME_ORDER_EQUIPMENT = "ORDER_EQUIPMENT";
	public static final String API_NAME_RESERVE_CONTRACT_IDENTIFIER = "RESERVE_CONTRACT_IDENTIFIER";
	public static final String API_NAME_RESERVE_SUBSCRIBER_NUMBER = "RESERVE_SUBSCRIBER_NUMBER";
	public static final String API_NAME_RETRIEVE_CONTRACT_IDENTIFIER = "RETRIEVE_CONTRACT_IDENTIFIER";
	public static final String API_NAME_UPDATE_COMMON_ORDER = "UPDATE_COMMON_ORDER";
	public static final String API_NAME_UPDATE_SHARE_DATA_GROUP = "UPDATE_SHARE_DATA_GROUP";
	public static final String API_NAME_UPDATE_SUBSCRIBER_PROFILE = "UPDATE_SUBSCRIBER_PROFILE";
	public static final String API_NAME_UPGRADE_EQUIPMENT = "UPGRADE_EQUIPMENT";
	public static final String API_NAME_VALIDATE_ADDRESS = "VALIDATE_ADDRESS";
	public static final String ERROR_ACTION_APPEND = "APPEND";
	public static final String ERROR_ACTION_REMOVE_ADD = "REMOVE_ADD";
	public static final String IsEncrypt_true = "true";
	public static final String Provide = "Provide";
	public static final String LOSGSUBSTATUS_CONTACT_US = "Contact US";
	/* IRU Unlock Constants */
	public static final String SECTION_ELIGIBILITY_CHECK = "Eligibility Check";
	public static final String CODE_FRAUD_CHECK = "Fraud_Check";
	public static final String VALUE_PASSED = "Passed";
	public static final String VALUE_FAILED = "Failed";
	/* DTV Refer a Friend Constant */
	public static final String dtvRefAccNum = "dtvRefAccNum";
	public static final String COMSCSIVersion = "202";
	/* Childs Created */
	public static final String WIRELESS_CHILD = "WIRELESS";
	public static final String DTV_CHILD = "DTV";
	public static final String UVERSE_CHILD = "UVERSE";
	public static final String SS_ORDER = "SSORDER";
	/*Invalid Profile Name */
	public static final String CAPM_INVALID_PROFILE_EAY5IGY800000000 = "EAY5IGY800000000";
	/* CRU Wireless */
	public static final String API_NAME_FRAUD_VALIDATION = "FRAUD_VALIDATION";
	public static final String API_NAME_INQUIRE_AVAILABLE_DEVICE = "InquireAvailableDevice";
	public static final String API_NAME_INQUIRE_MARKET_SERVICE_AREA = "InquireMarketServiceArea";
	public static final String API_NAME_INQUIRE_UPGRADE_ELIGIBILITY = "InquireUpgradeEligibility";
	public static final String API_NAME_RESERVE_AND_BIND_ESIM = "ReserveAndBindESIM";
	public static final String LOSGSUBSTATUS_RESERVE_AND_BIND_ESIM_PASS = "RESERVE_AND_BIND_ESIM_PASS";
	public static final String LOSGSUBSTATUS_RESERVE_AND_BIND_ESIM_FAIL = "RESERVE_AND_BIND_ESIM_VALIDATION_FAIL";
	public static final String LOSGSUBSTATUS_INQUIRE_UPGRADE_ELIGIBILITY_PASS = "INQUIRE_UPGRADE_ELIGIBILITY_PASS";
	public static final String LOSGSUBSTATUS_INQUIRE_UPGRADE_ELIGIBILITY_VALIDATION_FAIL = "INQUIRE_UPGRADE_ELIGIBILITY_VALIDATION_FAIL";
	public static final String LOSGPERORDER_POS = "5";
	/* CMP constants */
	public static final String UVERSE_ACCOUNT = "U";
	public static final String DTV_ACCOUNT = "D";
	public static final String LINESTATUS_INPROGRESS = "IN_PROGRESS";
	public static final String LINESTATUS_SUBMITTED = "SUBMITTED";
	/* WSC constants */
	public static final String WSCFound = "U-verse Conflicting Service found";
	public static final String TestingOrderIndicator = "TestingOrderIndicator";
	/* CRU Wireless POC */
	public static final String API_NAME_CHANGE_CTN = "ChangeSubscriberNumber";
	public static final String B2B_CONTRACT_TYPES_NACK622 = "SBPL,SBNC,SBDC";
	public static final String B2B_CONTRACT_TYPES_NACK620 = "SBPL";
	public static final String LOSGPERORDER_POC = "10";
	public static final String LOSGPERORDER_CHANGE_SDG = "0";
	public static final String API_INQUIRE_SUBSCRIBER_PROFILE_POC = "InquireSubscriberProfile";
	public static final String API_SWAP_EQUIPMENT_POC = "SwapEquipment";
	public static final String CANCEL_FUTURE_SERVICE_POC = "CANCEL_FUTURE_SERVICE";
	public static final String ACTION_TYPE_TRANSFER_BAN = "TRANSFER_BAN";
	public static final String ACTION_TYPE_REASSIGN_FAN = "REASSIGN_FAN";
	public static final String TOBR_STATUS_AWAITED_POC = "TOBR_STATUS_AWAITED";
	public static final String TOBR_COMPLETED_POC = "TOBR_COMPLETED";
	public static final String TOBR_CTN_CANCEL_COMPLETED = "CTN_CANCEL_COMPLETED";
	public static final String API_INQUIRE_SUBSCRIBER_PROFILE_TOBR = "InquireSubscriberProfileTOBR";
	public static final String API_UPDATE_SUBSCRIBER_STATUS_TOBR = "UpdateSubscriberStatusTOBR";
	/* C2S API Constants */
	public static final String API_INQUIRE_COMMON_ORDER_FAIL = "INQUIRE_COMMON_ORDER_FAIL";
	public static final String API_UPDATE_COMMON_ORDER_FAIL = "UPDATE_COMMON_ORDER_FAIL";
	public static final String API_UPDATE_COMMON_ORDER_STATUS_FAIL = "UPDATE_COMMON_ORDER_STATUS_FAIL";
	public static final String PortType = "CVOIP";
	public static final String ShipToType = "SERVICE";
	public static final String Full_Val = "Full";
	/*IUSApp Constants*/
	public static final String PRODUCT_TYPE_UVERSE = "UVERSE";
	public static final String PRODUCT_TYPE_DTV = "DTV";
	public static final String OFFERID_UVERSE = "2000043";
	public static final String OFFERID_DTV = "422383389";
	public static final String DISPATCH_SINGLE = "SINGLE";
	public static final String DISPATCH_DUAL = "DUAL";
	public static final String TYPE_TECH = "TECH";
	public static final String PORT_TYPE = "CVOIP";
	public static final String SHIP_TO_TYPE = "SERVICE";
	public static final String FULL_VAL = "Full";
	public static final String GRPPKG_CATEGORY = "PACKAGE";
	public static final String PACKAGE_CATEGORY = "OFFER";
	public static final String PUSPOREQ = "PUSPO1Request";
	public static final String FMO_STATE_SALES_CODE = "ALTAY8A";
	public static final String NOT_AVAILABLE = "NOT_AVAILABLE";
	public static final String ADVANCE_PAYMENT = "ADVANCE_PAYMENT";
	public static final String SMB_SALES_CODE = "2ZYZFAA";
	public static final String NON_REFUNDABLE_FEE = "NON_REFUNDABLE_FEE";
	public static final String DISPLAY_ADVANCEPAYMENT= "Advance_Payment";
	public static final String DISPLAY_NON_REFUNDABLE_FEE= "Non_Refundable_Fee";
	public static final String PUSPO_VOIP = "PUSPO_VOIP";
	public static final String PUSPO_SUBMIT = "PUSPO_SUBMIT";
	public static final String PUSPO_QUOT = "PUSPO_QUOT";
	public static final String PUSPO_VOIP_QUOT = "PUSPO_VOIP_QUOT";
	public static final String MASK_QUOTED_TAX = "QUOTED_TAX";
	public static final String MASK_CROSS_PROD_DISCOUNT_DATA = "CROSS_PRODUCTS_DISCOUNTS_DATA";
	public static final String MASK_QUOTED_PRICES = "QUOTED_PRICES";
	public static final String MASK_CATALOG_LITE = "CATALOG_LITE";
	public static final String MASK_PROD_CONFIG = "PRODUCT_CONFIGURATION";
	public static final String MASK_DISPLAY_INFO = "DISPLAY_INFO";
	public static final String ACTIVITY_CONFIG_PUSPO_QUOT = "AMSSUverseCompRules1~~NegotiatePricingAndBilling~~AMSSCreditCompRules";
	public static final String ACTIVITY_CONFIG_PUSPO_VOIP = "AMSSUverseCompRules1~~AMSSCreditCompRules";
	public static final String ACTIVITY_CONFIG_PUSPO_VOIP_QUOT = "AMSSUverseCompRules2~~NegotiatePricingAndBilling";
	public static final String ACTIVITY_CONFIG_MODIFY = "AMSSAssignedProductView";
	public static final String SALES_CHANNEL = "WEB";
	public static final String APP_ID = "OCE";
	public static final String EXISTING_WL_NEW_FMO_WIRELINE = "FLOW_PROVIDE";
	public static final String EXISTING_WL_MODIFY_FMO_WIRELINE = "FLOW_MODIFY";
	public static final String ACTIVITY_CONFIG_PROVIDE = "AMSSProductView";
	public static final String MASK_DISPLAYINFO = "DISPLAY_INFO";
	public static final String MASK_CATELOG_LITE= "CATALOG_LITE";
	public static final String MASK_ONLY_VISIBLE= "ONLY_VISIBLE";
	public static final String MODE_DETAIL = "DETAIL";
	public static final String APPLICATION_ID = "OCE";
	/* Offer IDs */
	public static final String[] UVERSE_OFFER_ID = {"2000043"};
	public static final String[] DTV_OFFER_ID = {"422383389"};
	/* WorkOrderID Mapping */
	public static final String UMC = "UMC";
	public static final String ATT_DTV_MAIN = "ATTDTVMain";
	public static final String WORK_ORDER_ID = "workOrderID";
	public static final String SERVICECODE_DTV = "DTV";
	public static final String SERVICECODE_INTERNET = "INTERNET";
	public static final String HSIA_PRODUCTCODE = "HSIA";
	public static final String SERVICECODE_VOIP = "VOIP";
	
	

	public static final String[] UPDATE_ACCOUNT_PROFILE_STATUS = {
			"SYS_PROCESSING/FRAUD_APPROVED",
			"SYS_PROCESSING/ADD_CONVERGE_BUNDLED_ACCOUNT_PASS",
			"SYS_PROCESSING/ADD_CONVERGE_BUNDLED_ACCOUNT_IGNORE",
			"SYS_PROCESSING/ADD_CONVERGE_BUNDLED_ACCOUNT_MANUAL",
			"SYS_PROCESSING/ADD_CONVERGE_BUNDLED_ACCOUNT_SKIPPED" };

	public static final String[] RETREIVE_CONTRACT_IDENTIFIER_STATUS = {
			"SYS_PROCESSING/UPDATE_ACCOUNT_PROFILE_PASS",
			"SYS_PROCESSING/UPDATE_ACCOUNT_PROFILE_SKIPPED",
			"SYS_PROCESSING/UPDATE_ACCOUNT_PROFILE_TIMEOUT_IGNORE",
			"SYS_PROCESSING/UPDATE_ACCOUNT_PROFILE_FAIL_IGNORE",
			"SYS_PROCESSING/UPDATE_ACCOUNT_PROFILE_MANUAL" };

	public static final String[] INQUIRE_INCOMPATIBLE_OFFERING_STATUS = {
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_IGNORE",
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_PASS",
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_SKIPPED",
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_TIMEOUT_IGNORE",
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_MANUAL" };

	public static final String[] USP_STATUS = {
			"SYS_PROCESSING/INQUIRE_INCOMPATIBLE_OFFERING_TIMEOUT_IGNORE",
			"SYS_PROCESSING/INQUIRE_INCOMPATIBLE_OFFERING_FAIL_IGNORE",
			"SYS_PROCESSING/INQUIRE_INCOMPATIBLE_OFFERING_PASS",
			"SYS_PROCESSING/INQUIRE_INCOMPATIBLE_OFFERING_SKIPPED" };

	public static final String[] INQUIRE_SUBSCRIBER_PROFILE_STATUS = {
			"SYS_PROCESSING/FRAUD_APPROVED",
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_FAIL_IGNORE",
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_PASS",
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_TIMEOUT_IGNORE",
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_SKIPPED",
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_MANUAL",
			"SYS_PROCESSING/UPDATE_ACCOUNT_PROFILE_FAIL_IGNORE",
			"SYS_PROCESSING/UPDATE_ACCOUNT_PROFILE_PASS",
			"SYS_PROCESSING/UPDATE_ACCOUNT_PROFILE_SKIPPED",
			"SYS_PROCESSING/UPDATE_ACCOUNT_PROFILE_TIMEOUT_IGNORE",
			"SYS_PROCESSING/UPDATE_ACCOUNT_PROFILE_MANUAL",
			"SYS_PROCESSING/UPDATE_SUBSCRIBER_PROFILE_PASS",
			"COMPLETE/SHARED_FAMILY_FEATURE_CHANGED",
			"SYS_HOLD/SHARED_FAMILY_FEATURE_CHANGE_REQUIRED",
			"SYS_PROCESSING/UPDATE_SUBSCRIBER_PROFILE_SKIPPED",
			"SYS_PROCESSING/UPDATE_SUBSCRIBER_PROFILE_FAIL_IGNORE",
			"SYS_PROCESSING/UPDATE_SUBSCRIBER_PROFILE_TIMEOUT_IGNORE",
			"SYS_PROCESSING/UPDATE_SUBSCRIBER_PROFILE_PERFORMED_MANUAL" };

	public static final String[] USDGP_STATUS = {
			"SYS_PROCESSING/INQUIRE_SUBSCRIBER_PROFILE_PASS",
			"SYS_PROCESSING/INQUIRE_SUBSCRIBER_PROFILE_SKIPPED",
			"SYS_PROCESSING/INQUIRE_SUBSCRIBER_PROFILE_TIMEOUT_IGNORE",
			"SYS_PROCESSING/INQUIRE_SUBSCRIBER_PROFILE_FAIL_IGNORE" };

	public static final String[] INQUIRE_SUBSCRIBER_PROFILE_STATUS_CBS = {
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_IGNORE",
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_PASS",
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_SKIPPED",
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_TIMEOUT_IGNORE",
			"SYS_PROCESSING/RETRIEVE_CONTRACT_IDENTIFIER_MANUAL" };

	public static final String[] USDGP_STATUS_CBS = {
			"SYS_PROCESSING/INQUIRE_SUBSCRIBER_PROFILE_PASS",
			"SYS_PROCESSING/INQUIRE_SUBSCRIBER_PROFILE_SKIPPED",
			"SYS_PROCESSING/INQUIRE_SUBSCRIBER_PROFILE_TIMEOUT_IGNORE",
			"SYS_PROCESSING/INQUIRE_SUBSCRIBER_PROFILE_FAIL_IGNORE" };

	public static final String[] INQUIRE_INCOMPATIBLE_OFFERING_STATUS_CBS = {
			"COMPLETE/SHARED_DATA_PLAN_CHANGED",
			"SYS_HOLD/SHARED_DATA_PLAN_CHANGE_REQUIRED",
			"SYS_PROCESSING/UPDATE_SHARE_DATA_GROUP_PASS",
			"SYS_PROCESSING/UPDATE_SHARE_DATA_GROUP_TIMEOUT_IGNORE",
			"SYS_PROCESSING/UPDATE_SHARE_DATA_GROUP_FAIL_IGNORE",
			"SYS_PROCESSING/UPDATE_SHARE_DATA_GROUP_SKIPPED",
			"SYS_PROCESSING/UPDATE_SHARE_DATA_GROUP_PERFORMED_MANUAL" };

	public static final String[] UE_STATUS = {
			"COMPLETE/SHARED_DATA_PLAN_CHANGED",
			"SYS_HOLD/SHARED_DATA_PLAN_CHANGE_REQUIRED",
			"SYS_PROCESSING/UPDATE_SHARE_DATA_GROUP_PASS",
			"SYS_PROCESSING/UPDATE_SHARE_DATA_GROUP_TIMEOUT_IGNORE",
			"SYS_PROCESSING/UPDATE_SHARE_DATA_GROUP_FAIL_IGNORE",
			"SYS_PROCESSING/UPDATE_SHARE_DATA_GROUP_SKIPPED",
			"SYS_PROCESSING/UPDATE_SHARE_DATA_GROUP_PERFORMED_MANUAL",
			"SYS_PROCESSING/INQUIRE_INCOMPATIBLE_OFFERING_TIMEOUT_IGNORE",
			"SYS_PROCESSING/INQUIRE_INCOMPATIBLE_OFFERING_FAIL_IGNORE",
			"SYS_PROCESSING/INQUIRE_INCOMPATIBLE_OFFERING_PASS",
			"SYS_PROCESSING/INQUIRE_INCOMPATIBLE_OFFERING_SKIPPED" };

	public static final String[] UE_SIM_STATUS = {
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_PASS",
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_MANUAL" };
	
	public static final String[] OE_STATUS = {
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_PASS",
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_TIMEOUT_IGNORE",
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_SKIPPED",
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_MANUAL",
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_SIM_PARKING_PASS",
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_SIM_PARKING_SKIPPED",
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_SIM_IGNORE",
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_SIM_PARKING_TIMEOUT_IGNORE",
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_SIM_PARKING_FAIL_IGNORE",
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_SIM_PARKING_MANUAL",
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_FAIL_IGNORE",
			"SYS_PROCESSING/ADD_PAYMENT_PROFILE_PASS",
			"COMPLETE/CONTRACT_SWAPPED", "SYS_HOLD/CONTRACT_SWAP_REQUIRED",
			"SYS_PROCESSING/SUBMIT_TO_AUTOMATION" };

	public static final String[] RETREIVE_TELEGENCE_NEW = {
			"SYS_PROCESSING/ACTIVATE_SUBSCRIBER_FAIL",
			"SYS_PROCESSING/ACTIVATE_SUBSCRIBER_TIMEOUT",
			"SYS_PROCESSING/ACTIVATE_SUBSCRIBER_IGNORE",
			"SYS_PROCESSING/ADD_NOTES_PASS", "SYS_PROCESSING/ADD_NOTES_IGNORE" };

	public static final String[] IEUCE_STATUS = { "CANCELED" };

	public static final String[] UCO_STATUS = { "SYS_PROCESSING/INQUIRE_COMMON_ORDER_PASS" };

	public static final String[] UPDATEORDERSTATUS_STATUS = { "SYS_PROCESSING/UPDATE_COMMON_ORDER_PASS" };
	public static final String[] ADDNOTES_STATUS = {
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_PASS",
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_SIM_PARKING_PASS" };

	public static final String[] INQUIRE_COMMON_ORDERLIST_DETAILS_STATUS = {
			"SYS_PROCESSING/UDPATE_ACCOUNT_PROFILE_PASS",
			"SYS_PROCESSING/UDPATE_ACCOUNT_PROFILE_SKIPPED",
			"SYS_PROCESSING/UDPATE_ACCOUNT_PROFILE_IGNORE" };

	public static final String[] UE_DONOR_SIM_CONTRACT_FREE_FALLOUT_STATUS = {
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_SIM_PARKING_FAIL",
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_SIM_PARKING_TIMEOUT" };

	public static final String[] UE_FALLOUT_STATUS = {
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_TIMEOUT",
			"SYS_PROCESSING/UPGRADE_EQUIPMENT_FAIL" };
	
	//SMB ATPO AUTOAMTION

	public static final String ACCOUNTCATEGORY_DTV = "DTV_ACCOUNT";
	public static final String ACCOUNTCATEGORY_WIRELINE = "WIRELINE_ACCOUNT";
	public static final String PRODUCTCATEGORY_ADD_ON_SOLUTIONS = "ADDON-SOLUTIONS";
	public static final String BILLINGTYPE_OWNER = "OWNER";
	public static final String ACCOUNTCATEGORY_UVERSE = "UVERSE_ACCOUNT";
	public static final String API_NAME_ATPO = "AddThirdPartyOrder";
	public static final String PROVISIONING_SYSTEM = "provisioningSystem";
	public static final String PROVISIONING_SYSTEMS = "provisioningSystems";
	public static final String SYSTEM_NAME_BOOST = "systemName";
	public static final String SYSTEM_ORDER_REF ="systemOrderRef";
	public static final String ACCOUNTCATEGORY_ADDON_SOLUTIONS_ACCOUNT = "ADDON-SOLUTIONS_ACCOUNT";
	public static final String ACCOUNT_BILLING_ACCOUNT_NUMBER = "billingAccountNumber";
	public static final String ACCOUNT_ATPO="account";
	public static final String ADD_THIRD_PARTY_CREDITCARD_TYPE_MC = "MC";
	public static final String ADD_THIRD_PARTY_CREDITCARD_TYPE_AE = "AE";
	public static final String ADD_THIRD_PARTY_CREDITCARD_TYPE_DISC = "DISC";
	public static final String ADD_THIRD_PARTY_CREDITCARD_TYPE_DINE = "DINE";
	
	//AddWireline payment plan
	public static final String SYSTEM_DIVISION = "PC0";
	public static final String PAYMENT_PLAN_TYPE = "RecurringAdv";
	
	
	//ExecuteUnifiedCreditPolicyCheck Constants
	public static final String UVERSE_GROUP_AFFILIATES_COUNT = "1";
	public static final String UVERSE_AFFILIATE_ID = "LS";
	public static final String MOBILITY_AFFILIATE_ID = "MT";
	public static final String SOURCE_APPLICATION_ID = "MYATTSALES";
	public static final String BUSINESS_ORRESIDENCE_CODE = "BUS";
	public static final String ENTERPRISETYPE_CON = "T0016";
	public static final String ENTERPRISETYPE_IRU = "T0001";
	public static final String ENTERPRISETYPE_INDIVIDUAL = "T0001";
	public static final String ENTERPRISETYPE_DEFAULT = "T0017";
	public static final String UVERSE_PRODUCT_TYPE = "P0007";
	public static final String UVERSE_CUSTOMER_ACTIVITY_TYPE = "A0017";
	public static final String UVERSE_CUSTOMER_ACTIVITY_TYPE1 = "A0018";
	public static final String INDIVIDUAL_ACCOUNT_TYPE = "I";
	public static final String BUSINESS_ACCOUNT_TYPE = "B";
	public static final String GOVERNMENT_ACCOUNT_TYPE = "G";
	public static final String SPECIAL_ACCOUNT_TYPE = "G";
	public static final String CUSTOMER_ACTIVITY_TYPE2 = "A0013";
	public static final String CUSTOMER_ACTIVITY_TYPE3 = "A0005";
	public static final String ACTION_TYPE = "AD";
	public static final String QUANTITY_ATTRIBUTE_CODE = "AC010";
	public static final String PRODUCT_SKU_ATTRIBUTE_CODE = "AC011";
	public static final String OPTIONAL_FEATURE_ATTRIBUTE_CODE = "AC011";
	public static final String PRODUCT_INTERNET_CATEGORY_ATTRIBUTE = "INTERNET";
	public static final String PRODUCT_IPTV_CATEGORY_ATTRIBUTE = "IPTV";
	public static final String PRODUCT_VOIP_CATEGORY_ATTRIBUTE = "VOIP";
	public static final String SPOKEN_LANGUAGE_ENGLISH = "ENGLISH";
	public static final String SPOKEN_LANGUAGE_SPANISH = "SPANISH";
	public static final String CUSTOMER_PREFERRED_LANGUAGE_EN = "EN";
	public static final String CUSTOMER_PREFERRED_LANGUAGE_ES = "ES";
	public static final String PRODUCT_SKU_ATTRIBUTE_VALUE = "Price Plan";
	public static final String OPTIONAL_FEATURE_SKU_ATTRIBUTE_VALUE = "Price Plan";
	public static final String LOSGSUBSTATUS_EXECUTE_UNIFIED_CREDIT_POLICY_FAIL = "EXECUTE_UNIFIED_CREDIT_POLICY_FAIL";
	
	//UUCP Constants
	public static final String SOURCE_APPLICATION_ID_MYATTSALES="MYATTSALES";
	public static final String NUMBER_OF_POLICIES_1="1";
	public static final String SECURITY_TYPE_ADVPAY="ADVPAY";
	public static final String SECURITY_TYPE_NRF="NRF";
	public static final String SECURITY_TYPE_NOSEC="NOSEC";
	public static final String LOSGSUBSTATUS_ADVANCE_PAYMENT_AND_NRF_REQUIRED="ADVANCE_PAYMENT_AND_NRF_REQUIRED";
	public static final String LOSGSUBSTATUS_NO_SECURITY_FEE_REQUIRED="NO_SECURITY_FEE_REQUIRED";
	public static final String LOSGSUBSTATUS_CREDIT_POLICY_REQUIRED="CREDIT_POLICY_REQUIRED";
	public static final String LOSGSUBSTATUS_NON_REFUNDABLE_FEE_REQUIRED="NON_REFUNDABLE_FEE_REQUIRED";
	public static final String LOSGSUBSTATUS_ADVANCE_PAYMNET_REQUIRED="ADVANCE_PAYMNET_REQUIRED";
	public static final String LOSGSUBSTATUS_UPDATE_UNIFIED_CREDIT_POLICY_PASS="UPDATE_UNIFIED_CREDIT_POLICY_PASS";
	public static final String SECURITY_TYPE_PIF="PIF";
	public static final String ORDER_STATUS_CA="CA";
	public static final String ORDER_STATUS_PE="PE";
	public static final String UUCP_CREDIT_POLICY_EXPIRED = "CREDIT_POLICY_EXPIRED";
	
	/* IUSA related constants*/
	public static final String IUSA_SYSTEM_IDENTIFIER="GENERIC";
	public static final String IUSA_ORIGINATOR_SYSTEM_NAME="OCE";
	
	/*IUSO related constants*/
	public static final String IUSO_CUSTOMER_SUBTYPE="R";
	public static final String IUSO_PRODUCT_TYPE="ALL";
	
	public static final String FLOWTYPE_STANDALONEUV = "Standalone-UverseOrder";
	public static final String FLOWTYPE_STANDALONEDTV = "Standalone-DTVOrder";
	public static final String FLOWTYPE_BUNDLED = "Bundled-Order";
	public static final String FLOWTYPE_UNIFY = "Unify-Order";
	public static final String FLOWTYPE_UNKNOWN = "Unknown-Order";
	/*Validate Credit Card related constants*/
	
	public static final  String VCC_CONCAT_STR="CreditCardType.";
	
	public static final String SYSTEM_ADVANCE_PAYMENT = "ADVANCE_PAYMENT";
	public static final String SYSTEM_CREDIT_MANAGEMENT_FEE = "CREDIT_MANAGEMENT_FEE";
	public static final String AUTHCODE_DUMMY = "DUMMY";
	
	public static final String ACC_TYPE_CHECKING = "CHECKING";
	public static final String ACC_TYPE_SAVINGS = "SAVINGS";
	
	/* WSC related constants */
	public static final String SERVICE_EXIST_INDICATOR_LIGHTSPEED="LIGHTSPEED";
	public static final List<String> ACCEPTABLE_SERVICE_TYPE= Arrays.asList(new String[]{"U-Verse","UNE-L","UNE-P"});
	public static boolean AUTOPENDSWITCH = true;
	public static boolean DTVCONFLICTFLAG = true;
	
	public static final String BPMN_ERR_WLERR001 = "WLERR001";
	public static final String SYS_ERROR = "SYS_ERROR";
	
	public static final String PAYMENT_ITEM_CAT_DEP = "DEP";
	public static final String PAYMENT_ITEM_CAT_APMT = "APMT";
	
	public static final String PAYMENT_TYPE_ADVPMT = "ADVPMT";
	public static final String PAYMENT_TYPE_NRF = "NRF";
	
	public static final String SYSTEM_DTV_SECURITY_FEE = "DTV_SECURITY_FEE";
	
	public static final List<String> AWP_SYSTEM_NAMES = Arrays.asList(new String[]{"DEPOSIT_FEE","ADVANCE_PAYMENT","NON_REFUNDABLE_FEE", "DTV_SECURITY_FEE"});
	public static final List<String> AWP_PRICE_TYPES = Arrays.asList(new String[]{"DUENOW","DueToday"});
	public static final String[] CUSA_BILLING_CUSTOMER_SubType = {"Consumer" , "Consumer Small Office"};
	public static final List<String> AWP_SYSTEMS_NAMES = Arrays.asList(new String[]{"DEPOSIT_FEE","ADVANCE_PAYMENT","NON_REFUNDABLE_FEE"});
	public static final String NEW_ORDER = "NEW";
	public static final String MODIFY_ORDER = "CHANGE";
	
	//<!-- Product Type -->
	public static final String New_ProductType = "NEW";
	public static final String NO_CHANGE_ProductType="NO_CHANGE";
	public static final String CHANGE_ProductType = "CHANGE";
	public static final String UP_ProductType = "UP";
	
	public static final List<String> WIRELINE_PRODUCT_TYPE = Arrays.asList(new String[]{ 
			New_ProductType,NO_CHANGE_ProductType,CHANGE_ProductType,UP_ProductType,
	});
}
