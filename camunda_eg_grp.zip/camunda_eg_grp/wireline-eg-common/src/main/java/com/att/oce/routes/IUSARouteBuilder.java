package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;
import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.InitiateUnifiedServiceOrderRequestTransformation;
import com.att.oce.transformation.InquireTransportProductAvailabilityTransformation;
import com.att.oce.transformation.InquireUnifiedServiceAccountRequestTransformation;

@Component("iusaRouteBuilder")
public class IUSARouteBuilder  extends RouteBuilder {

	@Override
	public void configure() throws Exception
	{
		from("direct:csi:iusa")
		.routeId("IUSAId")
		.bean(InquireUnifiedServiceAccountRequestTransformation.class,"transformWrapper")
		.to("velocity:///vm/IUSA.vm")
		.wireTap("direct:auditlog:request")
		.to("https://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.wireTap("direct:auditlog:response")
		.bean(InquireUnifiedServiceAccountRequestTransformation.class,"processResponseWrapper");
	}
}

	
