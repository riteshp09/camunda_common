package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;


import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.CreateUnifiedServiceAccountTransformation;

@Component("CUSARouteBuilder")
public class CUSARouteBuilder extends RouteBuilder {
	@Override
	public void configure() throws Exception
	{
		from("direct:csi:cusa")
		.routeId("CUSAId")
		.bean(CreateUnifiedServiceAccountTransformation.class,"transformWrapper")
		.to("velocity:///vm/CUSA.vm")
		.wireTap("direct:auditlog:request")
		.to("https://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.wireTap("direct:auditlog:response")
		.bean(CreateUnifiedServiceAccountTransformation.class,"processResponseWrapper");
	}
}
