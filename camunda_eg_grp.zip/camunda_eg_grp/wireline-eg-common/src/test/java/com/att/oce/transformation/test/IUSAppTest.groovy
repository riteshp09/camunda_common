package com.att.oce.transformation.test;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import org.apache.camel.Exchange
import javax.xml.parsers.ParserConfigurationException

import org.apache.camel.Exchange;
import org.junit.Test;
import org.xml.sax.SAXException;

import com.att.oce.transformation.InquireUnifiedServiceAppointmentsTransformation;

import groovy.json.JsonSlurper;
import groovy.util.XmlSlurper;


public class IUSAppTest {
	@Test
	public void standaloneProductTest() throws IOException, SAXException, ParserConfigurationException {

		File inputFile = new File("./src/test/resources/data/IUSApp.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		File inputFile1 = new File("./src/test/resources/data/IUSAppFMOSD.json");
		Map<String,Object> Order1 = (Map<String, Object>) new JsonSlurper().parse(inputFile1);
		def xmlPayload = new File("D:/rk00330305/ATT/1705release/camunda_entertainment_group/wireline-eg/wireline-eg-bpmn/src/test/resources/data/IUSAppResponse.xml").text
		def slurper = new XmlSlurper()
		def IUSAppResponse = slurper.parseText(xmlPayload)
		def iusappRes = IUSAppResponse.Body.InquireUnifiedServiceAppointmentsResponse
		InquireUnifiedServiceAppointmentsTransformation iusap = new InquireUnifiedServiceAppointmentsTransformation();
		iusap.checkforStandaloneProduct(Order);
		iusap.dispatchType(Order);
		iusap.determineNextAvailableDate(Order, iusappRes, "true")
		iusap.determineNxtAvailableAppoinmentDateUsingDayType1("2016-12-22T11:00:00.292-06:00", "AM")
		iusap.convert12hrto24hr("01:00 PM")
		iusap.determineActualAppointmentDate(Order, iusappRes)
		iusap.converttodatetime("2016-12-22T12:00:00.292-06:00")
		iusap.constructAppointmentInfo("UVERSE", "2016-12-22T12:00:00.292+05:30", "2016-12-22T13:00:00.292+05:30", "TECH", "asduyag")
		iusap.determineNxtAvailableDateForAnyDay(Order, iusappRes, "true", "AM")
		iusap.determineNxtAvailableDateForAnyDayParentfunction(Order, iusappRes, "true", "AM")
		iusap.determineNxtAvailableDateUsingDay(Order, iusappRes, "true", "PM", "5")
		iusap.determineNxtAvailableDateUsingDayParentfunction(Order, iusappRes, "true", "PM", "5")
		iusap.determineFMOAppointmentStartDate(Order1, iusappRes, "UVERSE")
		iusap.isAppointmentMatchFoundinIUSAPResp(Order1, iusappRes, "UVERSE")
	}
}


