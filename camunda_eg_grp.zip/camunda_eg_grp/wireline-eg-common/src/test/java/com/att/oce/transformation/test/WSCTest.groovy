package com.att.oce.transformation.test

import java.io.File;
import java.io.IOException;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.junit.Test;
import org.xml.sax.SAXException;

import com.att.oce.transformation.WorkServiceConflictResolution

import groovy.json.JsonSlurper;

class WSCTest {

	@Test
	public void workServiceConflictExistsTest()throws IOException, SAXException, ParserConfigurationException {
		
		File inputFile = new File("./src/test/resources/qualtestdata/creditCard.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		WorkServiceConflictResolution wsc = new WorkServiceConflictResolution();
		wsc.workServiceConflictExists(Order);
	}
}
