package com.att.oce.transformation.test;

import org.junit.Test

import static org.junit.Assert.*;

import com.att.oce.transformation.CancelWirelinePaymentTransformation;;
import groovy.json.JsonSlurper

public class CancelWirelinePaymentTest {
	
	@Test
	def void preConditionTest() {
		File inputFile = new File("./src/test/resources/data/ITPAValidpayload.json");
		Map<String,Object> order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		CancelWirelinePaymentTransformation cwp = new CancelWirelinePaymentTransformation();
		def flag = cwp.preCondition(order, null)
		assertTrue(flag)
	}
	

}
