package com.att.oce.transformation.test


import com.att.oce.transformation.InitiateUnifiedServiceOrderRequestTransformation
import groovy.json.JsonSlurper
import org.junit.Test;
import groovy.util.XmlSlurper
import java.lang.String
class IusoTest {
	
   @Test
	void test()
	{
		File f = new File("./src/test/resources/data/IUSOValidPaylod.json")
		Map<String,Object> order = (Map<String, Object>) new JsonSlurper().parse(f)
		File iusaResponseFile =new File("./src/test/resources/data/iusaResponse.xml")
	def iusaXml=new XmlSlurper().parse(iusaResponseFile)
		 
    def mapAdd= iusaXml.Body.InquireUnifiedServiceAccountResponse.CustomerIdDetailsByOrgId.MapAddressesExt
    println(mapAdd)
		 
    def addressId= mapAdd.findAll{tt-> tt.type.equals ('ServiceFSP')}.collect{it.address1}.flatten().minus(null)
	println(addressId)
		
		 
		    
	 
     InitiateUnifiedServiceOrderRequestTransformation iuso =new InitiateUnifiedServiceOrderRequestTransformation()
    println(iuso.prepareRequest(order,null,null))
			
     File iusoFile = new File("./src/test/resources/data/iusoResponse.xml")
     def iusoXml = new XmlSlurper().parse(iusoFile)
     def iusoRes = iusoXml.Body.InitiateUnifiedServiceOrderResponse
   println(iuso.validateIUSOResponse(Order, iusoRes))
		
		
		
	}
	
}
