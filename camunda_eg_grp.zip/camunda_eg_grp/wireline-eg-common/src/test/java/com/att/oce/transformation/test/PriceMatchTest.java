package com.att.oce.transformation.test;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.junit.Test;
import org.xml.sax.SAXException;

import com.att.oce.transformation.PriceMatchService;

import groovy.json.JsonSlurper;
import groovy.util.XmlSlurper;

public class PriceMatchTest {
	
	@Test
	public void computePricelistTest() throws IOException, SAXException, ParserConfigurationException {
		
		File inputFile = new File("./src/test/resources/qualtestdata/creditCard.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		PriceMatchService pm = new PriceMatchService();
		Map<String,Object> executionContext = new HashMap<String, Object>();
		File puspo = new File("./src/test/resources/qualtestdata/pusporesponse.xml");
		pm.computePriceMisMatch(Order,executionContext,new XmlSlurper().parse(puspo));
		//pm.checkForWirelineUnifyFlow(Order);
	}
}
