package com.att.oce.routes.test;

import static org.junit.Assert.*;

import java.io.File;
import java.util.ArrayList;
//import java.util.Collections
import java.util.Date;
import java.util.List;
import java.util.Map;
//import com.att.oce.config.components.GlobalProperties
import com.att.oce.transformation.WirelineOrderValidation;

import groovy.json.JsonSlurper;

import com.att.oce.beans.config.APIResultConfig;
import com.att.oce.beans.config.OceConfig;
import com.att.oce.bpm.common.WirelineTransformationService;
import com.att.oce.config.components.ErrorConfig;
//import com.att.oce.config.components.ErrorConfig
import com.att.oce.config.components.GlobalProperties;
import com.att.oce.config.components.URNResolver;

import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
//import org.springframework.stereotype.Component
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {WirelineOrderValidationTest.TestConfig.class,
		OceConfig.class, GlobalProperties.class,
		ErrorConfig.class,WirelineOrderValidationTest.class, 
		URNResolver.class, APIResultConfig.class, WirelineOrderValidation.class})
public class WirelineOrderValidationTest 
{
	@Autowired
	protected WirelineOrderValidation validateOrder;
	
	@BeforeClass
	public static void init() {
		//System.setProperty("OCE_RESOURCES_HOME", System.getProperty("user.dir") + "/src/main/resources/dmn/");
		System.setProperty("OCE_RESOURCES_HOME", "D:/rk00330305/ATT/wrkspc1/oce_framework/oce-resources/src/main/resources/");
		System.setProperty("OCE_ERROR_CONFIG", "wireline");
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireless");
	} 

	@Configuration
	public static class TestConfig{
		@Bean
		public static DmnEngine dmnEngine() {
			// create default DMN engine configuration
			DmnEngineConfiguration configuration = DmnEngineConfiguration
			  .createDefaultDmnEngineConfiguration();

			// build a new DMN engine
			DmnEngine dmnEngine = configuration.buildEngine();
			return dmnEngine;
		}
	}
	
	@Test
	public void nack504test() {
		File inputFile = new File("./src/test/resources/data/nack504.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack504"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack507test() {
		File inputFile = new File("./src/test/resources/data/nack507.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack507"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack508test() {
		File inputFile = new File("./src/test/resources/data/nack508.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack508"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack509test() {
		File inputFile = new File("./src/test/resources/data/nack509.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack509"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack510test() {
		File inputFile = new File("./src/test/resources/data/nack510.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack510"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack512test() {
		File inputFile = new File("./src/test/resources/data/nack512.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack512"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack515test() {
		File inputFile = new File("./src/test/resources/data/nack515.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack515"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack517test() {
		File inputFile = new File("./src/test/resources/data/nack517.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack517"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack518test() {
		File inputFile = new File("./src/test/resources/data/nack518.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack518"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack519test() {
		File inputFile = new File("./src/test/resources/data/nack519.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack519"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack520test() {
		File inputFile = new File("./src/test/resources/data/nack520.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack520"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack522test() {
		File inputFile = new File("./src/test/resources/data/nack522.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack522"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack527test() {
		File inputFile = new File("./src/test/resources/data/nack527.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack527"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack532test() {
		File inputFile = new File("./src/test/resources/data/nack532.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack532"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);
	}
	
	@Test
	public void nack534test() {
		File inputFile = new File("./src/test/resources/data/nack534.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack534"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack535test() {
		File inputFile = new File("./src/test/resources/data/nack535.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack535"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack536test() {
		File inputFile = new File("./src/test/resources/data/nack536.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack536"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack538test() {
		File inputFile = new File("./src/test/resources/data/nack538.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack538"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack544test() {
		File inputFile = new File("./src/test/resources/data/nack544.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack544"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}

	@Test
	public void nack555test() {
		File inputFile = new File("./src/test/resources/data/nack555.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack555"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);
	}
	
	@Test
	public void nack556test() {
		File inputFile = new File("./src/test/resources/data/nack556.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack556"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);
	}
	
	@Test
	public void nack557test() {
		File inputFile = new File("./src/test/resources/data/nack557.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack557"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);
	}
	
	@Test
	public void nack558test() {
		File inputFile = new File("./src/test/resources/data/nack558.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack558"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);
	}
	
	@Test
	public void nack570test() {
		File inputFile = new File("./src/test/resources/data/nack570.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack570"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);
	}
	
	@Test
	public void nack579test() {
		File inputFile = new File("./src/test/resources/data/nack579.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack579"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);
	}
	
	@Test
	public void nack581test() {
		File inputFile = new File("./src/test/resources/data/nack581.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack581"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);
	}
	
	@Test
	public void nack586test() {
		File inputFile = new File("./src/test/resources/data/nack586.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack586"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);
	}
	
	@Test
	public void nack611test() {
		File inputFile = new File("./src/test/resources/data/nack611.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack611"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);
	}
	
	@Test
	public void nack617test() {
		File inputFile = new File("./src/test/resources/data/nack617.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack617"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);
	}
	
	@Test
	public void nack627test() {
		File inputFile = new File("./src/test/resources/data/nack627.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack627"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);
	}
	
	@Test
	public void nack502test() {
		File inputFile = new File("./src/test/resources/data/nack502.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack502"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack503test() {
		File inputFile = new File("./src/test/resources/data/nack503.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack503"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack511test() {
		File inputFile = new File("./src/test/resources/data/nack511.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack511"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	@Test
	public void nack514test() {
		File inputFile = new File("./src/test/resources/data/nack514.json");;
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		Map<String,Object> updatedOrder = (Map<String, Object>) validateOrder.validateWirelineOrder(Order);
		List<String> errorCodeList = getErrorList(updatedOrder);

		assertTrue(errorCodeList.contains("nack514"));
		System.out.println("error=========================>>>>>>>>>>>>>"+errorCodeList);

	}
	
	public List getErrorList(Map<String,Object> updatedOrder)
	{
		Map<String,Object> errors = (Map<String, Object>)updatedOrder.get("Errors");
		List errorList = (List) errors.get("Error");
		List<String> errorCodeList = new ArrayList<String>();
		for (int i = 0; i < errorList.size(); i++) {
			Map<String,Object> e = (Map<String, Object>) errorList.get(i);
			String code = (String) e.get("ErrorCode") ;
			errorCodeList.add(code);			
		}
		return errorCodeList;
		
	}
}
	
	

