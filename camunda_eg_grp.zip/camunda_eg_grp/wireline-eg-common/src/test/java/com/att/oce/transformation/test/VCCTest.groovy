package com.att.oce.transformation.test

import com.att.oce.transformation.ValidateCreditCardTransformation
import groovy.json.JsonSlurper
import org.junit.Test

class VCCTest {
	@Test
	def void testTransformation()
	{
		File f=new File("./src/test/resources/data/VCCpayload.json");
		    Map<String,Object> order = (Map<String,Object>)new JsonSlurper().parse(f);
			ValidateCreditCardTransformation vcc=new ValidateCreditCardTransformation();
			//println(vcc.prepareRequest(order,null));
			println(vcc.preCondition(order));
			println(vcc.prepareRequest(order,null));
	}

}
