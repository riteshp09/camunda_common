package com.att.oce.transformation.test;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.beans.config.APIResultConfig;
import com.att.oce.beans.config.OceConfig;
import com.att.oce.bpm.utility.WirelineUtility;
import com.att.oce.config.components.ErrorConfig;
import com.att.oce.config.components.URNResolver;
import com.att.oce.transformation.QualificationRules;

import groovy.json.JsonSlurper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {QualificationRules.class,OceConfig.class, ErrorConfig.class,URNResolver.class})
public class QualificationRulesTest {

	@Autowired
	protected QualificationRules qualificationRules;

	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "D:/aj00351351/ATT/Camunda/Camunda_OCE_framework/oce-resources/src/main/resources");
		//		System.setProperty("OCE_ERROR_CONFIG", "wireline");
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireline");
	} 

	/*@Configuration
	public static class TestConfig{
		@Bean
		public static DmnEngine dmnEngine() {
			// create default DMN engine configuration
			DmnEngineConfiguration configuration = DmnEngineConfiguration
			  .createDefaultDmnEngineConfiguration();

			// build a new DMN engine
			DmnEngine dmnEngine = configuration.buildEngine();
			return dmnEngine;
		}

	}*/

	//@Test
	public void dobQualificationRuleTest() {
		//		init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/dobCheckOrder.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.dateOfBirth(Order,qualErrorList);
		assertTrue(errorCodeList.size() > 0);
	}

	//@Test
	public void AuthenticationQuestionTest() {
		//			init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/dobCheckOrder.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.CheckAuthenticationQuestion(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
	}

	//@Test
	public void MultipleInstallmentTermsTest() {
		//			init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/dobCheckOrder.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.CheckMultipleInstallmentTerms(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
	}

	//@Test
	public void checkSafeScanTest() {
		//			init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/SafeScan.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkSafeScan(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
	}

	//@Test
	public void CheckDTVReferralExistsTest() {
		//			init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/SafeScan.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.CheckDTVReferralExists(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
	}

	//@Test
	public void CheckSalesChannelTest() {
		//			init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/SafeScan.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.CheckSalesChannel(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
	}

	//@Test
	public void CheckCreditCardTest() {
		//			init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/creditCard.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.CheckCreditCard(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
	}

	//@Test
	public void IsDSLAvailableTest() {
		//					init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/creditCard.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.IsDSLAvailable(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
	}

	//@Test
	public void checkIsPOTSAvailableTest() {
		//			init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/creditCard.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkIsPOTSAvailable(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
	}

	//@Test
	public void checkLPMInfoExistsTest() {
		//					init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/creditCard.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkLPMInfoExists(Order, qualErrorList);
		System.out.println(errorCodeList.size());
		assertTrue(errorCodeList.size() > 0);
	}

	//@Test
	public void checkAutopayLPMTermsandConditionsTest() {
		//					init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/creditCard.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkAutopayLPMTermsandConditions(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
	}	

	//@Test
	public void checkOfferIdTest() {
		//					init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/creditCard.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkOfferId(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
		System.out.println(errorCodeList);
	}	


	//@Test
	public void checkCAPMTest() {
		//					init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/creditCard.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkCAPM(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
		System.out.println(errorCodeList);
	}	

	//@Test
	public void checkACHDetailsExistsTest() {
		//					init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/creditCard.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkACHDetailsExists(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
		System.out.println(errorCodeList);
	}	

	//@Test
	public void checkIfAutopayForHighRiskCustomerTest() {
		//					init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/creditCard.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkIfAutopayForHighRiskCustomer(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
		System.out.println(errorCodeList);
	}	

	//@Test
	public void checkMorethanOnePaymentOptionForAutopayTest() {
		//					init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/creditCard.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkMorethanOnePaymentOptionForAutopay(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
		System.out.println(errorCodeList);
	}

	//@Test
	public void checkForCAPMProfileNameTest() {
		//					init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/creditCard.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkForCAPMProfileName(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
		System.out.println(errorCodeList);
	}

	//@Test
	public void checkServiceAddressTest() {
		//					init();
		List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/qualtestdata/serviceAddress.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkServiceAddress(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
		System.out.println(errorCodeList);
	}

	// @Test
	public void checkForPortingAddressNotVerfiedTest() {
		//					init();
		List qualErrorList = new ArrayList();
		String voipGrpRef = "GROUP_04";
		String voipAGrpRef = "GROUP_06";
		String desc = "PortingAddress1NotVerfied";
		File inputFile = new File("./src/test/resources/qualtestdata/PortingAddressNotVerified.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkForPortingAddressNotVerfied(Order,voipGrpRef, qualErrorList, desc);
		assertTrue(errorCodeList.size() > 0);
		System.out.println(errorCodeList);
	}

	//@Test
	public void checkIfPortingAccountsNotSameTest() {
		//					init();
		List qualErrorList = new ArrayList();
		String voipPGrpRef = "GROUP_04";
		String voipAGrpRef = "GROUP_06";
		
		File inputFile = new File("./src/test/resources/qualtestdata/PortingAddressNotVerified.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkIfPortingAccountsNotSame(Order, voipPGrpRef, voipAGrpRef, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
		System.out.println(errorCodeList);
	}

	//@Test
	public void checkForPortingEligibilityLineRespDoesnotExistsTest() {
		//					init();
		List qualErrorList = new ArrayList();
		String voipPGrpRef = "GROUP_04";
		String desc = "checkForPortingEligibilityLineRespDoesnotExists";

		File inputFile = new File("./src/test/resources/qualtestdata/PortingAddressNotVerified.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkForPortingEligibilityLineRespDoesnotExists(Order, voipPGrpRef, qualErrorList, desc);
		assertTrue(errorCodeList.size() > 0);
		System.out.println(errorCodeList);
	}
	
	//@Test
	public void checkIfPortingAddressNotSameTest() {
		//					init();
		List qualErrorList = new ArrayList();
		String voipPGrpRef = "GROUP_04";
		String voipAGrpRef = "GROUP_06";
		

		File inputFile = new File("./src/test/resources/qualtestdata/PortingAddressNotVerified.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.checkIfPortingAddressNotSame(Order, voipPGrpRef, voipAGrpRef, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
		System.out.println(errorCodeList);
	}
	
	@Test
	public void QualificationChecksForVOIPTest() {
		//					init();
		List qualErrorList = new ArrayList();
		
		File inputFile = new File("./src/test/resources/qualtestdata/PortingAddressNotVerified.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) qualificationRules.QualificationChecksForVOIP(Order, qualErrorList);
		assertTrue(errorCodeList.size() > 0);
		System.out.println("Error List " + errorCodeList);
		
		WirelineUtility wu = new WirelineUtility();
		wu.assignFalloutStatus(Order, errorCodeList);
		wu.prepeareErrorLsit(Order, errorCodeList, null);
		
	}


	/*public List getErrorList(Map<String,Object> updatedOrder)
	{
		Map<String,Object> errors = (Map<String, Object>)updatedOrder.get("Errors");
		List errorList = (List) errors.get("Error");
		List<String> errorCodeList = new ArrayList<String>();
		for (int i = 0; i < errorList.size(); i++) {
			Map<String,Object> e = (Map<String, Object>) errorList.get(i);
			String code = (String) e.get("ErrorCode") ;
			errorCodeList.add(code);			
		}
		return errorCodeList;

	}*/


}
