package com.att.oce.transformation.test

import com.att.oce.transformation.InquireTransportProductAvailabilityTransformation;
import groovy.json.JsonSlurper
import org.junit.Test

class ITPATest {

	@Test
	def void testTransformation() {
		File inputFile = new File("./src/test/resources/data/ITPAValidpayload.json");
		Map<String,Object> order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
	InquireTransportProductAvailabilityTransformation itpa = new InquireTransportProductAvailabilityTransformation();
		println(itpa.prepareRequest(order,null))
	}
}
