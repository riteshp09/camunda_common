package com.att.oce.bpm.beans.services

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate
import org.camunda.bpm.engine.history.HistoricProcessInstance;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.springframework.stereotype.Component;
import com.att.oce.config.components.GlobalProperties;


@Component('initiateOrdQualificationRuleCtx')
class InitiateOrderQualificationRuleCtx implements JavaDelegate {
	
	@Resource
	protected GlobalProperties globalConfig;
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		def order = (HashMap<String, Object>) execution.getVariable("order");
		
		def ruleContext = new HashMap<String, String>();
		
		ruleContext.put("channel", order.OrderSource.Channel)
//		ruleContext.put("losgType", order.Groups.Group[0].GroupCharacteristics.LoSGCharacteristics.LoSGType)
		ruleContext.put("productCategory", order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.ProductCategory)
		ruleContext.put("enterpriseType",order.Accounts.Account.EnterpriseType)
		ruleContext.put("accountCategory",order.Accounts.Account.AccountCategory)
		
		execution.setVariable("ruleContext",ruleContext)
		execution.setVariable("LoSGTypes",order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.LoSGType)
				
		
	}


}
