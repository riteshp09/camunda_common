package com.att.oce.bpm.beans.services;

import java.util.HashMap;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

import com.att.oce.bpm.common.WirelineConstants;
import com.att.oce.bpm.utility.OrderUtility;

@Component("updateOrderLoSGStatus")
public class UpdateOrderLoSGStatus implements JavaDelegate {

	@SuppressWarnings("unchecked")
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		Map<String,Object> executionContext = (Map<String, Object>) execution.getVariable("executionContext");
		Map<String, Object> order = (Map<String, Object>) execution.getVariable("order");
		
		Map<String, Object> wirelineAccount = (Map<String, Object>) OrderUtility.getWirelineAccount(order);
		Map<String, Object> dtvAccount = (Map<String, Object>) OrderUtility.getDTVAccount(order);
		
		if(wirelineAccount != null && !wirelineAccount.isEmpty()) {
			executionContext.put("referenceId",wirelineAccount.get("Id"));
			OrderUtility.updateLoSGStatusForAccount(order, wirelineAccount.get("Id"),
					WirelineConstants.LOSG_STATUS_IN_QUEUE,WirelineConstants.LOSG_MANUAL_PROVISIONING_REQUIRED);
			OrderUtility.updateErrorList(order, executionContext, null,
					WirelineConstants.LOSG_STATUS_IN_QUEUE, WirelineConstants.LOSG_MANUAL_PROVISIONING_REQUIRED, executionContext.get("referenceId"));
		}
		if(dtvAccount != null && !dtvAccount.isEmpty()) {
			executionContext.put("referenceId",dtvAccount.get("Id"));
			OrderUtility.updateLoSGStatusForAccount(order, dtvAccount.get("Id"),
					WirelineConstants.LOSG_STATUS_IN_QUEUE,WirelineConstants.LOSG_MANUAL_PROVISIONING_REQUIRED);
			OrderUtility.updateErrorList(order, executionContext, null,
					WirelineConstants.LOSG_STATUS_IN_QUEUE, WirelineConstants.LOSG_MANUAL_PROVISIONING_REQUIRED, executionContext.get("referenceId"));
		}
		
//		String addOnSolAcc = (String) OrderUtility.getAddOnSolutionAccount(order);
		
//		Map<String,Object> qualificationResult = (HashMap<String, Object>) execution.getVariable("qualificationResult");
		/*OrderUtility.updateLoSGStatusForAccount(order, wirelineAccount.get("Id"),
				WirelineConstants.LOSG_STATUS_IN_QUEUE,WirelineConstants.LOSG_MANUAL_PROVISIONING_REQUIRED);*/
		
		
		/*

		ArrayList<Map<String,Object>> transactionHistory = (ArrayList<Map<String, Object>>) executionContext.get("transactionHistory");

		if( transactionHistory != null){
			transactionHistory.add(CommonUtility.getMap("time",new Date(),
					"status",qualificationResult.get("losgStatus"),
					"subStatus",qualificationResult.get("losgSubStatus")));
		} else {
			transactionHistory = new ArrayList<Map<String,Object>>();
			transactionHistory.add(CommonUtility.getMap("time",new Date(),
					"status",qualificationResult.get("losgStatus"),
					"subStatus",qualificationResult.get("losgSubStatus")));
		}
		executionContext.put("transactionHistory",transactionHistory);
		execution.setVariable("executionContext",executionContext);
		
		OrderUtility.updateLoSGStatus(order, executionContext);
		execution.setVariable("order", order);*/
	}
}
