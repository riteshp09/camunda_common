Place any Deployment Packages (zips) in this folder to be deployed with your service.
This can be used for importing older Nimbus deployment packages to the AJSC. Not all
prior Nimbus services are available and therefore, not ALL former Nimbus deployment
packages will convert directly to AJSC. However, for Service Development, you may create
other Services (Deployment Packages) as separate services and test by themselves. Then, 
simply take the created zip (deployment package) of the service and place in THIS services folder for it
to be deployed within this AJSC Container.  This folder will be copied to the ultimate AJSC_HOME/services
folder from which all services are deployed.