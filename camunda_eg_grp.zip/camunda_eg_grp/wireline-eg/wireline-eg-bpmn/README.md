# Wireless DF Upgrade Process

This respository is used to define processes. Related processes can be defined together but each process should be testable by itself.


# wireless-up-df
This process validates and automated wireless DF upgrade orders.

# Unit testing framework
This process also includes a unit testing framework which will mock the camel routes and return the responses provided by the test case
based on the activity Id or activity name.
  


