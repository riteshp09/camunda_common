package org.camunda.bpm;

import org.camunda.bpm.engine.history.HistoricActivityInstance;
import org.camunda.bpm.engine.history.HistoricProcessInstance;
import org.camunda.bpm.engine.runtime.Job;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.engine.test.Deployment;
import org.camunda.bpm.engine.test.ProcessEngineRule;
import org.camunda.bpm.engine.test.mock.Mocks;
import org.junit.Rule;
import org.junit.Test;
import static org.junit.Assert.*;

import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.transformation.InquireAccountProfileTransformation;

import java.util.HashMap;
import java.util.Map;

/**
 * Sanity test to verify the example process is syntactical correct and can be
 * deployed to the engine. All "real" tests should be implemented in the
 * according modules (jbehave, assertions, needle, ...).
 */

public class SuccessPreconditionTrueTest {

	@Rule
	public ProcessEngineRule processEngineRule = new ProcessEngineRule();

	@Test
	@Deployment(resources = "bpmn/example.bpmn")
	public void execute() throws Exception {

		Mocks.register("camel", new CamelMock(processEngineRule));
		Mocks.register("inquireAccountProfileTransformation", new InquireAccountProfileTransformation());

		Map<String, Object> variables = new HashMap<>();
		variables.put("order", TestOrderBuilder.build("SimpleWirelessOrder").getMapofMaps());
		variables.put("executionContext", new HashMap<String, Object>());

		final ProcessInstance processInstance = processEngineRule.getRuntimeService()
				.startProcessInstanceByKey("example-key", "regular", variables);
		while (true) {
			Job job = processEngineRule.getManagementService().createJobQuery().singleResult();
			if (job == null)
				break;
			processEngineRule.getManagementService().executeJob(job.getId());
		}
		
		ProcessInstance runinst = processEngineRule.getRuntimeService().createProcessInstanceQuery()
				.processInstanceId(processInstance.getId()).singleResult();
		assertEquals(null,runinst);
		HistoricProcessInstance histinst = processEngineRule.getHistoryService().createHistoricProcessInstanceQuery()
				.processInstanceId(processInstance.getId()).finished().singleResult();
		assertNotEquals(histinst, null);
		
		assertTrue(processEngineRule.getHistoryService().createHistoricActivityInstanceQuery().activityId("execUAP").list().size() > 0);

	}

}
