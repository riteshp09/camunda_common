package org.camunda.bpm;

import org.camunda.bpm.engine.history.HistoricProcessInstance;
import org.camunda.bpm.engine.runtime.Job;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.engine.test.Deployment;
import org.camunda.bpm.engine.test.ProcessEngineRule;
import org.camunda.bpm.engine.test.mock.Mocks;
import org.junit.Rule;
import org.junit.Test;
import static org.junit.Assert.*;

import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.transformation.InquireAccountProfileTransformation;

import java.util.HashMap;
import java.util.Map;

/**
 * Sanity test to verify the example process is syntactical correct and can be
 * deployed to the engine. All "real" tests should be implemented in the
 * according modules (jbehave, assertions, needle, ...).
 */

public class SuccessPreconditionFalseTest {

	@Rule
	public ProcessEngineRule processEngineRule = new ProcessEngineRule();

	@SuppressWarnings("unchecked")
	@Test
	@Deployment(resources = "bpmn/example.bpmn")
	public void execute() throws Exception {

		Mocks.register("camel", new CamelMock(processEngineRule));
		Mocks.register("inquireAccountProfileTransformation", new InquireAccountProfileTransformation());
		
		InquireAccountProfileTransformation transform = new InquireAccountProfileTransformation();
		
		Map<String,Object> order = (Map<String,Object>)transform.updateOrder(TestOrderBuilder.build("SimpleWirelessOrder").getMapofMaps(), TestOrderBuilder.build("InquireAccountProfileSuccessResponse.xml").toString(),0);

		Map<String, Object> variables = new HashMap<>();
		variables.put("order", order);
		variables.put("executionContext", new HashMap<String, Object>());

		final ProcessInstance processInstance = processEngineRule.getRuntimeService()
				.startProcessInstanceByKey("example-key", "regular", variables);
		while (true) {
			Job job = processEngineRule.getManagementService().createJobQuery().singleResult();
			if (job == null)
				break;
			processEngineRule.getManagementService().executeJob(job.getId());
		}
		
		ProcessInstance runinst = processEngineRule.getRuntimeService().createProcessInstanceQuery()
				.processInstanceId(processInstance.getId()).singleResult();
		assertEquals(null,runinst);
		HistoricProcessInstance histinst = processEngineRule.getHistoryService().createHistoricProcessInstanceQuery()
				.processInstanceId(processInstance.getId()).finished().singleResult();
		assertNotEquals(histinst, null);
		
		assertTrue(processEngineRule.getHistoryService().createHistoricActivityInstanceQuery().activityId("execUAP").list().size() == 0);

	}

}
