package org.camunda.bpm;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.ExchangeBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.ModelCamelContext;
import org.apache.camel.spring.javaconfig.SingleRouteCamelConfiguration;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.apache.camel.test.spring.CamelSpringDelegatingTestContextLoader;

import com.att.oce.beans.config.APIResultConfig;
import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.bpm.error.APIFailedException;
import com.att.oce.beans.config.OceConfig;
import com.att.oce.config.components.GlobalProperties;
import com.att.oce.config.components.URNResolver;
import com.att.oce.routes.ExampleRouteBuilder;
import com.att.oce.transformation.InquireAccountProfileTransformation;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;

import org.junit.runners.MethodSorters;

@RunWith(CamelSpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {ExampleRouteFailure200Test.TestConfig.class,OceConfig.class, APIResultConfig.class,
		InquireAccountProfileTransformation.class, GlobalProperties.class, URNResolver.class}, loader = CamelSpringDelegatingTestContextLoader.class)

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ExampleRouteFailure200Test extends AbstractJUnit4SpringContextTests{
	
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "../../../oce_framework/oce-resources/src/main/resources/");
		System.out.println(System.getProperty("OCE_RESOURCES_HOME"));
		System.setProperty("OCE_ENV", "dev");
	}

	@Configuration
	public static class TestConfig extends SingleRouteCamelConfiguration {
		@Bean
		@Override
		public RouteBuilder route() {
			return new ExampleRouteBuilder();
		}
		@Bean
		public static DmnEngine dmnEngine() {
			// create default DMN engine configuration
			DmnEngineConfiguration configuration = DmnEngineConfiguration
			  .createDefaultDmnEngineConfiguration();

			// build a new DMN engine
			DmnEngine dmnEngine = configuration.buildEngine();
			return dmnEngine;
		}
	}

	@Produce(uri = "direct:csi:iapx")
	protected ProducerTemplate testProducer;

	

	@Test
	public void testRouteFailure200() throws Exception {
		//if (true) return;
		InquireAccountProfileTransformation iapXfrm = new InquireAccountProfileTransformation();
		testProducer.getCamelContext().getRouteDefinitions().get(0)
				.adviceWith(testProducer.getCamelContext().adapt(ModelCamelContext.class), new RouteBuilder() {
					@Override
					public void configure() throws Exception {
						interceptSendToEndpoint("https://headeruri?throwExceptionOnFailure=false").skipSendToOriginalEndpoint().setBody(constant(
								TestOrderBuilder.build("InquireAccountProfileFailure200Response.xml").toString()));
					}
				});
		Map<String,Object> map = new HashMap<>();
		map.put("order", TestOrderBuilder.build("SimpleWirelessOrder").getMapofMaps());
		Exchange e = ExchangeBuilder.anExchange(testProducer.getCamelContext())
				.withBody(map)
				.withProperty("executionContext", new HashMap<String, Object>()).withPattern(ExchangePattern.InOut)
				.build();
		testProducer.send(e);
		if (e.getException() != null){
			assertEquals(e.getException().getClass(), APIFailedException.class);
		}
		
	}

	
	
	
}
