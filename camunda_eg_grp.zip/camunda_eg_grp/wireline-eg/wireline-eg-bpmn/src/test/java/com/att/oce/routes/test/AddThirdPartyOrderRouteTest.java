package com.att.oce.routes.test;

import java.util.HashMap;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.ExchangeBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.ModelCamelContext;
import org.apache.camel.spring.javaconfig.SingleRouteCamelConfiguration;
import org.apache.camel.test.spring.CamelSpringDelegatingTestContextLoader;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;


import com.att.oce.bpm.common.MapBuilder;
import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.beans.config.APIResultConfig;
import com.att.oce.beans.config.OceConfig;

import com.att.oce.config.components.GlobalProperties;
import com.att.oce.config.components.URNResolver;

import com.att.oce.routes.AddThirdPartyOrderRouteBuilder;
import com.att.oce.transformation.AddThirdPartyOrderTransformation;

@RunWith(CamelSpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {AddThirdPartyOrderRouteTest.TestConfig.class,
		OceConfig.class,
		APIResultConfig.class,
		AddThirdPartyOrderTransformation.class,
		GlobalProperties.class,
		URNResolver.class}, loader = CamelSpringDelegatingTestContextLoader.class)

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AddThirdPartyOrderRouteTest  {

	@Configuration
	public static class TestConfig extends SingleRouteCamelConfiguration {
		@Bean
		@Override
		public RouteBuilder route() {
			return new AddThirdPartyOrderRouteBuilder();
		}
		@Bean
		public static DmnEngine dmnEngine() {
			// create default DMN engine configuration
			DmnEngineConfiguration configuration = DmnEngineConfiguration
					.createDefaultDmnEngineConfiguration();

			// build a new DMN engine
			DmnEngine dmnEngine = configuration.buildEngine();
			return dmnEngine;
		}

	}

	@Produce(uri = "direct:AddThirdPartyOrder")
	protected ProducerTemplate ATPOTemplate;

	@BeforeClass
	public static void  init() {
		//System.setProperty("OCE_RESOURCES_HOME", "./../../../../oce_framework_all_24_03/oce-resources/src/main/resources/");	
		System.setProperty("OCE_RESOURCES_HOME", "D:/RP00425428/ATT/project_documents/oce-resources/");
		System.setProperty("OCE_ERROR_CONFIG", "wireline");
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireless");
	}

	@DirtiesContext
	@Test
	public void testRoute() throws Exception {

		HashMap<String, Object> orderMap = (HashMap<String, Object>) TestOrderBuilder
				.build("ATPOPreConditionTest.json").getMapofMaps();
		HashMap<String, Object> groups = (HashMap<String, Object>) orderMap.get("productGroups");
		List<Object> groupList = (List<Object>) groups.get("group");
		HashMap<String, Object> losg = (HashMap<String, Object>) groupList.get(2);
		System.out.println("losg**" +losg);
		ATPOTemplate.getCamelContext().getRouteDefinitions().get(0)
		.adviceWith(ATPOTemplate.getCamelContext().adapt(ModelCamelContext.class), new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				String responseXml = TestOrderBuilder.build("data/csi/AddThirdPartyOrderResponse.xml").toString();
				System.out.println("responseXml" +responseXml);
				interceptSendToEndpoint("http://headeruri?throwExceptionOnFailure=false")
				.skipSendToOriginalEndpoint().setBody(constant(responseXml));
			}
		});
		
		
		Exchange e = ATPOTemplate.send("direct:AddThirdPartyOrder",
				ExchangeBuilder.anExchange(ATPOTemplate.getCamelContext())
				.withBody(MapBuilder.build()
						.add("group", losg)
						.add("order", TestOrderBuilder.build("ATPOPreConditionTest.json").getMapofMaps()).get())
				.withProperty("executionContext", MapBuilder.build().add("test", "testvalue").get())
				.build());

		System.out.println("Response from Camel to BPMN:"+e.getProperty("executionContext"));
	}

}





