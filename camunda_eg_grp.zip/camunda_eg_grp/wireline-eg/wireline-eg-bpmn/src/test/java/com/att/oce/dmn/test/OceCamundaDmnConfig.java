package com.att.oce.dmn.test;

import java.io.File;
import java.io.FileNotFoundException;

import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.model.dmn.Dmn;
import org.camunda.bpm.model.dmn.DmnModelInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OceCamundaDmnConfig {

	private final Logger logger = LoggerFactory.getLogger(OceCamundaDmnConfig.class);
	
	private static String OCE_RESOURCES_HOME = System.getProperty("OCE_RESOURCES_HOME");

	private static String ORDER_QUALIFICATION_DMN = OCE_RESOURCES_HOME + "OrderAutomationQualificationRules.dmn";
	
	//dmnEngine should be exposed using @Bean by the Spring Application which needs to leverage this RetryConfig 
	@Autowired
	private DmnEngine dmnEngine;

	@Bean(name = "orderStatusRules")
	public DmnDecision orderStatusRules() throws FileNotFoundException {
		File file = new File(ORDER_QUALIFICATION_DMN);		
		//FileInputStream fis = new FileInputStream(file);
		DmnModelInstance dmnModelInstance  = Dmn.readModelFromFile(file);
		
		//XlsxConverter converter = new XlsxConverter();
		//DmnModelInstance dmnModelInstance = converter.convert(fis);		
		return dmnEngine.parseDecision("decision-getstatus" , dmnModelInstance);
	}	
	
	@Bean(name = "orderQualificationRules")
	public DmnDecision orderQualificationRules() throws FileNotFoundException {
		File file = new File(ORDER_QUALIFICATION_DMN);		
		//FileInputStream fis = new FileInputStream(file);
		DmnModelInstance dmnModelInstance  = Dmn.readModelFromFile(file);
		
		//XlsxConverter converter = new XlsxConverter();
		//DmnModelInstance dmnModelInstance = converter.convert(fis);		
		return dmnEngine.parseDecision("orderQualificationRules" , dmnModelInstance);
	}	
	
}
