package com.att.oce.dmn.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.jasper.tagplugins.jstl.core.ForEach;
import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionRuleResult;
import org.camunda.bpm.dmn.engine.DmnDecisionTableResult;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.camunda.bpm.engine.variable.VariableMap;
import org.camunda.bpm.engine.variable.Variables;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Test class to validate Retry Decision table.
 * 
 * This test class takes care of exposing dependent dmnEngine bean.
 * 
 * 
 * Imp: 
 *  configure ENV variable as below to run this test on local machine:
 * 		-DOCE_RESOURCES_HOME= <path to oce-resources/src/main/resources>
 *
 * @author kp7466
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {OrderQualificationDmnTest.class, OceCamundaDmnConfig.class})
public class OrderQualificationDmnTest {

	/**
	 * Env variable OCE_RESOURCES_HOME is used to read resources file.
	 *  -DOCE_RESOURCES_HOME= <path to oce-resources/src/main/resources>
	 */
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", System.getProperty("user.dir") + "/src/main/resources/dmn/");
		System.out.println(System.getProperty("OCE_RESOURCES_HOME"));
	} 
	
	@Autowired
	private DmnEngine dmnEngine;
	
	@Bean
	public static DmnEngine dmnEngine() {
		// create default DMN engine configuration
		DmnEngineConfiguration configuration = DmnEngineConfiguration
		  .createDefaultDmnEngineConfiguration();

		// configure as needed
		// ...

		// build a new DMN engine
		DmnEngine dmnEngine = configuration.buildEngine();
		return dmnEngine;
	}
	
	@Resource(name = "orderQualificationRules")
	private DmnDecision orderQualificationRules;
	
	@Resource(name = "orderStatusRules")
	private DmnDecision orderStatusRules;
	
	/*@Test
	public void testDmnEngineInjection() {
		Assert.assertNotNull(dmnEngine);
	}*/
	
	/*@Test
	public void testRetryDecisionTableInjection() {
		Assert.assertNotNull(retryDecisions);		
		Assert.assertTrue(retryDecisions.isDecisionTable());
	}*/
	
	@Test
	public void testLegacy() {
		
		ArrayList<String> productCategory = new ArrayList<>();
		productCategory.add("DSL");
		productCategory.add("CDTV");
		productCategory.add("POTS");
		
		ArrayList<String> accountCategory = new ArrayList<>();
		accountCategory.add("DTV_ACCOUNT");
		accountCategory.add("WIRELINE_ACCOUNT");
		
		HashMap<String, Object> ruleContext = new HashMap<>();
		
		ruleContext.put("channel", "SMB-WEB-CENTER");
		ruleContext.put("losgType", "PROVIDE");
		ruleContext.put("productCategory", productCategory);
		ruleContext.put("enterpriseType","SMB");
		ruleContext.put("accountCategory", accountCategory);
		
		VariableMap variables = Variables.createVariables()
			.putValue("ruleContext", ruleContext);
		
		DmnDecisionTableResult results = dmnEngine
					.evaluateDecisionTable(orderStatusRules, variables);
		
		//Assert that only one result has matched
		Assert.assertEquals(1, results.size());
		
		
		DmnDecisionRuleResult result = results.getFirstResult();		

		//assert that it only has 1 entry
		//assert that returned entry is for "numOfRetries" and is 0
		Assert.assertEquals("IN_QUEUE", result.get("losgStatus"));
		Assert.assertEquals("MANUAL_PROVISIONING_REQUIRED", result.get("losgSubStatus"));
		Assert.assertEquals("LEGACY", result.get("flowType"));
	}
	
	@Test
	public void testLegacyPlusBoost() {
		
		ArrayList<String> productCategory = new ArrayList<>();
		productCategory.add("DSL");
		productCategory.add("CDTV");
		productCategory.add("BOOST");
		
		ArrayList<String> accountCategory = new ArrayList<>();
		accountCategory.add("DTV_ACCOUNT");
		accountCategory.add("WIRELINE_ACCOUNT");
		accountCategory.add("BOOST_ACCOUNT");
		
		HashMap<String, Object> ruleContext = new HashMap<>();
		
		ruleContext.put("channel", "SMB-WEB-CENTER");
		ruleContext.put("losgType", "PROVIDE");
		ruleContext.put("productCategory", productCategory);
		ruleContext.put("enterpriseType","SMB");
		ruleContext.put("accountCategory", accountCategory);
		
		VariableMap variables = Variables.createVariables()
			.putValue("ruleContext", ruleContext);
		
		DmnDecisionTableResult results = dmnEngine
					.evaluateDecisionTable(orderStatusRules, variables);
		
		//Assert that only one result has matched
		Assert.assertEquals(1, results.size());
		
		
		DmnDecisionRuleResult result = results.getFirstResult();		

		//assert that it only has 1 entry
		//assert that returned entry is for "numOfRetries" and is 0
		Assert.assertEquals("SYS_PROCESSING", result.get("losgStatus"));
		Assert.assertEquals("BOOST_VERIFIED", result.get("losgSubStatus"));
		Assert.assertEquals("SMB", result.get("flowType"));
	}
	
	@Test
	public void testLegacyPlusBoostPlusUverse() {
		
		ArrayList<String> productCategory = new ArrayList<>();
		productCategory.add("DSL");
		productCategory.add("CDTV");
		productCategory.add("BOOST");
		productCategory.add("INTERNET");
		
		ArrayList<String> accountCategory = new ArrayList<>();
		accountCategory.add("DTV_ACCOUNT");
		accountCategory.add("WIRELINE_ACCOUNT");
		accountCategory.add("BOOST_ACCOUNT");
		accountCategory.add("UVERSE_ACCOUNT");
		
		HashMap<String, Object> ruleContext = new HashMap<>();
		
		ruleContext.put("channel", "SMB-WEB-CENTER");
		ruleContext.put("losgType", "PROVIDE");
		ruleContext.put("productCategory", productCategory);
		ruleContext.put("enterpriseType","SMB");
		ruleContext.put("accountCategory", accountCategory);
		
		VariableMap variables = Variables.createVariables()
			.putValue("ruleContext", ruleContext);
		
		DmnDecisionTableResult results = dmnEngine
					.evaluateDecisionTable(orderStatusRules, variables);
		
		//Assert that only one result has matched
		Assert.assertEquals(1, results.size());
		
		
		DmnDecisionRuleResult result = results.getFirstResult();		

		//assert that it only has 1 entry
		//assert that returned entry is for "numOfRetries" and is 0
		Assert.assertEquals("SYS_PROCESSING", result.get("losgStatus"));
		Assert.assertEquals("UVERSE_VERIFIED", result.get("losgSubStatus"));
		Assert.assertEquals("UVERSE", result.get("flowType"));
	}
	
	@Test
	public void testOtherOrderTypes() {
		
		ArrayList<String> productCategory = new ArrayList<>();
		productCategory.add("WIRELESS");
		
		ArrayList<String> accountCategory = new ArrayList<>();
		accountCategory.add("MOBILITY_ACCOUNT");
		
		HashMap<String, Object> ruleContext = new HashMap<>();
		
		ruleContext.put("channel", "UNLOCK");
		ruleContext.put("losgType", "UNLOCK");
		ruleContext.put("productCategory", productCategory);
		ruleContext.put("enterpriseType","CON");
		ruleContext.put("accountCategory", accountCategory);
		
		VariableMap variables = Variables.createVariables()
			.putValue("ruleContext", ruleContext);
		
		DmnDecisionTableResult results = dmnEngine
					.evaluateDecisionTable(orderStatusRules, variables);
		
		//Assert that only one result has matched
		Assert.assertEquals(1, results.size());
		
		
		DmnDecisionRuleResult result = results.getFirstResult();		

		//assert that it only has 1 entry
		//assert that returned entry is for "numOfRetries" and is 0
		Assert.assertEquals("SYS_PROCESSING", result.get("losgStatus"));
		Assert.assertEquals("UVERSE_VERIFIED", result.get("losgSubStatus"));
		Assert.assertEquals("UVERSE", result.get("flowType"));
	}

	/*@Test
	public void testMatchedRetryDecision() {
		
		VariableMap variables = Variables.createVariables()
			.putValue("errorCode", "200")
			.putValue("api", "ValidateAddress");
		
		DmnDecisionTableResult results = dmnEngine
					.evaluateDecisionTable(retryDecisions, variables);
		
		//Assert that only one result has matched
		Assert.assertEquals(1, results.size());
		
		
		DmnDecisionRuleResult result = results.getFirstResult();		

		//assert that it only has 1 entry
		Assert.assertEquals(3, result.size());		
		Assert.assertEquals(5, result.get("numOfRetries"));
		Assert.assertEquals(10, result.get("interval"));
		Assert.assertEquals(true, result.get("expBackoff"));
	}*/

}
