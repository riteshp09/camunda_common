package com.att.oce.transformation

import javax.annotation.Resource;

import org.apache.camel.Exchange
import org.json.JSONObject
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component

import com.att.oce.bpm.common.OceConstants
import com.att.oce.bpm.common.WirelineProperties
import com.att.oce.bpm.transformations.ATGHelper

import groovy.json.JsonSlurper
import com.att.oce.bpm.utility.BpmProcessUtility

@Component('startProcessTransformation')
class StartProcessTransformation {
	
	static Logger log = LoggerFactory.getLogger(StartProcessTransformation.class)
	
	@Resource
	protected WirelineProperties wirelineProperties;

	/*
	 * This function will check the order payload and decide which process to invoke
	 */
	public void transform(Exchange exchange){
		println('StartProcessTransformation.transform <-- Entering')
		log.info('StartProcessTransformation.transform <-- Entering');
		def incomingPayload = exchange.in.body
		incomingPayload = BpmProcessUtility.toJSONMap(incomingPayload.toString(),true)
		if(!incomingPayload.customerOrderNumber && incomingPayload.order.customerOrderNumber){
			incomingPayload = incomingPayload.order
		}
		def fedPayload = ATGHelper.convertFToNF(incomingPayload)
		println('StartProcessTransformation.transform <-- Converted fedPayload ' + fedPayload)
		log.info('StartProcessTransformation.transform <-- Converted fedPayload ' + fedPayload);
		def jsonMap = BpmProcessUtility.toJSONMap(fedPayload.toString(),false);
		println('StartProcessTransformation.transform <-- Converted jsonMap ' + jsonMap)
		log.info('StartProcessTransformation.transform <-- Converted jsonMap ' + jsonMap);
		incomingPayload = jsonMap.Order
		println('StartProcessTransformation.transform <-- incomingPayload ' + incomingPayload)
		log.info('StartProcessTransformation.transform <-- incomingPayload ' + incomingPayload);
		def customerOrderNumber = incomingPayload.CustomerOrderNumber
		println('StartProcessTransformation.transform <-- CustomerOrderNumber ' + customerOrderNumber)
		log.info('StartProcessTransformation.transform <-- CustomerOrderNumber ' + customerOrderNumber);
		
		/*def groups = incomingPayload.Order.Groups.Group.findAll  { group ->
			group.Type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE}.collect{ it }*/

		def processDefKey = wirelineProperties.getPropertyStringValue("wireline.smb.actionType.processkey") //'wireline-parent-process'
		exchange.in.headers.put("camelCamundaUri","camunda-bpm:start?processDefinitionKey="+processDefKey+"&copyBodyAsVariable=order")
		exchange.properties.CamundaBpmBusinessKey = customerOrderNumber //Assigning the property in exchange which is used to set BusinessKey for the process instance
		exchange.out.headers = exchange.in.headers
		exchange.out.body = incomingPayload
	}
}
