package com.att.oce.transformation


import com.att.oce.bpm.error.APIFailedException
import com.att.oce.config.components.GlobalProperties
import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.utility.OrderUtility
import com.att.oce.bpm.common.WirelineConstants;
import com.att.oce.bpm.common.WirelineTransformationService
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



@Component('addThirdPartyTransformation')
class AddThirdPartyOrderTransformation extends TransformationService {
	static Logger log = LoggerFactory.getLogger(AddThirdPartyOrderTransformation.class);
	String url;

	@Override
	String getApiName(){
		return WirelineConstants.API_NAME_ATPO
	}

	/*
	 * This function will return address where billingType = Owner
	 * @param - account of order Map object
	 * */

	static def getAddress(def order){
		def addressMap
		def ownerAddress
		def acc
		if(order.accounts && order.accounts.account) {
			for(def account in order.accounts.account){
				if(account.billingDetail && account.billingDetail.findAll{bd->bd.billingType && bd.billingType == WirelineConstants.BILLINGTYPE_OWNER}) {
					acc= account
					break
				}
			}
		}
		if(order.addresses && order.addresses.address) {
			for(def address in order.addresses.address) {
				if(acc && acc.billingDetail && acc.billingDetail.findAll{bd->bd.addressReference && bd.addressReference == address.id}) {
					addressMap = address
					break
				}
			}
		}
		if(addressMap && addressMap.unparsedAddress) {
			ownerAddress = addressMap.unparsedAddress
		}
		return ownerAddress
	}

	/*
	 * This function will return BillingName
	 * @param - account of order Map object
	 * */

	static def getBillingName(def order){
		def billingName
		if(order.names && order.names.name && order.orderContact && order.orderContact.nameReference) {
			for(def name in order.names.name) {
				if(name.id == order.orderContact.nameReference) {
					billingName = name
					break
				}
			}
		}
		if(billingName) {
			billingName = billingName
		}

		return billingName
	}

	/*
	 * This function will return TelePhoneMumber
	 * @param - account of order Map object
	 * */

	def getCanBeReachedPhone(def order){
		def canBeReachedPhone
		def orderContactNameRef = order.orderContact.nameReference
		def contactName = order.names.name.findAll{n -> n.id == orderContactNameRef}.collect{it}.get(0)
		if(contactName && contactName.primaryContactPhones && contactName.primaryContactPhones.phoneNumber) {
			canBeReachedPhone = contactName.primaryContactPhones.phoneNumber
		}
		return canBeReachedPhone.get(0)
	}

	/*
	 * This function will return BillingAccountname where billingType = Owner
	 * @param - account of order Map object
	 * */
	static def getBillingAccountname(def order){
		def accountName;
		def acc;
		if(order.accounts && order.accounts.account) {
			for(def account in order.accounts.account) {
				if(account.billingDetail && account.billingDetail.findAll{bd->bd.billingType && bd.billingType == WirelineConstants.BILLINGTYPE_OWNER}) {
					acc=account
					break
				}
			}
		}
		if(acc && acc.businessAccountName) {
			accountName = acc.businessAccountName
		}
		return accountName
	}

	/*
	 * This function will return BillingAccountNumber where billingType = Owner
	 * @param - account of order Map object
	 * */

	static def getBillingAccountNumber(def order){
		def BillingAccountNumber
		def acc

		if(order.accounts && order.accounts.account) {
			for(def account in order.accounts.account) {

				if(account.accountCategory == WirelineConstants.ACCOUNTCATEGORY_UVERSE) {
					acc=account
					break
				}
			}
		}
		if(acc && acc.billingAccountNumber) {
			BillingAccountNumber = acc.billingAccountNumber
		}
		return BillingAccountNumber
	}


	/* This function will return BillingAccountNumber where billingType = Owner
	 * @param - account of order Map object
	 * */

	static def getPaymentOption(def order){
		def planMap
		def planLineItem
		def ccType
		def str
		if(getBillingAccountNumber(order) == null && order.paymentOptions && order.paymentOptions.paymentOption){
			def PaymentOptionsList = order.paymentOptions.paymentOption
			for(def i = 0;i < PaymentOptionsList.size();i++){
				def PaymentOptionsMap = PaymentOptionsList.get(i)
				if(PaymentOptionsMap != null && PaymentOptionsMap?.paymentMethod?.capm){
					switch(PaymentOptionsMap?.paymentMethod?.capm?.creditCardType) {

						case 'AMERICAN_EXPRESS' : ccType = WirelineConstants.ADD_THIRD_PARTY_CREDITCARD_TYPE_AE
							break;
						case 'DISCOVER' : ccType = WirelineConstants.ADD_THIRD_PARTY_CREDITCARD_TYPE_DISC
							break;
						case 'MASTERCARD' : ccType = WirelineConstants.ADD_THIRD_PARTY_CREDITCARD_TYPE_MC
							break;
						case 'DINER\'S_CLUB' : ccType = WirelineConstants.ADD_THIRD_PARTY_CREDITCARD_TYPE_DINE
							break;
						default: ccType = PaymentOptionsMap?.paymentMethod?.capm?.creditCardType
					}
					if(PaymentOptionsMap?.paymentMethod?.capm?.expirationYearMonth) {
						String cc_ExpirationYearMonth = PaymentOptionsMap?.paymentMethod?.capm?.expirationYearMonth
						if(cc_ExpirationYearMonth!=null && cc_ExpirationYearMonth.indexOf("-") > 0) {
							Date date = Date.parse( 'yyyy-MM', cc_ExpirationYearMonth )
							String newDate = date.format( 'yyMM' )
							str=newDate
						}
						else {
							str = cc_ExpirationYearMonth
						}
					}

					planMap = [
						ccType: ccType,
						ccNumber:PaymentOptionsMap.paymentMethod.capm.creditCardNumber,
						ccExpiration:str,
						ccName:PaymentOptionsMap.paymentMethod.capm.creditCardHolderName,
						ccZip:PaymentOptionsMap.paymentMethod.capm.cardBillingZipCode,
					]
				}
			}
		}
		return planMap
	}


	static def getwirelineBTN(def order){
		def wirelineBTN
		def planLineItem
		if(getBillingAccountNumber(order) == null && getPaymentOption(order) == null && order.paymentOptions && order.paymentOptions.paymentOption){
			def PaymentOptionsList = order.paymentOptions.paymentOption
			for(def i = 0;i < PaymentOptionsList.size();i++){
				def PaymentOptionsMap = PaymentOptionsList.get(i)
				if(PaymentOptionsMap != null && PaymentOptionsMap?.paymentMethod?.btn){
					wirelineBTN = PaymentOptionsMap.paymentMethod.btn.tn
					break
				}
			}
		}
		return wirelineBTN
	}

	static def getPromotionID(def order,lineItem){
		def promotionId
		if(order.promotions && order.promotions.promotion) {
			for(def promotion in order.promotions.promotion) {
				if(lineItem.promotionReferences && lineItem.promotionReferences.promotionReference) {
					if(promotion.id in lineItem.promotionReferences.promotionReference) {
						promotionId = promotion.promotionCode
						break
					}
				}
			}
		}
		return promotionId
	}

	/*
	 * This function Populate the Parent Product Information
	 * */
	
	
	static def constructProductInfo(order,losg) {
		def ProductPlan = new ArrayList()
		def planLineItem
		def planMap
		def PromotionId
		def AddOnSolutionsGroup = new ArrayList()
		def optionalAndPdpLineItem = new ArrayList()

		if(order.lineItems && order.lineItems.lineItem) {
			def lineItemsList = order.lineItems.lineItem
			for(def i = 0;i < lineItemsList.size();i++){
				def lineItemsMap = lineItemsList.get(i)
				if(lineItemsMap?.groupReferences?.groupReference && lineItemsMap.groupReferences.groupReference.contains(losg.id) && ((lineItemsMap.characteristics?.addOnSolutionCharacterstics && lineItemsMap.characteristics.addOnSolutionCharacterstics.parentItem == null) || (lineItemsMap?.characteristics?.addOnSolutionCharacterstics == null)))  {
					planLineItem = lineItemsMap
					optionalAndPdpLineItem.add(planLineItem)
				}
			}
		}
		List<Map> ProductInfoPlan = new ArrayList<Map>()
		for(def lineItem in optionalAndPdpLineItem){
			if(lineItem){
				planMap = [
					productId: lineItem.productCode,
					promotionId:getPromotionID(order,lineItem),
					quantity:lineItem.quantity,
					charge:lineItem.price?.amount,
					domainName: lineItem.characteristics.addOnSolutionCharacterstics?.domainName? lineItem.characteristics.addOnSolutionCharacterstics.domainName.toLowerCase() : null,
					ChildProducts: constructProductInfoForChild(order,lineItem)
				]
			}
			
			ProductInfoPlan.add(planMap)
		}
		return ProductInfoPlan
	}

	static def constructProductInfoForChild(order,parentLineItem) {

		def planChildLineItem
		def planMap
		def AddOnSolutionsGroup = new ArrayList<Map>()
		def parentMap
		def optionalAndPdpLineItem = new ArrayList()
		def parentId
		if(order.lineItems && order.lineItems.lineItem) {
			def lineItemsList = order.lineItems.lineItem
			for(def i = 0;i < lineItemsList.size();i++){
				def lineItemsMap = lineItemsList.get(i)
				if(lineItemsMap.characteristics && lineItemsMap.characteristics.addOnSolutionCharacterstics && lineItemsMap.characteristics.addOnSolutionCharacterstics.parentItem.equals(parentLineItem.id)){
					optionalAndPdpLineItem.add(lineItemsMap)
				}
			}
		}

		List<Map> ProductInfoPlan = new ArrayList<Map>()
		for(def lineItem in optionalAndPdpLineItem){
			planMap = [
				productId: lineItem.productCode,
				quantity: lineItem.quantity,
				charge: lineItem.price?.amount
			]
			ProductInfoPlan.add(planMap)
		}
		return ProductInfoPlan
	}
	/*
	 * This function will do the transformation for ATPO Enrollment
	 * @param exchange of type Camel Exchange
	 * */
	public void transform(Exchange exchange){

		def order=exchange.in.body.order
		exchange.properties.referenceId = order.customerOrderNumber
		exchange.properties.fedIndicator = true
		def losg= exchange.in.body.group
		def address = getAddress(order)
		def billingAccountName = getBillingAccountname(order)
		def billingName = getBillingName(order)
		def phoneNumber= getCanBeReachedPhone(order)
		def billingAccountNumber=getBillingAccountNumber(order)
		def paymentOption=getPaymentOption(order)
		def wirelinebtn=getwirelineBTN(order)
		exchange.properties.order = exchange.in.body.order
		exchange.properties.losg = exchange.in.body.group


		def apiURN = 'urn:csi:servicessmb:boltonorderandsalestool:AddThirdPartyOrder.jws'
		def apiUrl = super.resolveURN(apiURN, null)
		exchange.properties.apiURN = apiURN
		exchange.properties.apiUrl = apiUrl

		def msgHeader = super.createMessageHeader((Map<String,Object>)exchange.in.body.order)

		def ATPORequest = [  messageHeader : msgHeader,
			AddThirdPartyOrderRequest: [
				foreignOrderSource: order?.orderSource?.application,
				foreignOrderId: order?.customerOrderNumber,
				CustomerDetails: [
					firstName: billingName?.firstName,
					lastName: billingName?.lastName,
					companyName:billingAccountName,
					telephoneNumber:phoneNumber,
					emailAddress:order?.orderContact?.primaryEmailAddress,
					Address: [
						address1:address?.addressLine1,
						address2:address?.addressLine2,
						city:address?.city,
						state:address?.state,
						zip:address?.zip
					]
				],
				PaymentMethod: [
					uverseBAN: billingAccountNumber,
					CreditCardDetails: paymentOption,
					wirelineBTN: wirelinebtn
				],
				ProductDetails : constructProductInfo(order,losg),
			]
		]
		
		setAuditLogProperties(exchange,true)
		exchange.out.body = ATPORequest
		super.setCSIHttpHeaders(exchange)
		//exchange.in.headers.put("CamelHttpUri","https://csi-tst-q31a.it.att.com:31443/Services/com/cingular/csi/BoltOnOrderAndSalesTool/AddThirdPartyOrder.jws")
		//exchange.in.headers.put("CamelHttpUri",resolveURN('urn:csi:services:cam:ATPO.jws',url))
		exchange.in.headers.put("CamelHttpUri",apiUrl)
		exchange.out.headers = exchange.in.headers
		exchange.properties.put(WirelineConstants.OCE_CSI_API_NAME,WirelineConstants.API_NAME_ATPO)
	}
	/*
	 * precondition for ATPO
	 * @param order of Map Object
	 * */
	static def preATPO(order) {

		def callAA = false
		if(order.productGroups && order.productGroups.group){
			for(def group in order.productGroups.group) {
				if(preATPO_Losg(order,group)){
					callAA = true
				}
			}
		}
		return callAA
	}

	static def preATPO_Losg(order,group) {

		def callAA = false
		if(order.accounts && order.accounts.account) {
			for(def account in order.accounts?.account) {
				if(group && group.characteristics && group.characteristics.losgCharacteristics && group.characteristics.losgCharacteristics.productCategory) {
					def loSGCharacteristics = group.characteristics.losgCharacteristics
					if((loSGCharacteristics.productCategory.toUpperCase().equals(WirelineConstants.PRODUCTCATEGORY_ADD_ON_SOLUTIONS) && (account.accountCategory && account.accountCategory.toUpperCase().equals(WirelineConstants.ACCOUNTCATEGORY_ADDON_SOLUTIONS_ACCOUNT) && loSGCharacteristics.accountReference == account.id))) {
						callAA = true
					}
				}
				if(callAA){
					break
				}
			}
		}
		return callAA
	}

	/*
	 * This function will take the API response  and necessary processing
	 * Will update order xml during success or return the APIFailedException object in case of Soap Fault
	 * @param exchange - Camel Exchange
	 * */
	def processResponse(Exchange exchange) throws APIFailedException{


		def order = exchange.properties.order
		def group = exchange.properties.losg
		def apiException
		def addOnSolAcc = getAddOnSolutionAccount(order);
		exchange.properties.referenceId = addOnSolAcc.id

		if (!(exchange.in.body.contains("Envelope"))) {
			APIFailedException exception = new APIFailedException()
			exception.api = getApiName()
			exception.code = exchange.in.body
			exception.codeDescription = exchange.in.body
			updateLoSGStatusForAccount(order, addOnSolAcc.id,WirelineConstants.LOSG_STATUS_IN_QUEUE,"BOOSTORDER_FAIL");
			super.addTransactionHistory(exchange, exception)
			throw exception
		}
		else {

			def csiResponseXML = new XmlSlurper().parseText(exchange.in.body)
			if (csiResponseXML.Body.Fault && csiResponseXML.Body.Fault.size() >0) {
				apiException = OrderUtility.getAPIExceptionForCSI(csiResponseXML,this.getApiName())
				log.debug("CSI Fault was thrown with code:"+csiResponseXML.Body.Fault.detail.CSIApplicationException.Response.code)
				super.addTransactionHistory(exchange,apiException)
				exchange.setException(apiException)
				updateLoSGStatusForAccount(order, addOnSolAcc.id,WirelineConstants.LOSG_STATUS_IN_QUEUE,"BOOSTORDER_FAIL");
				throw apiException
			}
			if(csiResponseXML.Body.AddThirdPartyOrderResponse){

				if(csiResponseXML.Body.AddThirdPartyOrderResponse.Response.code == WirelineConstants.SUCCESS_CODE_0){
					apiException = OrderUtility.getAPIException(WirelineConstants.SUCCESS_CODE_0,this.getApiName())
					super.addTransactionHistory(exchange,apiException)
					return updateOrder(order,csiResponseXML,group)
				}
			}
		}
		return order
	}

	def getAddOnSolutionAccount(order) {
		def accountList = order.accounts.account

		for(def i=0;i<accountList.size();i++){
			def accountMap=accountList.get(i)
			if(accountMap.accountCategory == WirelineConstants.ACCOUNTCATEGORY_ADDON_SOLUTIONS_ACCOUNT ){
				return accountMap;
			}
		}
		return null;
	}

	def updateLoSGStatusForAccount(order, accountId, status, subStatus){
		def loSGStatus= [:];

		order.productGroups.group.each{ losg ->
			if(losg.characteristics.losgCharacteristics &&
			losg.characteristics.losgCharacteristics.accountReference == accountId){
				def losgStatus = [status:status, subStatus:subStatus]
				losg.characteristics.losgCharacteristics.put("losgStatus",losgStatus)
			}
		}
		return order
	}

	/*
	 * This function will take the API response  and necessary processing
	 * Will update order payload for SystemOrderRef and SystemName
	 * @param exchange - Camel Exchange
	 * */

	def updateOrder(order,responseXml,group){
		if (responseXml instanceof String)
			responseXml = new XmlSlurper().parseText(responseXml)

		def acc
		def provisioningSystem
		def provisioningSystems

		if(responseXml.Body.AddThirdPartyOrderResponse.ResponseDetails.orderId) {
			if(order.accounts && order.accounts.account) {
				for(def account in order.accounts.account) {
					if(account.accountCategory) {
						if(account.accountCategory == WirelineConstants.ACCOUNTCATEGORY_ADDON_SOLUTIONS_ACCOUNT && group.characteristics && group.characteristics.losgCharacteristics && group.characteristics.losgCharacteristics.accountReference && group.characteristics.losgCharacteristics.accountReference == account.id) {
							acc=account
							if(acc.provisioningSystems && acc.provisioningSystems.provisioningSystem) {
								for(def provisioningsystem in acc.provisioningSystems.provisioningSystem) {
									provisioningSystems = acc.provisioningSystems
									provisioningSystem = provisioningsystem
									provisioningSystem.put(WirelineConstants.SYSTEM_NAME_BOOST,"BOOST")
									provisioningSystem.put(WirelineConstants.SYSTEM_ORDER_REF,responseXml.Body.AddThirdPartyOrderResponse.ResponseDetails.orderId.text())
								}
							}
							else {
								def provisioningSystemsNew = new HashMap<String,Object>()
								def provisioningSystemHashNew = new HashMap<String,Object>()
								def provisioningSystemNew = new ArrayList();

								provisioningSystemHashNew.put(WirelineConstants.SYSTEM_NAME_BOOST,"BOOST")
								provisioningSystemHashNew.put(WirelineConstants.SYSTEM_ORDER_REF,responseXml.Body.AddThirdPartyOrderResponse.ResponseDetails.orderId.text())
								provisioningSystemNew.add(provisioningSystemHashNew)
								provisioningSystemsNew.put("provisioningSystem", provisioningSystemNew)
								acc.put("provisioningSystems",provisioningSystemsNew)
							}

							if(acc && acc.billingAccountNumber) {
								acc.put(WirelineConstants.ACCOUNT_BILLING_ACCOUNT_NUMBER,responseXml.Body.AddThirdPartyOrderResponse.ResponseDetails.customerId.text())
							}

							else {
								acc.put(WirelineConstants.ACCOUNT_BILLING_ACCOUNT_NUMBER,responseXml.Body.AddThirdPartyOrderResponse.ResponseDetails.customerId.text())
							}
						}
					}
				}
			}
		}
		return order
	}


	static def getGroupssForATPO(order){
		def groups = new ArrayList()
		if(order.productGroups && order.productGroups.group) {
			def groupList = order.productGroups.group

			for(def i=0;i<groupList.size();i++){
				def groupMap = groupList.get(i)
				if(preATPO_Losg(order,groupMap)){
					groups.add(groupMap)
				}
			}
		}
		return groups
	}

	static def ATPOGroupCount(order) {
		def count = 0
		if(order.productGroups && order.productGroups.group) {
			def groupList = order.productGroups.group

			def groups = new ArrayList()
			for(def i=0;i<groupList.size();i++){
				def groupMap = groupList.get(i)
				if(preATPO_Losg(order,groupMap)){
					count ++
				}
			}
		}
		return count
	}
}