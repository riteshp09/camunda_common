package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.StartProcessTransformation;

@Component("startProcessRestRouteBuilder")
public class RestSTartProcessRouteBuilder extends RouteBuilder {
	
	@Override
	public void configure() throws Exception {
		from("att-dme2-servlet:///wireline-eg-cntr/process-instance/rest/start?matchOnUriPrefix=true")
			.bean(AuditLogHelper.class,"logRequest")
			.convertBodyTo(java.lang.String.class)
			.bean(StartProcessTransformation.class, "transform")
			.recipientList(header("camelCamundaUri"));
	}

}
