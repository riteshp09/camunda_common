package com.att.oce.routes;

import javax.annotation.Resource;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.att.oce.bpm.common.WirelineProperties;
import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.transformation.StartProcessTransformation;


@Component("startProcessRouteBuilder")
public class StartProcessRouteBuilder extends RouteBuilder{

	@Resource
	protected WirelineProperties wirelineProperties;
	
	
	@Override
	public void configure() throws Exception {
		from("wireline-activemq:"+ wirelineProperties.getPropertyStringValue("smb.fuse.processorder.amq.queuename"))
			.bean(AuditLogHelper.class,"logRequest")
			.bean(StartProcessTransformation.class, "transform")
			.recipientList(header("camelCamundaUri"));
	}
	

}
