package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component("addThirdPartyOrderRouteBuilder")
public class AddThirdPartyOrderRouteBuilder extends RouteBuilder{

	@Override
	public void configure() throws Exception {		
		from("direct:AddThirdPartyOrder")
		.beanRef("addThirdPartyTransformation","transform")
//		.bean(AddThirdPartyOrderTransformation.class,"transform")
		.to("velocity://vm/ATPO.vm")		
		.wireTap("direct:auditlog:request")
		.to("http://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.wireTap("direct:auditlog:response")
//	    .bean(AddThirdPartyOrderTransformation.class,"processResponse")	
		.beanRef("addThirdPartyTransformation","processResponse")
		.routeId("addThirdPartyOrderRouteBuilder");
	}
}

