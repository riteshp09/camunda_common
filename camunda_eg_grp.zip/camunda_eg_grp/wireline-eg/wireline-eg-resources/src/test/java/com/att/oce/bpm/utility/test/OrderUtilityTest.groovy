package com.att.oce.bpm.utility.test;

import static org.junit.Assert.*;

import java.io.File;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test
import org.junit.runner.RunWith
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner

//import com.att.oce.beans.api.config.APIresultConfig;
import com.att.oce.beans.config.OceConfig
import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.bpm.utility.OrderUtility;

import com.att.oce.bpm.transformations.ATGHelper;
import com.att.oce.config.components.GlobalProperties;
import com.att.oce.config.components.URNResolver

import groovy.json.JsonSlurper;;;

public class OrderUtilityTest {
	
	@Test
	def void convertJsonToXmlTest() {
		File inputFile = new File(System.getProperty("user.dir") + "/src/test/resources/data/wireless-order2.json");;
		Map<String,Object> order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		def orderMap = [Order:order]
		String xml = OrderUtility.convertJsonToXml(orderMap);
		println(xml)
		assertTrue(xml.indexOf("<Order") == 0)
	}
	
	@Test
	def void converXmltoJsonTest() {
		File inputFile = new File(System.getProperty("user.dir") + "/src/test/resources/data/SMB_NewDTV_NewUVerseBB_NewVOIP.xml");
		FileInputStream fis = new FileInputStream(inputFile)
		byte[] content = new byte[fis.available()]
		fis.read(content)
		def orderXml = new String(content);
		String json = OrderUtility.convertXmlToJson(orderXml);
		println(json)
	}
	
	@Test
	def void isCUSAEligibleTest() {
		File inputFile = new File("./src/test/resources/data/Internet_new_with_ban.json");;
		Map<String,Object> order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		assertTrue(!OrderUtility.isCUSAEligible(order))
	}
	
	@Test
	def void creditCheckAndCreditClassValidationsTest() {
		File inputFile = new File("./src/test/resources/data/Internet_new_with_ban.json");;
		Map<String,Object> order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		assertTrue(OrderUtility.creditCheckAndCreditClassValidations(order).size() > 0)
		
	}
	
	@Test
	def void consentCheckTest() {
		File inputFile = new File("./src/test/resources/data/Internet_new_with_ban.json");;
		Map<String,Object> order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		assertTrue(OrderUtility.consentCheck(order))
	}
	
	
	@Test
	def void hasMultipleAuthorizedBillingDetailsTest() {
		File inputFile = new File("./src/test/resources/data/DemoOrder_BillingDetail.json");
		Map<String,Object> order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		assertTrue(OrderUtility.hasMultipleAuthorizedBillingDetails(order))
	}
	
	@Test
	def void isUverseProductGroupExistTest() {
		File inputFile = new File("./src/test/resources/data/SMBProductOnly.json");
		Map<String,Object> order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		assertFalse(OrderUtility.isUverseProductGroupExist(order))
	}
	
	@Test
	def void getOwnerAddressRefTest() {
		File inputFile = new File("./src/test/resources/data/ATG_NF_Payload.json");
		Map<String,Object> order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		def ref = OrderUtility.getOwnerAddressRef(order)
	}

}
