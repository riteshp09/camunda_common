package com.att.oce.bpm.utility.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import groovy.json.StringEscapeUtils;

public class JavaTest {
	
	public static void main(String[] args) throws ParseException {
		StringBuffer str = new StringBuffer("?:p<P\n\"_@|I['th?");
		System.out.println(str);
		
		 String s = "some value " +  StringEscapeUtils.escapeJava(str.toString()) + " end";
		
		System.out.println(s);
		
		String subDt = "1493025911000";
		
		long ldt = Long.parseLong(subDt);
		
		Date dt = new Date(ldt);
		
		System.out.println("Unformated Date : " + dt);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSz");
		String formatedDt = sdf.format(dt);
		
		System.out.println("Formated Date : " + formatedDt);
		System.out.println("String parsed : " + sdf.parse(formatedDt));
				
	}

}
