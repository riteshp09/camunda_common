package com.att.oce.bpm.utility.test

import org.junit.Test;
import groovy.json.StringEscapeUtils;

class TestGroovy {
	
	@Test
	def void stringTest() {
		def v = "?:p<P\"_@|I['th?"
		def jOrder = StringBuilder.newInstance();
		jOrder <<= '"';
		def ts = StringEscapeUtils.escapeJava(v).replaceAll("\\s+", " ")
		jOrder <<= ts
		jOrder <<= '",';
		jOrder <<= '"';
		jOrder <<= 'DueToday';
		jOrder <<= '",';
		println jOrder
	}

}
