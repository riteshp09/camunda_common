package com.att.oce.bpm.utility.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.beans.config.OceConfig;
import com.att.oce.bpm.common.WirelineProperties;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {OceConfig.class, WirelineProperties.class})
public class WirelinePropertyTest {
	
	@Autowired
	WirelineProperties wirelineProps;
	
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "src/test/resources/");
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireline");
	}
	
	@Test
	public void testWirelineConfigStringProeprty() {
		String value = wirelineProps.getPropertyStringValue("error.message.nack504");
		System.out.println(value);
		assertNotNull(value);
	}
	
	@Test
	public void testWirelineConfigIntegerProperty() {
		int val = wirelineProps.getPropertyIntegerValue("ccar.bancache.retry.interval");
		assertNotNull(val);
	}
	
	@Test
	public void testWirelineConfigBooleanProperty() {
		boolean val = wirelineProps.getPropertyBooleanValue("OE.activation.disabled");
		assertTrue(val);
	}

}
