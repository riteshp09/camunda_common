package com.att.oce.bpm.utility.test;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.beans.config.OceConfig;
import com.att.oce.config.components.ErrorConfig;
import com.att.oce.config.components.URNResolver;
import com.att.oce.bpm.utility.WirelineUtility;

import groovy.json.JsonSlurper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {WirelineUtility.class,OceConfig.class, ErrorConfig.class,URNResolver.class})
public class WirelineUtilityTest {

	@Autowired
	protected WirelineUtility wirelineUtility;
	
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "D:/aj00351351/ATT/Camunda/Camunda_OCE_framework/oce-resources/src/main/resources");
//		System.setProperty("OCE_ERROR_CONFIG", "wireline");
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireline");
	} 
	
	/*@Configuration
	public static class TestConfig{
		@Bean
		public static DmnEngine dmnEngine() {
			// create default DMN engine configuration
			DmnEngineConfiguration configuration = DmnEngineConfiguration
			  .createDefaultDmnEngineConfiguration();

			// build a new DMN engine
			DmnEngine dmnEngine = configuration.buildEngine();
			return dmnEngine;
		}
		
	}*/
	
	
	@Test
	public void assignFalloutStatusTest() {
	init();
	List errorList = new ArrayList();
	//errorList.add("IsQualifiedForAutomation");
		File inputFile = new File("./src/test/resources/VoipTest/isVOIPOrderExists.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		//String errorList = "PortingAddress1NotVerfied";
		System.out.println(wirelineUtility.assignFalloutStatus(Order, errorList));
		boolean booleanValue= (boolean) wirelineUtility.assignFalloutStatus(Order, errorList);
		assertTrue(booleanValue);
	}
	
	

	
}
