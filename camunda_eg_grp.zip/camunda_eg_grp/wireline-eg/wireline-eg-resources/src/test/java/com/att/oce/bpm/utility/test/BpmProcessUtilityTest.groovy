package com.att.oce.bpm.utility.test;

import static org.junit.Assert.*;

import java.io.File;
import java.util.Map;

import org.json.JSONObject
import org.junit.Test

import com.att.oce.bpm.utility.BpmProcessUtility;
import com.att.oce.bpm.utility.OrderUtility;

import groovy.json.JsonSlurper;

public class BpmProcessUtilityTest {
	
//	@Test
	def void convertFToNFTest() {
		File inputFile = new File(System.getProperty("user.dir") + "/src/test/resources/data/SMB_Internet_OCERT.json");;
		Map<String,Object> order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		def nonFedJson = BpmProcessUtility.convertFToNF(order);
		println('Non Fed Json : ' + new JSONObject(nonFedJson).toString())
//		assertTrue(nonFedJson.indexOf("CustomerOrderNumber") > 0)
	}
	
	@Test
	def void convertNFToTest() {	
		File inputFile = new File(System.getProperty("user.dir") + "/src/test/resources/data/DTV_Provide.json");;
		Map<String,Object> order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		def fedJson = BpmProcessUtility.convertNFToF(order);
		println('Fed Json : ' + new JSONObject(fedJson).toString())
//		assertTrue(fedJson.indexOf("customerOrderNumber") > 0)
	}

}
