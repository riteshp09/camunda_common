package com.att.oce.bpm.utility.test;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.beans.config.APIResultConfig;
import com.att.oce.beans.config.OceConfig;
import com.att.oce.config.components.ErrorConfig;
import com.att.oce.config.components.URNResolver;
import com.att.oce.bpm.utility.PaymentFunctions;

import groovy.json.JsonSlurper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PaymentFunctions.class,OceConfig.class, ErrorConfig.class,URNResolver.class})
public class PaymentFunctionsTest {

	@Autowired
	protected PaymentFunctions paymentFunctions;
	
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "D:/aj00351351/ATT/Camunda/Camunda_OCE_framework/oce-resources/src/main/resources");
//		System.setProperty("OCE_ERROR_CONFIG", "wireline");
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireline");
	} 
	
	/*@Configuration
	public static class TestConfig{
		@Bean
		public static DmnEngine dmnEngine() {
			// create default DMN engine configuration
			DmnEngineConfiguration configuration = DmnEngineConfiguration
			  .createDefaultDmnEngineConfiguration();

			// build a new DMN engine
			DmnEngine dmnEngine = configuration.buildEngine();
			return dmnEngine;
		}
		
	}*/
	
//	@Test
	public void getPaymentRefforAutoPayTest() {
//		init();
		//List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/PaymentTest/PaymentRefforAutoPay.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		List<String> errorCodeList = (List<String>) paymentFunctions.getPaymentRefforAutoPay(Order);
		System.out.println(errorCodeList);
	}
	
	@Test
	public void getPaymentRefforAutoPayIdTest() {
//		init();
		//List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/PaymentTest/PaymentRefforAutoPay.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		String paymentOptId = (String) paymentFunctions.getPaymentRefforAutoPayId(Order);
		System.out.println(paymentOptId);
	}
	
	//@Test
	public void getPaymentRefforAdvancePayTest() {
//		init();
		//List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/PaymentTest/PaymentRefforAdvancePay.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		String paymentOptId = (String) paymentFunctions.getPaymentRefforAdvancePay(Order);
		System.out.println(paymentOptId);
	}
	
	@Test
	public void getPaymentRefforAdvancePayIdTest() {
//		init();
		//List qualErrorList = new ArrayList();
		File inputFile = new File("./src/test/resources/PaymentTest/PaymentRefforAdvancePay.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		String paymentOptId = (String) paymentFunctions.getPaymentRefforAdvancePayId(Order);
		System.out.println(paymentOptId);
	}
	
	   @Test
		public void doesOrderhaveAutopayTest() {
//			init();
			//List qualErrorList = new ArrayList();
			File inputFile = new File("./src/test/resources/PaymentTest/doesOrderhaveAutopay.json");
			Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
			boolean booleanValue= (boolean) paymentFunctions.doesOrderhaveAutopay(Order);
			//String paymentOptId = (String) paymentFunctions.doesOrderhaveAutopay(Order);
			System.out.println(booleanValue);
		}
	
	
	/*public List getErrorList(Map<String,Object> updatedOrder)
	{
		Map<String,Object> errors = (Map<String, Object>)updatedOrder.get("Errors");
		List errorList = (List) errors.get("Error");
		List<String> errorCodeList = new ArrayList<String>();
		for (int i = 0; i < errorList.size(); i++) {
			Map<String,Object> e = (Map<String, Object>) errorList.get(i);
			String code = (String) e.get("ErrorCode") ;
			errorCodeList.add(code);			
		}
		return errorCodeList;
		
	}*/

	
}
