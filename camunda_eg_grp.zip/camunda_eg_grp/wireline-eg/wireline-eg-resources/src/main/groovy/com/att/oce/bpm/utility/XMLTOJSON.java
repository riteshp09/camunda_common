package com.att.oce.bpm.utility;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class XMLTOJSON {

	public static void main(String[] args) {
		
		String xmlString = readFile("D:/RP00425428/TECHM/deletel/DTV_Provide.xml");
		
		System.out.println(OrderUtility.convertXmlToJson(xmlString));
	}
	
	public static String readFile(String path) {
		 BufferedReader br = null;
	    StringBuilder sb = new StringBuilder();
	    String sCurrentLine;
	    try
	    {
	       br = new BufferedReader(new FileReader(path));
	
	       while ((sCurrentLine = br.readLine()) != null) {
	        sb.append(sCurrentLine);
	       }
	
	    }catch(Exception e) {
	    	
	    	e.printStackTrace();
	    }finally {
	    	
	    	if(br != null) {
	    		
	    		try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    	}	    		
	    }
	
	  return sb.toString();
	}

}
