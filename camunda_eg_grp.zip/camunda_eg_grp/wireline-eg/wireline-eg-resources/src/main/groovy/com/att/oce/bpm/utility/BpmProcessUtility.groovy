package com.att.oce.bpm.utility

import org.json.JSONArray
import org.json.JSONObject
import org.springframework.stereotype.Component
import groovy.json.StringEscapeUtils;
import com.att.oce.bpm.transformations.ATGHelper;
import groovy.json.JsonSlurper

@Component("processUtility")
class BpmProcessUtility {

	static def convertFToNF(order) {
		def nFed = ATGHelper.convertFToNF(order)
		println("###### Converted Fed Payload :  " + nFed.toString())
		def jsonObject = new JSONObject(nFed.toString());
		def jsonMap = toMap(jsonObject,false);
		/*def nFedLMap = new JsonSlurper().parseText(nFed.toString())
		def retMap = new LinkedHashMap<String, Object>();
		retMap.putAll(nFedLMap)*/
		jsonMap = jsonMap.Order
		return jsonMap
	}
	
	static def convertNFToF(order) {
		def fed = ATGHelper.convertNFToF(order)
		def jsonObject = new JSONObject(fed.toString());
		def jsonMap = toMap(jsonObject,false);
//		def fedLMap = new JsonSlurper().parseText()
		/*def retMap = new LinkedHashMap<String, Object>();
		retMap.putAll(fedLMap);*/
		return jsonMap;
	}
	
	public static Map<String, Object> toJSONMap(String jsonString, def encode) {
		def jsonObject = new JSONObject(jsonString);
		def objMap = toMap(jsonObject,encode)
		return objMap
	}
	
	private static Map<String, Object> toMap(JSONObject object, def encode)  {
		Map<String, Object> map = new LinkedHashMap<String, Object>();

		Iterator<String> keysItr = object.keys();
		while(keysItr.hasNext()) {
			String key = keysItr.next();
			Object value = object.get(key);
			if(value instanceof JSONArray) {
				value = toList((JSONArray) value,encode);
			}

			else if(value instanceof JSONObject) {
				value = toMap((JSONObject) value,encode);
			}
			if(!value.equals(JSONObject.NULL)){
					if(value instanceof String){
						if(encode)
							map.put(key,StringEscapeUtils.escapeJava(value).replaceAll("\\s+", " "))
						else
							map.put(key,value)
							
					}
					else{
						map.put(key, value);
					}
				}
		}

		return map;
	}
	
	private static List<Object> toList(JSONArray array, def encode)  {
		List<Object> list = new ArrayList<Object>();
		for(int i = 0; i < array.length(); i++) {
			Object value = array.get(i);
			if(value instanceof JSONArray) {
				value = toList((JSONArray) value, encode);
			}

			else if(value instanceof JSONObject) {
				value = toMap((JSONObject) value, encode);
			}
			list.add(value);
		}
		return list;
	}
}
