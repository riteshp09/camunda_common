create index ACT_IDX_GE_BYTEARR_ID on ACT_HI_VARINST(BYTEARRAY_ID_);
create index ACT_IDX_GE_BYTEARR_ID on act_hi_dec_in(BYTEARRAY_ID_);
create index ACT_IDX_GE_BYTEARR_ID on act_hi_dec_out(BYTEARRAY_ID_);
create index ACT_IDX_GE_BYTEARR_ID on act_hi_detail(BYTEARRAY_ID_);
create index ACT_IDX_GE_BYTEARR_ID on act_ru_variable(BYTEARRAY_ID_);
commit;
/