package com.att.oce.transformation

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.error.OceErrorHandler
import com.att.oce.config.components.GlobalProperties
import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component

@Component('inquireAccountProfileTransformation') class InquireAccountProfileTransformation extends TransformationService {
	
	static Logger log = LoggerFactory.getLogger(InquireAccountProfileTransformation.class)
	
	@Override String getApiName(){
		return 'InquireAccountProfile';
	}
	
	public void transform(Exchange exchange){
		println ('InquireAccountProfileTransformation.transform')
		int index = 0
		exchange.properties.order = exchange.in.body.order
		def order = exchange.in.body.order
		def iapRequest = [ messageHeader : createMessageHeader(order),
						   inquireAccountProfileRequest : [
							   accountOrSubscriptionIDSelector : [
								   accountSelector : [
									   billingAccountNumber : order.Accounts.Account[index].billingAccountNumber,
									   marketServiceInfo:[
										   billingMarket:[
											   billingMarket : order.Accounts.Account[index].market,
											   billingSubMarket : order.Accounts.Account[index].subMarket
											]
										]
									]
								]
							]
						 ]
		 exchange.out.body = iapRequest
		 setCSIHttpHeaders(exchange)
		 exchange.out.headers.put("CamelHttpUri",resolveURN('urn:csi:services:cam:InquireAccountProfile.jws',''))
		 exchange.properties.put("OceCSIApiName","InquireAccountProfile")
		 println('InquireAccountProfileTransformation.transform done')
	}
	
	def processResponse(Exchange exchange) throws Exception {
		log.debug('InquireAccountProfileTransformation.processResponse')
		int index=0
		def order = exchange.properties.order
		def iapResponseXml = new XmlSlurper().parseText(exchange.in.body)
		log.debug(exchange.in.body)
		if (iapResponseXml.Body.Fault.size() > 0){
			def apie = new APIFailedException(
				api : getApiName(),
				code : iapResponseXml.Body.Fault.detail.CSIApplicationException.Response.code,
				codeDescription : iapResponseXml.Body.Fault.detail.CSIApplicationException.Response.description,
				subCode : iapResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code,
				subCodeDescription : iapResponseXml.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
			)
			addTransactionHistory(exchange,apie)
			exchange.out.body = order
			throw apie
		}
		addTransactionHistory(exchange,null)
		exchange.out.body = updateOrder(order,iapResponseXml,index)
	}
	
	def updateOrder(order,responseXml,int index){
		log.debug('InquireAccountProfileTransformation.updateOrder')
		if (responseXml instanceof String)
			responseXml = new XmlSlurper().parseText(responseXml)
		
		order.Accounts.Account[index].BillingInfo.LastUpdated = responseXml.Body.InquireAccountProfileResponse.Account.Customer.AddIPAddressRequest.lastUpdate.text()
		order.Accounts.Account[index].Market = responseXml.Body.InquireAccountProfileResponse.Account.billingMarket.billingMarket.text()
		order.Accounts.Account[index].SubMarket = responseXml.Body.InquireAccountProfileResponse.Account.billingMarket.billingSubMarket.text()
		order.Accounts.Account[index].EffectiveDate = responseXml.Body.InquireAccountProfileResponse.Account.AccountCreationDate.effectiveDate.text()
		log.debug('InquireAccountProfileTransformation.updateOrder done')
		return order
	}
	
	boolean preCondition(def order,int index=0){
		log.debug('InquireAccountProfileTransformation.preCondition')
		if (order.Accounts.Account[index].EffectiveDate)
			return false
		return true
	}
	
	def ignore(def order,int index=0){
		if (order.Accounts.Account[index].EffectiveDate)
			return false
		return true
	}


}
