package com.att.oce.bpm.common;

import java.util.HashMap;
import java.util.Map;

public class OceEnums {

	protected static enum ACCOUNT_TYPE_OCE {
		INDIVIDUAL, BUSINESS, EXCP_CTRL, GOVERNMENT, SPECIAL, RESELLER, SINGLE_NON_COMMERCIAL
	};

	protected static enum ACCOUNT_TYPE_CSI {
		I, B, E, G, S, C, T
	};

	protected static enum ACCOUNT_SUB_TYPE_OCE {
		P, R, G, H, S, E, T, L, M, N
	};

	private static Map<String, String> oceToCsi = new HashMap<String, String>();
	private static Map<String, String> csiToOce = new HashMap<String, String>();

	static {
		populateMaps();
	}

	public static String getCSIAccountType(String accountType) {
		if (accountType.length() == 1) {
			return accountType;
		} else {
			return oceToCsi.get(accountType);
		}
	}

	public static String getOCEAccountType(String accountType) {
		if (accountType.length() > 1) {
			return accountType;
		} else {
			return csiToOce.get(accountType);
		}

	}

	public static void populateMaps() {
		oceToCsi.put(ACCOUNT_TYPE_OCE.INDIVIDUAL.name(), ACCOUNT_TYPE_CSI.I.name());
		oceToCsi.put(ACCOUNT_TYPE_OCE.BUSINESS.name(), ACCOUNT_TYPE_CSI.B.name());
		oceToCsi.put(ACCOUNT_TYPE_OCE.EXCP_CTRL.name(), ACCOUNT_TYPE_CSI.E.name());
		oceToCsi.put(ACCOUNT_TYPE_OCE.GOVERNMENT.name(), ACCOUNT_TYPE_CSI.G.name());
		oceToCsi.put(ACCOUNT_TYPE_OCE.SPECIAL.name(), ACCOUNT_TYPE_CSI.S.name());
		oceToCsi.put(ACCOUNT_TYPE_OCE.RESELLER.name(), ACCOUNT_TYPE_CSI.C.name());
		oceToCsi.put(ACCOUNT_TYPE_OCE.SINGLE_NON_COMMERCIAL.name(), ACCOUNT_TYPE_CSI.T.name());

		csiToOce.put(ACCOUNT_TYPE_CSI.I.name(), ACCOUNT_TYPE_OCE.INDIVIDUAL.name());
		csiToOce.put(ACCOUNT_TYPE_CSI.B.name(), ACCOUNT_TYPE_OCE.BUSINESS.name());
		csiToOce.put(ACCOUNT_TYPE_CSI.E.name(), ACCOUNT_TYPE_OCE.EXCP_CTRL.name());
		csiToOce.put(ACCOUNT_TYPE_CSI.G.name(), ACCOUNT_TYPE_OCE.GOVERNMENT.name());
		csiToOce.put(ACCOUNT_TYPE_CSI.S.name(), ACCOUNT_TYPE_OCE.SPECIAL.name());
		csiToOce.put(ACCOUNT_TYPE_CSI.C.name(), ACCOUNT_TYPE_OCE.RESELLER.name());
		csiToOce.put(ACCOUNT_TYPE_CSI.T.name(), ACCOUNT_TYPE_OCE.SINGLE_NON_COMMERCIAL.name());
	}

}
