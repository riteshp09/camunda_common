package com.att.oce.jsonpathpatch;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.att.oce.objectpatch.ObjectPatch;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.JsonSerializable;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
import com.jayway.jsonpath.DocumentContext;

/**
 * 
 * JsonPathPatch is inspired by jsonpatch specification <a href="https://tools.ietf.org/html/rfc6902">RFC 6902</a> from the IETF.
 * JsonPatch uses JsonPointer to specify "path" content, which uses indexes for array elements.
 * 
 * JsonPathPatch is designed to use JsonPath (https://github.com/jayway/JsonPath) instead of JsonPointer for the "path" content.
 * 
 * <p>An example of a JsonPathPatch is as follows:</p>
 *
 * <pre>
 *     [
 *         {
 *             "op": "add",
 *             "path": "$.lines[[?(@.id == 'line1')]",
 *             "key": "mobileNumber",
 *             "value": "2342234234"
 *         }
 *     ]
 * </pre>
 *
 * <p>This patch contains a single operation which add a property to element(s) identified usign path.
 * A JsonPathPatch can contain more than one operation; in this case, all
 * operations are applied to the input JSON value in their order of appearance,
 * until all operations are applied or an error condition is encountered.</p>	
 * 
 * @see JsonPathPatchOperation
 * 
 * @author kp7466
 *
 */
public final class JsonPathPatch
    implements JsonSerializable, ObjectPatch<DocumentContext>
{
    /**
     * List of operations
     */
    private final List<JsonPathPatchOperation> operations;

    /**
     * Constructor
     *
     * <p>Normally, you should never have to use it.</p>
     *
     * @param operations the list of operations for this patch
     * @see JsonPathPatchOperation
     */
    @JsonCreator
    public JsonPathPatch(final List<JsonPathPatchOperation> operations)
    {
        this.operations = operations;
    }
    /**
     * 
     * <p>Normally, you should never have to use it.</p>
     * 
     * Constructor to deserialize from map
     * {
     * 		type: "JsonPathPath",
     * 		operations : 
     * 			[
     *	 			{ "op" : "remove",
     *				   "path" : "$.a.b",
     *					"value" : "5"
     * 				}
     * 			]
     * 	}
     * 
     * 
     * @param map 
     * @see JsonPathPatchOperation
     */
	@JsonCreator
    public JsonPathPatch(final Map<String, List<JsonPathPatchOperation>> map)
    {
        this((List<JsonPathPatchOperation>)map.get("operations"));
    }    
    
    /**
     * Static factory method to build a JSON Patch out of a JSON representation
     *
     * @param node the JSON representation of the generated JSON Patch
     * @return a JSON Patch
     * @throws IOException input is not a valid JSON patch
     * @throws NullPointerException input is null
     */
    public static JsonPathPatch fromJson(final JsonNode node)
        throws IOException
    {
    	ObjectMapper mapper = new ObjectMapper();
        return mapper.reader().forType(ObjectPatch.class).readValue(node);
    }
    
    /**
     * Static factory method to build a JSON Patch out of a JSON String
     *
     * @param json the JSON String representation of JSON Path
     * @return a JSON Patch
     * @throws IOException input is not a valid JSON patch
     * @throws NullPointerException input is null
     */
    public static JsonPathPatch fromJson(final String json)
        throws IOException
    {
		ObjectMapper mapper = new ObjectMapper();
        return mapper.reader().forType(ObjectPatch.class).readValue(json);
    }

    /**
     * Apply this patch to a JSON value
     *
     * @param node the value to apply the patch to
     * @return the patched JSON value
     * @throws JsonPathPatchException failed to apply patch
     * @throws NullPointerException input is null
     */
    public DocumentContext apply(final DocumentContext doc)
        throws JsonPathPatchException
    {
        DocumentContext ret = doc;
        for (final JsonPathPatchOperation operation: operations)
            ret = operation.apply(ret);

        return ret;
    }

    @Override
    public String toString()
    {
        return operations.toString();
    }

    @Override
    public void serialize(final JsonGenerator jgen,
        final SerializerProvider provider)
        throws IOException
    {
        jgen.writeStartArray();
        for (final JsonPathPatchOperation op: operations)
            op.serialize(jgen, provider);
        jgen.writeEndArray();
    }

    @Override
    public void serializeWithType(final JsonGenerator jgen,
        final SerializerProvider provider, final TypeSerializer typeSer)
        throws IOException
    {
        serialize(jgen, provider);
    }

}
