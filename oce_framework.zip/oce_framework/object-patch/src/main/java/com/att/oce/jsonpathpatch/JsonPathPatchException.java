package com.att.oce.jsonpathpatch;

import com.att.oce.objectpatch.ObjectPatchException;

public final class JsonPathPatchException
    extends ObjectPatchException
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JsonPathPatchException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JsonPathPatchException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public JsonPathPatchException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public JsonPathPatchException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}		
}
