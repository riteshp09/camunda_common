package com.att.oce.jsonpathpatch;

import com.github.fge.msgsimple.bundle.MessageBundle;
import com.github.fge.msgsimple.bundle.PropertiesBundle;
import com.github.fge.msgsimple.load.MessageBundleLoader;

public final class JsonPathPatchMessages
    implements MessageBundleLoader
{
    @Override
    public MessageBundle getBundle()
    {
        return PropertiesBundle.forPath("/com/att/oce/jsonpathpatch/messages");
    }
}
