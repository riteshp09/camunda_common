package com.att.oce.jsonpathpatch;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

/**
 * JSON Patch {@code replace} operation
 *
 * <p>For this operation, {@code path} points to the value to replace, and
 * {@code value} is the replacement value.</p>
 *
 * <p>It is an error condition if {@code path} does not point to an actual JSON
 * value.</p>
 */
public final class ReplaceOperation
    extends PathValueOperation
{
    @JsonCreator
    public ReplaceOperation(@JsonProperty("path") final String path,
        @JsonProperty("value") final JsonNode value)
    {
        super("replace", path, value);
    }

    @Override
    public DocumentContext apply(final DocumentContext doc)
        throws JsonPathPatchException
    {
    	//parsing is required to support json sub-document as value
    	//and ability to perform subsequent JsonPath queries on that json sub-document.
    	doc.set(path, JsonPath.parse(value.toString()).json());    	
    	return doc;
    }
}
