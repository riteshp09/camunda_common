package com.att.oce.jsonobjectpatch;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import com.att.oce.jsonpathpatch.JsonPathPatch;
import com.att.oce.jsonpathpatch.JsonPathPatchOperation;
import com.att.oce.objectpatch.ObjectPatch;
import com.att.oce.objectpatch.ObjectPatchException;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
/**
 * Placeholder for Partial JsonObject Patch
 * 
 * <p>Given the JSON resource
 *  
 *   
 *   <pre>
 *   {
 *     "a" : "1",
 *     "b" : {
 *        "x" : "2",
 *        "y" : "3"         
 *    }
 *   }
 *   </pre>
 *
 *   Applying the below patch
 *   
 *   <pre>
 *   {
 *     "b" : {
 *        "y" : 4,
 *        "z" : 5
 *     }
 *   }
 *   </pre>
 *
 *  should result into
 *  <pre>
 *  {
 *    "a" : "1",
 *    "b" : {
 *       "x" : "2",
 *       "y" : "4",
 *       "z" : "5"         
 *    }
 *  }
 *  
 *  </pre>
 * 
 * @author kp7466
 *
 */
public class JsonObjectPatch<T> implements Serializable, ObjectPatch<T> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JsonNode patch;
	
	 @JsonCreator
    public JsonObjectPatch(final JsonNode patch)
    {
        this.patch = patch;
    }
	 
	/**
	 * Properties which hold the Key mapping for each Array element
	 */ 
	private Properties matchProps;

	public Properties getMatchProps() {
		return matchProps;
	}

	public void setMatchProps(Properties matchProps) {
		this.matchProps = matchProps;
	}
	
	public T apply(T source) throws ObjectPatchException {
		ObjectMapper mapper = new ObjectMapper();
		JsonNode sourceNode = mapper.valueToTree(source);
		
		JsonNode targetNode = merge(sourceNode, patch, matchProps);
		
		return (T) mapper.convertValue(targetNode, source.getClass());
	}	
	
	/**
     * Private method to merge the Existing Json with the Update request by matching ID
     *
     * @param JsonNode the JSON String representation of input request
     * @param JsonNode the JSON String representation of the partial update request
     * @return a JsonNode of the Updated content
     * @throws IOException input is not a valid JSON patch
     * @throws NullPointerException input is null
     */
	private JsonNode merge(JsonNode source, JsonNode patch, Properties matchProps) {

		Iterator<String> fieldNames = patch.fieldNames();

		while (fieldNames.hasNext()) {
			String patchFieldName = fieldNames.next();			
			JsonNode sourceNode = source.get(patchFieldName);
			JsonNode patchNode = patch.get(patchFieldName);

			// If the node is an @ArrayNode
			if (sourceNode != null && sourceNode.isArray() && patchNode.isArray()) {
				// running a loop for all elements of the updated ArrayNode
				mergeArrayElement(sourceNode, patchNode, patchFieldName);
				
			// if the Current Node is an @ObjectNode
			} else if (sourceNode != null && sourceNode.isObject()) {
				merge(sourceNode, patchNode, matchProps);
			} else {
				//If the Current Node is not an Object Node and Parent Node is an Object Node - Then current Node is a json element- Update that element directly
				if (source instanceof ObjectNode) {
					((ObjectNode) source).replace(patchFieldName, patchNode);
				}
			}
		}
		return source;
	}
	
	/**
     * Private method to merge the Array element of the Json 
     *
     * @param JsonNode the JSON String representation of input request
     * @param JsonNode the JSON String representation of the partial update request
     * @param String the field name of the Array element
     */
	private void mergeArrayElement(JsonNode parentNodeToBeUpdated,JsonNode updatedValue,String updatedFieldName){
		// running a loop for all elements of the updated ArrayNode
		for (int i = 0; i < updatedValue.size(); i++) {
			boolean matchFound = false;
			JsonNode updatedChildNode = updatedValue.get(i);
			for (int j = 0; j < parentNodeToBeUpdated.size(); j++) {
				// Create a new Node in the node that should be updated,
				// if there was no corresponding node in it
				// Use-case - where the updateNode will have a new
				// element in its Array
				if (parentNodeToBeUpdated.size() <= i) {
					((ArrayNode) parentNodeToBeUpdated).add(updatedChildNode);
				}
				// getting reference for the node to be updated
				if (parentNodeToBeUpdated.get(j).get(matchProps.getProperty(updatedFieldName)).toString()
						.equalsIgnoreCase(updatedChildNode.get(matchProps.getProperty(updatedFieldName)).toString())) {
					matchFound = true;
					JsonNode childNodeToBeUpdated = parentNodeToBeUpdated.get(j);
					merge(childNodeToBeUpdated, updatedChildNode,matchProps);
				}
			}
			//If no match for the Incoming update request found in the existing Json Array element - then add the entire Node.
			if (!matchFound) {
				((ArrayNode) parentNodeToBeUpdated).add(updatedChildNode);
			}
		}
	}
	
	/**
     * Static factory method to build a JsonObjectPatch out of a JSON String
     *
     * @param json the JSON String representation of input request
     * @return a JSON Patch
     * @throws IOException input is not a valid JSON patch
     * @throws NullPointerException input is null
     */
    public static JsonObjectPatch fromJson(final String json)
        throws IOException
    {
		ObjectMapper mapper = new ObjectMapper();
        return mapper.reader().forType(JsonObjectPatch.class).readValue(json);
    }

}