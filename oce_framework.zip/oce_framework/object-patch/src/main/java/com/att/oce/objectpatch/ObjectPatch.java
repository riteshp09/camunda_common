package com.att.oce.objectpatch;

import com.att.oce.jsonobjectpatch.JsonObjectPatch;
import com.att.oce.jsonpathpatch.JsonPathPatch;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

@JsonTypeInfo(use = Id.NAME, include = As.PROPERTY, property = "type", defaultImpl = JsonObjectPatch.class)

@JsonSubTypes({
    @Type(name = "JsonPathPatch", value = JsonPathPatch.class),    
    @Type(name = "JsonObjectPatch", value = JsonObjectPatch.class)
})

public interface ObjectPatch<T> {
  /**
   * 
   * @param target
   * @return
   * @throws ObjectPatchException
   */
  T apply(T target) throws ObjectPatchException;

}