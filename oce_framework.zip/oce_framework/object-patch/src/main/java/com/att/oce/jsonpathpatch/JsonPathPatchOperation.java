package com.att.oce.jsonpathpatch;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.databind.JsonSerializable;
import com.github.fge.msgsimple.bundle.MessageBundle;
import com.github.fge.msgsimple.load.MessageBundles;
import com.jayway.jsonpath.DocumentContext;

@JsonTypeInfo(use = Id.NAME, include = As.PROPERTY, property = "op", defaultImpl= ReplaceOperation.class)

@JsonSubTypes({
    @Type(name = "add", value = AddOperation.class),
    @Type(name = "replace", value = ReplaceOperation.class),
    @Type(name = "test", value = TestOperation.class)
})

/**
 * Base abstract class for one patch operation
 *
 * <p>Three more abstract classes extend this one according to the arguments of
 * the operation:</p>
 *
 * <ul>
 *     <li>{@link DualPathOperation} for operations taking a second pointer as
 *     an argument ({@code copy} and {@code move});</li>
 *     <li>{@link PathValueOperation} for operations taking a value as an
 *     argument ({@code replace} and {@code test}).</li>
 *     <li>{@link PathKeyValueOperation} for operations taking key and value as an
 *     arguments ({@code add}</li>
 * </ul>
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public abstract class JsonPathPatchOperation
    implements JsonSerializable
{
	
    protected static final MessageBundle BUNDLE
    		= MessageBundles.getBundle(JsonPathPatchMessages.class);


	protected final String op;

    protected final String path;
    
    /**
     * Constructor
     *
     * @param op the operation name
     * @param path the JSON Path for this operation
     */
    protected JsonPathPatchOperation(final String op, final String path)
    {
        this.op = op;
        this.path = path;
    }

    /**
     * Apply this operation to a JSON value
     *
     * @param node the value to patch
     * @return the patched value
     * @throws JsonPathPatchException operation failed to apply to this value
     */
    public abstract DocumentContext apply(final DocumentContext doc)
        throws JsonPathPatchException;

    @Override
    public abstract String toString();
}
