package com.att.oce.jsonpathpatch;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import com.jayway.jsonpath.DocumentContext;

/**
 * JSON Patch {@code test} operation
 *
 * <p>The two arguments for this operation are the pointer containing the value
 * to test ({@code path}) and the value to test equality against ({@code
 * value}).</p>
 *
 * <p>It is an error if no value exists at the given path.</p>
 *
 * <p>Also note that equality as defined by JSON Patch is exactly the same as it
 * is defined by JSON Schema itself. As such, this operation reuses {@link
 * JsonNumEquals} for testing equality.</p>
 */
public final class TestOperation
    extends PathValueOperation
{

	@JsonCreator
    public TestOperation(@JsonProperty("path") final String path,
        @JsonProperty("value") final JsonNode value)
    {
        super("test", path, value);
    }

    @Override
    public DocumentContext apply(final DocumentContext doc)
        throws JsonPathPatchException
    {
    	String expected = doc.read(path);
        if (expected == null)
            throw new JsonPathPatchException(BUNDLE.getMessage(
                    "jsonPatch.noSuchPath"));
        if (!expected.equalsIgnoreCase(value.toString()))
            throw new JsonPathPatchException(BUNDLE.getMessage(
                "jsonPatch.valueTestFailure"));
        return doc;
    }
}
