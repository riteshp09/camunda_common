package com.att.oce.jsonpathpatch;

import static com.att.oce.jsonpathpatch.JsonPathPatch.fromJson;
import static com.jayway.jsonpath.JsonPath.parse;
import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.List;

import org.junit.Test;

import com.att.oce.jsonpathpatch.JsonPathPatch;
import com.att.oce.jsonpathpatch.JsonPathPatchException;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

public class ReplaceOperationTest extends BaseOperationTest {
	
	@Test
	public void testSingleReplace() throws JsonPathPatchException, IOException {
		
		DocumentContext doc = JsonPath.parse(JSON_DOCUMENT);
		
		String patchString = "{ " +
						"	\"type\" : \"JsonPathPatch\", \n" +
						"	\"operations\" : [{\n" +
			            "   			\"op\" : \"replace\", \n" +
			            "   			\"path\" : \"$.int-max-property\", \n" +
			            "   			\"value\" : 10 \n" +
			            "		}]" +
			            "}";
		
		JsonPathPatch patch = fromJson(patchString);		
		doc = patch.apply(doc);
		
		DocumentContext result = parse(doc.jsonString());
		Integer changed = result.read("$.int-max-property");
		assertThat(changed).isEqualTo(10);
	}
	
	@Test
	public void testMultiReplace() throws JsonPathPatchException, IOException {
		
		DocumentContext doc = JsonPath.parse(JSON_DOCUMENT);
		
		String patchString = "{ \n" +
						"	\"type\" : \"JsonPathPatch\", \n" +
						"	\"operations\" : [{\n" +
			            "   		\"op\" : \"replace\", \n" +
			            "   		\"path\" : \"$.int-max-property\", \n" +
			            "   		\"value\" : 10 \n" +
			            "   	},\n" +
			            "		{\n" +
			            "   		\"op\" : \"replace\", \n" +
			            "   		\"path\" : \"$.foo\", \n" +
			            "   		\"value\" : \"changed-foo\" \n" +
			            "   	},\n" +
			            "   	{\n" +
			            "   		\"op\" : \"replace\", \n" +
			            "   		\"path\" : \"$.store.book[?(@.display-price > 10)].display-price\", \n" +
			            "   		\"value\" : 9.99 \n" +
			            "		}]" +
			            "}";
		
		JsonPathPatch patch = fromJson(patchString);		
		doc = patch.apply(doc);	
		
		DocumentContext result = parse(doc.jsonString());
				
		Integer intProp = result.read("$.int-max-property");
		String foo = result.read("$.foo");
		List<Double> price = result.read("$.store.book[?(@.display-price == 9.99)].display-price");		
		
		assertThat(intProp).isEqualTo(10);
		assertThat(foo).isEqualTo("changed-foo");
		assertThat(price).hasSize(2);
		assertThat(price).containsOnly(9.99, 9.99);		
	}
	
	@Test
	public void testSubDocReplace() throws JsonPathPatchException, IOException {
		
		DocumentContext doc = JsonPath.parse(JSON_DOCUMENT);
		
		String patchString = "{ \n" +
						"	\"type\" : \"JsonPathPatch\", \n" +
						"	\"operations\" : [{\n" +
			            "   	\"op\" : \"replace\", \n" +
			            "   	\"path\" : \"$.store.book[?(@.category == 'reference')].display-price\", \n" +
			            "   	\"value\" : { \n" +
				        "   		\"amount\" : 9.99, \n" +
				        "   		\"currency\" : \"Dollar\" \n" +
				        "   	} \n" +
			            "		}]" +
			            "}";
		
		JsonPathPatch patch = fromJson(patchString);		
		doc = patch.apply(doc);			
		
		//immediate query on sub-document field
		Double amount = doc.read("$.store.book[0].display-price.amount");						
		assertThat(amount).isEqualTo(9.99);

		
		DocumentContext result = parse(doc.jsonString());
		Double amount2 = result.read("$.store.book[0].display-price.amount");		
		assertThat(amount2).isEqualTo(9.99);		
	}
	
	@Test
	public void testWithoutJsonPatch() throws JsonPathPatchException, IOException {
		
		DocumentContext doc = JsonPath.parse(JSON_DOCUMENT);
		
		String value = "{ \n" +
				"\"amount\" : 9.99, \n" +
				"\"currency\" : \"Dollar\" \n" +
				"}";
		
		doc = doc.set("$.store.book[?(@.category == 'reference')].display-price", JsonPath.parse(value).json());
		//immediate query on sub-document field
		Double amount = doc.read("$.store.book[0].display-price.amount");						
		assertThat(amount).isEqualTo(9.99);

		//read after reparsing
		DocumentContext result = parse(doc.jsonString());
		Double amount2 = result.read("$.store.book[0].display-price.amount");		
		assertThat(amount2).isEqualTo(9.99);		
	}
	

}
