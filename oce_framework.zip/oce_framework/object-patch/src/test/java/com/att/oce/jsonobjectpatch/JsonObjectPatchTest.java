package com.att.oce.jsonobjectpatch;

import static com.att.oce.jsonobjectpatch.JsonObjectPatch.fromJson;
import static com.jayway.jsonpath.JsonPath.parse;
import static org.assertj.core.api.Assertions.assertThat;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Properties;

import org.junit.Test;

import com.att.oce.jsonpathpatch.BaseOperationTest;
import com.att.oce.jsonpathpatch.JsonPathPatchException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;

public class JsonObjectPatchTest extends BaseOperationTest {
	
	
	@Test
	public void testBasicMerge() throws JsonPathPatchException, IOException {
				
		String input = readFile("src/test/resources/com/att/oce/jsonobjectpatch/input2.json", StandardCharsets.UTF_8);
		
		final ObjectMapper mapper = new ObjectMapper();        
		
		JsonNode inputNode = mapper.readValue(input, JsonNode.class);
		
		/*String patchString = "{ \"type\": \"JsonObjectPatch\", \"data\": { \"store\":"
				+ " { \"book\": [{ \"id\": 2, \"category\": \"fiction\", \"author\": \"Evelyn Waugh Updated\", \"newField\": \"newValue\" },"
				+ " { \"id\": 4, \"category\": \"fiction\", \"author\": \"J. R. R. Tolkien PG\", \"title\": \"The Lord of the Rings PG\" }, "
				+ "{ \"id\": 5, \"category\": \"fiction5\", \"author\": \"Evelyn Waugh Updated5\", \"newField\": \"newValue5\" }], \"bicycle\": "
				+ "[{ \"id\": 3, \"color\": \"orange\", \"price\": 19.95 }] }, \"expensive\": 300, \"newOutsideField\": 400 } }";*/
		
		
		String patchString = "{ \"b\" : { \"y\" : 4, \"z\" : 5 } }";
		
		JsonObjectPatch<JsonNode> patch = fromJson(patchString);		
		patch.setMatchProps(loadProps());
		inputNode = patch.apply(inputNode);
		
		JsonNode expectedOutputNode = mapper.readValue("{\"a\":\"1\",\"b\":{\"x\":\"2\",\"y\":4,\"z\":5}}", JsonNode.class);
		assertThat(inputNode).isEqualTo(expectedOutputNode);
		
	}
	
	@Test
	public void testArrayrMerge() throws JsonPathPatchException, IOException {
				
		String input = readFile("src/test/resources/com/att/oce/jsonobjectpatch/input.json", StandardCharsets.UTF_8);
		String update = readFile("src/test/resources/com/att/oce/jsonobjectpatch/update.json", StandardCharsets.UTF_8);
		
		final ObjectMapper mapper = new ObjectMapper();        
		
		JsonNode inputNode = mapper.readValue(input, JsonNode.class);
		JsonNode updateNode = mapper.readValue(update, JsonNode.class);
		
		/*String patchString = "{ \"type\": \"JsonObjectPatch\", \"data\": { \"store\":"
				+ " { \"book\": [{ \"id\": 2, \"category\": \"fiction\", \"author\": \"Evelyn Waugh Updated\", \"newField\": \"newValue\" },"
				+ " { \"id\": 4, \"category\": \"fiction\", \"author\": \"J. R. R. Tolkien PG\", \"title\": \"The Lord of the Rings PG\" }, "
				+ "{ \"id\": 5, \"category\": \"fiction5\", \"author\": \"Evelyn Waugh Updated5\", \"newField\": \"newValue5\" }], \"bicycle\": "
				+ "[{ \"id\": 3, \"color\": \"orange\", \"price\": 19.95 }] }, \"expensive\": 300, \"newOutsideField\": 400 } }";
		*/
		
		String patchString = "{ \"store\":"
				+ " { \"book\": [{ \"id\": 2, \"category\": \"fiction\", \"author\": \"Evelyn Waugh Updated\", \"newField\": \"newValue\" },"
				+ " { \"id\": 4, \"category\": \"fiction\", \"author\": \"J. R. R. Tolkien PG\", \"title\": \"The Lord of the Rings PG\" }, "
				+ "{ \"id\": 5, \"category\": \"fiction5\", \"author\": \"Evelyn Waugh Updated5\", \"newField\": \"newValue5\" }], \"bicycle\": "
				+ "[{ \"bicycleId\": 3, \"color\": \"orange updated\", \"price\": 19.95 }] }, \"expensive\": 30054, \"newOutsideField\": 400000  }";
		
		JsonObjectPatch<JsonNode> patch = fromJson(patchString);		
		patch.setMatchProps(loadProps());
		inputNode = (JsonNode)patch.apply(inputNode);
		System.out.println(inputNode.toString());
		DocumentContext result = parse(inputNode.toString());
		List<String> updatedValue = result.read("$.store.book[?(@.id == 2)].author");
		System.out.println("updatedValue : "+updatedValue);
		assertThat(updatedValue).contains("Evelyn Waugh Updated");
	}
	
	
	
	
	public String readFile(String path, Charset encoding) 
			  throws IOException 
			{
			  byte[] encoded = Files.readAllBytes(Paths.get(path));
			  return new String(encoded, encoding);
			}
	
	private Properties loadProps(){
		Properties properties = new Properties();
		FileInputStream in;
		try {
			in = new FileInputStream("src/test/resources/com/att/oce/jsonobjectpatch/matchprops.properties");
			properties.load(in);
			in.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return properties;
	}

}
