## About

**object-patch** library is enabler to support implementation of the HTTP PATCH requests for Restful APIs.

### HTTP PATCH
The HTTP PATCH method is defined in RFC 5789 as an extension of HTTP 1.1, and provides a dedicated request method to apply partial modifications to a resource. Note that the PUT method could not be used for this purpose since its definition specifies that is used to completely overwrite a resource.


### ObjectPatch Interface

ObjectPath is a marker interface to abstract mulitple implementations for PATCHing a resource (Partial Updates).

    package com.att.oce.objectpatch;

    public interface ObjectPatch {

        <T> T apply(T target) throws ObjectPatchException;
    }

### Introducing JSON Patch Specification
JSON Patch <a href="https://tools.ietf.org/html/rfc6902">RFC 6902</a> is a format for describing changes to a JSON document.

JSON Pointer (IETF RFC 6901) defines a string format for identifying a specific value within a JSON document. It is used by all operations in JSON Patch to specify the part of the document to operate on.

#### Simple example

The original document

    {
      "baz": "qux",
      "foo": "bar"
    }

The patch

    [
      { "op": "replace", "path": "/baz", "value": "boo" },
      { "op": "add", "path": "/hello", "value": ["world"] },
      { "op": "remove", "path": "/foo"}
    ]

The result

{
   "baz": "boo",
   "hello": ["world"]
}

#### JSON Patch Array updates

    [
      {"op": "replace", "path": "/biscuits/0/name", "value": "Chocolate Digestive"}
      {"op": "add", "path": "/biscuits/1", "value": {"name": "Ginger Nut"}}
    ]

**As it can be seen, JSON Patch relies on index to refer to the array element, its critical that the client who is issuing the PATCH request is aware about the element position in a resource.** The element can be removed by some of the concurrent clients, hence the optimistic locking using CAS (compare-and-swap) is highly recommended solution to avoid accidently updating undesired array element.

> As of now, JsonPatch is NOT supported as an implementation of ObjectPatch.

### JSONPathPatch   

JsonPathPatch is a **custom implementation** and inspired by JSON Patch specification but instead of JSON Pointer, it relies on <a href="https://github.com/jayway/JsonPath" >JsonPath </a> to refer element(s) for modification.

JsonPath enables querying elements using predicates and supports modifications as well.

An example of a JsonPathPatch is as follows:</p>

    [
       {
       	"op": "add",
          "path": "$.lines[[?(@.id == 'line1')]",
          "key": "mobileNumber",
          "value": "2342234234"
		}
    ]

This patch contains a single operation which add a property to element(s) identified usign path. A JsonPathPatch can contain more than one operation; in this case, all operations are applied to the input JSON value in their order of appearance, until all operations are applied or an error condition is encountered.

## Further Development

-  Support Partial Json Object merge

    Given the JSON resource
    {
      "a" : "1",
      "b" : {
         "x" : "2",
         "y" : "3"         
      }
    }

    Applying the below patch
    {
      "b" : {
         "y" : 4,
         "z" : 5
      }
    }

   should result into
    {
      "a" : "1",
      "b" : {
          "x" : "2",
          "y" : "4",
          "z" : "5"         
     }
    }
