package com.att.oce.fallout.notificationsvc;

import java.util.List;
import java.util.logging.Logger;
import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import org.apache.camel.Exchange;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.ProcessEngines;
import org.camunda.bpm.engine.TaskService;
import org.w3c.dom.NodeList;

/**
 * <h1>Notify Service</h1> This class is to implement the cxf service interface.
 * 
 * @author Karthikeyan_M39
 * @version 1.0
 */
public class NotifyService {

	Logger log = Logger.getLogger("NotifyService.class");
	
	/**
	 * This method is for marking the Human Task to completed based on the
	 * Notification recieved from ATG for the task id which is sent.
	 * 
	 * @param Exchange
	 * @return SOAPMessage
	 */
	public SOAPMessage completeATGTask(Exchange exchange) {

		log.info("Inside NotifyService.completeATGTask() : ");

		SOAPMessage soapMessage = (SOAPMessage) exchange.getIn().getBody(List.class).get(0);
		if (soapMessage == null) {
			log.info("Incoming null message detected...");
			return createDefaultSoapMessage("Failed due to no soap body");
		}

		try {
			SOAPPart soapPart = soapMessage.getSOAPPart();
			SOAPEnvelope soapEnv = soapPart.getEnvelope();
			SOAPBody soapBody = soapEnv.getBody();
			String taskID = "";
			log.info("soapBody.getTextContent() : " + soapBody.getTextContent());

			String ns = "http://oce.att.com/OCE/Namespaces/Messages/Private/NotifyTaskUpdateServiceMessagesV1.0.xsd";
			NodeList notifyRequest = soapBody.getElementsByTagNameNS(ns, "NotifyTaskUpdateRequest");

			// Retrieves the task id from request
			for (int k = 0; k < notifyRequest.getLength(); k++) {
				NodeList notifyOrderTask = notifyRequest.item(k).getChildNodes();

				for (int l = 0; l < notifyOrderTask.getLength(); l++) {
					NodeList orderTaskItems = notifyOrderTask.item(l).getChildNodes();

					for (int m = 0; m < orderTaskItems.getLength(); m++) {
						
						if (orderTaskItems.item(m).getNodeName().endsWith(":TaskId")) {
							log.info("orderTaskItems.item(m).getNodeName() is : " + orderTaskItems.item(m).getNodeName());
							taskID = orderTaskItems.item(m).getTextContent().trim();
						}
					}
				}
			}

			log.info("taskID : " + taskID);

			// completes the human task based on ID provided on request
			ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
			TaskService taskService = processEngine.getTaskService();
			taskService.complete(taskID);
			log.info("taskID completed !!"); 
			
			//return createDefaultSoapMessage("Success");
			return createDefaultSoapMessage("RECEIVED");
		} catch (Exception e) {
			e.printStackTrace();
			return createDefaultSoapMessage("Failed :: " + e.getClass().getName());
		}
	}

	/**
	 * This method will construct the soap response content.
	 * 
	 * @param String
	 *            response message to be sent
	 * @return SOAPMessage constructed SOAP Response message
	 */
	private SOAPMessage createDefaultSoapMessage(String responseMessage) {
		try {
			SOAPMessage soapMessage = MessageFactory.newInstance().createMessage();
			SOAPBody body = soapMessage.getSOAPPart().getEnvelope().getBody();

			QName payloadName = new QName(
					"http://oce.att.com/OCE/Namespaces/Messages/Private/NotifyTaskUpdateServiceMessagesV1.0.xsd",
					"NotifyTaskUpdateResponse", "ns1");

			SOAPBodyElement payload = body.addBodyElement(payloadName);

			payload.addTextNode(responseMessage);

			return soapMessage;
		} catch (SOAPException e) {
			e.printStackTrace();
			throw new RuntimeException(e); 
		}
	}

}
