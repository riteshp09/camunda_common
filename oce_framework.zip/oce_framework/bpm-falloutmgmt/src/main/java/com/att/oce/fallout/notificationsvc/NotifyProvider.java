package com.att.oce.fallout.notificationsvc;

import javax.xml.soap.SOAPMessage;
import javax.xml.ws.Provider;
import javax.xml.ws.ServiceMode;
import javax.xml.ws.WebServiceProvider;
import javax.xml.ws.Service;

/**
 * <h1>Notify Provider</h1> This class is a provider for cxf interface.
 * 
 * @author Karthikeyan_M39
 * @version 1.0
 */

@WebServiceProvider()
@ServiceMode(value = Service.Mode.MESSAGE)
public class NotifyProvider implements Provider<SOAPMessage> {

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.xml.ws.Provider#invoke(java.lang.Object)
	 */
	@Override
	public SOAPMessage invoke(SOAPMessage request) {
		// Requests should not come here as the Camel route will
		// intercept the call before this is invoked.
		throw new UnsupportedOperationException("Placeholder method");
	}

}
