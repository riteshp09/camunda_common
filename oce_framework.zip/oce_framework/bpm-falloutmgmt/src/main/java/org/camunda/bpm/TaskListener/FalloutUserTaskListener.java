package org.camunda.bpm.TaskListener; 

import java.util.logging.Logger;
import com.att.oce.bpm.camel.common.CamelServiceImpl;
import org.camunda.bpm.engine.delegate.DelegateTask;
import org.camunda.bpm.engine.delegate.TaskListener;

/**
 * <h1>Fallout Task Listener</h1> This class implements TaskListener to listen
 * create events on configured human tasks and create a Fallout Task on ATG.
 * 
 * @author Karthikeyan_M39
 * @version 1:0
 */
public class FalloutUserTaskListener implements TaskListener {

	private CamelServiceImpl camelCon;

	public FalloutUserTaskListener() {
	}

	Logger logger = Logger.getLogger("FalloutUserTaskListener.class");

	/**
	 * Sets the camel context bean
	 * 
	 * @param CamelServiceImpl
	 * @return
	 */
	public void setCamelCon(CamelServiceImpl camel) {
		logger.info("|| setCamelCon() invoked ||");
		this.camelCon = camel;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.camunda.bpm.engine.delegate.TaskListener#notify(org.camunda.bpm.
	 * engine.delegate.DelegateTask)
	 */
	@Override
	public void notify(DelegateTask delegateTask) {

		logger.info(" || Inside notify() || ");
		logger.info(" || delegateTask.getId() || " + delegateTask.getId());

		try {			
			
			delegateTask.setVariable("camundaTaskId", delegateTask.getId());
			
			if (camelCon != null) {
				logger.info(" || Inside camel call || ");
				camelCon.sendTo("direct:atgcreatetask","order,camundaTaskId,executionContext");
			} else {
				logger.info(" || camel is null || ");
			}
		} catch (Exception e) {
			logger.warning("Inside Catch Block stack trace :: ");
			e.printStackTrace();
		}
	}
}  
