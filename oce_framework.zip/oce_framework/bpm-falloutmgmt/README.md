## About
This Project is created to keep the Fallout Management Module as a generic component for reusability and make it as plug and play to work on any BPMN's.

### Fallout Management Component Design

![Fallout-Management-Component-Design](images/FalloutDesign.jpg)

 -	Any faults will be creating a user task for Fallout.
 -	TaskListener on Task Create event will make a Camel route call to ATG for creating a Fallout Task in ATG.
 -	Post Fallout Task is created in ATG it waits for notification for Agent Updates.
 -	Once agent updates the fallout task in UI it gets updated in ATG DB. The Human Task id will to be passed as CamundaTaskId element in the request. 
 -	ATG Notification job will pull all completed Fallout Tasks and calls Notification Service exposed in AJSC camunda as camel CXF service.
 -	The Notification service will take the TaskID from the Notification request and mark the Human Task completed.
 -	Post User Task Status is updated the automation resumes from there further. Get Order call needs to be made to refresh order.

### How to Integrate Fallout Component on BPMN

 -	Checkout the bpm-falloutmgmt Project.
 -	Add Maven Dependency of this project as below to the pom.xml of your **�cntr** Project,
 
		 <dependency>
			 <groupId>com.att.oce</groupId>
			 <artifactId>falloutmgmt</artifactId>
			 <version>0.0.1-SNAPSHOT</version>
		 </dependency>				
 -	Add the below cxf servlet configuration under runner-web.xml present under your container project,
 
		<servlet>
		    <servlet-name>CXFServlet</servlet-name>	    
		    <servlet-class>org.apache.cxf.transport.servlet.CXFServlet</servlet-class> 
		    <init-param>
			      <param-name>config-location</param-name>
			      <param-value>classpath:cfxconfig/cfxbeans.xml</param-value>    
		    </init-param>   
		    <load-on-startup>1</load-on-startup>		    
  		</servlet>
  		<servlet-mapping>
		    <servlet-name>CXFServlet</servlet-name>
		    <url-pattern>/active-bpel/services/*</url-pattern>
	  </servlet-mapping>
			  		 
 - 	Add  falloutUserTaskListener under **Properties->Listener->Task Listeners->Delegate** Expression of the appropriate User Task in your BPEL and select Create Event from the list.
 
 	![Listener-Config](images/ListenerConfig.jpg)
 
 -  Add the below entry under camel context of camel outbound configuration xml, 
		
		<route id="atg-route">
			<from uri="direct:atgcreatetask" />
			<setHeader headerName="CamelHttpMethod">
				<constant>POST</constant>
			</setHeader>
			<setHeader headerName="Content-Type">
				<constant>application/json</constant>
			</setHeader>
			<setHeader headerName="Accept">
				<constant>application/json</constant>
			</setHeader>
			<setProperty propertyName="transactionHistory">
				<groovy>com.att.oce.bpm.subscriptions.WirelessSubscriptionTransformation.gettransactionHistory(body.executionContext)
				</groovy>
			</setProperty> 
			<setHeader headerName="CamelHttpUri">
				<groovy>com.att.oce.bpm.bpmn.ConfigurationManager.getInstance().urnMappings.resolve("urn:atgtask:orders")
				</groovy>
			</setHeader>
			<setBody>
				<groovy>com.att.oce.bpm.subscriptions.WirelessSubscriptionTransformation.convertATGOrderString(body.order, exchange.properties.transactionHistory,body.camundaTaskId)
				</groovy>
			</setBody>
			<to uri="http://headeruri?throwExceptionOnFailure=false" />	
			<convertBodyTo type="java.lang.String" />
		</route>
	
#### Class Diagram

![Listener Class](images/ClassDiagram.jpg)

- **completeATGTask() :** This method is for marking the Human Task to complete based on the Notification received from ATG for the task id which is sent.
- **createDefaultSoapMessage() :**
This method will construct the soap response content for this service.	

#### Sequence Diagram

##### Task Listener :

![Listener Sequence](images/Fallout-Sequence-Listener.jpg)

- The service task faults are captured and routed to Human Task.
- Task Listener will trigger notify method of FalloutUserTaskListener from where ATG Task is created.

##### Notification Service :

![Notification Service](images/Fallout-Sequence-notify.jpg)

- Notification Service is exposed by CXF Endpoint
- completeATGTask() method will retrieve the task id from the request and call the complete() method of Task Service by passing that TaskId for marking the task for closure.
- createDefaultSOAPMessage() method will be used to construct response.


	 	
