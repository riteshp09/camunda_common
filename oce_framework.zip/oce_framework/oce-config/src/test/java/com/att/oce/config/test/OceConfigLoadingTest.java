package com.att.oce.config.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.beans.config.OceConfig;
import com.att.oce.config.components.GlobalProperties;
import com.att.oce.config.components.ErrorConfig;



/**
 * Test Class which validates the loading of ACTUAL bootstrap-config.yml and global-config.yml
 * This is important for catching syntactical errors in ACTUAL yml.
 * 
 *  configure ENV variable as below to run this test on local machine:
 * 		-DOCE_RESOURCES_HOME= <path to oce-resources/src/main/resources>
 * 
 * @author kp7466
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {OceConfig.class, GlobalProperties.class,ErrorConfig.class})
public class OceConfigLoadingTest {
	
	@Autowired
	GlobalProperties global;
	//ApplicationContext appCtx;
	
	@Autowired
	ErrorConfig config;
	
	/**
	 * Env variable OCE_RESOURCES_HOME is used to read resources file.
	 *  -DOCE_RESOURCES_HOME= <path to oce-resources/src/main/resources>
	 */
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "src/test/resources/");
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireless");
	} 
	
	
	
	@Test
	public void testBootStrapConfigLoading() {
		assertNotNull(global.csiVersion);
	}
	
	@Test
	public void testCCarErrorConfiguration() {
		assertNotNull(config.getErrorDescription("nack800"));
	}
	
}
