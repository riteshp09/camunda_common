package com.att.oce.config.test;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.beans.config.OceConfig;
import com.att.oce.config.components.ErrorConfig;
import com.att.oce.config.components.GlobalProperties;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;


/**
 * Test class to validate merging of properties based on ENV.
 * It uses the dummy test yml file.
 * 
 * @author kp7466
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {OceConfig.class,GlobalProperties.class,ErrorConfig.class})
public class OceConfigMergeTest {
	
	@Autowired
	GlobalProperties global;
	
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "src/test/resources/");
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireless");
		System.setProperty("CAMUNDA_ENGINE_DB_POOL_MAX_ACTIVE", "800");
	} 
	
	@Test
	public void testConfigMerge(){
		assertNotNull(global.AuditLogLevel);
	}
	
	@Test
	public void testSysPropOverride(){
		assertEquals(300, global.CamundaDbPoolMaxActive);
	}
}


