package com.att.oce.config.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.beans.config.OceConfig;
import com.att.oce.config.components.URNResolver;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {OceConfig.class, URNResolver.class })
public class URNResolverTest {
	
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "src/test/resources/");
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireless");
	} 
	
	@Autowired
	URNResolver urnResolver;
	
	@Test
	public void testURNResolveComplete(){
		assertEquals(urnResolver.resolveUrn("urn:csi:services:cam:InquireAccountProfile.jws"),"https://csi-tst-q28.it.att.com:28443/Services1/com/cingular/csi/cam/InquireAccountProfile.jws");
		assertEquals(urnResolver.resolveUrn("urn:csi:services:cam:AddAccount.jws"),"https://csi-tst-q28.it.att.com:28443/Services/com/cingular/csi/cam/AddAccount.jws");
	}

}
