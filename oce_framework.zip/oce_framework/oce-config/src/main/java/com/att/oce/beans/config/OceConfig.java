package com.att.oce.beans.config;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;


@Configuration
public class OceConfig  {
	
	private static final Logger logger = LoggerFactory.getLogger(OceConfig.class);
	
	private static String ENV = System.getProperty("OCE_ENV");
	private static String DOMAIN = System.getProperty("OCE_DOMAIN");
	
	//static configuration CONSTANTS
	private static String OCE_RESOURCES_HOME = System.getProperty("OCE_RESOURCES_HOME");

	private static String APPLICATION_CONFIG = OCE_RESOURCES_HOME + "application.properties";
	private static String DOMAIN_APPLICATION_CONFIG = OCE_RESOURCES_HOME  + "application-" + DOMAIN + ".properties";	
	private static String ENV_APPLICATION_CONFIG = OCE_RESOURCES_HOME  + "application-" + ENV + ".properties";	

	/**
	 * Loads the properties defined in bootstrap-config.yml.
	 * 
	 * It would merge the properties with bootstrap-config-{env}.yml
	 * 
	 * @return
	 */
	@Bean
	public static PropertySourcesPlaceholderConfigurer oceProperties() {
		
		logger.info("Loading bootstrap config with Env Settings..");
		logger.info("AJSC_CONFIG_HOME = " + OCE_RESOURCES_HOME);
		logger.info("OCE_ENV = " + ENV);
		logger.info("OCE_DOMAIN = " + DOMAIN);
		
		PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
		
		List<Resource>  resources = new ArrayList<Resource>();
		resources.add(new FileSystemResource(APPLICATION_CONFIG));
		FileSystemResource envSpecific = new FileSystemResource(DOMAIN_APPLICATION_CONFIG);
		if(envSpecific.exists())
			resources.add(envSpecific);	
		envSpecific = new FileSystemResource(ENV_APPLICATION_CONFIG);
		if(envSpecific.exists())
			resources.add(envSpecific);	
		
		Resource[] resourcesArray = new Resource[resources.size()];		
		
		propertySourcesPlaceholderConfigurer.setIgnoreResourceNotFound(true);
		propertySourcesPlaceholderConfigurer.setLocations(resources.toArray(resourcesArray));
		
		propertySourcesPlaceholderConfigurer.setIgnoreUnresolvablePlaceholders(true);
		
		return propertySourcesPlaceholderConfigurer;
	}

}
