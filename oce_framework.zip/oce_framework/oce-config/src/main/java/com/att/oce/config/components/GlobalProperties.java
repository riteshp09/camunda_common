package com.att.oce.config.components;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import org.springframework.context.EmbeddedValueResolverAware;
import org.springframework.stereotype.Component;
import org.springframework.util.StringValueResolver;

@Component
public class GlobalProperties implements EmbeddedValueResolverAware {

	public String camundaHistory;
	public String camundaMetricsFlag;
	public String csiVersion;
	public String csiOriginatorId;
	public String csiIotUserName;
	public String csiIotPassword;
	public String csiOceUserName;
	public String csiOcePassword;
	public String AuditLogBrokerUrl;
	public String AuditLogQueueName;
	public String AuditLogBrokerUserbame;
	public String AuditLogBrokerPassword;
	public int AuditLogBrokerMinConnections;
	public int AuditLogBrokerMaxConnections;
	public int AuditLogLevel;
	public String AuditLogSystemProperty;
	public String isATGEndPointAMQ;
	public String atgBrokerUrl;
	public String atgQueueName;
	public String atgBrokerUserbame;
	public String atgBrokerPassword;
	public int atgBrokerMinConnections;
	public int atgBrokerMaxConnections;
	private StringValueResolver resolver;
	public String atgSwitch;

	public int CamundaExecutorCorePoolSize;
	public int CamundaExecutorMaxPoolSize;
	
	
	public String CamundaDbDriverClass;
	public String CamundaDbUrl;
	public String CamundaDbUsername;
	public String CamundaDbPassword;
	public int CamundaDbPoolInitialSize;
	public int CamundaDbPoolMaxActive;
	public int CamundaDbPoolMaxWait;
	public boolean CamundaDbPoolTestOnBorrow;
	public String CamundaDbValidationQuery;
	public int CamundaDbValidationQueryTimeout;
	
	public int CamelWiretapExecutorCorePoolSize;
	public int CamelWiretapExecutorMaxPoolSize;
	
	public int CamelHttpMaxPerRoute;
	public int CamelHttpMaxTotal;
	
//	#Camel Wiretap Executor Settings
//	camel.wiretap.corepoolsize = 500
//	camel.wiretap.maxPoolSize = 500
//
//	#Camel Http Connection Pool Size
//	camel.http.maxPerRoute = 500
//	camel.http.maxTotal = 1000


	/*Validate Address*/
	public int validateAddressConfidence;
	public Map<String,String> mAddressTypes;
	public String wirelessCapmSwitch;
	
	/*CRSM Partial Cancel*/
	public String csrmPartialCancelErrorMessage;
	public String csrmPartialCancelErrorCode;
	
	@PostConstruct
	public void init()
	{
		this.camundaHistory = this.resolver.resolveStringValue("${camunda.history}");
		this.camundaMetricsFlag = this.resolver.resolveStringValue("${camunda.metrics.flag}");
		
		this.csiIotUserName = this.resolver.resolveStringValue("${csi.iot.username}");
		this.csiIotPassword = this.resolver.resolveStringValue("${csi.iot.password}");
		this.csiOceUserName = this.resolver.resolveStringValue("${csi.oce.username}");
		this.csiOcePassword = this.resolver.resolveStringValue("${csi.oce.password}");
		this.csiVersion = this.resolver.resolveStringValue("${csi.version}");
		this.csiOriginatorId = this.resolver.resolveStringValue("${csi.originatorId}");

		this.AuditLogBrokerUrl = this.resolver.resolveStringValue("${auditlog.amq.url}");
		this.AuditLogQueueName = this.resolver.resolveStringValue("${auditlog.amq.queuename}");
		this.AuditLogBrokerUserbame = this.resolver.resolveStringValue("${auditlog.amq.username}");
		this.AuditLogBrokerPassword = this.resolver.resolveStringValue("${auditlog.amq.password}");
		this.AuditLogBrokerMinConnections = Integer.parseInt(this.resolver.resolveStringValue("${auditlog.amq.min.idle.connections}"));
		this.AuditLogBrokerMaxConnections = Integer.parseInt(this.resolver.resolveStringValue("${auditlog.amq.max.idle.connections}"));
		this.AuditLogLevel = Integer.parseInt(this.resolver.resolveStringValue("${auditlog.log.level}"));
		this.AuditLogSystemProperty = this.resolver.resolveStringValue("${auditlog.system.property}");
		
		this.isATGEndPointAMQ = this.resolver.resolveStringValue("${atg.isATGEndPointAMQ}");
		this.atgBrokerUrl = this.resolver.resolveStringValue("${atg.amq.url}");
		this.atgQueueName = this.resolver.resolveStringValue("${atg.amq.queuename}");
		this.atgBrokerUserbame = this.resolver.resolveStringValue("${atg.amq.username}");
		this.atgBrokerPassword = this.resolver.resolveStringValue("${atg.amq.password}");
		this.atgBrokerMinConnections = Integer.parseInt(this.resolver.resolveStringValue("${atg.amq.min.idle.connections}"));
		this.atgBrokerMaxConnections = Integer.parseInt(this.resolver.resolveStringValue("${atg.amq.max.idle.connections}"));


		this.CamundaDbDriverClass = this.resolver.resolveStringValue("${CAMUNDA_ENGINE_DB_DRIVER_CLASS}");
		this.CamundaDbUrl = this.resolver.resolveStringValue("${CAMUNDA_ENGINE_DB_URL}");
		this.CamundaDbUsername = this.resolver.resolveStringValue("${CAMUNDA_ENGINE_DB_USERNAME}");
		this.CamundaDbPassword = this.resolver.resolveStringValue("${CAMUNDA_ENGINE_DB_PASSWORD}");
		this.CamundaDbPoolInitialSize = Integer.parseInt(this.resolver.resolveStringValue("${CAMUNDA_ENGINE_DB_POOL_INITIAL_SIZE}"));
		this.CamundaDbPoolMaxActive = Integer.parseInt(this.resolver.resolveStringValue("${CAMUNDA_ENGINE_DB_POOL_MAX_ACTIVE}"));
		this.CamundaDbPoolMaxWait = Integer.parseInt(this.resolver.resolveStringValue("${CAMUNDA_ENGINE_DB_POOL_MAX_WAIT}"));
		this.CamundaDbPoolTestOnBorrow = Boolean.parseBoolean(this.resolver.resolveStringValue("${CAMUNDA_ENGINE_DB_POOL_TEST_ON_BORROW}"));
		this.CamundaDbValidationQuery = this.resolver.resolveStringValue("${CAMUNDA_ENGINE_DB_POOL_VALIDATION_QUERY}");
		this.CamundaDbValidationQueryTimeout = Integer.parseInt(this.resolver.resolveStringValue("${CAMUNDA_ENGINE_VALIDATION_QUERY_TIMEOUT}"));

		this.CamundaExecutorCorePoolSize = Integer.parseInt(this.resolver.resolveStringValue("${camunda.executor.corepoolsize}"));
		this.CamundaExecutorMaxPoolSize = Integer.parseInt(this.resolver.resolveStringValue("${camunda.executor.maxPoolSize}"));
		
		this.CamelWiretapExecutorCorePoolSize = Integer.parseInt(this.resolver.resolveStringValue("${camel.wiretap.corepoolsize:100}"));
		this.CamelWiretapExecutorMaxPoolSize = Integer.parseInt(this.resolver.resolveStringValue("${camel.wiretap.maxPoolSize:100}"));
		
		this.CamelHttpMaxPerRoute = Integer.parseInt(this.resolver.resolveStringValue("${camel.http.maxPerRoute:20}"));
		this.CamelHttpMaxTotal = Integer.parseInt(this.resolver.resolveStringValue("${camel.http.maxTotal:200}"));
		
		this.validateAddressConfidence = Integer.parseInt(resolver.resolveStringValue("${validateaddress.confidence}"));
		this.mAddressTypes = mapValues(resolver.resolveStringValue("${addressTypes}"));
		this.wirelessCapmSwitch = this.resolver.resolveStringValue("${CAPM.Switch}");
		this.atgSwitch = this.resolver.resolveStringValue("${atg.create.switch}");
		this.csrmPartialCancelErrorMessage = this.resolver.resolveStringValue("${csrm.partialcancel.error.message}");
		this.csrmPartialCancelErrorCode = this.resolver.resolveStringValue("${csrm.partialcancel.error.code}");
	}

	public void setEmbeddedValueResolver(StringValueResolver resolver)
	{
		this.resolver = resolver;
	}

	private Map<String,String> mapValues(String values){
		Map<String,String> mValues = new HashMap<String,String>();
		String[] aValues =values.split(",");
		for(int i=0;i<aValues.length;i++){
			String[] aValue = aValues[i].split(":");
			mValues.put(aValue[0],aValue[1]);
		}
		return mValues;
	}
}

