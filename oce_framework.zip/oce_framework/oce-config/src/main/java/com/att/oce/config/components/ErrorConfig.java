package com.att.oce.config.components;

import org.springframework.context.EmbeddedValueResolverAware;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.util.StringValueResolver;

@Component
public class ErrorConfig implements EmbeddedValueResolverAware {

	private StringValueResolver resolver;
	
	public String getErrorDescription(String errorCode)
	{
		String error = "${error.message."+ errorCode +"}";
		return resolver.resolveStringValue(error);
		
	}

	public void setEmbeddedValueResolver(StringValueResolver resolver) {
		this.resolver = resolver;
	}

}
