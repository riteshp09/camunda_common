package com.att.oce.config.components;

import org.springframework.context.EmbeddedValueResolverAware;
import org.springframework.stereotype.Component;
import org.springframework.util.StringValueResolver;

@Component
public class URNResolver implements EmbeddedValueResolverAware {

	private StringValueResolver resolver;
	public void setEmbeddedValueResolver(StringValueResolver resolver) {
		this.resolver = resolver;		
	}
	
	private static String PREFIX="${";
	private static String SUFFIX="}";
	
	private static String PLACEHOLDER_PREFIX="${urn.";
	
	private static String SEMICOLON=":";
	private static String SEMICOLON_DOLLAR=":$";
	private static String EMPTY="";
	
	public String resolveUrn(String urn){
		String key = PREFIX+urn+SUFFIX;
		String url = resolver.resolveStringValue(key);
		if (url == null || url.length()==0 || key.indexOf(url) > 0 )
		{
			// resolve partial urn
			String[] parts = urn.split(":");
			for (int i=parts.length-1;i>0;i--){
				String partialurn="";
				for (int j=0;j<i;j++){
					partialurn += parts[j]+SEMICOLON;
				}
				partialurn = partialurn.replaceAll(SEMICOLON_DOLLAR, EMPTY);
				key = PREFIX+partialurn+SUFFIX;
				url = resolver.resolveStringValue(key);

				if (url != null && url.length()>0 && key.indexOf(url) == -1) {
					for (int k=0;k<parts.length;k++)
						url = url.replace(PLACEHOLDER_PREFIX+(k+1)+SUFFIX, parts[k]);
					return url;
				}
			}
			return urn;
		} 
		String[] parts = urn.split(":");
		for (int k=0;k<parts.length;k++)
			url = url.replace(PLACEHOLDER_PREFIX+(k+1)+SUFFIX, parts[k]);
		return url;
		
	}

}
