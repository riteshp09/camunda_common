## About

oce-config loads the bootstrap-config.yml and dynamic-config.yml as properties. These file are managed as file-system resoruces in oce-resources.

See oce-resources/README.md for more details.
