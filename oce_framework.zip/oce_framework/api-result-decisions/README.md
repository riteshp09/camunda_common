## About

retry-decisions loads the retry-decisions.dmn (defined in oce-resources) and exposes Decisions as Spring bean to be readily used in various applications (mainly Camunda based stateful services).

It provides thourough unittests for various API retry scenarios.

See oce-resources/README.md for more details.
