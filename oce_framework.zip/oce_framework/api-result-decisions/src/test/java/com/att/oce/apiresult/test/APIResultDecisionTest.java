package com.att.oce.apiresult.test;

import javax.annotation.Resource;

import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionRuleResult;
import org.camunda.bpm.dmn.engine.DmnDecisionTableResult;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.camunda.bpm.engine.variable.VariableMap;
import org.camunda.bpm.engine.variable.Variables;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.beans.config.APIResultConfig;

/**
 * Test class to validate Retry Decision table.
 * 
 * This test class takes care of exposing dependent dmnEngine bean.
 * 
 * 
 * Imp: 
 *  configure ENV variable as below to run this test on local machine:
 * 		-DOCE_RESOURCES_HOME= <path to oce-resources/src/main/resources>
 *
 * @author kp7466
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {APIResultDecisionTest.class, APIResultConfig.class})
public class APIResultDecisionTest {

	/**
	 * Env variable OCE_RESOURCES_HOME is used to read resources file.
	 *  -DOCE_RESOURCES_HOME= <path to oce-resources/src/main/resources>
	 */
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "src/test/resources/");
	} 
	
	@Autowired
	private DmnEngine dmnEngine;
	
	
	@Bean
	public static DmnEngine dmnEngine() {
		// create default DMN engine configuration
		DmnEngineConfiguration configuration = DmnEngineConfiguration
		  .createDefaultDmnEngineConfiguration();

		// configure as needed
		// ...

		// build a new DMN engine
		DmnEngine dmnEngine = configuration.buildEngine();
		return dmnEngine;
	}
	
	@Resource(name = "apiResultDecisions")
	private DmnDecision apiResultDecisions;
	
	@Test
	public void testDmnEngineInjection() {
		Assert.assertNotNull(dmnEngine);
	}
	
	@Test
	public void testAPIResultDecisionTableInjection() {
		Assert.assertNotNull(apiResultDecisions);		
		Assert.assertTrue(apiResultDecisions.isDecisionTable());
	}
	
	@Test
	public void testAPIResultDecision() {
		
		VariableMap variables = Variables.createVariables()
			.putValue("code", "300")
			.putValue("subCode", null)
			.putValue("losgType", null)
			.putValue("api", "ValidateAddress");
		
		DmnDecisionTableResult results = dmnEngine
					.evaluateDecisionTable(apiResultDecisions, variables);
		
		DmnDecisionRuleResult result = results.getFirstResult();		

		//assert that it only has 1 entry
		Assert.assertEquals(3, result.size());		
		Assert.assertEquals("VALIDATE_ADDRESS_SKIPPED", result.get("subStatus"));
	}

	@Test
	public void testAPIResultWithEmptyStatusDecision() {
		
		VariableMap variables = Variables.createVariables()
			.putValue("code", null)
			.putValue("subCode", null)
			.putValue("losgType", null)
			.putValue("api", "InquireMobileSubscriberProfile");
		
		DmnDecisionTableResult results = dmnEngine
					.evaluateDecisionTable(apiResultDecisions, variables);
		
		DmnDecisionRuleResult result = results.getFirstResult();		

		//assert that it only has 1 entry
		Assert.assertEquals(3, result.size());		
		Assert.assertEquals("INQUIRE_MOBILE_SUBSCRIBER_PROFILE_FAIL", result.get("subStatus"));
	}
	

}
