#!/bin/sh

env

ls -lrt /
ls -lrt /scripts

touch /app.war

if [ "$AUTOMATION_COMMAND" = "extract" ]
then
	curl -fsSL -o /oce-ajsc-utility.jar http://mavencentral.it.att.com:8084/nexus/service/local/repositories/oce-snapshots/content/com/att/oce/oce-ajsc-utility/0.0.1-SNAPSHOT/oce-ajsc-utility-0.0.1-20170607.172841-1.jar
	/bin/bash /scripts/extract
fi

if [ "$AUTOMATION_COMMAND" = "prepare" ]
then
	/bin/bash /scripts/prepare
fi

if [ "$AUTOMATION_COMMAND" = "test" ]
then
	/bin/bash /scripts/test
fi

if [ "$AUTOMATION_COMMAND" = "report-server" ]
then
	perl ./scripts/server
fi

