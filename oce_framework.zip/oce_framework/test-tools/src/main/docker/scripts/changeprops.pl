sub trim {
	my $s = shift;
	$s =~ s/\n//g;
	$s =~ s/\r//g;
	return $s;
}



open PROP,$ARGV[0] || die $!+"";
my $camunda=!1;
my @lines=();
while (<PROP>){
	
	if ($_ =~ /^SOA_CLOUD_ENV/){
		push(@lines,'SOA_CLOUD_ENV=false');
	} elsif ($_ =~ /^ssf_filemonitor_threadpool_size/){
		push(@lines,'ssf_filemonitor_threadpool_size=2');
	} elsif ($_ =~ /^ssf_filemonitor_polling_interval/){
		push(@lines,'ssf_filemonitor_polling_interval=3600');
	} elsif ($_ =~ /^CAMUNDA_ENGINE_DB_POOL_TEST_ON_BORROW/){
		push(@lines,'CAMUNDA_ENGINE_DB_POOL_TEST_ON_BORROW=false');
	} elsif ($_ =~ /^camunda\.history/){
		push(@lines,'camunda.history = audit');
	} elsif ($_ =~ /(AMQ_USERNAME|AMQ_PASSWORD|\.amq\.username|\.amq\.password)/){
		my $s=trim($_);
		$s =~ s/\=.*$/=admin/;
		push(@lines,$s);
	} elsif ($_ =~ /(DB_PASSWORD|DB_USERNAME)/){
		my $s=trim($_);
		$s =~ s/\=.*$/=camunda/;
		push(@lines,$s);
	} elsif ($_ =~ /OCE_RESOURCES_HOME/){
		my $s=trim($_);
		$s =~ s/\=.*$/=\/work\/oce_framework\/oce-resources\/src\/main\/resources\//;
		push(@lines,$s);
	} elsif ($_ =~ /tcp:\/\/([^\:]+)\:([0-9]+)/){
		my $s = $_;
		my $s1 = $_;
		while(1){
			if ($s =~ /tcp:\/\/([^\:]+)\:([0-9]+)/){
				my $server=$1;my $pp=$2;
				my $f = "tcp://$server:$pp";
				$s1 =~ s/$f/tcp:\/\/localhost:8500/g;
				$s =~ s/$f//g;
			} else {
				last;
			}
		}
		push(@lines,trim($s1));
	} elsif ($_ =~ /http[s]?:\/\/([^\:]+)\:([0-9]+)/){
		my $server=$1;my $pp=$2;
		my $f1 = "http://$server:$pp";
		my $f2 = "https://$server:$pp";
		my $s1 = $_;
		$s1 =~ s/$f/http:\/\/localhost:25555/g;
		push(@lines,trim($s1));
	} elsif ($_ =~ /processorder\.amq\.queuename/){
		my $s=trim($_);
		$s =~ s/\=.*$/=ORDER_INTAKE_Q/;
		push(@lines,$s);
	} elsif ($_ =~ /PROCESSORDER\_AMQ\_NAME/){
		my $s=trim($_);
		$s =~ s/\=.*$/=ORDER_INTAKE_Q/;
		push(@lines,$s);
	} elsif ($_ =~ /NOTIFY\_AMQ\_NAME/){
		my $s=trim($_);
		$s =~ s/\=.*$/=OCE_CAMUNDA_ATG_NOTIFY/;
		push(@lines,$s);
	} elsif ($_ =~ /OCE_ENV/){
		push(@lines,'OCE_ENV=auto');
	} elsif ($_ =~ /jdbc\:/){
		my $s=trim($_);
		$s =~ s/\=.*$/=jdbc\:h2\:tcp\:\/\/localhost\:9092\/mem\:camdata;MVCC=TRUE;DB_CLOSE_DELAY=\-1;/;
		push(@lines,$s);
	} elsif ($_ =~ /oracle\.jdbc\.OracleDriver/){
		my $s=trim($_);
		$s =~ s/\=.*$/=org.h2.Driver/;
		push(@lines,$s);
	} else {
		push(@lines,trim($_));
	}
}
close PROP;

my $file = $ARGV[1];
$file = $ARGV[0] if (!defined($file));

print "Props changed $ARGV[0] ==> $file\n";
open PROPO,'>'.$file;
my $joins = join("\n",@lines);
print PROPO $joins;
if (index($joins,'camunda.history') == -1){
	print PROPO "\ncamunda.history = audit\n"
}
close PROPO;
