use Encode qw(decode encode);
my $OS_PATH_SEP='/';

if ($ARGV[1] eq 'fixutf'){
	opendir(my $dh, $ARGV[0]) || die "Can't open ".$ARGV[0].": $!";
	while (readdir $dh) {
		if (substr($_,-12) eq '-REQUEST.xml' || substr($_,-11) eq 'GET-RES.xml' ){
			my $file=$ARGV[0]."${OS_PATH_SEP}$_";
			if (! -e $file.'.ready.json'){
				print "$file\n";
				open XML,$file;
				local $/;
				my $xml = <XML>;
				close XML;

				my $octets    = decode('UTF-8', $xml, Encode::FB_DEFAULT);
				my $xml_good_utf8 = encode('UTF-8', $octets,         Encode::FB_CROAK);
				$xml_good_utf8 =~ s/“/\'/g;
				$xml_good_utf8 =~ s/”/\'/g;
				$xml_good_utf8 =~ s/ ‡/\'/g;
				$xml_good_utf8 =~ s/¿//g;

				my $ordstart = index($xml_good_utf8,'<Order>');
				if ($ordstart>-1){
					my $ordend = rindex($xml_good_utf8,'</Order>');
					open OUT,'>'.$file.'.ready';
					print OUT '<Order xmlns="http://oce.att.com/OCE/Namespaces/Types/Public/OCEDataModel.xsd">';
					print OUT substr($xml_good_utf8,$ordstart+7,($ordend+8)-($ordstart+7));
					close OUT;
				} else {
					$ordstart = index($xml_good_utf8,'<Order xmlns="http://oce.att.com/OCE/Namespaces/Types/Private/OCEDataModel.xsd">');
					if ($ordstart>-1){
						my $ordend = rindex($xml_good_utf8,'</Order>');
						open OUT,'>'.$file.'.ready';
						print OUT '<Order xmlns="http://oce.att.com/OCE/Namespaces/Types/Public/OCEDataModel.xsd">';
						print OUT substr($xml_good_utf8,$ordstart+80,($ordend+8)-($ordstart+80));
						close OUT;
					}
				}
			}
		}
	}
}
if ($ARGV[1] eq 'fixrequestid'){
	opendir(my $dh, $ARGV[0]) || die "Can't open ".$ARGV[0].": $!";
	while (readdir $dh) {
		my $file=$ARGV[0]."${OS_PATH_SEP}$_";
		if (substr($file,-22) eq 'GET-RES.xml.ready.json'){
			open JSON,$file;local $/;my $json = <JSON>;close JSON;
			if (index($json,'"requestId"') == -1){
				open XML,substr($file,0,-11);local $/;my $xml = <XML>;close XML;
				if ($xml =~ /<RequestId>([a-z0-9\-]+)<\/RequestId>/){
					my $reqid = $1;
					print $file," $reqid\n";
					my $json = substr($json,1);
					open JSONO,'>'.$file;
					print JSONO '{',"\n",'  "requestId": "',$reqid,'",';
					print JSONO $json;
					close JSONO;
				}
			}
		}
	}
}






