package com.att.oce.ajsc.xmltojson;

import com.att.oce.ajsc.order.model.Order;
import com.att.oce.fuse.util.AJSCElementNameChangeConfig;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import javax.xml.bind.JAXBException;
import javax.xml.stream.XMLStreamException;
import java.io.File;

public class GenerateSampleJson2
{
  public static void main(String[] args)
    throws XMLStreamException, JAXBException, JsonProcessingException, FileNotFoundException, java.io.IOException
  {
    
    FuseXmlToAjscXmlParser xmlToJsonParser = new FuseXmlToAjscXmlParser();
    AJSCElementNameChangeConfig config = new AJSCElementNameChangeConfig(args[0]);
    xmlToJsonParser.setMapReplaceElementNames(config.getMapReplaceElementNames());
	
	File folder = new File(args[1]);
	File[] listOfFiles = folder.listFiles();
	
	for (int i = 0; i < listOfFiles.length; i++) {
	  File file = listOfFiles[i];
	  if (file.isFile() && file.getName().endsWith(".ready")) {
			//System.out.println(file.getCanonicalPath());
			
			try {
				String xml = ConvertionUtil.readFile(file.getCanonicalPath());
				String  modifiedXml = xmlToJsonParser.parseXML(xml);
			
				if (modifiedXml != null){
					Order order = ConvertionUtil.unmarshlXmlToObject(modifiedXml);
					String json = ConvertionUtil.marshalToJson(order);
					PrintStream out = new PrintStream(new FileOutputStream(file.getCanonicalPath()+".json"));
					out.println(json);
					out.close();
				}
			}
			catch(Exception e){
				System.out.println("Error in file "+file.getCanonicalPath());
			}
		}
	}
  }
}
