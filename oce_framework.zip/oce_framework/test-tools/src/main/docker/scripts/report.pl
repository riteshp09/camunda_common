#perl report.pl
sub uniq {
    my %seen;
    grep !$seen{$_}++, @_;
}

sub trim {
	my $s = shift;
	$s =~ s/\n//g;
	$s =~ s/\r//g;
	return $s;
}
my $OS_PATH_SEP='/';
my $taskNotifiation =<<'END';
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:not="http://oce.att.com/OCE/Namespaces/Messages/Private/NotifyTaskUpdateServiceMessagesV1.0.xsd" xmlns:oced="http://oce.att.com/OCE/Namespaces/Types/Private/OCEDataModelExtensionV1.0.xsd">
	<soapenv:Header/>
	<soapenv:Body>
		<NotifyTaskUpdateRequest xmlns="http://oce.att.com/OCE/Namespaces/Messages/Private/NotifyTaskUpdateServiceMessagesV1.0.xsd">
			<ns1:OrderTask xmlns:ns1="http://oce.att.com/OCE/Namespaces/Types/Private/OCEDataModelExtensionV1.0.xsd">
				<ns1:OrderNumber>ORDERNUMBER</ns1:OrderNumber>
				<ns1:CustomerOrderNumber>CUSTOMERORDERNUMBER</ns1:CustomerOrderNumber>
				<ns1:QueueType>UNDEFINED</ns1:QueueType>
				<ns1:TaskId>CAMUNDATASKID</ns1:TaskId>
				<ns1:TaskStatus>COMPLETED</ns1:TaskStatus>
				<ns1:CsrId>LS659F</ns1:CsrId>
				<ns1:CreatedBy>SYSTEM</ns1:CreatedBy>
				<ns1:LastModifiedBy>SYSTEM</ns1:LastModifiedBy>
				<ns1:LastModifiedDateTime>2017-05-09T13:55:15.934Z</ns1:LastModifiedDateTime>
				<ns1:CreationDateTime>2017-05-09T13:54:16.118Z</ns1:CreationDateTime>
				<ns1:ApplicationName>NotifyCamundaTaskUpdateService</ns1:ApplicationName>
			</ns1:OrderTask>
		</NotifyTaskUpdateRequest>
	</soapenv:Body>
</soapenv:Envelope>
END

sub checktasks(){
	my $notasks=1;
	opendir(my $dh, 'orderreceived') || die "Can't open orderreceived: $!";
	while (readdir $dh) {
		next if ($_ eq '.' || $_ eq '..' || substr($_,-4) eq '.ans');
		local $/;
		open ORDJSON,"orderreceived${OS_PATH_SEP}$_"; my $ordJson=<ORDJSON>;close ORDJSON;
		open ORDANSJSON,"orderreceived${OS_PATH_SEP}${_}.ans"; my $ordAnsJson=<ORDANSJSON>;close ORDANSJSON;
		#print $ordJson;
		if ($ordJson =~ /CamundaTaskId/){
			$ordJson =~ s/\s+//g;
			my ($camtask ,$custno,$ordno);
			if ($ordJson =~ /"CustomerOrderNumber"\:"([^"]+)"/){
				$custno = $1;
			}
			if ($ordJson =~ /"CamundaTaskId"\:"([^"]+)"/){
				$camtask = $1;
			}
			if (! -e "tasks${OS_PATH_SEP}$camtask" && ! -e "tasks${OS_PATH_SEP}.camel${OS_PATH_SEP}$camtask" ){
				
				if (defined($custno) && defined($camtask)){
					my $notif = $taskNotifiation;
					if ($ordAnsJson =~ /"OrderNumber"\:\s+"([A-Z]\d+)"/){
						$ordno=$1;
					}
					print "$camtask ,$custno, $ordno                                                            \r";
					$notif =~ s/CUSTOMERORDERNUMBER/$custno/g;
					$notif =~ s/ORDERNUMBER/$ordno/g;
					$notif =~ s/CAMUNDATASKID/$camtask/g;
					$notasks=!1;
					open my $FH, ">tasks${OS_PATH_SEP}$camtask" or die("Can't open file: tasks${OS_PATH_SEP}$camtask: $!\n");
					print $FH $notif;
					close $FH; 
				}
			}
		}
	}
	return $notasks;
}

my $LOGCONTENT=undef;
my $i=int(3600/30);
my $prevlength=0;
while($i>0){
	$i--;
	my $notasks=checktasks();
	print "Waiting for test to complete timeout in ".($i*30)." secs   [$prevlength]                 \r";STDOUT->flush();
	
	my $size = -s $ARGV[0];
	if ($prevlength == $size && $notasks){
		local $/;
		open LOG,"$ARGV[0]"; my $log=<LOG>;close LOG;
		if (index($log,'start process')>-1){
			$LOGCONTENT=$log;
			last;
		}
	}
	$prevlength=$size;
	sleep(30);
	STDOUT->flush();
}

print "Completed\n";

my $orders_summary = <<'END';
<!DOCTYPE html><html><head>
<link rel="stylesheet" type="text/css" href="DataTables-1.10.15/css/jquery.dataTables.css"/>
<link rel="stylesheet" type="text/css" href="Scroller-1.4.2/css/scroller.dataTables.css"/>
<style>
.good {
	background-color: #c6efce;
}
.bad {
	background-color: #ffc7cd;
}
</style>
 
<script type="text/javascript" src="jQuery-2.2.4/jquery-2.2.4.js"></script>
<script type="text/javascript" src="DataTables-1.10.15/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="Scroller-1.4.2/js/dataTables.scroller.js"></script>
<script language="javascript">
$(document).ready(function() {
    var table = $('#example').DataTable( {
        "scrollY": "600px",
        "paging": false
    } );
 
    var table = $('#example2').DataTable( {
        "scrollY": "300px",
        "paging": false
    } );

} );
</script>
</head><body>
<table id="summary" class="display" cellspacing="0" width="50%">
	__ORDERSUMMARY__
</table>		
<table id="example" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Customer Order Number</th>
                <th>LOSG Types</th>
                <th>Number of Lines</th>
                <th>Contract Type</th>
                <th>Contract Extended</th>
                <th>Result</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>Customer Order Number</th>
                <th>LOSG Types</th>
                <th>Number of Lines</th>
                <th>Contract Type</th>
                <th>Contract Extended</th>
                <th>Result</th>
            </tr>
        </tfoot>
		<tbody>
		__ORDERS__
		</tbody>
</table>
<table id="example2" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Field</th>
                <th>Orders</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>Field</th>
                <th>Orders</th>
            </tr>
        </tfoot>
		<tbody>
		__FIELDISSUES__
		</tbody>
</table>
</body></html>
END

my $order_api_summary = <<'END';
<!DOCTYPE html><html><head>
<link rel="stylesheet" type="text/css" href="DataTables-1.10.15/css/jquery.dataTables.css"/>
<link rel="stylesheet" type="text/css" href="Scroller-1.4.2/css/scroller.dataTables.css"/>
 <style>
#scrollable-content {
  height: 180px;
  overflow: auto;
  color: yellow;
  background-color: blue;
}

 
</style>
<script type="text/javascript" src="jQuery-2.2.4/jquery-2.2.4.js"></script>
<script type="text/javascript" src="DataTables-1.10.15/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="Scroller-1.4.2/js/dataTables.scroller.js"></script>
<script language="javascript">
$(document).ready(function() {
    var table = $('#example').DataTable( {
        "scrollY": "600px",
        "paging": false
    } );
 
    $('a.toggle-vis').on( 'click', function (e) {
        e.preventDefault();
 
        // Get the column API object
        var column = table.column( $(this).attr('data-column') );
 
        // Toggle the visibility
        column.visible( ! column.visible() );
    } );
} );
</script>
</head><body>
<table id="example" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>API</th>
				<th>Sequence</th>
                <th>Result</th>
                <th>Result File</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>API</th>
				<th>Sequence</th>
                <th>Result</th>
                <th>Result File</th>
            </tr>
        </tfoot>
		<tbody>
		__ORDERAPIRESULTS__
		</tbody>
</table>
<h2>Mocker Logs</h2>
<div id="scrollable-content">
<pre>
__ORDERMOCKERLOGS__
</pre>
</div>
<h2>Camunda Logs</h2>
<div id="scrollable-content">
<pre>
__ORDERCAMUNDALOGS__
</pre>
</div>
</body></html>
END

my $api_result_summary = <<'END';
<!DOCTYPE html><html><head>
<link rel="stylesheet" type="text/css" href="DataTables-1.10.15/css/jquery.dataTables.css"/>
<link rel="stylesheet" type="text/css" href="Scroller-1.4.2/css/scroller.dataTables.css"/>
 
<script type="text/javascript" src="jQuery-2.2.4/jquery-2.2.4.js"></script>
<script type="text/javascript" src="DataTables-1.10.15/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="Scroller-1.4.2/js/dataTables.scroller.js"></script>
<script language="javascript">
$(document).ready(function() {
    var table = $('#example').DataTable( {
        "scrollY": "600px",
        "paging": false
    } );
 
    $('a.toggle-vis').on( 'click', function (e) {
        e.preventDefault();
 
        // Get the column API object
        var column = table.column( $(this).attr('data-column') );
 
        // Toggle the visibility
        column.visible( ! column.visible() );
    } );
} );
</script>
</head><body>
<div>
Toggle column: <a class="toggle-vis" data-column="0">Customer Order Number</a> - <a class="toggle-vis" data-column="1">LOSG Types</a> - 
<a class="toggle-vis" data-column="2">Number of Lines</a> - <a class="toggle-vis" data-column="3">Contract Type</a> - 
<a class="toggle-vis" data-column="4">Contract Extended</a> - <a class="toggle-vis" data-column="5">Something</a>
</div>
<table id="example" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Field Name</th>
                <th>Expected</th>
                <th>Actual</th>
                <th>Result</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>Field Name</th>
                <th>Expected</th>
                <th>Actual</th>
                <th>Result</th>
            </tr>
        </tfoot>
		<tbody>
		__APIRESULTS__
		</tbody>
</table>
</body></html>
END


my %ordermap=();
my %fieldissues=();
my @orders=();

open ORDERLST,"orders.lst"; 
my @orders_list = <ORDERLST>;
close ORDERLST;

opendir(my $dh, 'refdata') || die "Can't open refdata: $!";
while (readdir $dh) {
	if ($_ =~ /.*\-REQUEST\.xml$/){
		$orderdata .= '<tr>';
		local $/;
		open ORDXML,"refdata${OS_PATH_SEP}$_"; my $ordXml=<ORDXML>;close ORDXML;
		my $co=undef;
		$co=$1 if ($ordXml =~ /<CustomerOrderNumber>(.+?)<\/CustomerOrderNumber>/);
		my @matches = grep { /$co/ } @orders_list;
		if ($#matches == 0){
			push(@orders,$co);
			while($ordXml =~ /<LoSGType>(.+?)<\/LoSGType>/g){
				$ordermap{$co.'.losg'} = $1.' ';
			}
			while($ordXml =~ /<ContractType>(.+?)<\/ContractType>/g){
				$ordermap{$co.'.ct'} = $1.' ';
			}
			while($ordXml =~ /<ContractExtended>(.+?)<\/ContractExtended>/g){
				$ordermap{$co.'.ce'} = $1.' ';
			}
		}
	}
}
closedir $dh;

opendir(my $dh, 'results') || die "Can't open results: $!";
my @files = sort {(stat "results${OS_PATH_SEP}$a")[9] <=> (stat "results${OS_PATH_SEP}$b")[9]} readdir($dh);
closedir $dh;
for (@files) {
	my $co = substr($_,0,18);
	if ($_ =~ /executeFraudChecks/){next;} else {$ordermap{$co.'.files'} .= $_.',';}
}


my @camundalogs = split(/\n/,$LOGCONTENT);
open MOCKER,"mocker.log" || die "Can't open mocker.log : $!";
my @mockerlogs = <MOCKER>;
close MOCKER;
for my $co (@orders){
	my @ofiles = split(/\,/,$ordermap{$co.'.files'});
	my $finres='';
	my $orderresults='';
	for my $resfile (@ofiles){
		if (index($resfile,'.result')>-1){
			#print "checking file $resfile\n";
			my $apires='';
			open RESFILE,"results${OS_PATH_SEP}$resfile" || die "Can't open results${OS_PATH_SEP}$resfile : $!";
			my $indiff=!1;
			my $apires='';
			my $result=1;
			while(<RESFILE>){
				if (index(trim($_),'FINAL RESULT:')==0){
					#print "result $_";
					$finres .= trim($_);
					if (index($_,'false')>-1){$result=!1;}#print "false\n";}
					
				}elsif ($indiff){
					my @data = split(/\t/,trim($_));
					if ($#data == 1){
						$data[2]='NA';$data[3]=$data[1];$data[1]='NA';
					}
					if (trim($data[3]) eq 'false'){
						my $fld = trim($data[0]);
						$fld =~ s/\[\d+\]/\[\]/g;
						$fieldissues{$fld} .= $co.',';
					}
					$apires .= '<tr><td>';
					$apires .= $data[0];$apires .= '</td><td>';
					$apires .= $data[1];$apires .= '</td><td>';
					$apires .= $data[2];$apires .= '</td><td>';
					$apires .= $data[3];$apires .= '</td></tr>';
				}
				$indiff=1 if (trim($_) eq '--- Diff');
			}
			close RESFILE;
			my $html = $api_result_summary;
			$html =~ s/__APIRESULTS__/$apires/;
			open RESHTML,">report${OS_PATH_SEP}$resfile.html";
			print RESHTML $html;
			close RESHTML;
			my @data = split(/\-/,$resfile);
			$orderresults .= '<tr><td>';
			$orderresults .= $data[3];$orderresults .= '</td><td>';
			$orderresults .= $data[2];$orderresults .= '</td><td>';
			#print $result?'PASS':'FAIL',"\n";
			$orderresults .= ($result?'PASS':'FAIL');$orderresults .= '</td><td><a href="'.$resfile.'.html">';
			$orderresults .= "$resfile.html";$orderresults .= '</a></td></tr>';
		}
	}
	
	my $html = $order_api_summary;
	$html =~ s/__ORDERAPIRESULTS__/$orderresults/;
	my $logs = '';
	for (grep(/${co}/i, @mockerlogs)){
		$logs .= trim($_);
		$logs .= "\r\n";
	}
	$finres .= 'NOT ALL API CALLED - false' if (index($logs,'RESPONSE NOT FOUND')>-1 || index($logs,'FAIL REQUEST NOT FOUND')>-1);
	$html =~ s/__ORDERMOCKERLOGS__/$logs/;
	$logs = '';
	if ($LOGCONTENT =~ /start process \-\-\- (.*) \-\-\- ${co}/){
		my $prid = $1;
		my $prev='';
		for (grep(/${prid}/i, @camundalogs)){
			my $curr=trim($_);
			if ($curr ne $prev){$logs .= substr($curr,index($curr,'com.att.oce.bpm.common.OceCamundaHistoryEventHandler - ')+55);$logs .= "\r\n";}
			$prev=trim($_);
		}
		$finres .= 'OPEN TASK FOUND - false' if (index($prev,'update task')>-1);
		$finres .= 'PROCESS NOT CLOSED - false' if (index($prev,'end process') == -1);
	}
	$html =~ s/__ORDERCAMUNDALOGS__/$logs/;
	open ORDSUMHTML,">report${OS_PATH_SEP}${co}.summary.html";
	print ORDSUMHTML $html;
	close ORDSUMHTML;
	
	if (index($finres,'false')>-1 || index($finres,'FINAL RESULT')==-1 ){$ordermap{$co.'.result'}='FAIL';}else{$ordermap{$co.'.result'}='PASS';}
	$ordermap{$co.'.resultdesc'} = '';
	if ($finres =~ /FINAL RESULT\: false/){
		$finres =~ s/(FINAL RESULT\: false)//g;
		$finres .= 'API COMAPRISON FAILURE';
	}
	if ($finres =~ /FINAL RESULT\: true/){
		$finres =~ s/(FINAL RESULT\: true)//g;
	}
	$ordermap{$co.'.resultdesc'} = $finres;
	
	#print $co,' === ',$finres,"\n";
	
}



my $orderdata='';
my %ordersummary=();
for my $co (@orders){
	$orderdata .= '<tr>';$orderdata .= '<td><a href="'.$co.'.summary.html">';
	$orderdata .= $co;$orderdata .= '</a></td><td>';
	$ordersummary{$ordermap{$co.'.result'}} += 1;
	$orderdata .= $ordermap{$co.'.losg'};$orderdata .= '</td><td>';
	$orderdata .= scalar(split(/ /,$ordermap{$co.'.losg'}));$orderdata .= '</td><td>';
	$orderdata .= $ordermap{$co.'.ct'};$orderdata .= '</td><td>';
	$orderdata .= $ordermap{$co.'.ce'};$orderdata .= '</td><td>';
	$orderdata .= $ordermap{$co.'.result'}.' - '.$ordermap{$co.'.resultdesc'};$orderdata .= '</td></tr>';
}

my $fieldiss='';
for (keys(%fieldissues)){
	$fieldiss .= '<tr><td>';
	$fieldiss .= $_;$fieldiss .= '</td><td>';
	my $ordlll='';
	my @ordsss = split(/\,/,$fieldissues{$_});
	
	for my $ordss (uniq(@ordsss)){
		if (trim($ordss) ne ''){
			$ordlll .= '<a href="'.$ordss.'.summary.html">'.$ordss.'</a><br>';
			last;
		}
	}
	$fieldiss .= $ordlll;$fieldiss .= '</td></tr>';
}
$orders_summary =~ s/__FIELDISSUES__/$fieldiss/;
$fieldiss = '<tr class="good"><td>PASS</td><td>'.$ordersummary{'PASS'}.'</td></tr>';
$fieldiss .= '<tr class="bad"><td>FAIL</td><td>'.$ordersummary{'FAIL'}.'</td></tr>';
$fieldiss .= '<tr><td>TOTAL</td><td>'.($ordersummary{'FAIL'}+$ordersummary{'PASS'}).'</td></tr>';

$orders_summary =~ s/__ORDERSUMMARY__/$fieldiss/;
$orders_summary =~ s/__ORDERS__/$orderdata/;


open OUT,">report${OS_PATH_SEP}orders.html";
print OUT $orders_summary;
close OUT;
