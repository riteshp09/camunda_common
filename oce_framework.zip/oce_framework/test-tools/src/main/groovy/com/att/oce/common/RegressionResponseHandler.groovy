package com.att.oce.common;

import groovy.json.JsonSlurper
import groovy.util.slurpersupport.GPathResult

import java.util.Map
import java.util.concurrent.ConcurrentHashMap
import javax.annotation.PostConstruct
import javax.swing.text.html.HTMLEditorKit.HTMLFactory.BodyBlockView

import org.apache.camel.Exchange
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.stereotype.Component
import org.apache.commons.io.FilenameUtils
import org.json.JSONObject
import org.xmlunit.builder.DiffBuilder;
import org.xmlunit.builder.Input;
import org.xmlunit.diff.Diff;
import org.json.XML
import com.fasterxml.jackson.databind.ObjectMapper

@Component
@ConditionalOnProperty(name = "regressiondata")
class RegressionResponseHandler {

	@Value(value = '${regressiondata}') String regressionData;
	ObjectMapper objectMapper

	def exclusions;
	Map<String,String> assignments;

	static Map<String,Integer> orderseq;

	def paralellops = ['||OrderEquipment||InquireSubscriberBillingAgreement||AddPaymentProfile||']

	public def flattenXml (String xml){
		def envelope = new XmlSlurper().parseText(xml)
		def xmlMap = [:]
		envelope.depthFirst().each() {
			if (it.children().size() == 0){
				def path = ''
				def n = it
				while (n.name() != 'Body' && n.name() != envelope.name()){
					int count=0;
					int index=-1;
					if (n.parent() != null){
						n.parent().children().each {
							if (it.name() == n.name()){
								count++;
							}
							if (it == n){
								index=count;
							}
						}
					}
					if (count>1){
						path = n.name()+'['+index+'].'+path
					} else {
						path = n.name()+'.'+path
					}

					n=n.parent()
				}
				if (envelope.name() != 'Envelope')
					xmlMap[envelope.name()+'.'+path+it.name()] = it.text().trim()
				else
					xmlMap[path+it.name()] = it.text().trim()
			}
		}
		return xmlMap
	}

	String numberRegex = "\\d+(\\.\\d+)?";

	boolean compare(def path,def a,def b){
		if (a != null && b != null && a.matches(numberRegex) && b.matches(numberRegex)){
			return (Double.valueOf(a) == Double.valueOf(b));
		}
		return (a == b)
	}

	public boolean generateDiff(String expected,String actual,String fname) throws Exception{
		boolean same = true
		def expectedMap = flattenXml(expected)
		def actualMap = flattenXml(actual)
		File resF = new File('results',FilenameUtils.getBaseName(fname)+'.result');
		resF << "--- Expected\n"
		resF << " ${expected}\n"
		resF << "--- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n";
		expectedMap.each { k,v ->
			resF << "${k} = ${v}\n"
		}
		resF << "--- Actual\n"
		resF << " ${actual}\n"
		resF << "--- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n";
		actualMap.each { k,v ->
			resF << "${k} = ${v}\n"
		}
		resF << "--- Diff\n"

		expectedMap.each() {

			boolean excluded=false
			String excludedString=null
			exclusions.each{ exreg ->
				if (it.key.matches(exreg)){
					//println 'matched '+ it.key + ' with '+exreg
					excluded=true
					excludedString=exreg
				}
				//				 else {
				//					println 'not matched '+ it.key + ' with '+exreg
				//					;
				//				}
			}

			if (excluded && actualMap.containsKey(it.key)){
				if (assignments.containsKey(excludedString)){
					resF << it.key+"\t[Static]|"+assignments[excludedString]+"|\t|"+actualMap[it.key]+"|\t"+compare(it.key,assignments[excludedString] , actualMap[it.key])+"\n"
					same &=  compare(it.key,actualMap[it.key] , assignments[excludedString])
				} else {
					resF << it.key+"\tExcluded - present in actual\n"
				}
			} else if (excluded && assignments.containsKey(excludedString) && assignments[excludedString] == 'TOOLIGNORE'){
				resF << it.key+"\tExcluded - Note present in actual\n"
			} else {
				resF << it.key+"\t|"+it.value+"|\t|"+actualMap[it.key]+"|\t"+compare(it.key,it.value , actualMap[it.key])+"\n"
				same &=  compare(it.key,it.value , actualMap[it.key])
			}
		}
		actualMap.each() {
			boolean excluded=false
			String excludedString=null
			exclusions.each{ exreg ->
				if (it.key.matches(exreg)){
					//println 'matched '+ it.key + ' with '+exreg
					excluded=true
					excludedString=exreg
				} else {
					//println 'not matched '+ it.key + ' with '+exreg
				}
			}
			if (!expectedMap.containsKey(it.key)){
				if (excluded){
					resF << it.key+"\tExcluded - Not present in expected\n"
				} else {
					resF <<  it.key+"\t|"+expectedMap[it.key]+"|\t|"+it.value+"|\t"+compare(it.key,it.value , expectedMap[it.key])+"\n"
					same &=  compare(it.key,it.value , expectedMap[it.key])
				}
			}
		}
		resF << "FINAL RESULT: "+same+"\n";
		return same
	}
	
	void initiateCallBack(co,returnURL,messageId){
		int callbackseq = 1;
		if (orderseq.containsKey(co+".callback")){
			callbackseq = orderseq.get(co+".callback");
		}
		
		String filename = co+"-CALLBACK-"+callbackseq+".xml"
		String callbackRequest = new File(regressionData+filename).text

		String newPayload = callbackRequest.substring(0, callbackRequest.indexOf("messageId>")+10)+messageId+
							callbackRequest.substring(callbackRequest.indexOf("</cng:messageId>"),callbackRequest.indexOf("<cng:responseTo>")+16)+messageId+
							callbackRequest.substring(callbackRequest.indexOf("</cng:responseTo>"),callbackRequest.indexOf("<cng:returnURL>")+15)+returnURL+
							callbackRequest.substring(callbackRequest.indexOf("</cng:returnURL>"),callbackRequest.indexOf("</SOAP-ENV:Envelope>")+20);
		/*def envelope = new XmlSlurper().parseText(callbackRequest)
		envelope.Header.MessageHeader.TrackingMessageHeader.messageId = messageId
		envelope.Header.MessageHeader.TrackingMessageHeader.responseTo = messageId
		envelope.Header.MessageHeader.TrackingMessageHeader.returnURL = returnURL*/
		
		File callbackReqFile = new File('callback/'+filename)
		callbackReqFile.text=newPayload
		
		orderseq.put(co+".callback",++callbackseq);
	}
	
	File loadFile(filename,request){
		
		File f = new File(regressionData+filename)
		
		if(f.exists()){
			return f;
		}
		else{
			def envelope = new XmlSlurper().parseText(request)
			def requestNode = envelope.depthFirst().find{it -> it.parent().name() == 'Body'}
			String requestName= requestNode.name();
			
			String[] arrFileName = filename.split("-")
			arrFileName[3] = requestName
			filename = arrFileName.join("-")
			f = new File(regressionData+filename)
			if(f.exists()){
				return f;
			}
			else{
				return null;
			}
		}
	}
	
	def getCallbackResponse(Exchange exchange){
		String callbackRequest = exchange.in.body;
		println 'CALLBACK ==>>>>>>>>>>>>>>> '+callbackRequest
		def envelope = new XmlSlurper().parseText(callbackRequest)
		String returnURL = envelope.Header.MessageHeader.TrackingMessageHeader.returnURL.text()
		println 'RETURN URL ==>>>> '+returnURL
		returnURL = returnURL.replaceAll("https","http")
		exchange.in.headers.put("CamelHttpUri",returnURL);
		exchange.out.body = callbackRequest
		return callbackRequest;
	}
	
	void getResponse(Exchange exchange){
		try {
			boolean atg=false;
			def apiname = ''
			def co = ''
			def atgOrder=''
			def response='Not found'
			String request = exchange.in.body;
			String header='';
			def uri = exchange.in.headers.CamelHttpUri

			def contentType = exchange.in.getHeader("Content-Type");
			String requestMethod = exchange.in.getHeader(Exchange.HTTP_METHOD);
			def reqmap = [:];
			def resmap = [:];
			if (contentType){
				if(contentType?.contains("json")){
					reqmap = new JsonSlurper().parseText(request);
				}else{
					reqmap = new XmlSlurper().parseText(request);
					header = request.substring(request.indexOf("<soapenv:Header"), request.indexOf("</soapenv:Header>")+17);
				}
			}
			if(uri.contains('/BRMSServices/brmsService')){
				apiname = 'executeFraudChecks';
				co = reqmap.Body.executeFraudChecks.FraudDetectionRequest.Order.CustomerOrderNumber.text();
			} else if(uri.contains('/oce/api/orders')){
				if (requestMethod == 'POST' || requestMethod == 'PUT'){
					co = reqmap.Order.CustomerOrderNumber;
					String requestId = reqmap.Order.RequestId;
				} else {
					atgOrder = uri.replace('/oce/api/orders/','').trim()
					if (orderseq.containsKey(atgOrder+'.atg2co')){
						co=orderseq[atgOrder+'.atg2co']
					} else {
						exchange.out.body = 'No Order Found'
						exchange.out.headers.CamelHttpResponseCode = 404;
						return;
					}
				}
				apiname = uri.replace("/",".")+'.'+requestMethod;
				atg=true;
			} else {
				apiname = FilenameUtils.getBaseName(uri);
				String messageId = reqmap.Header.MessageHeader.TrackingMessageHeader.messageId.text();
				co = messageId?.split("~")[1];
			}
			println '> '+co+' : '+uri

			def seq = 1
			def apiseq = 1
			if (atg){
				if (orderseq.containsKey(co+'.'+apiname+'.seq'))
					seq = orderseq[co+'.'+apiname+'.seq']
	
			} else {
				if (orderseq.containsKey(co+'.seq'))
					seq = orderseq[co+'.seq']
				if (orderseq.containsKey(co+'.'+apiname))
					apiseq = orderseq[co+'.'+apiname]
			}
			
			int paralellIndex = paralellops.findIndexOf {it.contains('||'+apiname+'||')}
			//println "paralellIndex ${paralellIndex}"
			String filename = co+"-"+seq+"."+apiseq+"-"+apiname+"-REQ.xml"
			if (paralellIndex == -1){
				if (orderseq[co+".lastpp"] && orderseq[co+".lastpp"] > -1){
					seq++
				}
				if(atg){
					filename = co+"-ATG-"+seq+'-'+apiname+"-RES.xml"
				}else {
					filename = co+"-"+seq+'.'+apiseq+'-'+apiname+"-REQ.xml"
				}
				
			} else {
				seq++
				filename = co+"-"+seq+"PP"+paralellIndex+"-"+apiname+"-REQ.xml"
			}

			File f = loadFile(filename,request)
			if (f != null){
				if (!atg){
					int i=1;
					
					while(orderseq.containsKey(co+"."+apiname+i)){i++;}
					
					/* Changes for AS issue - starts */
					if(request.contains('returnURL')){
						
						String returnURL = reqmap.Header.MessageHeader.TrackingMessageHeader.returnURL.text();
						String messageId = reqmap.Header.MessageHeader.TrackingMessageHeader.messageId.text();
						initiateCallBack(co,returnURL,messageId)
						
					}
					/* Changes for AS issue - ends */
					
					filename = co+'-'+i+"-"+apiname+'-RES.xml'
					
					boolean same = generateDiff(f.text,request,f.getCanonicalPath())
					File fr = loadFile(filename,request)
					if (fr!=null){
						println '< '+co+' '+f.name+' ==> '+(same?"PASS":"FAIL")+' RESPONSE FOUND'+' '+fr.canonicalPath
						response = fr.text
						orderseq[co+"."+apiname+i]=1
					} else{
						println '< '+co+' : '+ f.name+' ==> '+(same?"PASS":"FAIL")+' RESPONSE NOT FOUND'
						response = 'No Response Found'
						exchange.out.headers.CamelHttpResponseCode = 500;
					}
					
				}else {
					try {
						File fjson = new  File(f.canonicalPath+'.ready.json');
						if (fjson.exists()){
							response = fjson.text
						} else {
							response = f.text
						}
						
						if (response.trim().startsWith('<')){
							response = ATGHelper.removeXmlStringNamespaceAndPreamble(response)
							def resjsonmap = new XmlSlurper().parseText(response)
							JSONObject resjsonobj = XML.toJSONObject(response)
							if (resjsonobj.has("Response")){
								response = resjsonobj.getJSONObject("Response").toString(4)
								Object atgResponse = objectMapper.readValue(response, Object.class);
								Object atgOrderId = org.apache.commons.beanutils.PropertyUtils.getProperty(atgResponse, "OrderNumber")
								Object atgCustOrder = org.apache.commons.beanutils.PropertyUtils.getProperty(atgResponse, "CustomerOrderNumber")
								if (atgOrderId && atgCustOrder){
									orderseq.put(atgOrderId+'.atg2co',atgCustOrder)
									orderseq.put(atgCustOrder+'.co2atg',atgOrderId)
								}
							} else if(resjsonobj.has("Envelope")) {
								response = resjsonobj.toString(4)
							} else {
								response = resjsonobj.toString(4)
							}
						} else {
							Map<String,Object> fmap = objectMapper.readValue(response, LinkedHashMap.class);
							String nfJson  = ATGHelper.convertFToNF(fmap);
							nfJson = nfJson.replace('&amp;','&')
							if (atg && requestMethod == 'GET'){
								nfJson = '{ "OrderDetails": '+nfJson+'}'
							}
							JSONObject resjsonobj = new JSONObject(nfJson);
							response = resjsonobj.toString(4)
						}
						println '< '+co+' : '+ f.name+' ==> ATG RESPONSE FOUND'
						exchange.out.headers.CamelHttpResponseCode = 200;
					} catch(Exception e){
						e.printStackTrace()
					}
				}
			} else {
				//println f.name+' ==> FAIL REQUEST NOT FOUND';
				println '< '+co+' : '+filename+' ==> FAIL REQUEST NOT FOUND';
				response = 'No REQUEST Found. Check data files or extract again'
				exchange.out.headers.CamelHttpResponseCode = 500;
			}

			if (response.startsWith('<?xml version="1.0" encoding="UTF-8"?>')){
				response=response.substring(38)
			}
			
			if (response.contains('CSIApplicationException')){
				response = """<soapenv:Envelope xmlns:cin=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"""+"\n"+header+"""
							  |<soapenv:Body>
							  | 	<SOAP-ENV:Fault xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">
							  |		<faultcode>soap-env:Client</faultcode>
							  |		<faultstring>Account is Temporarily Unavailable. Please Retry.</faultstring>
							  |		   <detail>
							  |	          ${response}
                              |			</detail>
                              |			<faultactor>soap-env:Client</faultactor>
                              |		</SOAP-ENV:Fault>
							  |</soapenv:Body>
							  |</soapenv:Envelope>""".stripMargin('|')
				exchange.out.headers['Content-Type'] = 'text/xml';
				exchange.out.body = response;
				exchange.out.headers.CamelHttpResponseCode = 500
			} else if (atg){
				exchange.out.body = response;
				exchange.out.headers['Content-Type'] = 'application/json';
				exchange.out.headers.CamelHttpResponseCode = 200
			} else {
				response = """<soapenv:Envelope xmlns:cin=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"""+"\n"+header+"""
								  |<soapenv:Body>
								  |	${response}
								  |</soapenv:Body>
								  |</soapenv:Envelope>""".stripMargin('|')
				exchange.out.headers['Content-Type'] = 'text/xml';
				exchange.out.body = response;
				exchange.out.headers.CamelHttpResponseCode = 200
			}

			if (paralellIndex == -1){
				if (atg){
					orderseq.put(co+'.'+apiname+'.seq',seq+1);
				} else {
					orderseq.put(co+'.'+apiname,apiseq+1);
					orderseq.put(co+'.seq',seq+1);
				}
			}
			orderseq.put(co+'.lastpp',paralellIndex);

			StringBuilder logdd = new StringBuilder()
			logdd << '< '+co+' : '+exchange.out.headers.CamelHttpResponseCode+' Length '+exchange.out.body.toString().length()+"\n"
			logdd <<  '------------------------------------------------------------------------------------------------------\n'
			logdd <<  exchange.out.body.toString()+"\n"
			logdd <<  '------------------------------------------------------------------------------------------------------\n'
			if(atg){
				if (requestMethod == 'POST' || requestMethod == 'PUT'){
					JSONObject jsonObject = new JSONObject(exchange.in.body)
					new File('orderreceived/'+co+'.json').text=jsonObject.toString(4)
					File ans = new File('orderreceived/'+co+'.json.ans');
					if (!ans.exists()){
						jsonObject = new JSONObject(exchange.out.body)
						ans.text=jsonObject.toString(4)
					}
				}
			}

		} catch(IOException io){
			exchange.out.headers.CamelHttpResponseCode = 500;
			exchange.out.body = "No Matching Response Found. Please configure valid response";
			io.printStackTrace();
		}catch(Exception e){
			exchange.out.body = e.getMessage();
			exchange.out.headers.CamelHttpResponseCode=500;
			e.printStackTrace()
		}

	}

	def escapeWildCard(s){
		String[] parts = s.trim().split("\\*");
		String regex = '';
		parts.each  {
			regex += "\\Q"
			regex += it
			regex += "\\E"
			regex += ".*";
		}
		return regex.substring(0,regex.length())
	}

	@PostConstruct void init(){

		if (orderseq == null){
			orderseq = new ConcurrentHashMap<String, Integer>();
			println "init RegressionResponseHandler"
		}

		exclusions = [];
		assignments = [:];
		File f = new File('exclusions.regex');
		if (f.exists()){
			new File('exclusions.regex').eachLine {
				if (it.contains("=")){
					String[] data = it.split("=");
					exclusions.push(escapeWildCard(data[0]))
					assignments[escapeWildCard(data[0])]=data[1].trim()
				} else {
					exclusions.push(escapeWildCard(it));
				}
			}
	
			println "Exclusions"
			exclusions.each{ println it }
			println "Assignments"
			assignments.each{ k,v -> println "${k} => ${v}"}
			objectMapper=new ObjectMapper();
	
		}

	}
}
