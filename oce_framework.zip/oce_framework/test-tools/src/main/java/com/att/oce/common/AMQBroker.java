package com.att.oce.common;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.activemq.broker.BrokerPlugin;
import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.broker.util.LoggingBrokerPlugin;
import org.apache.activemq.security.AuthenticationUser;
import org.apache.activemq.security.SimpleAuthenticationPlugin;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

public class AMQBroker {
	
	@Value("${amq.logging:false}")
	boolean amqlogging;
	
	String getUrl(){
		return "tcp://localhost:8500";
	}
	
	@PostConstruct
	public void init(){
		BrokerService broker = new BrokerService();
		broker.setBrokerName("localhost");
		broker.setDataDirectory("amqdata/");
		
		
		SimpleAuthenticationPlugin authentication = new SimpleAuthenticationPlugin();
		
		List<AuthenticationUser> users = new ArrayList<AuthenticationUser>();
		users.add(new AuthenticationUser("admin", "admin", "admins,publishers,consumers"));
		authentication.setUsers(users);
		
		
		if (amqlogging){
			LoggingBrokerPlugin logging = new LoggingBrokerPlugin();
			logging.setLogAll(true);
			broker.setPlugins(new BrokerPlugin[]{authentication,logging});
		} else {
			broker.setPlugins(new BrokerPlugin[]{authentication});
		}
		
		try {
			System.out.println("Broker started");
			broker.addConnector(getUrl());
			broker.start();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
