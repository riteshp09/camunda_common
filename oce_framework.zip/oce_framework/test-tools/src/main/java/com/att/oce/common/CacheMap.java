package com.att.oce.common;

import java.util.HashMap;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("singleton")
public class CacheMap extends HashMap<String,Object>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3623916630931060597L;

}
