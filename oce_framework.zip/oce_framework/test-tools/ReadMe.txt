Test Tools 
===================

Extract
==============

'extract' mode is used to extract orders and the api request/response from the Audit Log tables for the orders provided in the orders list.
This will scrub the xmls of any SPI/PCI data and also converts xml orders to federated order json.

Preparation:
Choose the orders numbers and enter it in a file.
Create a folder called refdata and mount this as in the syntax
Production Audit log DB creds for both ATG and AVOS has to be given, even if the same database is used, we need to provide both.

Syntax:
docker run --env AUTOMATION_COMMAND=extract --volume <<refdata folder absolute path >>:/refdata --volume <<orders files absolute path>>:/orders.lst --env PROD_AVOS_AUDIT='<<DB creds in the format listed below for AVOS audit log>>' --env PROD_ATG_AUDIT='DB creds in the format listed below for ATG audit log' aftswm-img-bodc1.it.att.com:5000/oce-tools/camunda-test-automation
If running on dev boxes, please prefix the syntax with sudo 

DB Format:
--dburl=jdbc:oracle:thin:@SERVER:PORT:SID --dbuser=USERNAME --dbpass=PASSWORD


Prepare
==============

'prepare' mode is used to build the projects that needs to be run as provided in the env variable PROJECT_CNTR_NAME. Note that this will build only the POM in the folder defined in env variable PROJECT_DIR. So ensure that all the required dependencies are provided correctly in that pom. 
This will also change the sys-properties file so that it works with the automation tool. Please follow naming conventions that is defined in the wireless-upgrade project for queue names and brokers, otherwise the tool will fail.

Syntax:
docker run --env AUTOMATION_COMMAND=prepare --volume <<working folder absolute path >>:/work --volume <<mvn_repo absolute path>>:/m2_repository  --env RELEASE_BRANCH=<<Release like 1706 1705>> --env RELEASE_BRANCH_DOT=<<Release like 17.06 17.05>> --env PROJECT_DIR='<<Project dir, relative path from working folder>>' --env PROJECT_CNTR_NAME=<<Container project name>> --env REPO_URL='<<Code cloud path with username and password>>' aftswm-img-bodc1.it.att.com:5000/oce-tools/camunda-test-automation
If running on dev boxes, please prefix the syntax with sudo 


Test
==============

'test' mode is used run the test on the projects defined in PROJECT_CNTR_NAME. Note that prepare should have been run on the project, otherwise the test will fail.
application-test.properties file will be changed to suit the automation tool and a file called application-auto.properties will be created. Note that proper naming conventions should be followed. The final report will be created under the work directory as 'report.7z'. All necessary files for troubleshooting is present in the report file.

Syntax:
docker run --env AUTOMATION_COMMAND=test --volume <<refdata folder absolute path >>:/refdata --volume <<orders files absolute path>>:/orders.lst --volume <<working folder absolute path >>:/work --volume <<mvn_repo absolute path>>:/m2_repository  --env PROJECT_DIR='<<Project dir, relative path from working folder>>' --env PROJECT_CNTR_NAME=<<Container project name>>  aftswm-img-bodc1.it.att.com:5000/oce-tools/camunda-test-automation:latest
If running on dev boxes, please prefix the syntax with sudo 

