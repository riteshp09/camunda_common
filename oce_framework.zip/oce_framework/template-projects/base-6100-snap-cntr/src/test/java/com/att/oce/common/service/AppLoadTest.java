package com.att.oce.common.service;
import org.apache.camel.CamelContext;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.att.ajsc.common.RequestScopeModifier;
import com.att.oce.beans.config.OceConfig;
import com.att.oce.common.Application;
import com.att.oce.config.components.GlobalProperties;

@SuppressWarnings("deprecation")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = { Application.class, RequestScopeModifier.class, OceConfig.class })
@WebAppConfiguration
@IntegrationTest({"server.port=0", "spring.profiles.active=test"})
public class AppLoadTest {
	
	@Autowired
	CamelContext camelContext;

	@Autowired
	GlobalProperties globalConfig;

	@BeforeClass
	public static void setUp() throws Exception {
		System.setProperty("OCE_RESOURCES_HOME", "../../oce-resources/src/main/resources/");
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireless");
		System.out.println("+++++++++++++++++++++++  "+new java.io.File( "." ).getCanonicalPath());
		System.out.println("+++++++++++++++++++++++  "+new java.io.File( System.getProperty("OCE_RESOURCES_HOME") ).getCanonicalPath());
	}

	@Test
	public void testQuickHello() throws Exception {
		System.out.println("+++++++++++++++++++++++  "+globalConfig.CamundaExecutorCorePoolSize);
		for (String s : camelContext.getEndpointMap().keySet()){
			System.out.println(camelContext.getEndpointMap().get(s).toString()); 
		}
	}
}
