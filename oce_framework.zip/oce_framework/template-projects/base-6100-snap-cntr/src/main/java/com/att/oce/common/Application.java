package com.att.oce.common;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.camunda.bpm.spring.boot.starter.webapp.CamundaBpmWebappAutoConfiguration;
import org.camunda.bpm.spring.boot.starter.webapp.CamundaBpmWebappInitializer;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.autoconfigure.security.SecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.ManagementWebSecurityAutoConfiguration;
import org.camunda.bpm.engine.rest.impl.CamundaRestResources;
import org.camunda.bpm.spring.boot.starter.SpringBootProcessApplication;
import org.springframework.context.annotation.ComponentScan;
import org.glassfish.jersey.filter.LoggingFilter;

import com.att.ajsc.common.messaging.DateTimeParamConverterProvider;
import com.att.ajsc.common.messaging.ObjectMapperContextResolverNonNull;
import com.att.ajsc.common.messaging.TransactionIdResponseFilter;
import com.att.ajsc.common.messaging.TransactionIdRequestFilter;

@SpringBootApplication
@ComponentScan(basePackages={"com","com.att.oce.common"})
@EnableAutoConfiguration(exclude = { CamundaBpmWebappAutoConfiguration.class, CamundaBpmWebappInitializer.class,HibernateJpaAutoConfiguration.class,JpaRepositoriesAutoConfiguration.class, SecurityAutoConfiguration.class, ManagementWebSecurityAutoConfiguration.class })
public class Application extends SpringBootProcessApplication {
	
    public static void main(String[] args) throws Exception {
    	
		  /* JERSEY SERVICES REGISTRATION */
		  CamundaRestResources.getConfigurationClasses().add(ObjectMapperContextResolverNonNull.class);
		  CamundaRestResources.getConfigurationClasses().add(TransactionIdRequestFilter.class);
		  CamundaRestResources.getConfigurationClasses().add(TransactionIdResponseFilter.class);
		  CamundaRestResources.getConfigurationClasses().add(DateTimeParamConverterProvider.class);   	  
		  CamundaRestResources.getConfigurationClasses().add(LoggingFilter.class);
		  
		  //Spring boot application run
		  SpringApplication.run(Application.class, args);
    }
}