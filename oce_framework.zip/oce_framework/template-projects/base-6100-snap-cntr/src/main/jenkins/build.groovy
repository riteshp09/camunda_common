def buildProject() {
   stage 'Build Git Project'
   wrap([$class: 'ConfigFileBuildWrapper', managedFiles: [[fileId: '368b3380-dfb5-429c-ade1-98235d2528ec', targetLocation: '', variable: 'MAVEN_SETTINGS']]]) {
		mvn '-s $MAVEN_SETTINGS -f ${artifactId}/pom.xml'
   }
}

def mvn(args) {
    sh "${tool 'maven3'}/bin/mvn ${args} ${MAVEN_GOALS}"
}

return this