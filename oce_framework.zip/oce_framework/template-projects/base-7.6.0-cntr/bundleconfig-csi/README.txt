The bundleconfig-csi directory contains the necessary configuration files to be included with your AJSC bundle when deploying
to a CSI env. This file is NOT used during local development. For local development, all files are read from the bundleconfig-local
folder.

For more information on these files, please goto wiki link: http://wiki.web.att.com/display/ajsc/Configuration+Opportunities+within+the+AJSC