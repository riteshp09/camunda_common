#!/bin/sh

. `dirname $0`/install.env

exit 0