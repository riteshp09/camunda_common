#!/bin/sh
##############################################################################
# - SCLD GRM SERVICE
# - Copyright 2009 AT&T Intellectual Properties
##############################################################################
. `dirname $0`/install.env

mkdir -p ${ROOT_DIR}/conf || fail 100 "Error on creating the conf directory."
mkdir -p ${ROOT_DIR}/docs || fail 100 "Error on creating the docs directory."
mkdir -p ${ROOT_DIR}/lib  || fail 100 "Error on creating the lib directory."
mkdir -p ${ROOT_DIR}/log || fail 100 "Error on creating the logs directory."

#Grab latest version of runtime for when Snapshots are used.
runtimeJarPath=`ls /opt/app/ajsc-camunda-runtime/*/lib/ajsc-camunda-runner-${ajscRuntimeVersion}.jar | tail -n 1`

if [ ! -f ${runtimeJarPath} ]; then
    echo "ERROR: ajsc-camunda-runtime not configured properly!"
    echo "ajsc-camunda-runner-${ajscRuntimeVersion}.jar not found on node."
    echo "Camunda runner could have been forcely deleted by some other unknown source"
    echo "Try and reinstall dependency SWM package com.att.ajsc:ajsc-camunda-runtime:${ajscRuntimeVersion}"
    fail "ERROR: ajsc-camunda-runtime not configured properly!"
else
	rm ${ROOT_DIR}/ajsc-camunda-runner-*.jar
	cp ${runtimeJarPath} ${ROOT_DIR}/lib/
	if [ $? -ne 0 ]; then
    	fail "Error: ajsc-camunda-runner-${ajscRuntimeVersion}.jar not copied to project, project will not start correctly"
	fi
fi

##############################################################################
# REMOVING THE DATA DIRECTORY
# The following if statement is checking to see if a new version is being installed
# on top of another version. If a new version is installed on top of the current
# version WITHOUT a proper deinstall, this will remove the data directory which
# is necessary to cleanup old AJSC route metadata. If CSTEM chooses to re-run
# the install_postproc.sh to update swm node variables, this if statement will NOT
# remove the data directory which is necessary for the SAME version to utilize the
# correct data directory route metadata.
##############################################################################
if [ "${AFTSWM_ACTION_NEW_VERSION}" != "${AFTSWM_ACTION_PREVIOUS_VERSION}" ]
then
rm -rf ${ROOT_DIR}/data
fi

# Cleaning the jetty directory which contains the AJSC exploded war as well as
# any other apps running under jetty directory
rm -rf ${ROOT_DIR}/jetty

# A simple override for the SOA Cloud platform value.  Normally this is not
# needed outside of SOA Cloud development sandboxes
# this is used in the template.lrm.xml file during startup of the service
if [ ! -z "${SCLD_PLATFORM}" ]; then
	SCLD_OPTIONAL_PLATFORM_FLAG="-Dplatform=${SCLD_PLATFORM}"; export SCLD_OPTIONAL_PLATFORM_FLAG
fi

##############################################################################
# LRM and swm template processing in SWM install script
##############################################################################

if [ "${AJSC_FULL_INSTALL}" = "false" ]; then
	echo "AJSC_FULL_INSTALL flag set to false. Skipping AJSC configurations and installation."
	exit 0;
fi

##############################################################################
# PROCESS TEMPLATE FILES FROM ENVIRONMENT
# pattern: looks for all files starting with "template.", processes them using the
# current environment, then renames them by removing the "template." in the same
# directory
##############################################################################
utilpath=`dirname $0`/utils 
for tfile in `ls ${ROOT_DIR}/bundleconfig/etc/sysprops/template.* ${ROOT_DIR}/bundleconfig/etc/appprops/template.* ${ROOT_DIR}/bin/template.* ${ROOT_DIR}/etc/template.* 2>/dev/null`; do
    dfile=`echo ${tfile} | sed -e 's@/template\.@/@g'`
    sh ${utilpath}/findreplace.sh ${tfile} ${dfile} || exit 200
done

runningCount=`${LRMCLI} -running | grep -w ${SOA_CLOUD_NAMESPACE}.${AFTSWM_ACTION_ARTIFACT_NAME} | wc -l` || fail 300 "Unable to determine how many instances are running prior to notifying LRM of the upgrade"

##############################################################################
# DEPLOY CONTAINER TO LRM
##############################################################################

if [ -z "${RESOURCE_MANAGER_WAIT_TIME_IN_SECONDS}" ]
then
  RESOURCE_MANAGER_WAIT_TIME_IN_SECONDS=180
  export RESOURCE_MANAGER_WAIT_TIME_IN_SECONDS
fi



DTE_TME_STAMP=`date +%Y%m%d_%H%M%S`

LRM_ADD_LOG=/tmp/${SOA_CLOUD_NAMESPACE}.${AFTSWM_ACTION_ARTIFACT_NAME}_ADD_${DTE_TME_STAMP}.out 
        echo "Adding resource to lrm" 
        echo "${LRMCLI} -add -file ${ROOT_DIR}/etc/lrm.xml -ttw ${RESOURCE_MANAGER_WAIT_TIME_IN_SECONDS}" 
        ${LRMCLI} -add -file ${ROOT_DIR}/etc/lrm.xml -ttw ${RESOURCE_MANAGER_WAIT_TIME_IN_SECONDS} > ${LRM_ADD_LOG}
        LRM_ADD_RC=$?
        echo "LRMCLI ADD RC : ${LRM_ADD_RC}"
        if [ "${LRM_ADD_RC}" -ne "0" ]; then
        
		RSRC_EXIST=`cat ${LRM_ADD_LOG} | grep SCLD-LRM-1024` # resource is already added 
            if [ "${RSRC_EXIST:-}x" = "x" ]; then 
                echo "LRM add for Resource ${SOA_CLOUD_NAMESPACE}.${AFTSWM_ACTION_ARTIFACT_NAME} failed..." 
                cat ${LRM_ADD_LOG} 
                rm -f ${LRM_ADD_LOG} 
                exit 1 
            fi 
            echo "LRM Resource for ${SOA_CLOUD_NAMESPACE}.${AFTSWM_ACTION_ARTIFACT_NAME} already exists. Proceeding with either addOrUpgrade or modify" 
            echo "Get the number of configured ${SOA_CLOUD_NAMESPACE}.${AFTSWM_ACTION_ARTIFACT_NAME} instance" 
            versionCtr=`${LRMCLI} -configured | grep ${SOA_CLOUD_NAMESPACE}.${AFTSWM_ACTION_ARTIFACT_NAME} | awk {'print $3'} | wc -l`
            if [ ${versionCtr} -eq 1 ]; then
                echo "Updating lrm resource"
                echo "${LRMCLI} -addOrUpgrade -file ${ROOT_DIR}/etc/lrm.xml -ttw ${RESOURCE_MANAGER_WAIT_TIME_IN_SECONDS}"
                ${LRMCLI} -addOrUpgrade -file ${ROOT_DIR}/etc/lrm.xml -ttw ${RESOURCE_MANAGER_WAIT_TIME_IN_SECONDS} || abort "lrmcli addOrUpgrade failed"
            else
                echo "Modifying lrm resource"
                echo "${LRMCLI} -modify -file ${ROOT_DIR}/etc/lrm.xml"
                ${LRMCLI} -modify -file ${ROOT_DIR}/etc/lrm.xml || abort "lrmcli modify failed"
            fi
        fi
                
		echo "LRMCLI execution on ${SOA_CLOUD_NAMESPACE}.${AFTSWM_ACTION_ARTIFACT_NAME} executed succesfully!"
            

if [ "${runningCount}" -eq 0 ]; then
    if [ "${LRM_START_SVC}" = "true" ]; then
        ${LRMCLI} -start -name ${SOA_CLOUD_NAMESPACE}.${AFTSWM_ACTION_ARTIFACT_NAME} -version ${AFTSWM_ACTION_NEW_VERSION} -routeoffer ${AFT_SERVICE_ENV} | egrep SUCCESS\|SCLD-LRM-1041 
        if [ $? -ne 0 ]; then 
    	    fail 500 "Start of ${SOA_CLOUD_NAMESPACE}.${AFTSWM_ACTION_ARTIFACT_NAME} with routeOffer ${AFT_SERVICE_ENV} failed" 
	    fi
        ${LRMCLI} -running | grep -w ${SOA_CLOUD_NAMESPACE}.${AFTSWM_ACTION_ARTIFACT_NAME}
    else
        echo "PROC_USER_MSG: LRM_START_SVC is set to false and no running instances were found prior to upgrading so ending install with no running service instances."
    fi 
else
    ${LRMCLI} -running | grep -w ${SOA_CLOUD_NAMESPACE}.${AFTSWM_ACTION_ARTIFACT_NAME}
fi
    
exit 0
