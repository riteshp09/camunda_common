package com.att.oce.bpm.beans.services;

import java.util.List;

import org.apache.camel.Exchange;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class ProcessQuery {
	
	@Autowired
	ProcessEngine processEngine;
	
	@Autowired
	ApplicationContext aCtx;
	
	public String processCount(Exchange e){
		
		System.out.println(String.join(System.lineSeparator(), aCtx.getBeanDefinitionNames())); 
		
		List<ProcessInstance> plist = processEngine.getRuntimeService().createProcessInstanceQuery().active().list();
		if (plist == null || plist.size() == 0){
			return "No processes found";
		}
		return String.format("Total active processes found : %d", plist.size());
	}

}
