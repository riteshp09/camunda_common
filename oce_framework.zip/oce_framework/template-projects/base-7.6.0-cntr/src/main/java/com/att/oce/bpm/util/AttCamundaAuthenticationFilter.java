package com.att.oce.bpm.util;


import static org.camunda.bpm.engine.authorization.Authorization.AUTH_TYPE_GRANT;
import static org.camunda.bpm.engine.authorization.Permissions.ACCESS;
import static org.camunda.bpm.engine.authorization.Resources.APPLICATION;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.Principal;
import java.util.*;

import org.springframework.security.access.AuthorizationServiceException;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.codec.binary.Base64;
import org.camunda.bpm.cockpit.Cockpit;
import org.camunda.bpm.engine.AuthorizationService;
import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.authorization.Authorization;
import org.camunda.bpm.engine.authorization.AuthorizationQuery;
import org.camunda.bpm.engine.authorization.Permissions;
import org.camunda.bpm.engine.identity.Group;
import org.camunda.bpm.engine.identity.GroupQuery;
import org.camunda.bpm.engine.identity.User;
import org.camunda.bpm.engine.identity.UserQuery;
import org.camunda.bpm.engine.impl.cmd.CreateGroupQueryCmd;
import org.camunda.bpm.engine.impl.cmd.CreateUserQueryCmd;
import org.camunda.bpm.engine.rest.spi.ProcessEngineProvider;
import org.camunda.bpm.webapp.impl.security.SecurityActions;
import org.camunda.bpm.webapp.impl.security.SecurityActions.SecurityAction;
import org.camunda.bpm.webapp.impl.security.auth.Authentication;
import org.camunda.bpm.webapp.impl.security.auth.Authentications;
import org.camunda.bpm.webapp.impl.security.auth.UserAuthentication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import aaf.v2_0.Request;

import com.att.ajsc.filemonitor.AJSCPropertiesMap;
import com.att.ajsc.camunda.core.AafCamundaRole;
import com.att.ajsc.camunda.core.AafCamundaRoles;
import com.att.ajsc.camunda.core.AttCamundaPermissionEnum;
import com.att.ajsc.camunda.core.AttCamundaResourceEnum;
import com.att.ajsc.camunda.core.AttNameTransform;
import com.att.cadi.CadiWrap;
import com.att.cadi.Permission;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * This security filter maps the user to the camunda user and group management
 *
 * @author Satish Addagada - sa482b@att.com
 */
public class AttCamundaAuthenticationFilter implements Filter {

    private static final String[] APPS = new String[] { "cockpit", "tasklist","admin" };
    private static final String APP_MARK = "/app/";
    private boolean isAafCamundaRolesEmpty = false;
    private static final String AJSC_PROPS_FILE = "AAFUserRoles.properties";
	private static final String CADIPROPSPATH = "\\etc\\cadi.properties";
	private static String engineName = "";
	private static final Logger logger = LoggerFactory.getLogger(AttCamundaAuthenticationFilter.class);
	private Map<String, List<String>> ajscResourcePermissionMap = null;
	private static final String  nameEndPointProp = "nameEndpointUrl";
	private static final String aafRestEndPointProp = "AAFRestEndPoint";
	private String aafRestEndPointPropValue = "";
	
	private IdentityService identityService;
	
	private List<Permission> aafPermissions = null;

    public void init(FilterConfig filterConfig) throws ServletException {
    }

    protected ProcessEngine lookupProcessEngine(String engineName) {
    	
        ServiceLoader<ProcessEngineProvider> serviceLoader = ServiceLoader.load(ProcessEngineProvider.class);
        Iterator<ProcessEngineProvider> iterator = serviceLoader.iterator();
        if (iterator.hasNext()) {
            ProcessEngineProvider provider = iterator.next();
            return provider.getProcessEngine(engineName);

        }
        return null;

    }

    protected boolean isAuthorizedForApp(AuthorizationService authorizationService, String username, List<String> groupIds, String application) {
        return authorizationService.isUserAuthorized(username, groupIds, ACCESS, APPLICATION, application);
    }

    private boolean managePermissions(String userName)
    {
    	boolean authorized =false;
    	try {
    		authorized = authorizeAndVerifyPermission(userName);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return authorized;
    }
    protected void setKnownPrinicipal(final ServletRequest request, Authentications authentications) {
        final HttpServletRequest req = (HttpServletRequest) request;
        
        Enumeration parameterNames = req.getParameterNames();
        Principal principal = req.getUserPrincipal();
        if (principal != null && principal.getName() != null && !principal.getName().isEmpty()) {
            for (Authentication aut : authentications.getAuthentications()) {
                if (aut.getName() == principal.getName()) {
                    // already in the list - nothing to do
                    return;
                }
            }
            String url = req.getRequestURL().toString();
            String[] appInfo = getAppInfo(url);
            if (appInfo != null) {
                engineName = getEngineName(appInfo);
                String appName = getAppName(appInfo);

                final ProcessEngine processEngine = lookupProcessEngine(engineName);
                if (processEngine != null) {
                    String username = principal.getName();
                    

                    // check user's app authorizations
                    AuthorizationService authorizationService = processEngine.getAuthorizationService();
                    identityService = processEngine.getIdentityService();
                    
                    HashSet<String> authorizedApps = new HashSet<String>();
                    if(req instanceof HttpServletRequestWrapper)
					{
						HttpServletRequestWrapper wrapper = (HttpServletRequestWrapper) req;
						if(wrapper.getRequest() instanceof CadiWrap)
						{
							CadiWrap cadiWrap = (CadiWrap)wrapper.getRequest();
							aafPermissions = cadiWrap.getPermissions(principal);
						}
						System.out.println("List of valid permissions:" + aafPermissions);
					}
                    if(managePermissions(username))
                    {
                 // get user's groups
	                    final List<Group> groupList = processEngine.getIdentityService().createGroupQuery().groupMember(username).list();
	                    // transform into array of strings:
	                    List<String> groupIds = new ArrayList<String>();
	                    for (Group group : groupList) {
	                        groupIds.add(group.getId());
	                    }
	                    for (String application : APPS) {
	                        if (isAuthorizedForApp(authorizationService, username, groupIds, application)) {
	                            authorizedApps.add(application);
	                        }
	                    }
	                    authorizedApps.add("admin");
	                    if (authorizedApps.contains(appName)) {
	                      //  UserAuthentication newAuthentication = new UserAuthentication(username, groupIds, engineName, authorizedApps);
	                        UserAuthentication newAuthentication = new UserAuthentication(username, engineName);
	                        newAuthentication.setGroupIds(groupIds);
	                        newAuthentication.setAuthorizedApps(authorizedApps);
	                        authentications.addAuthentication(newAuthentication);
	                    }
                    }
                    else
                    {
                    	throw new AuthorizationServiceException("Not Authorized,don't have valid permissions");
                    }
                }
            }
        }

    }

    private String getAppName(String[] appInfo) {
        return appInfo[0];
    }

    private String getEngineName(String[] appInfo) {
        return appInfo[1];
    }

    private String[] getAppInfo(String url) {
        String[] appInfo = null;
        if (url.endsWith("/")) {
            int index = url.indexOf(APP_MARK);
            if (index >= 0) {
                String apps = url.substring(index + APP_MARK.length(), url.length() - 1);
                String[] aa = apps.split("/");
                if (aa.length == 2) {
                    appInfo = aa;
                }
            }
        }
        return appInfo;
    }

    private boolean isApp(String url) {
        return url.contains("/app/");
    }

    public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain) throws IOException, ServletException {
        final HttpServletRequest req = (HttpServletRequest) request;
        
        // get authentication from session
        Authentications authentications = Authentications.getFromSession(req.getSession());
        setKnownPrinicipal(request, authentications);
        Authentications.setCurrent(authentications);
        try {

            SecurityActions.runWithAuthentications(new SecurityAction<Void>() {
                public Void execute() {
                    try {
                        chain.doFilter(request, response);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                    return null;
                }
            }, authentications);
        } finally {
            Authentications.clearCurrent();
            Authentications.updateSession(req.getSession(), authentications);
        }
    }

    protected void clearProcessEngineAuthentications(Authentications authentications) {
    	
        System.out.println("clearProcessEngineAuthentications  --->> " +  1111);
        for (Authentication authentication : authentications.getAuthentications()) {
            ProcessEngine processEngine = Cockpit.getProcessEngine(authentication.getProcessEngineName());
            if (processEngine != null) {
                processEngine.getIdentityService().clearAuthentication();
            }
        }
    }

    public void destroy() {
    	System.out.println("destroy  --->> " +  1111);

    }
    private String getNameEndPointUrl() 
	{
		String nameEndpointUrl = "";
		aafRestEndPointPropValue = "";
		Map<String, String> aafUserRolesMap = AJSCPropertiesMap
				.getProperties(AJSC_PROPS_FILE);
		if(aafUserRolesMap != null && aafUserRolesMap.size() > 0)
		{
			for(String currKey:aafUserRolesMap.keySet())
			{
				if(currKey != null)
				{
					if(currKey.equalsIgnoreCase(nameEndPointProp))
					{
						nameEndpointUrl = aafUserRolesMap.get(currKey);
					}
					if(currKey.equalsIgnoreCase(aafRestEndPointProp))
					{
						aafRestEndPointPropValue = aafUserRolesMap.get(currKey);
					}	
				}
				
			}
		}
		return nameEndpointUrl;
	}
	
    
    private boolean authorizeAndVerifyPermission(String userName) throws IOException,
	ServletException 
	{
			boolean validCreds = false;
			Map<String, String> aafUserRolesMap = AJSCPropertiesMap
					.getProperties(AJSC_PROPS_FILE);
			if(verifyRoles(aafUserRolesMap) && identityService != null)
			{
					String nameEndPointUrl = getNameEndPointUrl();
					AttNameTransform attNameTransform = getUserNames(nameEndPointUrl,userName);
					 List<AafCamundaRole> aafRolesOfUser = getAafRolesOfUser(nameEndPointUrl,userName);
					if(attNameTransform != null)
					{
						 UserQuery userQuery = identityService.createUserQuery();
						 /**
						  * For now , this solution basically stores userinformation in camunda database.
						  * Ideally , information needs to be stored in runtime objects and retrieved
						  */
						 if(userQuery.userId(userName)  != null && userQuery.userId(userName).count() > 0)
						 {
							 UserQuery userNameQuery = userQuery.userId(userName);
							 if(userNameQuery.userFirstName(attNameTransform.getFirstName()) != null && userNameQuery.userLastName(attNameTransform.getLastName()) != null && 
									 userNameQuery.userFirstName(attNameTransform.getFirstName()).count() ==  0 && userNameQuery.userLastName(attNameTransform.getLastName()).count() == 0)
							 {
								 GroupQuery groupQuery = identityService.createGroupQuery();
								 List<Group> groupList = groupQuery.groupMember(userName).list();
								 deletePreviousGroupMemberships(userName,groupList);
								 identityService.deleteUser(userName); 
								 User newUser = identityService.newUser(userName);
								 newUser.setFirstName(attNameTransform.getFirstName());
								 newUser.setLastName(attNameTransform.getLastName());
								 identityService.saveUser(newUser);
							 }
						 }
						 else
						 {
							 User newUser = identityService.newUser(userName);
							 newUser.setFirstName(attNameTransform.getFirstName());
							 newUser.setLastName(attNameTransform.getLastName());
							 identityService.saveUser(newUser);
						 }
					
						
						 GroupQuery groupQuery = identityService.createGroupQuery();
						 List<Group> groupList = groupQuery.groupMember(userName).list();
						 
						 if(aafRolesOfUser != null && aafRolesOfUser.size() > 0)
						 {
							 for(AafCamundaRole currAafCamundaRole:aafRolesOfUser)
							 {
								 if(currAafCamundaRole != null && currAafCamundaRole.getName() != null )
								 {
									 createNewGroup(userName,currAafCamundaRole.getName(),groupList);
								 }
							 }
						 }
						 else
						 {
							 String newGroupId = getNewGroupId(userName,groupList);
							// newGroupId = userName;
							 /**
							  * Delete previous group Memberships as authorizations exist for previousGroup
							  */
							 if(groupList != null && groupList.size() > 0 )
							 {
								 deletePreviousGroupMemberships(userName,groupList);
							 }
							 Group newGroup = identityService.newGroup(newGroupId);
							 newGroup.setName(newGroupId + userName + "_Name");
							 newGroup.setType("AttCamundaGroup");
							 identityService.saveGroup(newGroup);
							 identityService.createMembership(userName, newGroupId);
							 addAuthorizationsForCreatedGroup(ajscResourcePermissionMap ,newGroupId);
						 }
						 validCreds= true;
					}
			}
			return validCreds;
	 }
    
    
    private void createNewGroup(String userName,String groupName,List<Group> groupList )
    {
    	 String newGroupId = getNewGroupId(userName,groupList);
		 /**
		  * Delete previous group Memberships as authorizations exist for previousGroup
		  */
		 if(groupList != null && groupList.size() > 0 )
		 {
			 deletePreviousGroupMemberships(userName,groupList);
		 }
		 Group newGroup = identityService.newGroup(newGroupId);
		 newGroup.setName(groupName);
		 newGroup.setType("AttCamundaGroup");
		 identityService.saveGroup(newGroup);
		 identityService.createMembership(userName, newGroupId);
		 addAuthorizationsForCreatedGroup(ajscResourcePermissionMap ,newGroupId);
    }
    private void addAuthorizationsForCreatedGroup(Map<String,List<String>> resourcePermissionMap,String groupId)
	{
		final ProcessEngine processEngine = lookupProcessEngine(engineName);
		if(processEngine == null)
		{
			return;
		}
		AuthorizationService authorizationService = processEngine.getAuthorizationService();
		/**
		 * Delete previous Authorizations
		 */
		AuthorizationQuery createAuthorizationQuery = authorizationService.createAuthorizationQuery();
		List<Authorization> list = createAuthorizationQuery.groupIdIn(groupId).list();
		if(list != null && list.size() > 0)
		{
			for(Authorization currAuth:list)
			{
				if(currAuth != null)
				{
					authorizationService.deleteAuthorization(currAuth.getId());
				}
			}
		}
		if(resourcePermissionMap != null && resourcePermissionMap.size() > 0)
		{
			for(Map.Entry<String,List<String>> entry:resourcePermissionMap.entrySet())
			{
				if(entry != null && entry.getKey() != null && entry.getValue() != null && isValidAttCamundaResource(entry.getKey()))
				{
					int resourceValue = AttCamundaResourceEnum.valueOf(entry.getKey().toUpperCase()).getResourceValue();
					Authorization auth = authorizationService.createNewAuthorization(AUTH_TYPE_GRANT);
	 			    auth.setGroupId(groupId);
	 			    auth.setResourceId("*");
	 			    auth.setResourceType(resourceValue);
	 
	 			    //  permissions to access that resource can be assigned:
	 			    for(String currPerm:entry.getValue())
	 			    {
	 			    	if(isValidAttCamundaPermission(currPerm))
	 			    	{
	 			    		Permissions perm = AttCamundaPermissionEnum.valueOf(currPerm.toUpperCase()).getPermissions();
	 			    		auth.addPermission(perm);
	 			    	}
	 			    }
	 			    authorizationService.saveAuthorization(auth);
				}
			}
		}
		else
		{
			createAllPermissionsOnGroup(authorizationService,groupId);
		}
	}
    
    private void createAllPermissionsOnGroup(AuthorizationService authorizationService,String groupId)
	{
		for(AttCamundaResourceEnum currValue:AttCamundaResourceEnum.values())
		{
			Authorization auth = authorizationService.createNewAuthorization(AUTH_TYPE_GRANT);
		    auth.setGroupId(groupId);
		    auth.setResourceId("*");
		    // a resource can also be a process definition
		   // auth.setResource(Resources.APPLICATION);
		    // the process defintion key is the resource id
		    auth.setResourceType(currValue.getResourceValue());

		    // finally the permissions to access that resource can be assigned:
			auth.addPermission(Permissions.ALL);
		    authorizationService.saveAuthorization(auth);
		}
	}
	private boolean isValidAttCamundaPermission(String permission)
	{
		boolean isValid = false;
		for(AttCamundaPermissionEnum currPermission:AttCamundaPermissionEnum.values())
		{
			if(currPermission != null && currPermission.name() != null && currPermission.name().equalsIgnoreCase(permission))
			{
				isValid = true;
				break;
			}
		}
		return isValid;
	}
	
	private boolean isValidAttCamundaResource(String resourceName)
	{
		boolean isValid = false;
		for(AttCamundaResourceEnum currResource:AttCamundaResourceEnum.values())
		{
			if(currResource != null && currResource.name() != null && currResource.name().equalsIgnoreCase(resourceName))
			{
				isValid = true;
				break;
			}
		}
		return isValid;
	}
	
	
    private String getNewGroupId(String userId,List<Group> groupList)
	{
		String newGroupId = "";
		 List<Group> existGroupList = null;
		do
		{
			UUID uniqueGroupId = UUID.randomUUID();
			newGroupId = uniqueGroupId.toString();
			GroupQuery groupQuery = identityService.createGroupQuery();
			existGroupList = groupQuery.groupId(newGroupId).list();
		}
		while(existGroupList != null && existGroupList.size() > 0);

		return newGroupId;
	}
    private void deletePreviousGroupMemberships(String userId,List<Group> groupList) 
	{
		for(Group group:groupList)
		{
			if(group != null && group.getId() != null)
			{
				identityService.deleteMembership(userId, group.getId());
				identityService.deleteGroup(group.getId());
			}
		}
	}
    
    private Boolean verifyRoles(Map<String,String> aafUserRolesMap)
	{
		boolean authorize = false;
		ajscResourcePermissionMap = null;
		getAuthorizedAccessForUserRolesMap(aafUserRolesMap);
		if (ajscResourcePermissionMap != null && ajscResourcePermissionMap.size() > 0) {
			authorize = true;
		} else {
			if (isAafCamundaRolesEmpty) {
				authorize = true;
			}
		}
		return authorize;
	}
	
	
	private boolean getAuthorizedAccessForUserRolesMap(Map<String, String> aafUserRolesMap)
	{
		ajscResourcePermissionMap = new HashMap<String,List<String>>();
		isAafCamundaRolesEmpty = false;
		if(aafUserRolesMap != null && aafUserRolesMap.size() >0)
		{
			for (Map.Entry<String, String> entry : aafUserRolesMap.entrySet()) 
			{
				String keyResource = entry.getKey();
				String permissions = entry.getValue();
				if(keyResource != null && keyResource.toUpperCase().startsWith("/CAMUNDA"))
				{
					String[] resourceSplit = keyResource.split("/");
					if(resourceSplit != null && resourceSplit.length >= 3)
					{
						if(permissions != null  )
						{
							List<String> permissionList = new ArrayList<String>();
							if(permissions.contains(","))
							{
								String[] permissionsArray = permissions.split(",");
								if(permissionsArray != null && permissionsArray.length > 0)
								{
									for(String currPermission:permissionsArray)
									{
										String perm = getVerifiedAuthorizedPermission(currPermission);
										if(perm != null)
										{
											permissionList.add(perm);
											ajscResourcePermissionMap.put(resourceSplit[2], permissionList);
										}
									}
								}
							}
							else
							{
								String perm = getVerifiedAuthorizedPermission(permissions);
								if(perm != null)
								{
									permissionList.add(perm);
									ajscResourcePermissionMap.put(resourceSplit[2], permissionList);
								}
							}
						}
					}
				}
			}
		}
		else
		{
			isAafCamundaRolesEmpty = true;
		}
		return isAafCamundaRolesEmpty;
	}
	
	private String getVerifiedAuthorizedPermission(String permission)
	{
		String authPermission = null;
		if(aafPermissions != null && aafPermissions.size() > 0)
		{
			for(Permission currAafPermission:aafPermissions)
			{
				if(currAafPermission != null && currAafPermission.getKey() !=null && permission != null)
				{
					if(currAafPermission.getKey().equalsIgnoreCase(permission))
					{
						if(permission.contains("|"))
						{
							String[] splitPermission = permission.split("\\|");
							if(splitPermission != null && splitPermission.length >=3)
							{
									authPermission =  splitPermission[2];
									break;
							}
						}
					}
				}
			}
		}
		return authPermission;
	}
	
	public AttNameTransform getUserNames(String endpoint, String payload) {
		String ret ="";
		AttNameTransform attNameTransform = null ;
		if(payload != null && payload.contains("@"))
		{
			String[] split = payload.split("\\@");
			payload = split[0];
		}
		if (payload.isEmpty())
			return attNameTransform;
		try {

			URL url = new URL(endpoint+payload);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			
			while ((output = br.readLine()) != null) {
				ret+=output;
			}

			conn.disconnect();
			Gson gson = new Gson();
			Type listType = new TypeToken<ArrayList<AttNameTransform>>() {}.getType();
			List<AttNameTransform> attNameTransformList= gson.fromJson(ret, listType);
			if(attNameTransformList != null && attNameTransformList.size() > 0)
			{
				attNameTransform = attNameTransformList.get(0);
			}

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
		return attNameTransform;

	}

	public List<AafCamundaRole>  getAafRolesOfUser(String endpoint, String userName) {
		String ret ="";
		HashMap<String, String> cadiProperties = getCadiProperties();
		String mech_Id = "";
		String mech_pass = "";
		List<AafCamundaRole>  roles = new ArrayList<AafCamundaRole>();
		if(cadiProperties != null && cadiProperties.size() > 0)
		{
			mech_Id = cadiProperties.get("aaf_id");
			mech_pass = cadiProperties.get("aaf_clear_pass");
		}
		endpoint = aafRestEndPointPropValue + userName;
	
		try {
			String str = mech_Id + ":" + mech_pass;
			byte[]   bytesEncoded = Base64.encodeBase64(str .getBytes());
			
			String encodeValue = new String(bytesEncoded );
			String basicAuth = "Basic " + encodeValue;
			
			URL url = new URL(endpoint);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("Authorization", basicAuth);

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			
			while ((output = br.readLine()) != null) {
				ret+=output;
			}
			conn.disconnect();
			Gson gson = new Gson();
//			Type listType = new TypeToken<ArrayList<AafCamundaRole>>() {}.getType();
//			List<AafCamundaRole> attCamundaRolesList= gson.fromJson(ret, listType);
			AafCamundaRoles aafCamundaRoles = gson.fromJson(ret, AafCamundaRoles.class);
			if(aafCamundaRoles != null)
			{
				roles = aafCamundaRoles.getRole();
			}
		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
		return roles;
	}

	private HashMap<String, String> getCadiProperties()
	{
		Properties prop = new Properties();
		String cadiFilePath =  System.getProperty("AJSC_HOME") + CADIPROPSPATH;
		File file = new File(cadiFilePath);
		FileInputStream fis;
		try {
			fis = new FileInputStream(file);
			prop.load(fis);
			HashMap<String, String> propMap = new HashMap<String, String>((Map)prop);
			return propMap;
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage());
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		return null;
	}
}

