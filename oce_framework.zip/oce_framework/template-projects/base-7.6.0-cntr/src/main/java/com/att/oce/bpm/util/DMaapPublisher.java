package com.att.oce.bpm.util;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.json.JSONObject;

import com.att.nsa.mr.client.MRBatchingPublisher;
import com.att.nsa.mr.client.MRClientFactory;
import com.att.nsa.mr.client.MRPublisher.message;

/**
 *An example of how to use the Java publisher. 
 * @author  
 *
 */
public class DMaapPublisher
{
	static FileWriter routeWriter= null;
	static Properties props=null;	
	static FileReader routeReader=null;
	private static String preferredRouteFileName = "preferredRoute.txt";
	private static String producerProperties = "\\etc\\appprops\\producer.properties";
	
	public void publishMessage (String msg  ) throws IOException, InterruptedException, Exception
	{

		String routeFilePath = preferredRouteFileName;
		File fo= new File(routeFilePath);
		System.out.println("Enterd publishing");
		if(!fo.exists()){
				routeWriter=new FileWriter(new File (routeFilePath));
		}	
		routeReader= new FileReader(new File (routeFilePath));
		props= new Properties();
		String producerFilePath = System.getProperty("AJSC_CONF_HOME") + producerProperties;		
		// create our publisher
		System.out.println("Msg publishing to topic:" + msg);
		final MRBatchingPublisher pub = MRClientFactory.createBatchingPublisher(producerFilePath) ;
		pub.send ( "MyPartitionKey", msg);
		
		// close the publisher to make sure everything's sent before exiting. The batching
		// publisher interface allows the app to get the set of unsent messages. It could
		// write them to disk, for example, to try to send them later.
		final List<message> stuck = pub.close ( 20, TimeUnit.SECONDS );
		if ( stuck.size () > 0 )
		{
			System.err.println ( stuck.size() + " messages unsent" );
		}
		else
		{
			System.out.println ( "Clean exit; all messages sent." );
		}
	}
	
}



