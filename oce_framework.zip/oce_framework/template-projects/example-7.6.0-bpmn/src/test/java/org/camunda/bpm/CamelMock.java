package org.camunda.bpm;

import java.util.Map;

import org.camunda.bpm.engine.runtime.VariableInstance;
import org.camunda.bpm.engine.test.ProcessEngineRule;

import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.transformation.InquireAccountProfileTransformation;

public class CamelMock {
	
	private ProcessEngineRule processEngineRule;
	public CamelMock(ProcessEngineRule processEngineRule){
		this.processEngineRule = processEngineRule;
	}

	public Object sendTo(String s) {
		System.out.format("camel mock received %s\n",s);
		return s;
	}
	@SuppressWarnings("unchecked")
	public Object sendTo(String s,String s1) {
		System.out.format("camel mock received %s,%s\n",s,s1);
		
		if ("direct:csi:iap".equals(s)){
			VariableInstance var = processEngineRule.getRuntimeService().createVariableInstanceQuery().variableName("order").singleResult();
			Map<String,Object> order = (Map<String,Object>)var.getValue();
			InquireAccountProfileTransformation transform = new InquireAccountProfileTransformation();
			return transform.updateOrder(order, TestOrderBuilder.build("InquireAccountProfileSuccessResponse.xml").toString(),0);
		}
		
		
		return s;
	}
	public Object sendTo(String s,String s1,String s2) {
		System.out.format("camel mock received %s,%s,%s\n",s,s1,s2);
		return s;
	}

}
