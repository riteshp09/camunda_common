package com.att.oce.routes;

import com.att.oce.transformation.InquireAccountProfileTransformation;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component("exampleRouteBuilder")
public class ExampleRouteBuilder extends RouteBuilder {

  @Override
  public void configure() throws Exception {
    from("direct:csi:iap")
        .bean(InquireAccountProfileTransformation.class, "transform").id("Example-transform")
        .to("velocity:///vm/InquireAccountProfile.vm").id("Example-velocity")
        .to("https://headeruri?throwExceptionOnFailure=false")
        .convertBodyTo(String.class).id("Example-http-readstr")
        .bean(InquireAccountProfileTransformation.class, "processResponse").id("Example-processResponse")
        .routeId("Example");
  }
}