REPLACE=$1
echo replacing with $REPLACE
sed 's/trouble-shoot762/'$REPLACE'/g' .project > .project.tmp && mv .project.tmp .project
sed 's/trouble-shoot762/'$REPLACE'/g' pom.xml > pom.xml.tmp && mv pom.xml.tmp pom.xml
sed 's/trouble-shoot762/'$REPLACE'/g' src/main/config/cadi.properties > src/main/config/cadi.properties.tmp && mv src/main/config/cadi.properties.tmp src/main/config/cadi.properties
sed 's/trouble-shoot762/'$REPLACE'/g' src/main/config/runner-web.xml > src/main/config/runner-web.xml.tmp && mv src/main/config/runner-web.xml.tmp src/main/config/runner-web.xml
sed 's/trouble-shoot762/'$REPLACE'/g' src/main/config/template.runner-web.xml > src/main/config/template.runner-web.xml.tmp && mv src/main/config/template.runner-web.xml.tmp src/main/config/template.runner-web.xml
sed 's/trouble-shoot762/'$REPLACE'/g' src/main/swm/notes.txt > src/main/swm/notes.txt.tmp && mv src/main/swm/notes.txt.tmp src/main/swm/notes.txt 

mv ./src/main/swm/dist_files/appl/trouble-shoot762 ./src/main/swm/dist_files/appl/$REPLACE
mv ./src/main/ajsc/trouble-shoot762_v1/trouble-shoot762 ./src/main/ajsc/trouble-shoot762_v1/${REPLACE}
mv ./src/main/ajsc/trouble-shoot762_v1 ./src/main/ajsc/${REPLACE}_v1
