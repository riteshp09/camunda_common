package com.att.oce.bpm.base_76401_cntr.service;

import com.att.oce.bpm.base_76401_cntr.model.HelloWorld;

public interface SpringService {
	public HelloWorld getQuickHello(String name);
}
