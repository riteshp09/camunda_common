# Developer Contact
Owner: @${biasId}

# Build
Jenkins Job: ${jenkins-joblink}

# Monitoring
AppDynamics: http://appdynamics-ee.dtveng.net:8090/controller
Kubernetes: ${kubeui-link}

Cockpit: ${cockpit-link}

Logs: ${elk-link}
