
# AJSC Container

The following steps should be followed to create the container project

1. Copy the project https://codecloud.web.att.com/projects/ST_OCE/repos/oce_framework/browse/template-projects/base-XXX-cntr. Care should be taken to use the correct version of the base container.
2. Ensure that the copy is not pointing to the same git repository.
3. Change the folder name to the appropriate module name. Also change the folders names inside _src\main\ajsc\_.
4. Change the pom.xml to adapt the module name and version number.
5. Change the following properties to the appropriate values in the file _bundleconfig-local\etc\sys-props.properties_. You may be required to add additionals properties based on the numbers of brokers we may need to connect.

```
CAMUNDA_ENGINE_DB_DRIVER_CLASS=oracle.jdbc.OracleDriver
CAMUNDA_ENGINE_DB_URL=jdbc:oracle:thin:@localhost:1521:xe
CAMUNDA_ENGINE_DB_USERNAME=CamundaBPMSpring
CAMUNDA_ENGINE_DB_PASSWORD=camundauser

OCE_RESOURCES_HOME=C:/Venkat/workingdir/camunda/oce_framework/oce-resources/src/main/resources/
OCE_ENV=dev
OCE_DOMAIN=wireless

BASE_AMQ_BROKER_URL=tcp://localhost:61616
BASE_AMQ_USERNAME=admin
BASE_AMQ_PASSWORD=admin
BASE_AMQ_CONCURRENT_CONSUMERS=10

TASK_AMQ_BROKER_URL=tcp://localhost:61616
TASK_AMQ_USERNAME=admin
TASK_AMQ_PASSWORD=admin
TASK_AMQ_CONCURRENT_CONSUMERS=10
```

6. Include any AMQ connections that are required in the _src\main\ajsc\xxxxx\xxx\vxx\conf\beans.xml_. Note that for task no separate AMQ is required. If one service is catering multiple process triggers, then we may require more that 1 AMQ configuration.

7. Any properties added in the sys-props.properties should also be included in the template.sys-props.properties

8. Include all the process bpmn file names in the src\main\resources\META-INF\processes.xml file.

# BPMN Project

1. Refer the template project https://codecloud.web.att.com/projects/ST_OCE/repos/oce_framework/browse/template-projects/example-XXX-bpmn. You need not clone it but follow the structure of this project.
2. All routebuilder classes should be created in com.att.oce.routes package
3. All BPMN files should be present in the bpmn folder in resources.
4. All Velocity template files should be present in the vm folder in resources.
5. All test data files specific to this project should be present in the data folder in _src/test/resources_.


# BPMN Process Design Guidelines

1. Name all the activities and paths appropriately. The following prefixes are to be used,
    svc - Service Call
    scr - Script task
    tsk - Human task
    seq - Sequence paths
    chk - Mutually Exclusive joint
    err - Error Event
    init - Start Event
    stop - End Event

2. Ensure that appropriate labels are provided for the paths and activities
3. Ensure that default paths are marked properly. Do not leave provide conditions for all outgoing paths from an activity
4. Use Async Fallout appropriately. We must use Async fallout for APIs which are performing changes to the order.
5. Do not use inline scripts. Use bean methods for all the code related to servicing an API. For script kind of work, have a separate bean.
6. Use lanes to fucntionally segregate the APIs. Do not use lanes where there is not a need to show segregation
7. Do not provide any Job Prriority or Retry Cycle
8. Use the documentation section to provide any additional documentation regarding the activity.
9. Model multi line API calls (calls which are repeated multiple times for a order) using a multiline scope. Collect all the errors for all the lines and then go fallout. Do not use Multiline on activity level.
10. To get the count or exit condition for multi line api calls should also come from the transformation classes.
11. Do not use separate variables unless very much required. Always use additional keys in the executionContext variable.
12. Execution Context variable (executionContext) will be injected into all processes by the framework. There is no requirement to create this variable in the process.
13. All outbound calls should be done using Camel routes.

# Camel Outbound Route Guidelines

1. Ensure that all the routes have appropriate Ids.
2. Ensure that we use the https component for CSI calls.
3. Ensure that after https compoent we perform `convertBodyTo(String.class)` to convert the stream to String
4. Auditlog should be performed for all outbound calls.
5. All routes should be built with RouteBuilder classes. The classes should be marked with Component annotation.
6. The component name should be the same as the Routebuilder class name but with camel case notation
7. Do not handle errors in the camel route unless there is a specific need. The framework has mechanism to handle the errors from the route.
8. NO retry should be attempted from the route. All retry should be handled by the framework.
9. All routes should make exactly one API call and should have any logic around whether to call the API or not.

# Transformation Classes Guidelines

1. All Transformation classes should end with 'Transformation' in the name.
2. These classes should extend from TransformationService or any other class extending TransformationService.
3. getApiName methid needs to be overwritten for every transformation class.
4. transform and processResponse are mandatory public methods for any transformation class. Other than this preCondition, ignore methods also can be defined.
5. if required, supporting private methods should be used. Do no write the entire transformation in one single method.
6. transform method is responsible for the following,
  * Create a map which is the exact representation of the payload that needs to be sent. Ensure that required fields are xml sanitised.
  * Set the *CamelHttpUri* to the url of the API. to get the URL from urn use the resolveURN.
  * Set the header *OceCSIApiName* in the exchange.out to the API name. This is what the retry mechanism will use to check for retry configuration.
  * CSI or ATG http header parameters need to be set. The methods setCSIHttpHeaders or setATGHttpHeaders should be used. If there is a need to change these methods, override the same in your transformation class.
  * Order variable can be lost during the route execution. So in case the order is required in response processing, store the same in exchange.properties. Any other data that needs to be passed between transform and processResponse should use exchange.properties.
7.  processResponse method is responsible for the following
  * Check if there is an error in the response. If there is an error, create APIFailedException and throw the same.
  * addTransactionHistory should be called in both failure and success scenarios to add the result to the transaction history. For any reason if we dont want to use the API configuration to add transactionHistory, we can directly add the same details in executionContext.
  * Updated order or any other variable should be set as the exchange.out.body
8. preCondition method is responsible for the following
  * to check the precondition for the order and return true or false.
  * record the result in transactionHistory
9. Transformation classes can also inherit from other transformation classes. For example. CRU OrderEquipment transformation can extend from consumer, build the consumer OE map and then make changes to the map.

# Velocity Template Guidelines

1. Only body should be used in the velocity template. No other variables are to be used
2. Indentation in the xml should be proper.
3. All namespace declaration for the xml should be done in the topmost node. Duplicate declaration of namespaces should be avoided.

# Auditlog Implementation Guidelines

1. For each API in their respective transformation class in transform function we must set following properties in exchange. Please note to use same names as mentioned below for properties.
	* order -> order payload
	* apiURN -> Please give urn mapping by following guidelines
		- For CSI Call  -> must end with ".jws"(Example : urn:csi:services:iap:InquireMobileSubscriberProfile.jws)
		- For ATG Call  -> urn:atgOrderCreate 
		- For BRMS Call -> urn:brmsService
	* fedIndicator -> true or false (If Federated API is being used in project value must be "true" or viceversa)
2. Common Function has been implemented in TransformationService class which must be called so as to set additional properties.
	* setAuditLogProperties(Exchange e, boolean fedIndicator)
3. In application.properties file , there is a property called "auditlog.system.property" which specifies how auditlog works. Possible values are mentioned below.
	* OFF      -  to turn off auditlog
	* DETAIL   -  to log both request & response payload
	* ABSTRACT -  to ignore logging of request and response payload
4. We must use routeId() function to set route Id in route builder class & routeId must be same as routebuilder bean name.	