package com.att.oce.creditresult.test;

import javax.annotation.Resource;

import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionRuleResult;
import org.camunda.bpm.dmn.engine.DmnDecisionTableResult;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.camunda.bpm.engine.variable.VariableMap;
import org.camunda.bpm.engine.variable.Variables;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.beans.config.CreditResultConfig;

/**
 * Test class to validate Retry Decision table.
 * 
 * This test class takes care of exposing dependent dmnEngine bean.
 * 
 * 
 * Imp: 
 *  configure ENV variable as below to run this test on local machine:
 * 		-DOCE_RESOURCES_HOME= <path to oce-resources/src/main/resources>
 *
 * @author gm353e
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {CreditResultDecisionTest.class, CreditResultConfig.class})
public class CreditResultDecisionTest {

	/**
	 * Env variable OCE_RESOURCES_HOME is used to read resources file.
	 *  -DOCE_RESOURCES_HOME= <path to oce-resources/src/main/resources>
	 */
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "src/test/resources/");
	} 
	
	@Autowired
	private DmnEngine dmnEngine;
	
	
	@Bean
	public static DmnEngine dmnEngine() {
		// create default DMN engine configuration
		DmnEngineConfiguration configuration = DmnEngineConfiguration
		  .createDefaultDmnEngineConfiguration();

		// configure as needed
		// ...

		// build a new DMN engine
		DmnEngine dmnEngine = configuration.buildEngine();
		return dmnEngine;
	}
	
	@Resource(name = "creditResultDecisions")
	private DmnDecision creditResultDecisions;
	
	@Test
	public void testDmnEngineInjection() {
		Assert.assertNotNull(dmnEngine);
	}
	
	@Test
	public void testCreditResultDecisionTableInjection() {
		Assert.assertNotNull(creditResultDecisions);		
		Assert.assertTrue(creditResultDecisions.isDecisionTable());
	}
	
	@Test
	public void testDefaultCreditResultDecision() {
		
		VariableMap variables = Variables.createVariables()
			.putValue("CreditStatus", "")
			.putValue("ReasonCode", "");
		
		DmnDecisionTableResult results = dmnEngine
					.evaluateDecisionTable(creditResultDecisions, variables);
		
		DmnDecisionRuleResult result = results.getFirstResult();		

		Assert.assertEquals(3, result.size());
		Assert.assertEquals("IN_QUEUE", result.get("Status"));
		Assert.assertEquals("CREDIT_REVIEW", result.get("SubStatus"));
	}

	@Test
	public void testPendingCreditResultDecision() {
		
		VariableMap variables = Variables.createVariables()
				.putValue("CreditStatus", "REVIEW")
				.putValue("ReasonCode", "66");
			
			DmnDecisionTableResult results = dmnEngine
						.evaluateDecisionTable(creditResultDecisions, variables);
			
			DmnDecisionRuleResult result = results.getFirstResult();	

		Assert.assertEquals(3, result.size());		
		Assert.assertEquals("PENDING", result.get("Status"));
		Assert.assertEquals("OUTSTANDING_BALANCE_CAS", result.get("SubStatus"));
	}
	
	@Test
	public void testCanceledCreditResultDecision() {
		
		VariableMap variables = Variables.createVariables()
				.putValue("CreditStatus", "REVIEW")
				.putValue("ReasonCode", "VC");
			
			DmnDecisionTableResult results = dmnEngine
						.evaluateDecisionTable(creditResultDecisions, variables);
			
			DmnDecisionRuleResult result = results.getFirstResult();	

		Assert.assertEquals(3, result.size());		
		Assert.assertEquals("CANCELED", result.get("Status"));
		Assert.assertEquals("FRAUD_ALERT_CAS", result.get("SubStatus"));
	}

}
