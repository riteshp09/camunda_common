package com.att.oce.beans.config;

import java.io.File;
import java.io.FileNotFoundException;

import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.model.dmn.Dmn;
import org.camunda.bpm.model.dmn.DmnModelInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CreditResultConfig {

	private static String OCE_RESOURCES_HOME = System.getProperty("OCE_RESOURCES_HOME");

	private static String CREDIT_RESULT_DECISIONS = OCE_RESOURCES_HOME + "credit-result-decisions.dmn";
	
	//dmnEngine should be exposed using @Bean by the Spring Application which needs to leverage this CreditConfig 
	@Autowired
	private DmnEngine dmnEngine;

	@Bean(name = "creditResultDecisions")
	public DmnDecision creditResultDecisions() throws FileNotFoundException {
		File file = new File(CREDIT_RESULT_DECISIONS);
		DmnModelInstance dmnModelInstance  = Dmn.readModelFromFile(file);
		return dmnEngine.parseDecision("credit-result-decisions" , dmnModelInstance);
	}	
	
}
