/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.att.oce.bpm.camel.component.producer;

import org.apache.camel.impl.DefaultProducer;
import com.att.oce.bpm.camel.component.CamundaBpmEndpoint;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.RuntimeService;

import java.util.Map;

public abstract class CamundaBpmProducer extends DefaultProducer {

  protected ProcessEngine processEngine;
  protected RuntimeService runtimeService;
  protected Map<String, Object> parameters;

  public CamundaBpmProducer(CamundaBpmEndpoint endpoint, Map<String, Object> parameters) {
    super(endpoint);
	log.debug("Value of the ProcessEngine inside CamundaBpmProducer " + this.processEngine);
    this.processEngine = endpoint.getProcessEngine();
      if (this.processEngine != null) {
          this.runtimeService = processEngine.getRuntimeService();
      	  log.debug("Value of the RuntimeService inside the if loop in CamundaBpmProducer " + this.runtimeService);

      }
    this.parameters = parameters;
  }
  

  
  protected CamundaBpmEndpoint getCamundaBpmEndpoint() {
    return (CamundaBpmEndpoint) getEndpoint();
  }  
}
