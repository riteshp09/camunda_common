/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.att.oce.bpm.camel.component.producer;

import java.util.Map;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.oce.bpm.camel.component.CamundaBpmConstants;
import com.att.oce.bpm.camel.component.CamundaBpmEndpoint;

/**
 * Starts a process instance given a process definition key.
 * <p/>
 * Example: camunda-bpm://start?processDefinitionKey=aProcessDefinitionKey
 *
 * @author Ryan Johnston (@rjfsu)
 * @author Tijs Rademakers (@tijsrademakers)
 * @author Rafael Cordones (@rafacm)
 * @author Bernd Ruecker
 */
public class UserTaskProducer extends CamundaBpmProducer {

    static Logger log = LoggerFactory.getLogger(UserTaskProducer.class);

	private String CAMUNDA_BPM_TASK_ID = "CamundaTaskId";
	private String CAMUNDA_BPM_TASK_ACTION = "CamundaTaskAction";
	private String CAMUNDA_TASK_ACTION_PARAM = "action";

	private String TASK_ACTION_COMPLETE = "complete";

	private String action;

	public UserTaskProducer(CamundaBpmEndpoint endpoint, Map<String, Object> parameters) {
		super(endpoint, parameters);
	}

	public void process(Exchange exchange) throws Exception {
		String taskId = exchange.getIn().getHeader(CAMUNDA_BPM_TASK_ID).toString();
		if (parameters.containsKey(CAMUNDA_TASK_ACTION_PARAM)) {
			action = parameters.get(CAMUNDA_TASK_ACTION_PARAM).toString();
		} else { 
			action = exchange.getIn().getHeader(CAMUNDA_BPM_TASK_ACTION).toString();
		}
		
		log.debug("order update in task: " + exchange.getIn().getBody());
		if (parameters.containsKey(CamundaBpmConstants.COPY_MESSAGE_BODY_AS_PROCESS_VARIABLE_PARAMETER)) {
			String processVariableName = (String) parameters
					.get(CamundaBpmConstants.COPY_MESSAGE_BODY_AS_PROCESS_VARIABLE_PARAMETER);
//			Map updatedObject = (Map) JsonConverters.toMapofMaps((String) exchange.getIn().getBody());
			Map updatedObject = (Map) exchange.getIn().getBody();
			log.debug("UserTaskProducer Order Object Update " + updatedObject);
			log.debug("Value of the ProcessEngine inside UserTaskProducer " + processEngine);
			String processId = processEngine.getTaskService().createTaskQuery().taskId(taskId).singleResult().getProcessInstanceId();
			processEngine.getRuntimeService().setVariable(processId, processVariableName, updatedObject);
		}
		

		if (TASK_ACTION_COMPLETE.equals(action)) {
			processEngine.getTaskService().complete(taskId);
		}

	}

}