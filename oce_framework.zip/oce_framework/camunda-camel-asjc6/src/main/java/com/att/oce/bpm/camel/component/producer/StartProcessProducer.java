/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.att.oce.bpm.camel.component.producer;

import org.apache.camel.Exchange;
import com.att.oce.bpm.camel.component.CamundaBpmConstants;
import com.att.oce.bpm.camel.component.CamundaBpmEndpoint;
import org.camunda.bpm.engine.runtime.ProcessInstance;

import java.util.HashMap;
import java.util.Map;

import static com.att.oce.bpm.camel.component.CamundaBpmConstants.*;

/**
 * Starts a process instance given a process definition key.
 * <p/>
 * Example: camunda-bpm://start?processDefinitionKey=aProcessDefinitionKey
 *
 * @author Ryan Johnston (@rjfsu)
 * @author Tijs Rademakers (@tijsrademakers)
 * @author Rafael Cordones (@rafacm)
 * @author Bernd Ruecker
 */
public class StartProcessProducer extends CamundaBpmProducer {
	
  private final String processDefinitionKey;

  public StartProcessProducer(CamundaBpmEndpoint endpoint, Map<String, Object> parameters) {
    super(endpoint, parameters);

    if (parameters.containsKey(PROCESS_DEFINITION_KEY_PARAMETER)) {
      this.processDefinitionKey = (String) parameters.get(PROCESS_DEFINITION_KEY_PARAMETER);
    } else {
        processDefinitionKey = null;
      // throw new IllegalArgumentException("You need to pass the '" + PROCESS_DEFINITION_KEY_PARAMETER + "' parameter! Parameters received: " + parameters);
    }
  }

  public void process(Exchange exchange) throws Exception {
    Map<String, Object> processVariables = new HashMap<String, Object>();
    
	Object camelBody = exchange.getIn().getBody();

	// If the COPY_MESSAGE_BODY_AS_PROCESS_VARIABLE_PARAMETER was passed the
	// value of it
	// is taken as variable to store the (string) body in
	String processVariableName = "camelBody";
	if (parameters.containsKey(CamundaBpmConstants.COPY_MESSAGE_BODY_AS_PROCESS_VARIABLE_PARAMETER)) {
		processVariableName = (String) parameters
				.get(CamundaBpmConstants.COPY_MESSAGE_BODY_AS_PROCESS_VARIABLE_PARAMETER);
	}

	processVariables.put(processVariableName, camelBody);
	
    Map<String,Object> eContext = new HashMap<String, Object>();
	if (exchange.getIn().hasHeaders()){
		for (String header : exchange.getIn().getHeaders().keySet()){
			if (parameters.containsKey(CamundaBpmConstants.INDEXED_PROPERTY_PREFIX_PARAMETER) 
						&& header.startsWith(parameters.get(CamundaBpmConstants.INDEXED_PROPERTY_PREFIX_PARAMETER).toString())) {
				
				String variableKey = header.substring(parameters.get(CamundaBpmConstants.INDEXED_PROPERTY_PREFIX_PARAMETER).toString().length());
				String variableValue = (exchange.getIn().getHeaders().get(header) != null)? exchange.getIn().getHeaders().get(header).toString():null;
				/* If any indexed property value is NULL throw Exception */
				if(variableValue == null)
					throw new Exception("Value for" +variableKey+" is NULL");
				processVariables.put(variableKey,variableValue);
			} else if (!header.startsWith("Camel") && !header.startsWith("JMS")){
				eContext.put(header,exchange.getIn().getHeaders().get(header));
			}
		}
	}
	
	processVariables.put(CAMUNDA_PROCESS_EXECUTION_CONTEXT,eContext);
	
	if (exchange.hasProperties()){
		for (String property : exchange.getProperties().keySet()){
			if (!property.startsWith("Camel") && !property.equals(CAMUNDA_BPM_BUSINESS_KEY)){
				processVariables.put(property,exchange.getProperties().get(property));
			}
		}
	}
	
    /*
     * If the exchange contains the CAMUNDA_BPM_BUSINESS_KEY then we pass it to the engine
     */
    String processDefinitionKey = this.processDefinitionKey != null ? this.processDefinitionKey : exchange.getIn().getHeader(CAMUNDA_BPM_PROCESS_DEFINITION_KEY, String.class);

    ProcessInstance instance = null;
    if (exchange.getProperties().containsKey(CAMUNDA_BPM_BUSINESS_KEY)) {
      instance = runtimeService.startProcessInstanceByKey(processDefinitionKey,
                                                          exchange.getProperty(CAMUNDA_BPM_BUSINESS_KEY, String.class),
                                                          processVariables);
      exchange.setProperty(CAMUNDA_BPM_BUSINESS_KEY, instance.getBusinessKey());
    } else {
      instance = runtimeService.startProcessInstanceByKey(processDefinitionKey,processVariables);
    }

    exchange.setProperty(CAMUNDA_BPM_PROCESS_DEFINITION_ID, instance.getProcessDefinitionId());
    exchange.setProperty(CAMUNDA_BPM_PROCESS_INSTANCE_ID, instance.getProcessInstanceId());
    exchange.getOut().setBody(instance.getProcessInstanceId());
  }

}