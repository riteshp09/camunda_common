package com.att.oce.bpm;

import java.util.Map;

import org.apache.camel.Body;
import org.apache.camel.Headers;
import org.apache.camel.OutHeaders;

import com.att.oce.bpm.error.APIFailedException;

public class OceMockService {
	
	public Object handle(@Headers Map<?, ?> in, @Body Object payload, @OutHeaders Map<String, Object> out)
	        throws APIFailedException {
		APIFailedException error =  new APIFailedException();
		error.setApi("InquireAccountProfile");
		error.setCode("200");
		error.setCodeDescription("Business Error");
		System.out.println("OceMockService - Threw error");
		throw error;
	}

}
