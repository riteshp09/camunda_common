package com.att.oce.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class WirelessUpgradeRouteBuilder extends RouteBuilder {

  @Override
  public void configure() throws Exception {

    from("direct:csi:iap").setBody(constant("Success")).to("mock:result");
        .routeId("WirelessUpgrade");
  }
}