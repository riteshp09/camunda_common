/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.att.oce.bpm;

import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.repository.ProcessDefinition;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertNotNull;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.Map;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.ExchangeBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import com.att.oce.bpm.camel.component.CamundaBpmConstants;
import com.att.oce.bpm.common.TestOrderBuilder;

import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration("classpath:camel-camunda-context.xml")
public class RetryProcessTest {
	
	@BeforeClass
	public static void setup() {
		
		try {
			InputStream initialStream = RetryProcessTest.class.getResourceAsStream("/retry-decisions-test.dmn");
		    byte[] buffer = new byte[initialStream.available()];
		    initialStream.read(buffer);
			File retry = new File("target"+File.separator+"retry-decisions.dmn");
		    OutputStream outStream = new FileOutputStream(retry);
		    outStream.write(buffer);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.setProperty("CAMUNDA_ENGINE_DB_DRIVER_CLASS", "org.h2.Driver");
		System.setProperty("CAMUNDA_ENGINE_DB_URL", "jdbc:h2:mem:camunda;DB_CLOSE_DELAY=1000");
		System.setProperty("CAMUNDA_ENGINE_DB_USERNAME", "sa");
		System.setProperty("CAMUNDA_ENGINE_DB_PASSWORD", "");
		
	    System.setProperty("OCE_RESOURCES_HOME", "target"+File.separator);

	}
	

	@Autowired
	CamelContext ctx;

	@Autowired
	ProcessEngine processEngine;

	@Test
	public void testRetryProcess() throws Exception {
		
		processEngine.getRepositoryService().createDeployment().addClasspathResource("bpmn/retry-process.bpmn").deploy();
		ProcessDefinition pd = processEngine.getRepositoryService().createProcessDefinitionQuery().processDefinitionKey("retry-process").singleResult();
		assertNotNull(pd);

		ProducerTemplate tpl = ctx.createProducerTemplate();
		Exchange e = ExchangeBuilder.anExchange(ctx).withBody(TestOrderBuilder.build("SimpleWirelessOrder").toString())
				.withProperty(CamundaBpmConstants.CAMUNDA_BPM_BUSINESS_KEY, "RetryProcessTest1").build();
		tpl.send("direct:startretry", e);
		String processInstanceId = e.getOut().getBody().toString();
		int loopBreak=0;
		while (processEngine.getRuntimeService().createProcessInstanceQuery().processInstanceId(processInstanceId).singleResult() != null){
			if (processEngine.getTaskService().createTaskQuery().active().singleResult() != null){
				System.out.println(processEngine.getTaskService().createTaskQuery().active().singleResult().getId());
				tpl = ctx.createProducerTemplate();
				Map<String,Object> order = TestOrderBuilder.build("SimpleWirelessOrder").getMapofMaps();
				order.put("orderComplete", true);
				e = ExchangeBuilder.anExchange(ctx).withBody(order)
						.withHeader("CamundaTaskId", processEngine.getTaskService().createTaskQuery().active().singleResult().getId()).build();
				System.out.println("direct:completetask"); 
				tpl.send("direct:completetask", e);
			}
			Thread.sleep(100);
			loopBreak++;
			if (loopBreak > 100) break;
		}
		
	}
	
}
