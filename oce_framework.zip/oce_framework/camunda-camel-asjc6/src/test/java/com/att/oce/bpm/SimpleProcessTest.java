/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.att.oce.bpm;

import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.history.HistoricProcessInstance;
import org.camunda.bpm.engine.history.HistoricVariableInstance;
import org.camunda.bpm.engine.repository.ProcessDefinition;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

import java.util.Map;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.ExchangeBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.bpm.camel.component.CamundaBpmConstants;
import com.att.oce.bpm.common.TestOrderBuilder;


@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration("classpath:camel-camunda-context.xml")
public class SimpleProcessTest {

	MockEndpoint service1;

	MockEndpoint service2;

	@Autowired
	CamelContext ctx;

	@Autowired
	ProcessEngine processEngine;

	@Test
	public void testRunProcessByKey() throws Exception {
		
		processEngine.getRepositoryService().createDeployment().addClasspathResource("bpmn/simple-process.bpmn").deploy();
		ProcessDefinition pd = processEngine.getRepositoryService().createProcessDefinitionQuery().processDefinitionKey("simple-process").singleResult();
		assertNotNull(pd);
		
		ProducerTemplate tpl = ctx.createProducerTemplate();
		Exchange e = ExchangeBuilder.anExchange(ctx).withBody(TestOrderBuilder.build("SimpleWirelessOrder").toString())
				.withProperty(CamundaBpmConstants.CAMUNDA_BPM_BUSINESS_KEY, "SimpleProcessTest1").build();
		tpl.send("direct:start",e );
		String processId = e.getOut().getBody().toString(); 
		
		HistoricProcessInstance current = processEngine.getHistoryService().createHistoricProcessInstanceQuery().processInstanceBusinessKey("SimpleProcessTest1").finished().singleResult();
		assertNotNull(current);
		assertEquals("Validate Search by Business Key works",current.getId(),processId);
		assertEquals("Validate if Business Key is stored","SimpleProcessTest1", current.getBusinessKey()); 
		HistoricVariableInstance orderVar = processEngine.getHistoryService().createHistoricVariableInstanceQuery().processInstanceId(current.getId()).variableName("order").singleResult();
		assertNotNull(orderVar);
		assertEquals("java.util.LinkedHashMap", orderVar.getValue().getClass().getName()); 
		Map<String,Object> orderMap = (Map<String,Object>)orderVar.getValue();
		assertEquals("T1473830709711", orderMap.get("customerOrderNumber").toString());
		
		HistoricVariableInstance ecVar = processEngine.getHistoryService().createHistoricVariableInstanceQuery().processInstanceId(current.getId()).variableName("executionContext").singleResult();
		assertNotNull(ecVar);
		Map<String,Object> ec = (Map<String,Object>)ecVar.getValue();
		assertEquals("testHeaderValue", ec.get("testHeaderKey").toString());

		HistoricVariableInstance testPropVar = processEngine.getHistoryService().createHistoricVariableInstanceQuery().processInstanceId(current.getId()).variableName("testPropertyKey").singleResult();
		assertNotNull(testPropVar);
		assertEquals("testPropertyValue", testPropVar.getValue().toString());
		
		HistoricVariableInstance indProp = processEngine.getHistoryService().createHistoricVariableInstanceQuery().processInstanceId(current.getId()).variableName("CustomerOrderNumber").singleResult();
		assertNotNull(indProp);
		assertEquals("customerOrderNumberValue", indProp.getValue().toString());
	}
	
	
	
}
