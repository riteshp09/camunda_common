package com.att.oce.beans.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@EnableAutoConfiguration
@ConfigurationProperties(prefix = "csi")
public class CsiConfig {

	private String version;
	private String originatorId;
	private String iotUsername;
	private String iotPassword;
	private String oceUsername;
	private String ocePassword;
	
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getOriginatorId() {
		return originatorId;
	}
	public void setOriginatorId(String originatorId) {
		this.originatorId = originatorId;
	}
	public String getIotUsername() {
		return iotUsername;
	}
	public void setIotUsername(String iotUsername) {
		this.iotUsername = iotUsername;
	}
	public String getIotPassword() {
		return iotPassword;
	}
	public void setIotPassword(String iotPassword) {
		this.iotPassword = iotPassword;
	}
	public String getOceUsername() {
		return oceUsername;
	}
	public void setOceUsername(String oceUsername) {
		this.oceUsername = oceUsername;
	}
	public String getOcePassword() {
		return ocePassword;
	}
	public void setOcePassword(String ocePassword) {
		this.ocePassword = ocePassword;
	}
	
}
