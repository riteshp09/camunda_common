package com.att.oce.beans.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@EnableAutoConfiguration
@ConfigurationProperties(prefix = "camunda")
public class CamundaConfig {

	private String history;
	private String metricsFlag;
	private String auditlogSystemProperty;
	private int auditlogLogLevel;
	private int executorCorepoolsize;
	private int executorMaxPoolSize;
	private String isATGEndPointAMQ;
	
	/* Process Order AMQ Properties*/
	private String processOrderQName;
	private String processOrderAMQURL;
	private String processOrderAMQUserName;
	private String processOrderAMQPassword;
	private int processOrderAMQConcurrentConsumers;
	private int processOrderAMQMaxConnections;

	/* AuditLog AMQ Properties*/
	private String auditLogQName;
	private String auditLogAMQURL;
	private String auditLogAMQUserName;
	private String auditLogAMQPassword;
	private int auditLogAMQConcurrentConsumers;
	private int auditLogAMQMaxConnections;

	/* ATG AMQ Properties*/
	private String atgAMQName;
	private String atgAMQURL;
	private String atgAMQUserName;
	private String atgAMQPassword;
	private int atgAMQConcurrentConsumers;
	private int atgAMQMaxConnections;
	
	public String getHistory() {
		return history;
	}
	public void setHistory(String history) {
		this.history = history;
	}
	public String getMetricsFlag() {
		return metricsFlag;
	}
	public void setMetricsFlag(String metricsFlag) {
		this.metricsFlag = metricsFlag;
	}
	public String getAuditlogSystemProperty() {
		return auditlogSystemProperty;
	}
	public void setAuditlogSystemProperty(String auditlogSystemProperty) {
		this.auditlogSystemProperty = auditlogSystemProperty;
	}
	public int getAuditlogLogLevel() {
		return auditlogLogLevel;
	}
	public void setAuditlogLogLevel(int auditlogLogLevel) {
		this.auditlogLogLevel = auditlogLogLevel;
	}
	public int getExecutorCorepoolsize() {
		return executorCorepoolsize;
	}
	public void setExecutorCorepoolsize(int executorCorepoolsize) {
		this.executorCorepoolsize = executorCorepoolsize;
	}
	public int getExecutorMaxPoolSize() {
		return executorMaxPoolSize;
	}
	public void setExecutorMaxPoolSize(int executorMaxPoolSize) {
		this.executorMaxPoolSize = executorMaxPoolSize;
	}
	public String getIsATGEndPointAMQ() {
		return isATGEndPointAMQ;
	}
	public void setIsATGEndPointAMQ(String isATGEndPointAMQ) {
		this.isATGEndPointAMQ = isATGEndPointAMQ;
	}
	public String getProcessOrderQName() {
		return processOrderQName;
	}
	public void setProcessOrderQName(String processOrderQName) {
		this.processOrderQName = processOrderQName;
	}
	public String getProcessOrderAMQURL() {
		return processOrderAMQURL;
	}
	public void setProcessOrderAMQURL(String processOrderAMQURL) {
		this.processOrderAMQURL = processOrderAMQURL;
	}
	public String getProcessOrderAMQUserName() {
		return processOrderAMQUserName;
	}
	public void setProcessOrderAMQUserName(String processOrderAMQUserName) {
		this.processOrderAMQUserName = processOrderAMQUserName;
	}
	public String getProcessOrderAMQPassword() {
		return processOrderAMQPassword;
	}
	public void setProcessOrderAMQPassword(String processOrderAMQPassword) {
		this.processOrderAMQPassword = processOrderAMQPassword;
	}
	public int getProcessOrderAMQConcurrentConsumers() {
		return processOrderAMQConcurrentConsumers;
	}
	public void setProcessOrderAMQConcurrentConsumers(int processOrderAMQConcurrentConsumers) {
		this.processOrderAMQConcurrentConsumers = processOrderAMQConcurrentConsumers;
	}
	public int getProcessOrderAMQMaxConnections() {
		return processOrderAMQMaxConnections;
	}
	public void setProcessOrderAMQMaxConnections(int processOrderAMQMaxConnections) {
		this.processOrderAMQMaxConnections = processOrderAMQMaxConnections;
	}
	public String getAuditLogQName() {
		return auditLogQName;
	}
	public void setAuditLogQName(String auditLogQName) {
		this.auditLogQName = auditLogQName;
	}
	public String getAuditLogAMQURL() {
		return auditLogAMQURL;
	}
	public void setAuditLogAMQURL(String auditLogAMQURL) {
		this.auditLogAMQURL = auditLogAMQURL;
	}
	public String getAuditLogAMQUserName() {
		return auditLogAMQUserName;
	}
	public void setAuditLogAMQUserName(String auditLogAMQUserName) {
		this.auditLogAMQUserName = auditLogAMQUserName;
	}
	public String getAuditLogAMQPassword() {
		return auditLogAMQPassword;
	}
	public void setAuditLogAMQPassword(String auditLogAMQPassword) {
		this.auditLogAMQPassword = auditLogAMQPassword;
	}
	public int getAuditLogAMQConcurrentConsumers() {
		return auditLogAMQConcurrentConsumers;
	}
	public void setAuditLogAMQConcurrentConsumers(int auditLogAMQConcurrentConsumers) {
		this.auditLogAMQConcurrentConsumers = auditLogAMQConcurrentConsumers;
	}
	public int getAuditLogAMQMaxConnections() {
		return auditLogAMQMaxConnections;
	}
	public void setAuditLogAMQMaxConnections(int auditLogAMQMaxConnections) {
		this.auditLogAMQMaxConnections = auditLogAMQMaxConnections;
	}
	public String getAtgAMQName() {
		return atgAMQName;
	}
	public void setAtgAMQName(String atgAMQName) {
		this.atgAMQName = atgAMQName;
	}
	public String getAtgAMQURL() {
		return atgAMQURL;
	}
	public void setAtgAMQURL(String atgAMQURL) {
		this.atgAMQURL = atgAMQURL;
	}
	public String getAtgAMQUserName() {
		return atgAMQUserName;
	}
	public void setAtgAMQUserName(String atgAMQUserName) {
		this.atgAMQUserName = atgAMQUserName;
	}
	public String getAtgAMQPassword() {
		return atgAMQPassword;
	}
	public void setAtgAMQPassword(String atgAMQPassword) {
		this.atgAMQPassword = atgAMQPassword;
	}
	public int getAtgAMQConcurrentConsumers() {
		return atgAMQConcurrentConsumers;
	}
	public void setAtgAMQConcurrentConsumers(int atgAMQConcurrentConsumers) {
		this.atgAMQConcurrentConsumers = atgAMQConcurrentConsumers;
	}
	public int getAtgAMQMaxConnections() {
		return atgAMQMaxConnections;
	}
	public void setAtgAMQMaxConnections(int atgAMQMaxConnections) {
		this.atgAMQMaxConnections = atgAMQMaxConnections;
	}
	
}
