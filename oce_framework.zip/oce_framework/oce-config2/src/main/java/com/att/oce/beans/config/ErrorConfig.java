package com.att.oce.beans.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@EnableAutoConfiguration
@ConfigurationProperties(prefix = "error.message")
public class ErrorConfig {

	private String nack001;
	private String nack500;
	private String nack501;
	private String nack502;
	private String nack503;
	private String nack504;
	private String nack505;
	private String nack506;
	private String nack507;
	private String nack508;
	private String nack509;
	private String nack510;
	private String nack511;
	private String nack512;
	private String nack513;
	private String nack514;
	private String nack515;
	private String nack516;
	private String nack517;
	private String nack518;
	private String nack519;
	private String nack520;
	private String nack521;
	private String nack522;
	private String nack523;
	private String nack524;
	private String nack525;
	private String nack526;
	private String nack527;
	private String nack528;
	private String nack529;
	private String nack530;
	private String nack531;
	private String nack532;
	private String nack533;
	private String nack534;
	private String nack535;
	private String nack536;
	private String nack537;
	private String nack538;
	private String nack539;
	private String nack540;
	private String nack541;
	private String nack542;
	private String nack543;
	private String nack544;
	private String nack545;
	private String nack546;
	private String nack547;
	private String nack548;
	private String nack549;
	private String nack550;
	private String nack551;
	private String nack552;
	private String nack553;
	private String nack554;
	private String nack555;
	private String nack556;
	private String nack557;
	private String nack558;
	private String nack559;
	private String nack560;
	private String nack561;
	private String nack562;
	private String nack563;
	private String nack564;
	private String nack565;
	private String nack566;
	private String nack567;
	private String nack568;
	private String nack569;
	private String nack570;
	private String nack571;
	private String nack572;
	private String nack573;
	private String nack574;
	private String nack575;
	private String nack576;
	private String nack577;
	private String nack578;
	private String nack579;
	private String nack580;
	private String nack581;
	private String nack582;
	private String nack583;
	private String nack584;
	private String nack585;
	private String nack586;
	private String nack587;
	private String nack593;
	private String nack596;
	private String nack598;
	private String nack599;
	private String nack600;
	private String nack601;
	private String nack602;
	private String nack603;
	private String nack604;
	private String nack605;
	private String nack608;
	private String nack609;
	private String nack611;
	private String nack612;
	private String nack613;
	private String nack614;
	private String nack615;
	private String nack616;
	private String nack617;
	private String nack618;
	private String nack619;
	private String nack620;
	private String nack621;
	private String nack622;
	private String nack623;
	private String nack624;
	private String nack625;
	private String nack626;
	private String nack627;
	private String nack628;
	private String nack631;
	private String nack632;
	private String nack641;
	private String nack642;

	private String nack800;
	private String nack801;
	private String nack802;
	private String nack803;
	private String nack804;
	private String nack805;
	private String nack806;
	private String nack807;
	private String nack808;
	private String nack809;
	private String nack810;
	private String nack812;
	private String nack813;
	private String nack814;
	private String nack815;
	private String nack816;
	private String nack817;
	private String nack818;
	private String nack819;
	private String nack820;
	private String nack822;
	private String nack823;
	private String nack824;
	private String nack825;
	private String nack826;
	private String nack827;
	private String nack829;
	private String nack830;
	private String nack831;
	private String nack832;
	private String nack833;
	private String nack834;
	private String nack835;
	private String nack836;
	private String nack837;
	private String nack838;
	private String nack839;
	private String nack840;
	private String nack841;
	private String nack842;
	private String nack844;
	private String nack845;
	private String nack846;
	private String nack847;
	private String nack848;
	private String nack849;
	private String nack853;
	private String nack854;
	private String nack855;
	private String nack856;
	private String nack857;
	private String nack858;
	private String nack859;

	public String getNack001() {
		return nack001;
	}
	public void setNack001(String nack001) {
		this.nack001 = nack001;
	}
	public String getNack500() {
		return nack500;
	}
	public void setNack500(String nack500) {
		this.nack500 = nack500;
	}
	public String getNack501() {
		return nack501;
	}
	public void setNack501(String nack501) {
		this.nack501 = nack501;
	}
	public String getNack502() {
		return nack502;
	}
	public void setNack502(String nack502) {
		this.nack502 = nack502;
	}
	public String getNack503() {
		return nack503;
	}
	public void setNack503(String nack503) {
		this.nack503 = nack503;
	}
	public String getNack504() {
		return nack504;
	}
	public void setNack504(String nack504) {
		this.nack504 = nack504;
	}
	public String getNack505() {
		return nack505;
	}
	public void setNack505(String nack505) {
		this.nack505 = nack505;
	}
	public String getNack506() {
		return nack506;
	}
	public void setNack506(String nack506) {
		this.nack506 = nack506;
	}
	public String getNack507() {
		return nack507;
	}
	public void setNack507(String nack507) {
		this.nack507 = nack507;
	}
	public String getNack508() {
		return nack508;
	}
	public void setNack508(String nack508) {
		this.nack508 = nack508;
	}
	public String getNack509() {
		return nack509;
	}
	public void setNack509(String nack509) {
		this.nack509 = nack509;
	}
	public String getNack510() {
		return nack510;
	}
	public void setNack510(String nack510) {
		this.nack510 = nack510;
	}
	public String getNack511() {
		return nack511;
	}
	public void setNack511(String nack511) {
		this.nack511 = nack511;
	}
	public String getNack512() {
		return nack512;
	}
	public void setNack512(String nack512) {
		this.nack512 = nack512;
	}
	public String getNack513() {
		return nack513;
	}
	public void setNack513(String nack513) {
		this.nack513 = nack513;
	}
	public String getNack514() {
		return nack514;
	}
	public void setNack514(String nack514) {
		this.nack514 = nack514;
	}
	public String getNack515() {
		return nack515;
	}
	public void setNack515(String nack515) {
		this.nack515 = nack515;
	}
	public String getNack516() {
		return nack516;
	}
	public void setNack516(String nack516) {
		this.nack516 = nack516;
	}
	public String getNack517() {
		return nack517;
	}
	public void setNack517(String nack517) {
		this.nack517 = nack517;
	}
	public String getNack518() {
		return nack518;
	}
	public void setNack518(String nack518) {
		this.nack518 = nack518;
	}
	public String getNack519() {
		return nack519;
	}
	public void setNack519(String nack519) {
		this.nack519 = nack519;
	}
	public String getNack520() {
		return nack520;
	}
	public void setNack520(String nack520) {
		this.nack520 = nack520;
	}
	public String getNack521() {
		return nack521;
	}
	public void setNack521(String nack521) {
		this.nack521 = nack521;
	}
	public String getNack522() {
		return nack522;
	}
	public void setNack522(String nack522) {
		this.nack522 = nack522;
	}
	public String getNack523() {
		return nack523;
	}
	public void setNack523(String nack523) {
		this.nack523 = nack523;
	}
	public String getNack524() {
		return nack524;
	}
	public void setNack524(String nack524) {
		this.nack524 = nack524;
	}
	public String getNack525() {
		return nack525;
	}
	public void setNack525(String nack525) {
		this.nack525 = nack525;
	}
	public String getNack526() {
		return nack526;
	}
	public void setNack526(String nack526) {
		this.nack526 = nack526;
	}
	public String getNack527() {
		return nack527;
	}
	public void setNack527(String nack527) {
		this.nack527 = nack527;
	}
	public String getNack528() {
		return nack528;
	}
	public void setNack528(String nack528) {
		this.nack528 = nack528;
	}
	public String getNack529() {
		return nack529;
	}
	public void setNack529(String nack529) {
		this.nack529 = nack529;
	}
	public String getNack530() {
		return nack530;
	}
	public void setNack530(String nack530) {
		this.nack530 = nack530;
	}
	public String getNack531() {
		return nack531;
	}
	public void setNack531(String nack531) {
		this.nack531 = nack531;
	}
	public String getNack532() {
		return nack532;
	}
	public void setNack532(String nack532) {
		this.nack532 = nack532;
	}
	public String getNack533() {
		return nack533;
	}
	public void setNack533(String nack533) {
		this.nack533 = nack533;
	}
	public String getNack534() {
		return nack534;
	}
	public void setNack534(String nack534) {
		this.nack534 = nack534;
	}
	public String getNack535() {
		return nack535;
	}
	public void setNack535(String nack535) {
		this.nack535 = nack535;
	}
	public String getNack536() {
		return nack536;
	}
	public void setNack536(String nack536) {
		this.nack536 = nack536;
	}
	public String getNack537() {
		return nack537;
	}
	public void setNack537(String nack537) {
		this.nack537 = nack537;
	}
	public String getNack538() {
		return nack538;
	}
	public void setNack538(String nack538) {
		this.nack538 = nack538;
	}
	public String getNack539() {
		return nack539;
	}
	public void setNack539(String nack539) {
		this.nack539 = nack539;
	}
	public String getNack540() {
		return nack540;
	}
	public void setNack540(String nack540) {
		this.nack540 = nack540;
	}
	public String getNack541() {
		return nack541;
	}
	public void setNack541(String nack541) {
		this.nack541 = nack541;
	}
	public String getNack542() {
		return nack542;
	}
	public void setNack542(String nack542) {
		this.nack542 = nack542;
	}
	public String getNack543() {
		return nack543;
	}
	public void setNack543(String nack543) {
		this.nack543 = nack543;
	}
	public String getNack544() {
		return nack544;
	}
	public void setNack544(String nack544) {
		this.nack544 = nack544;
	}
	public String getNack545() {
		return nack545;
	}
	public void setNack545(String nack545) {
		this.nack545 = nack545;
	}
	public String getNack546() {
		return nack546;
	}
	public void setNack546(String nack546) {
		this.nack546 = nack546;
	}
	public String getNack547() {
		return nack547;
	}
	public void setNack547(String nack547) {
		this.nack547 = nack547;
	}
	public String getNack548() {
		return nack548;
	}
	public void setNack548(String nack548) {
		this.nack548 = nack548;
	}
	public String getNack549() {
		return nack549;
	}
	public void setNack549(String nack549) {
		this.nack549 = nack549;
	}
	public String getNack550() {
		return nack550;
	}
	public void setNack550(String nack550) {
		this.nack550 = nack550;
	}
	public String getNack551() {
		return nack551;
	}
	public void setNack551(String nack551) {
		this.nack551 = nack551;
	}
	public String getNack552() {
		return nack552;
	}
	public void setNack552(String nack552) {
		this.nack552 = nack552;
	}
	public String getNack553() {
		return nack553;
	}
	public void setNack553(String nack553) {
		this.nack553 = nack553;
	}
	public String getNack554() {
		return nack554;
	}
	public void setNack554(String nack554) {
		this.nack554 = nack554;
	}
	public String getNack555() {
		return nack555;
	}
	public void setNack555(String nack555) {
		this.nack555 = nack555;
	}
	public String getNack556() {
		return nack556;
	}
	public void setNack556(String nack556) {
		this.nack556 = nack556;
	}
	public String getNack557() {
		return nack557;
	}
	public void setNack557(String nack557) {
		this.nack557 = nack557;
	}
	public String getNack558() {
		return nack558;
	}
	public void setNack558(String nack558) {
		this.nack558 = nack558;
	}
	public String getNack559() {
		return nack559;
	}
	public void setNack559(String nack559) {
		this.nack559 = nack559;
	}
	public String getNack560() {
		return nack560;
	}
	public void setNack560(String nack560) {
		this.nack560 = nack560;
	}
	public String getNack561() {
		return nack561;
	}
	public void setNack561(String nack561) {
		this.nack561 = nack561;
	}
	public String getNack562() {
		return nack562;
	}
	public void setNack562(String nack562) {
		this.nack562 = nack562;
	}
	public String getNack563() {
		return nack563;
	}
	public void setNack563(String nack563) {
		this.nack563 = nack563;
	}
	public String getNack564() {
		return nack564;
	}
	public void setNack564(String nack564) {
		this.nack564 = nack564;
	}
	public String getNack565() {
		return nack565;
	}
	public void setNack565(String nack565) {
		this.nack565 = nack565;
	}
	public String getNack566() {
		return nack566;
	}
	public void setNack566(String nack566) {
		this.nack566 = nack566;
	}
	public String getNack567() {
		return nack567;
	}
	public void setNack567(String nack567) {
		this.nack567 = nack567;
	}
	public String getNack568() {
		return nack568;
	}
	public void setNack568(String nack568) {
		this.nack568 = nack568;
	}
	public String getNack569() {
		return nack569;
	}
	public void setNack569(String nack569) {
		this.nack569 = nack569;
	}
	public String getNack570() {
		return nack570;
	}
	public void setNack570(String nack570) {
		this.nack570 = nack570;
	}
	public String getNack571() {
		return nack571;
	}
	public void setNack571(String nack571) {
		this.nack571 = nack571;
	}
	public String getNack572() {
		return nack572;
	}
	public void setNack572(String nack572) {
		this.nack572 = nack572;
	}
	public String getNack573() {
		return nack573;
	}
	public void setNack573(String nack573) {
		this.nack573 = nack573;
	}
	public String getNack574() {
		return nack574;
	}
	public void setNack574(String nack574) {
		this.nack574 = nack574;
	}
	public String getNack575() {
		return nack575;
	}
	public void setNack575(String nack575) {
		this.nack575 = nack575;
	}
	public String getNack576() {
		return nack576;
	}
	public void setNack576(String nack576) {
		this.nack576 = nack576;
	}
	public String getNack577() {
		return nack577;
	}
	public void setNack577(String nack577) {
		this.nack577 = nack577;
	}
	public String getNack578() {
		return nack578;
	}
	public void setNack578(String nack578) {
		this.nack578 = nack578;
	}
	public String getNack579() {
		return nack579;
	}
	public void setNack579(String nack579) {
		this.nack579 = nack579;
	}
	public String getNack580() {
		return nack580;
	}
	public void setNack580(String nack580) {
		this.nack580 = nack580;
	}
	public String getNack581() {
		return nack581;
	}
	public void setNack581(String nack581) {
		this.nack581 = nack581;
	}
	public String getNack582() {
		return nack582;
	}
	public void setNack582(String nack582) {
		this.nack582 = nack582;
	}
	public String getNack583() {
		return nack583;
	}
	public void setNack583(String nack583) {
		this.nack583 = nack583;
	}
	public String getNack584() {
		return nack584;
	}
	public void setNack584(String nack584) {
		this.nack584 = nack584;
	}
	public String getNack585() {
		return nack585;
	}
	public void setNack585(String nack585) {
		this.nack585 = nack585;
	}
	public String getNack586() {
		return nack586;
	}
	public void setNack586(String nack586) {
		this.nack586 = nack586;
	}
	public String getNack587() {
		return nack587;
	}
	public void setNack587(String nack587) {
		this.nack587 = nack587;
	}
	public String getNack593() {
		return nack593;
	}
	public void setNack593(String nack593) {
		this.nack593 = nack593;
	}
	public String getNack596() {
		return nack596;
	}
	public void setNack596(String nack596) {
		this.nack596 = nack596;
	}
	public String getNack598() {
		return nack598;
	}
	public void setNack598(String nack598) {
		this.nack598 = nack598;
	}
	public String getNack599() {
		return nack599;
	}
	public void setNack599(String nack599) {
		this.nack599 = nack599;
	}
	public String getNack600() {
		return nack600;
	}
	public void setNack600(String nack600) {
		this.nack600 = nack600;
	}
	public String getNack601() {
		return nack601;
	}
	public void setNack601(String nack601) {
		this.nack601 = nack601;
	}
	public String getNack602() {
		return nack602;
	}
	public void setNack602(String nack602) {
		this.nack602 = nack602;
	}
	public String getNack603() {
		return nack603;
	}
	public void setNack603(String nack603) {
		this.nack603 = nack603;
	}
	public String getNack604() {
		return nack604;
	}
	public void setNack604(String nack604) {
		this.nack604 = nack604;
	}
	public String getNack605() {
		return nack605;
	}
	public void setNack605(String nack605) {
		this.nack605 = nack605;
	}
	public String getNack608() {
		return nack608;
	}
	public void setNack608(String nack608) {
		this.nack608 = nack608;
	}
	public String getNack609() {
		return nack609;
	}
	public void setNack609(String nack609) {
		this.nack609 = nack609;
	}
	public String getNack611() {
		return nack611;
	}
	public void setNack611(String nack611) {
		this.nack611 = nack611;
	}
	public String getNack612() {
		return nack612;
	}
	public void setNack612(String nack612) {
		this.nack612 = nack612;
	}
	public String getNack613() {
		return nack613;
	}
	public void setNack613(String nack613) {
		this.nack613 = nack613;
	}
	public String getNack614() {
		return nack614;
	}
	public void setNack614(String nack614) {
		this.nack614 = nack614;
	}
	public String getNack615() {
		return nack615;
	}
	public void setNack615(String nack615) {
		this.nack615 = nack615;
	}
	public String getNack616() {
		return nack616;
	}
	public void setNack616(String nack616) {
		this.nack616 = nack616;
	}
	public String getNack617() {
		return nack617;
	}
	public void setNack617(String nack617) {
		this.nack617 = nack617;
	}
	public String getNack618() {
		return nack618;
	}
	public void setNack618(String nack618) {
		this.nack618 = nack618;
	}
	public String getNack619() {
		return nack619;
	}
	public void setNack619(String nack619) {
		this.nack619 = nack619;
	}
	public String getNack620() {
		return nack620;
	}
	public void setNack620(String nack620) {
		this.nack620 = nack620;
	}
	public String getNack621() {
		return nack621;
	}
	public void setNack621(String nack621) {
		this.nack621 = nack621;
	}
	public String getNack622() {
		return nack622;
	}
	public void setNack622(String nack622) {
		this.nack622 = nack622;
	}
	public String getNack623() {
		return nack623;
	}
	public void setNack623(String nack623) {
		this.nack623 = nack623;
	}
	public String getNack624() {
		return nack624;
	}
	public void setNack624(String nack624) {
		this.nack624 = nack624;
	}
	public String getNack625() {
		return nack625;
	}
	public void setNack625(String nack625) {
		this.nack625 = nack625;
	}
	public String getNack626() {
		return nack626;
	}
	public void setNack626(String nack626) {
		this.nack626 = nack626;
	}
	public String getNack627() {
		return nack627;
	}
	public void setNack627(String nack627) {
		this.nack627 = nack627;
	}
	public String getNack628() {
		return nack628;
	}
	public void setNack628(String nack628) {
		this.nack628 = nack628;
	}
	public String getNack631() {
		return nack631;
	}
	public void setNack631(String nack631) {
		this.nack631 = nack631;
	}
	public String getNack632() {
		return nack632;
	}
	public void setNack632(String nack632) {
		this.nack632 = nack632;
	}
	public String getNack641() {
		return nack641;
	}
	public void setNack641(String nack641) {
		this.nack641 = nack641;
	}
	public String getNack642() {
		return nack642;
	}
	public void setNack642(String nack642) {
		this.nack642 = nack642;
	}
	public String getNack800() {
		return nack800;
	}
	public void setNack800(String nack800) {
		this.nack800 = nack800;
	}
	public String getNack801() {
		return nack801;
	}
	public void setNack801(String nack801) {
		this.nack801 = nack801;
	}
	public String getNack802() {
		return nack802;
	}
	public void setNack802(String nack802) {
		this.nack802 = nack802;
	}
	public String getNack803() {
		return nack803;
	}
	public void setNack803(String nack803) {
		this.nack803 = nack803;
	}
	public String getNack804() {
		return nack804;
	}
	public void setNack804(String nack804) {
		this.nack804 = nack804;
	}
	public String getNack805() {
		return nack805;
	}
	public void setNack805(String nack805) {
		this.nack805 = nack805;
	}
	public String getNack806() {
		return nack806;
	}
	public void setNack806(String nack806) {
		this.nack806 = nack806;
	}
	public String getNack807() {
		return nack807;
	}
	public void setNack807(String nack807) {
		this.nack807 = nack807;
	}
	public String getNack808() {
		return nack808;
	}
	public void setNack808(String nack808) {
		this.nack808 = nack808;
	}
	public String getNack809() {
		return nack809;
	}
	public void setNack809(String nack809) {
		this.nack809 = nack809;
	}
	public String getNack810() {
		return nack810;
	}
	public void setNack810(String nack810) {
		this.nack810 = nack810;
	}
	public String getNack812() {
		return nack812;
	}
	public void setNack812(String nack812) {
		this.nack812 = nack812;
	}
	public String getNack813() {
		return nack813;
	}
	public void setNack813(String nack813) {
		this.nack813 = nack813;
	}
	public String getNack814() {
		return nack814;
	}
	public void setNack814(String nack814) {
		this.nack814 = nack814;
	}
	public String getNack815() {
		return nack815;
	}
	public void setNack815(String nack815) {
		this.nack815 = nack815;
	}
	public String getNack816() {
		return nack816;
	}
	public void setNack816(String nack816) {
		this.nack816 = nack816;
	}
	public String getNack817() {
		return nack817;
	}
	public void setNack817(String nack817) {
		this.nack817 = nack817;
	}
	public String getNack818() {
		return nack818;
	}
	public void setNack818(String nack818) {
		this.nack818 = nack818;
	}
	public String getNack819() {
		return nack819;
	}
	public void setNack819(String nack819) {
		this.nack819 = nack819;
	}
	public String getNack820() {
		return nack820;
	}
	public void setNack820(String nack820) {
		this.nack820 = nack820;
	}
	public String getNack822() {
		return nack822;
	}
	public void setNack822(String nack822) {
		this.nack822 = nack822;
	}
	public String getNack823() {
		return nack823;
	}
	public void setNack823(String nack823) {
		this.nack823 = nack823;
	}
	public String getNack824() {
		return nack824;
	}
	public void setNack824(String nack824) {
		this.nack824 = nack824;
	}
	public String getNack825() {
		return nack825;
	}
	public void setNack825(String nack825) {
		this.nack825 = nack825;
	}
	public String getNack826() {
		return nack826;
	}
	public void setNack826(String nack826) {
		this.nack826 = nack826;
	}
	public String getNack827() {
		return nack827;
	}
	public void setNack827(String nack827) {
		this.nack827 = nack827;
	}
	public String getNack829() {
		return nack829;
	}
	public void setNack829(String nack829) {
		this.nack829 = nack829;
	}
	public String getNack830() {
		return nack830;
	}
	public void setNack830(String nack830) {
		this.nack830 = nack830;
	}
	public String getNack831() {
		return nack831;
	}
	public void setNack831(String nack831) {
		this.nack831 = nack831;
	}
	public String getNack832() {
		return nack832;
	}
	public void setNack832(String nack832) {
		this.nack832 = nack832;
	}
	public String getNack833() {
		return nack833;
	}
	public void setNack833(String nack833) {
		this.nack833 = nack833;
	}
	public String getNack834() {
		return nack834;
	}
	public void setNack834(String nack834) {
		this.nack834 = nack834;
	}
	public String getNack835() {
		return nack835;
	}
	public void setNack835(String nack835) {
		this.nack835 = nack835;
	}
	public String getNack836() {
		return nack836;
	}
	public void setNack836(String nack836) {
		this.nack836 = nack836;
	}
	public String getNack837() {
		return nack837;
	}
	public void setNack837(String nack837) {
		this.nack837 = nack837;
	}
	public String getNack838() {
		return nack838;
	}
	public void setNack838(String nack838) {
		this.nack838 = nack838;
	}
	public String getNack839() {
		return nack839;
	}
	public void setNack839(String nack839) {
		this.nack839 = nack839;
	}
	public String getNack840() {
		return nack840;
	}
	public void setNack840(String nack840) {
		this.nack840 = nack840;
	}
	public String getNack841() {
		return nack841;
	}
	public void setNack841(String nack841) {
		this.nack841 = nack841;
	}
	public String getNack842() {
		return nack842;
	}
	public void setNack842(String nack842) {
		this.nack842 = nack842;
	}
	public String getNack844() {
		return nack844;
	}
	public void setNack844(String nack844) {
		this.nack844 = nack844;
	}
	public String getNack845() {
		return nack845;
	}
	public void setNack845(String nack845) {
		this.nack845 = nack845;
	}
	public String getNack846() {
		return nack846;
	}
	public void setNack846(String nack846) {
		this.nack846 = nack846;
	}
	public String getNack847() {
		return nack847;
	}
	public void setNack847(String nack847) {
		this.nack847 = nack847;
	}
	public String getNack848() {
		return nack848;
	}
	public void setNack848(String nack848) {
		this.nack848 = nack848;
	}
	public String getNack849() {
		return nack849;
	}
	public void setNack849(String nack849) {
		this.nack849 = nack849;
	}
	public String getNack853() {
		return nack853;
	}
	public void setNack853(String nack853) {
		this.nack853 = nack853;
	}
	public String getNack854() {
		return nack854;
	}
	public void setNack854(String nack854) {
		this.nack854 = nack854;
	}
	public String getNack855() {
		return nack855;
	}
	public void setNack855(String nack855) {
		this.nack855 = nack855;
	}
	public String getNack856() {
		return nack856;
	}
	public void setNack856(String nack856) {
		this.nack856 = nack856;
	}
	public String getNack857() {
		return nack857;
	}
	public void setNack857(String nack857) {
		this.nack857 = nack857;
	}
	public String getNack858() {
		return nack858;
	}
	public void setNack858(String nack858) {
		this.nack858 = nack858;
	}
	public String getNack859() {
		return nack859;
	}
	public void setNack859(String nack859) {
		this.nack859 = nack859;
	}

}