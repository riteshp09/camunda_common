package com.att.oce.config.components.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.oce.beans.config.CsiConfig;

@RunWith(SpringRunner.class)
@ActiveProfiles("dev")
@SpringBootTest(classes=CsiConfig.class)
public class CsiConfigTest {

	@Autowired CsiConfig config;
	
	@Test
	public void testCsiConfig() {
		assertEquals("v116",config.getVersion());
		assertEquals("OCE",config.getOriginatorId());
		assertEquals("oce_iot0826",config.getIotPassword());
		assertEquals("oce_iot",config.getIotUsername());
		assertEquals("oce0606",config.getOcePassword());
		assertEquals("oce",config.getOceUsername());
	}

}
