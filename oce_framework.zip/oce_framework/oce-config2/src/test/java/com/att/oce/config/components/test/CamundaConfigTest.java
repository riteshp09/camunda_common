package com.att.oce.config.components.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.oce.beans.config.CamundaConfig;

@RunWith(SpringRunner.class)
@ActiveProfiles("dev")
@SpringBootTest(classes=CamundaConfig.class)
public class CamundaConfigTest {

	@Autowired CamundaConfig config;
	
	@Test
	public void testCamundaConfig() {
		assertEquals("audit",config.getHistory());
		assertEquals("OFF",config.getMetricsFlag());
		assertEquals("DETAIL",config.getAuditlogSystemProperty());
		assertEquals(3,config.getAuditlogLogLevel());
		assertEquals(500,config.getExecutorCorepoolsize());
		assertEquals(500,config.getExecutorMaxPoolSize());
		assertEquals("false",config.getIsATGEndPointAMQ());
		assertEquals("OCE_WIRLESS_UPGRADE_Q",config.getProcessOrderQName());
		assertEquals("failover:(tcp://localhost:61616)",config.getProcessOrderAMQURL());
		assertEquals("admin",config.getProcessOrderAMQUserName());
		assertEquals("admin",config.getProcessOrderAMQPassword());
		assertEquals(10,config.getProcessOrderAMQConcurrentConsumers());
		assertEquals(8,config.getProcessOrderAMQMaxConnections());
		assertEquals("AuditLog",config.getAuditLogQName());
		assertEquals("failover:(tcp://ocehyt02stracr01.vci.att.com:8501,tcp://ocehyt02stracr02.vci.att.com:8501)",config.getAuditLogAMQURL());
		assertEquals("ocefuseuser",config.getAuditLogAMQUserName());
		assertEquals("ocefuseuser",config.getAuditLogAMQPassword());
		assertEquals(10,config.getAuditLogAMQConcurrentConsumers());
		assertEquals(8,config.getAuditLogAMQMaxConnections());	
		assertEquals("ATG_AMQ",config.getAtgAMQName());
		assertEquals("failover:(tcp://ocehyt02stracr01.vci.att.com:8501,tcp://ocehyt02stracr02.vci.att.com:8501)",config.getAtgAMQURL());
		assertEquals("ocefuseuser",config.getAtgAMQUserName());
		assertEquals("ocefuseuser",config.getAtgAMQPassword());
		assertEquals(10,config.getAtgAMQConcurrentConsumers());
		assertEquals(8,config.getAtgAMQMaxConnections());	
	}

}
