## About

oce-resources holds the centralized file-based configurations for AJSC 5.x based applications.
For AJSC 6.x applications it would require necessary adjustment.

## Configuration Resources

oce-resources hold below kind of file-based configuration :

config file | Description
--- | --- |
bootstrap-config.yml | configuration properties required to initialized the application and not expected to be changed on-the-fly. e.g. database connection endpoints, JMS provider endpoints, credentials,etc. The environment specific variants should be defined as bootstrap-config-{env}.yml and are expected to be merged at runtime. Env specific properties would take precedence over the bootstrap-config.yml properties.
dynamic-config.yml |  Configuration properties that can change the application runtime behavior and does not require full restart of the application. The environment specific variants should be defined as dynamic-config-{env}.yml and are expected to be merged at runtime. Env specific properties would take precedence over the dynamic-config.yml properties.
*-decisions.dmn | Various .dmn files to define DMN decition tables. These file may have environment specific variants, but they are not expected to be merged with the base .dmn file.  e.g. **retry-decisions.dmn** defines the decisions rules for the API retries based on errorCode and api name.

## Consumer libraries

Below are examples of consumer libraries which loads the subset of the oce-resources configuration files for their own cause:

Library | Description
--- | ---
oce-config | loads the bootstrap-config.yml and dynamic-config.yml as properties. Provides convenient classes to access injected properties and unittests.
retry-decisions | loads the retry-decisions.dmn and provides unittests.
order-terminal-state-decisions | loads the order-terminal-state-decisions.yml and provides   unittests.

## Usage & Guidelines

1. oce-resources should be versioned, packaged and made available to nexus repository as .jar maven artifact.
2. The content of the oce-resources should be **unpack**ed to the OCE_RESOURCES_HOME location on the file-system.e.g. OCE_RESOURCES_HOME=/opt/app/oce-resources/
3. The applications/libraries are expected to load required resources using the OCE_RESOURCES_HOME.
4. To use the env specific configuration properties, set OCE_ENV accordingly. e.g. OCE_ENV=test.

> This common file location approach most likely would be changed in AJSC 6.x

### DOs

- **Whenever the oce-resources are changed, make sure the unittests for the relevant consumer libraries are passed successfully. YAML files are subjected to have accidental syntatical errors**

### DON'Ts

- DON'T add maven dependency of oce-resources in your application. The files in oce-resources should be accessed as file system resources at runtime.
- DON'T add any Java classes to the oce-resources.

## Design Goal of centralized configuration

As per microservices architecture, OCE would be componentized into many indepenent deployment units running across many micro-containers.

> @TODO provide wiki link with Microservices componentization details

AJSC development framework is one of the key enabler in moving towards microservices architecture.
AJSC framework focus towards developing self-contained, indepenendly deployable application, where every application has its local configuration.

However, there are some configuration aspects which needs to be controlled at courser-grain level
e.g.

Configuration  | Remark
--- | --- | ---  
CSI/GRM Endpoints | All/Group of OCE microservices would be pointing to single CSI env.     
Database Config     | Physical database server coordinates may be shared acroos microservices
Messaging Endpoints | Microservices integration using backbone messaging layer
API retry rules | Retry rules based on errorcode, api & other contextual stuff
API error-handling rules | Ignore, Skip APIs
Order Status/SubStatus | Status/SubStatus based on API results
Feature Flags   | Enable/Disable functional features which span across multiple microservices

The above examples provides idea about the need to manage the configuration at courser-grain level.
