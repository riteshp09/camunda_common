package com.att.oce.bpm.common;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Hello world!
 *
 */
public class TestOrderBuilder 
{
	private InputStream input;
	
	private TestOrderBuilder(String resourceName,InputStream input){
		this.input = input;
	}
	
	static String convertStreamToString(java.io.InputStream is) {
	    java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
	    return s.hasNext() ? s.next() : "";
	}

   
	public static TestOrderBuilder build(String resourceName){
		if (!resourceName.startsWith("/"))
			resourceName = "/"+resourceName;
		if (!resourceName.toLowerCase().endsWith(".json") && !resourceName.toLowerCase().endsWith(".xml"))
			resourceName = resourceName+".json";
		InputStream i = TestOrderBuilder.class.getResourceAsStream(resourceName);
		if (i == null){
			resourceName = "/data"+resourceName;
			i = TestOrderBuilder.class.getResourceAsStream(resourceName);
		}
		
		return new TestOrderBuilder(resourceName,i);
	}
	
	public Map<String,Object> getMapofMaps() throws JSONException{
		return jsonToMap(convertStreamToString(this.input));
	}
	
	public static StringBuilder toJsonString(Object object) throws JSONException {
		if (object instanceof Map<?, ?>) {
			return new StringBuilder(new JSONObject((Map) object).toString(2));
		}
		return new StringBuilder("");
	}

	public static Map<String, Object> jsonToMap(String json) throws JSONException {
		return toMap(new JSONObject(json));
	}

	public static Map<String, Object> jsonToMap(JSONObject json) throws JSONException {
		Map<String, Object> retMap = new LinkedHashMap<String, Object>();

		if (json != JSONObject.NULL) {
			retMap = toMap(json);
		}
		return retMap;
	}

	private static Map<String, Object> toMap(JSONObject object) throws JSONException {
		Map<String, Object> map = new LinkedHashMap<String, Object>();

		Iterator<String> keysItr = object.keys();
		while (keysItr.hasNext()) {
			String key = keysItr.next();
			Object value = object.get(key);

			if (value instanceof JSONArray) {
				value = toList((JSONArray) value);
			}

			else if (value instanceof JSONObject) {
				value = toMap((JSONObject) value);
			}
			map.put(key, value);
		}
		return map;
	}

	private static List<Object> toList(JSONArray array) throws JSONException {
		
		List<Object> list = new ArrayList<Object>();
		for (int i = 0; i < array.length(); i++) {
			Object value = array.get(i);
			if (value instanceof JSONArray) {
				value = toList((JSONArray) value);
			}

			else if (value instanceof JSONObject) {
				value = toMap((JSONObject) value);
			}
			list.add(value);
		}
		return list;
	}
	
	@Override
	public String toString() {
		return convertStreamToString(input);
		
	}
	
}
