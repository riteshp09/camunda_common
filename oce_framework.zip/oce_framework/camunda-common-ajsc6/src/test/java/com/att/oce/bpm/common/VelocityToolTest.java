package com.att.oce.bpm.common;

import org.junit.Test;

import com.att.oce.bpm.common.util.VelocityTool;

import static org.junit.Assert.*;


/**
 * Unit test for simple App.
 */
public class VelocityToolTest
{
    @Test
    public void testGetXmlDateTime()
    {
    	assertNotNull(VelocityTool.getXmlDateTime());
    }
    

}

