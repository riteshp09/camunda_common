package com.att.oce.bpm.common.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class VelocityTool {
	
	private static SimpleDateFormat xmlDateTimeformat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

	public static String getXmlDateTime(){
		return xmlDateTimeformat.format(new Date());
	}
	
	public static String getUUId(){
		return java.util.UUID.randomUUID().toString();
	}
    
}
