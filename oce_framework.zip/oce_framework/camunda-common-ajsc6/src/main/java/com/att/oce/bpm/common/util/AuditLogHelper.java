package com.att.oce.bpm.common.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;
import org.slf4j.MarkerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.oce.beans.config.CamundaConfig;
import com.att.oce.dblog.util.AuditLog;

public class AuditLogHelper {

	@Autowired CamundaConfig camundaConfig;
	
	public static String AUDITLOG_REQUEST_ID = "AuditLogRequestId";
	public static String AUDITLOG_CUSTOMER_ORDER_NUMBER = "AuditLogCustomerOrderNumber";
	public static String AUDITLOG_ORDER_NUMBER = "AuditLogOrderNumber";
	public static String AUDITLOG_CONVERSATION_ID = "AuditLogConversationId";
	public static String AUDITLOG_REQUEST_TIME = "AuditLogRequestTime";
	public static String AUDITLOG_RESPONSE_TIME = "AuditLogResponseTime";
	public static String AUDITLOG_INTERFACE_NAME = "AuditLogInterfaceName";
	public static String AUDITLOG_CORRELATION_ID = "AuditLogCorrelationId";
	public static String AUDITLOG_OPERATION_NAME = "AuditLogOperationName";
	public static String AUDITLOG_SERVICE_NAME = "AuditLogServiceName";
	public static String AUDITLOG_INSERTED_BY = "AuditLogInsertedBy";
	public static String AUDITLOG_INSERTED_DATE = "AuditLogInsertedDate";
	public static String AUDITLOG_LAYER = "AuditLogLayer";
	
	final Logger log = LoggerFactory.getLogger(this.getClass());
	Marker auditLogMarker = MarkerFactory.getMarker("AUDITLOG");
	private static SimpleDateFormat xmlDateTimeformat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	protected static String getXmlDateTime(){
		return xmlDateTimeformat.format(new Date());
	}
	
	public void logRequest(Exchange exchange){
		Object exchangeBody = exchange.getIn().getBody();
		if(exchangeBody != null && exchangeBody instanceof String && exchange.getIn().getBody().toString().contains("SecurityMessageHeader")){
			String updatedBody = updateAuditLogRequestResponse((String)exchange.getIn().getBody(),"x");
			log.debug(auditLogMarker,updatedBody);
		}else{
			log.debug(auditLogMarker,exchangeBody.toString());
		}
		
		exchange.getOut().setBody(exchange.getIn().getBody());
		if (exchange.getIn().hasHeaders()){
			for (String header : exchange.getIn().getHeaders().keySet()){
				exchange.getOut().getHeaders().put(header, exchange.getIn().getHeader(header));
			}
		}
		
	}
	
	public void logResponse(Exchange exchange){
		Object exchangeBody = exchange.getIn().getBody();
		if(exchangeBody != null && exchangeBody instanceof String && exchange.getIn().getBody().toString().contains("SecurityMessageHeader")){
			String updatedBody = updateAuditLogRequestResponse((String)exchange.getIn().getBody(),"x");
			log.debug(auditLogMarker,updatedBody);
		}else{
			log.debug(auditLogMarker,exchangeBody.toString());
		}
		exchange.getOut().setBody(exchange.getIn().getBody());
		if (exchange.getIn().hasHeaders()){
			for (String header : exchange.getIn().getHeaders().keySet()){
				exchange.getOut().getHeaders().put(header, exchange.getIn().getHeader(header));
			}
		}
	}

	public void prepareRequest(Exchange exchange){
		
		AuditLog alog = new AuditLog();
		String operationName = "api_operation_name";
		String serviceName = "api_service_name";
		String interfaceName = "CSI";
		String customerOrderNumber = "";
		String orderNumber = "";
		String requestId = "";
		String layer = "CAMUNDA";
	    String insertedBy = "CAMUNDA";
	    Calendar insertedDate = Calendar.getInstance();
	    insertedDate.setTime(new Date());

		boolean fedIndicator = (Boolean) exchange.getProperties().get("fedIndicator");
		if (fedIndicator) {
			Map<String, Object> order = (Map<String, Object>) exchange.getProperties().get("order");
			if (null != order) {
				customerOrderNumber = (String) order.get("customerOrderNumber");
				if (order.containsKey("oceOrderNumber"))
					orderNumber = (String) order.get("oceOrderNumber");
				
				requestId = (null != order.get("requestId"))?order.get("requestId").toString():"";
			}
		} else {
			Map<String, Object> order = (Map<String, Object>) exchange.getProperties().get("order");
			if (null != order) {
				customerOrderNumber = order.get("CustomerOrderNumber").toString();
				if (order.containsKey("OCEOrderNumber"))
					orderNumber = order.get("OCEOrderNumber").toString();
				/**
				 * Modified by jt316g
				 * ADDP/APP orders (AT&T Business Console), requestId is not a mandatory field.
				 * Change: order.get("RequestId").toString() -> (String) order.get("RequestId")
				 */
				requestId = (null != order.get("RequestId"))?order.get("RequestId").toString():"";
			}
		}
		
		if (exchange.hasProperties()){
			alog.setRequestID(exchange.getProperties().containsKey("AUDITLOG_REQUEST_ID")?exchange.getProperties().get("AUDITLOG_REQUEST_ID").toString():requestId);
			alog.setCustomerOrderNumber(exchange.getProperties().containsKey("AUDITLOG_CUSTOMER_ORDER_NUMBER")?(String) exchange.getProperties().get("AUDITLOG_CUSTOMER_ORDER_NUMBER"):customerOrderNumber);
			alog.setOrderID(exchange.getProperties().containsKey("AUDITLOG_ORDER_NUMBER")?(String) exchange.getProperties().get("AUDITLOG_ORDER_NUMBER"):orderNumber);
			alog.setConversationID(exchange.getProperties().containsKey("AUDITLOG_CONVERSATION_ID")?exchange.getProperties().get("AUDITLOG_CONVERSATION_ID").toString():null);
			alog.setRequestTime(insertedDate);
			alog.setInterfaceName(exchange.getProperties().containsKey("AUDITLOG_INTERFACE_NAME")?(String) exchange.getProperties().get("AUDITLOG_INTERFACE_NAME"):interfaceName);
			alog.setCorrelationID(exchange.getProperties().containsKey("AUDITLOG_CORRELATION_ID")?exchange.getProperties().get("AUDITLOG_CORRELATION_ID").toString():null);
			alog.setOperationName(exchange.getProperties().containsKey("AUDITLOG_OPERATION_NAME")?(String) exchange.getProperties().get("AUDITLOG_OPERATION_NAME"):operationName);
			alog.setServiceName(exchange.getProperties().containsKey("AUDITLOG_SERVICE_NAME")?(String) exchange.getProperties().get("AUDITLOG_SERVICE_NAME"):serviceName);
			alog.setLayer(exchange.getProperties().containsKey("AUDITLOG_LAYER")?(String) exchange.getProperties().get("AUDITLOG_LAYER"):layer);
			alog.setInsertedBy(exchange.getProperties().containsKey("AUDITLOG_INSERTED_BY")?(String) exchange.getProperties().get("AUDITLOG_INSERTED_BY"):insertedBy);
			alog.setInsertedDate(insertedDate);
		}
		
		Object exchangeBody = exchange.getIn().getBody();
		if(exchangeBody != null && exchangeBody instanceof String && exchange.getIn().getBody().toString().contains("SecurityMessageHeader")){
			exchangeBody = updateAuditLogRequestResponse(exchange.getIn().getBody().toString(),"x");
		}
		if(null != exchangeBody) {
			if (camundaConfig.getAuditlogLogLevel() == 2 || camundaConfig.getAuditlogLogLevel() == 3) {
				log.debug(auditLogMarker,"------------------------------------ AUDIT LOG REQUEST ----------------------------------------------------");
				log.debug(auditLogMarker,exchangeBody.toString());
			}

			if (camundaConfig.getAuditlogSystemProperty().equals("DETAIL"))
				alog.setRequest(exchangeBody.toString());
		}
		
		exchange.getOut().setBody(alog);
		
	}
	
	public void prepareResponse(Exchange exchange){

		AuditLog alog = new AuditLog();
		String operationName = "api_operation_name";
		String serviceName = "api_service_name";
		String interfaceName = "CAMUNDA";
		String customerOrderNumber = "";
		String orderNumber = "";
		String requestId = "";
		String layer = "CAMUNDA";
	    String insertedBy = "CAMUNDA";
	    Calendar insertedDate = Calendar.getInstance();
	    insertedDate.setTime(new Date());

		
		boolean fedIndicator =  (Boolean) exchange.getProperties().get("fedIndicator");

		if (fedIndicator) {
			Map<String, Object> order = (Map<String, Object>) exchange.getProperties().get("order");
			if (null != order) {
				customerOrderNumber = (String) order.get("customerOrderNumber");
				if (order.containsKey("oceOrderNumber"))
					orderNumber = (String) order.get("oceOrderNumber");
				
				requestId = (null != order.get("requestId"))?order.get("requestId").toString():"";
			}
		} else {
			Map<String, Object> order = (Map<String, Object>) exchange.getProperties().get("order");
			if (null != order) {
				customerOrderNumber = (String) order.get("CustomerOrderNumber");
				if (order.containsKey("OCEOrderNumber"))
					orderNumber = (String) order.get("OCEOrderNumber");
				
				requestId = (null != order.get("RequestId"))?order.get("RequestId").toString():"";
			}
		}
		
		if (exchange.hasProperties()){
			alog.setRequestID(exchange.getProperties().containsKey("AUDITLOG_REQUEST_ID")?exchange.getProperties().get("AUDITLOG_REQUEST_ID").toString():requestId);
			alog.setCustomerOrderNumber(exchange.getProperties().containsKey("AUDITLOG_CUSTOMER_ORDER_NUMBER")?(String) exchange.getProperties().get("AUDITLOG_CUSTOMER_ORDER_NUMBER"):customerOrderNumber);
			alog.setOrderID(exchange.getProperties().containsKey("AUDITLOG_ORDER_NUMBER")?(String) exchange.getProperties().get("AUDITLOG_ORDER_NUMBER"):orderNumber);
			alog.setConversationID(exchange.getProperties().containsKey("AUDITLOG_CONVERSATION_ID")?exchange.getProperties().get("AUDITLOG_CONVERSATION_ID").toString():null);
			alog.setResponseTime(insertedDate);
			alog.setInterfaceName(exchange.getProperties().containsKey("AUDITLOG_INTERFACE_NAME")?(String) exchange.getProperties().get("AUDITLOG_INTERFACE_NAME"):interfaceName);
			alog.setCorrelationID(exchange.getProperties().containsKey("AUDITLOG_CORRELATION_ID")?exchange.getProperties().get("AUDITLOG_CORRELATION_ID").toString():null);
			alog.setOperationName(exchange.getProperties().containsKey("AUDITLOG_OPERATION_NAME")?(String) exchange.getProperties().get("AUDITLOG_OPERATION_NAME"):operationName);
			alog.setServiceName(exchange.getProperties().containsKey("AUDITLOG_SERVICE_NAME")?(String) exchange.getProperties().get("AUDITLOG_SERVICE_NAME"):serviceName);
			alog.setLayer(exchange.getProperties().containsKey("AUDITLOG_LAYER")?(String) exchange.getProperties().get("AUDITLOG_LAYER"):layer);
			alog.setInsertedBy(exchange.getProperties().containsKey("AUDITLOG_INSERTED_BY")?(String) exchange.getProperties().get("AUDITLOG_INSERTED_BY"):insertedBy);
			alog.setInsertedDate(insertedDate);

		}
		
		Object exchangeBody = exchange.getIn().getBody();
		if(exchangeBody != null && exchangeBody instanceof String && exchange.getIn().getBody().toString().contains("SecurityMessageHeader")){
			exchangeBody = updateAuditLogRequestResponse((String) exchange.getIn().getBody(),"x");
		}	

		if(null != exchangeBody) {
			if (camundaConfig.getAuditlogLogLevel() == 2 || camundaConfig.getAuditlogLogLevel() == 3) {
				log.debug(auditLogMarker,"------------------------------------ AUDIT LOG RESPONSE ----------------------------------------------------");
				log.debug(auditLogMarker,(String) exchangeBody);
			}

			if (camundaConfig.getAuditlogSystemProperty().equals("DETAIL"))
				alog.setResponse((String) exchangeBody);
		}
		
		exchange.getOut().setBody(alog);
		
	}
	
	/**
	 * @param csiXML
	 * @param matcherRegex
	 * @param maskString
	 * @return csiXML - content that matches the matcherRegex masked with maskString
	 */
	private  String maskData(String csiXML, String matcherRegex,String maskString){	
		String matchedData = "";
		Pattern pattern = Pattern.compile(matcherRegex);
		Matcher matcher = pattern.matcher(csiXML);
		if (matcher.find()){
		    matchedData = matcher.group(1);
		}
		
		String maskedData = "";
		for(int i = 0; i < matchedData.length(); i++){
			maskedData +=  maskString;
		}
		return csiXML.replaceFirst(">"+matchedData+"<", ">"+maskedData+"<");
	
    }

	/**
	 * This function will get the xmlString in which the user credentials needs to be masked with the provided maskString
	 * @param xmlString
	 * @param maskString
	 * @return updatedAuditLog
	 */
	private  String updateAuditLogRequestResponse(String xmlString,String maskString){		
		String requestUpdatedUserName = maskData(xmlString,"userName>(.*?)<",maskString);
		String updatedAuditLog = maskData(requestUpdatedUserName,"userPassword>(.*?)<",maskString);	
		return updatedAuditLog;
		
	}


}
