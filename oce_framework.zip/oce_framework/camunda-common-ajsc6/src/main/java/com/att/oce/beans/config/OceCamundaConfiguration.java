package com.att.oce.beans.config;

import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.att.oce.bpm.common.task.OceTaskCreateListener;
import com.att.oce.bpm.common.task.OceTaskParseListener;
import com.att.oce.bpm.common.util.AuditLogHelper;

@Configuration
public class OceCamundaConfiguration
{
  static final Logger log = LoggerFactory.getLogger(OceCamundaConfiguration.class);

  @Bean
  public DmnEngine dmnEngine()
  {
    log.info("DmnEngine created");
    
    DmnEngineConfiguration configuration = 
      DmnEngineConfiguration.createDefaultDmnEngineConfiguration();
    
    DmnEngine dmnEngine = configuration.buildEngine();
    return dmnEngine;
  }
  
  @Bean
  public OceTaskCreateListener oceTaskCreateListener()
  {
    log.info("oceTaskCreateListener created");
    return new OceTaskCreateListener();
  }
  
  @Bean
  public OceTaskParseListener oceTaskParseListener()
  {
    log.info("oceTaskParseListener created");
    return new OceTaskParseListener();
  }
/*  
  
  @Bean
  @ConditionalOnMissingBean(CamundaFailedJobConfiguration.class)
  public static CamundaFailedJobConfiguration failedJobConfiguration() {
    return new OceCamundaFailedJobConfiguration();
  }  */
  
  @Bean
  public AuditLogHelper auditLogeHelper()
  {
    log.info("auditLogeHelper created");
    return new AuditLogHelper();
  }
  
}
