package com.att.oce.bpm.common.util;

import com.att.oce.beans.config.CamundaConfig;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("auditLogResponseRouteBuilder")
public class AuditLogResponseRouteBuilder extends RouteBuilder {

  @Autowired CamundaConfig camundaConfig;

  @Override
  public void configure() throws Exception {

    from("direct:auditlog:response")
        .choice()
        .when(constant(camundaConfig.getAuditlogLogLevel()).in(1, 3))
        .to("auditlogq:" + camundaConfig.getAuditLogQName())
        .end()
        .routeId("AuditLogResponse");
  }
}