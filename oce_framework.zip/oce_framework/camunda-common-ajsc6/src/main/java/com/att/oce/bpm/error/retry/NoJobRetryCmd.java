package com.att.oce.bpm.error.retry;

import org.camunda.bpm.engine.OptimisticLockingException;
import org.camunda.bpm.engine.impl.cfg.TransactionContext;
import org.camunda.bpm.engine.impl.cfg.TransactionState;
import org.camunda.bpm.engine.impl.context.Context;
import org.camunda.bpm.engine.impl.interceptor.Command;
import org.camunda.bpm.engine.impl.interceptor.CommandContext;
import org.camunda.bpm.engine.impl.jobexecutor.JobExecutor;
import org.camunda.bpm.engine.impl.jobexecutor.MessageAddedNotification;
import org.camunda.bpm.engine.impl.persistence.entity.JobEntity;

public class NoJobRetryCmd implements Command<Object> {
	protected static final long serialVersionUID = 1L;
	protected String jobId;
	protected Throwable exception;

	public NoJobRetryCmd(String jobId, Throwable exception) {
		this.jobId = jobId;
		this.exception = exception;
	}

	protected JobEntity getJob() {
		return Context.getCommandContext().getJobManager().findJobById(jobId);
	}

	protected void unlockJob(JobEntity job) {
		job.setLockOwner(null);
		job.setLockExpirationTime(null);
	}

	protected void logException(JobEntity job) {
		if (exception != null) {
			job.setExceptionMessage(exception.getMessage());
			job.setExceptionStacktrace(getExceptionStacktrace());
		}
	}

	protected void decrementRetries(JobEntity job) {
		if (exception == null || shouldDecrementRetriesFor(exception)) {
			job.setRetries(job.getRetries() - 1);
		}
	}

	protected String getExceptionStacktrace() {
		return "";// getJobExceptionStacktrace(exception);
	}

	protected boolean shouldDecrementRetriesFor(Throwable t) {
		return !(t instanceof OptimisticLockingException);
	}

	protected void notifyAcquisition(CommandContext commandContext) {
		JobExecutor jobExecutor = Context.getProcessEngineConfiguration().getJobExecutor();
		MessageAddedNotification messageAddedNotification = new MessageAddedNotification(jobExecutor);
		TransactionContext transactionContext = commandContext.getTransactionContext();
		transactionContext.addTransactionListener(TransactionState.COMMITTED, messageAddedNotification);
	}

	public Object execute(CommandContext commandContext) {
		JobEntity job = getJob();
		job.setRetries(0);
		job.setLockExpirationTime(null);

		logException(job);
		notifyAcquisition(commandContext);
		return null;
	}

}
