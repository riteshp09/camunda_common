package com.att.oce.bpm.error;

public class APIFailedException extends Exception {
	
	private String api;
	private String processName;
	private String processId;
	private String httpCode;
	private String code;
	private String codeDescription;
	private String subCode;
	private String subCodeDescription;
	private String executionId;
	private String rawFault;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String getApi() {
		return api;
	}
	public void setApi(String api) {
		this.api = api;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public String getProcessId() {
		return processId;
	}
	public void setProcessId(String processId) {
		this.processId = processId;
	}
	public String getHttpCode() {
		return httpCode;
	}
	public void setHttpCode(String httpCode) {
		this.httpCode = httpCode;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCodeDescription() {
		return codeDescription;
	}
	public void setCodeDescription(String codeDescription) {
		this.codeDescription = codeDescription;
	}
	public String getSubCode() {
		return subCode;
	}
	public void setSubCode(String subCode) {
		this.subCode = subCode;
	}
	public String getSubCodeDescription() {
		return subCodeDescription;
	}
	public void setSubCodeDescription(String subCodeDescription) {
		this.subCodeDescription = subCodeDescription;
	}
	public String getExecutionId() {
		return executionId;
	}
	public void setExecutionId(String executionId) {
		this.executionId = executionId;
	}
	public String getRawFault() {
		return rawFault;
	}
	public void setRawFault(String rawFault) {
		this.rawFault = rawFault;
	}
	
	public APIFailedException(){
		
	}
	
	@Override
	public String getMessage(){
		return String.format("API %1$s failed with code: %2$s description: %2$s faultCode: %4$s faultDescription: %5$s",api,code,codeDescription,subCode,subCodeDescription);
	}

	
}

