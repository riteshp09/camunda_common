package com.att.oce.bpm.common.util;

import com.att.oce.beans.config.CamundaConfig;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("auditLogRequestRouteBuilder")
public class AuditLogRequestRouteBuilder extends RouteBuilder {

  @Autowired CamundaConfig camundaConfig;

  @Override
  public void configure() throws Exception {

    from("direct:auditlog:request")
        .choice()
        .when(constant(camundaConfig.getAuditlogLogLevel()).in(1, 3))
        .to("auditlogq:" + camundaConfig.getAuditLogQName())
        .end()
        .routeId("AuditLogRequest");
  }
}