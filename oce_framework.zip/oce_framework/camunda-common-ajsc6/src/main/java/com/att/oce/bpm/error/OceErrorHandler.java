package com.att.oce.bpm.error;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionTableResult;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

public class OceErrorHandler {
	
	Logger logger = LoggerFactory.getLogger(OceErrorHandler.class);
	
	@Autowired
	private DmnEngine dmnEngine;
	
	@Resource(name="retryDecisions")
	protected DmnDecision retryDecisions;
	
	public Map<String,Object> handleError(Object error){
		
		Map<String,Object> errorContext = null;
		if (error instanceof Map){
			errorContext = (Map<String,Object>)error;
		} else if (error instanceof APIFailedException){
			APIFailedException apierror = (APIFailedException)error;
			errorContext = new HashMap<String, Object>();
			errorContext.put("errorCode", apierror.getCode());
			errorContext.put("subCode", apierror.getSubCode());
			errorContext.put("api", apierror.getApi());
		}
		
		DmnDecisionTableResult results = dmnEngine
				.evaluateDecisionTable(retryDecisions, errorContext);
		if (results!= null && results.getFirstResult() != null){
			errorContext.put("retry",true);
			for(String k : results.getFirstResult().keySet()){
				errorContext.put(k, results.getFirstResult().get(k));
			}
		} else {
			errorContext.put("retry",false);
		}
		logger.info("Retry Configuration evaluated {"+errorContext+"}");
		System.out.println("Retry Configuration evaluated {"+errorContext+"}");
		return errorContext;

	}

}
