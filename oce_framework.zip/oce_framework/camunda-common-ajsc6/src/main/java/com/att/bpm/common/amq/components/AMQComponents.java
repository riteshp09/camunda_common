package com.att.bpm.common.amq.components;

public class AMQComponents {

}
