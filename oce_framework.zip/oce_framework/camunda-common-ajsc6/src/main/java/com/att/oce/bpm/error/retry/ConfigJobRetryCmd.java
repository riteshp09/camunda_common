package com.att.oce.bpm.error.retry;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.Duration;

import org.camunda.bpm.engine.OptimisticLockingException;
import org.camunda.bpm.engine.impl.cfg.TransactionContext;
import org.camunda.bpm.engine.impl.cfg.TransactionState;
import org.camunda.bpm.engine.impl.context.Context;
import org.camunda.bpm.engine.impl.interceptor.Command;
import org.camunda.bpm.engine.impl.interceptor.CommandContext;
import org.camunda.bpm.engine.impl.jobexecutor.JobExecutor;
import org.camunda.bpm.engine.impl.jobexecutor.MessageAddedNotification;
import org.camunda.bpm.engine.impl.persistence.entity.JobEntity;
import org.camunda.bpm.engine.impl.util.ClockUtil;

import com.att.oce.bpm.error.RetryException;

public class ConfigJobRetryCmd implements Command<Object> {
	protected static final long serialVersionUID = 1L;
	  protected String jobId;
	  protected Throwable exception;

	  public ConfigJobRetryCmd(String jobId, Throwable exception) {
	    this.jobId = jobId;
	    this.exception = exception;
	  }

	  protected JobEntity getJob() {
	    return Context
	        .getCommandContext()
	        .getJobManager()
	        .findJobById(jobId);
	  }

	  protected void unlockJob(JobEntity job) {
	    job.setLockOwner(null);
	    job.setLockExpirationTime(null);
	  }

	  protected void logException(JobEntity job) {
	    if(exception != null) {
	      job.setExceptionMessage(exception.getMessage());
	      job.setExceptionStacktrace(getExceptionStacktrace());
	    }
	  }

	  protected void decrementRetries(JobEntity job) {
	    if (exception == null || shouldDecrementRetriesFor(exception)) {
	      job.setRetries(job.getRetries() - 1);
	    }
	  }

	  protected String getExceptionStacktrace() {
	    return "";//getJobExceptionStacktrace(exception);
	  }

	  protected boolean shouldDecrementRetriesFor(Throwable t) {
	    return !(t instanceof OptimisticLockingException);
	  }

	  protected void notifyAcquisition(CommandContext commandContext) {
	    JobExecutor jobExecutor = Context.getProcessEngineConfiguration().getJobExecutor();
	    MessageAddedNotification messageAddedNotification = new MessageAddedNotification(jobExecutor);
	    TransactionContext transactionContext = commandContext.getTransactionContext();
	    transactionContext.addTransactionListener(TransactionState.COMMITTED, messageAddedNotification);
	  }

	public Object execute(CommandContext commandContext) {
		JobEntity job = getJob();
		RetryException e = (RetryException)exception;
		String[] config_retry_interval = getConfigInterval(e);
		if (job.getExceptionByteArrayId() == null && job.getExceptionMessage() == null){
			System.out.println("Setting the job retry as"+e.getMaxRetryAttempts()+" for job id "+job.getId());
			job.setRetries(e.getMaxRetryAttempts());
			if(config_retry_interval != null && (Boolean)e.getErrorContext().get("config_retry")){
				e.setInterval(Integer.valueOf(config_retry_interval[0]));
			}
		} else {
			System.out.println("Setting the job retry as"+(job.getRetries()-1)+" for job id "+job.getId());
			job.setRetries(job.getRetries()-1);
			if(config_retry_interval != null && (Boolean)e.getErrorContext().get("config_retry")){
				e.setInterval(Integer.valueOf(config_retry_interval[config_retry_interval.length - job.getRetries()]));
			}
		}
		
		Date start  = ClockUtil.getCurrentTime();
		Duration period=null;
		try {
			period = DatatypeFactory.newInstance().newDuration(e.getInterval()*1000);
		} catch (DatatypeConfigurationException e1) {
			e1.printStackTrace();
		}
		job.setLockExpirationTime(add(start,period));
		logException(job);
		notifyAcquisition(commandContext);
		return null;
	}
	
	private Date add(Date date, Duration duration) {
	    Calendar calendar = new GregorianCalendar();
	    calendar.setTime(date);
	    duration.addTo(calendar);
	    return calendar.getTime();
	  }
	
	private String[] getConfigInterval(RetryException e) {
		String[] config_retry_interval=null;
		if(e.getErrorContext()!=null){
			if(e.getErrorContext().get("config_retry") != null){
				if((Boolean)e.getErrorContext().get("config_retry")){
					config_retry_interval=(String[]) e.getErrorContext().get("config_retry_interval");
					
				}
			}
		}
		return config_retry_interval;
	}
}
