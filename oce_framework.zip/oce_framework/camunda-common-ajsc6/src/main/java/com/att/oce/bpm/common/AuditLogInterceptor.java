package com.att.oce.bpm.common;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.RouteDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.jmx.export.MBeanExporter;
import org.springframework.stereotype.Component;

import com.att.oce.beans.config.CamundaConfig;
import com.att.oce.bpm.common.util.AuditLogHelper;

@Component
public class AuditLogInterceptor implements ApplicationListener<ContextRefreshedEvent>{

	static Logger log = LoggerFactory.getLogger(AuditLogInterceptor.class);

	@Autowired CamundaConfig camundaConfig;
	
	@Autowired CamelContext context;
	
	@SuppressWarnings("deprecation")
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {

		List<RouteDefinition> RouteDefinitions = context.getRouteDefinitions();
		for(RouteDefinition r : RouteDefinitions)
		{
			log.info("Route ID " + r.getId() + " exists in context");
		}

		List<String> ignorableRoutes = new ArrayList<String>();
		ignorableRoutes.add("auditLogRouteBuilder");
		ignorableRoutes.add("auditLogResponseRouteBuilder");

		for(int i=0; i<RouteDefinitions.size(); i++)
		{
			RouteDefinition routeDef = RouteDefinitions.get(i);
			if(camundaConfig.getAuditlogSystemProperty().equals("OFF") && !ignorableRoutes.contains(routeDef.getId()))
			{
				try 
				{
					routeDef.adviceWith(context, new RouteBuilder(){
						@Override
						public void configure() throws Exception {
							interceptSendToEndpoint("direct:auditlog:request").skipSendToOriginalEndpoint().bean(AuditLogHelper.class,"logRequest");
							interceptSendToEndpoint("direct:auditlog:response").skipSendToOriginalEndpoint().bean(AuditLogHelper.class,"logResponse");
						}
					});
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
				log.info("Turned off AuditLog for " + routeDef.getId());
			}
		}

	}	
}
