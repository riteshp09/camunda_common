package com.att.oce.retry.test;

import javax.annotation.Resource;

import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionRuleResult;
import org.camunda.bpm.dmn.engine.DmnDecisionTableResult;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.camunda.bpm.engine.variable.VariableMap;
import org.camunda.bpm.engine.variable.Variables;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.retry.RetryConfig;

/**
 * Test class to validate Retry Decision table.
 * 
 * This test class takes care of exposing dependent dmnEngine bean.
 * 
 * 
 * Imp: 
 *  configure ENV variable as below to run this test on local machine:
 * 		-DOCE_RESOURCES_HOME= <path to oce-resources/src/main/resources>
 *
 * @author kp7466
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {RetryDecisionTest.class, RetryConfig.class})
public class RetryDecisionTest {

	/**
	 * Env variable OCE_RESOURCES_HOME is used to read resources file.
	 *  -DOCE_RESOURCES_HOME= <path to oce-resources/src/main/resources>
	 */
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "../oce-resources/src/main/resources/");
		System.out.println(System.getProperty("OCE_RESOURCES_HOME"));
	} 
	
	@Autowired
	private DmnEngine dmnEngine;
	
	@Bean
	public static DmnEngine dmnEngine() {
		// create default DMN engine configuration
		DmnEngineConfiguration configuration = DmnEngineConfiguration
		  .createDefaultDmnEngineConfiguration();

		// configure as needed
		// ...

		// build a new DMN engine
		DmnEngine dmnEngine = configuration.buildEngine();
		return dmnEngine;
	}
	
	@Resource(name = "retryDecisions")
	private DmnDecision retryDecisions;
	
	@Test
	public void testDmnEngineInjection() {
		Assert.assertNotNull(dmnEngine);
	}
	
	@Test
	public void testRetryDecisionTableInjection() {
		Assert.assertNotNull(retryDecisions);		
		Assert.assertTrue(retryDecisions.isDecisionTable());
	}
	
	@Test
	public void testNoRetryDecision() {
		
		VariableMap variables = Variables.createVariables()
			.putValue("errorCode", "300")
			.putValue("api", "ValidateAddress");
		
		DmnDecisionTableResult results = dmnEngine
					.evaluateDecisionTable(retryDecisions, variables);
		
		//Assert that only one result has matched
		Assert.assertEquals(1, results.size());
		
		
		DmnDecisionRuleResult result = results.getFirstResult();		
		//assert that it only has 1 entry
		Assert.assertEquals(2, result.size());		
		//assert that returned entry is for "numOfRetries" and is 0
		Assert.assertEquals(0, result.get("numOfRetries"));
	}

	@Test
	public void testMatchedRetryDecision() {
		
		VariableMap variables = Variables.createVariables()
			.putValue("errorCode", "200")
			.putValue("api", "ValidateAddress");
		
		DmnDecisionTableResult results = dmnEngine
					.evaluateDecisionTable(retryDecisions, variables);
		//Assert that only one result has matched
		Assert.assertEquals(1, results.size());
		
		
		DmnDecisionRuleResult result = results.getFirstResult();		

		//assert that it only has 1 entry
		Assert.assertEquals(3, result.size());		
		Assert.assertEquals(5, result.get("numOfRetries"));
		Assert.assertEquals("10", result.get("interval"));
		Assert.assertEquals(true, result.get("expBackoff"));
	}

}
