package com.att.oce.retry;

import java.io.File;
import java.io.FileNotFoundException;

import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.model.dmn.Dmn;
import org.camunda.bpm.model.dmn.DmnModelInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RetryConfig {

	private final Logger logger = LoggerFactory.getLogger(RetryConfig.class);
	
	private static String OCE_RESOURCES_HOME = System.getProperty("OCE_RESOURCES_HOME");

	private static String RETRY_DECISIONS = OCE_RESOURCES_HOME + "retry-decisions.dmn";
	
	//dmnEngine should be exposed using @Bean by the Spring Application which needs to leverage this RetryConfig 
	@Autowired
	private DmnEngine dmnEngine;

	@Bean(name = "retryDecisions")
	public DmnDecision retryDecisions() throws FileNotFoundException {
		File file = new File(RETRY_DECISIONS);		
		//FileInputStream fis = new FileInputStream(file);
		DmnModelInstance dmnModelInstance  = Dmn.readModelFromFile(file);
		
		//XlsxConverter converter = new XlsxConverter();
		//DmnModelInstance dmnModelInstance = converter.convert(fis);		
		return dmnEngine.parseDecision("retry-decisions" , dmnModelInstance);
	}	
	
}
