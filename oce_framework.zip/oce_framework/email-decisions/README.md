## About

emailRuleDecisions loads the emailrules-decisions.dmn defined in resources and exposes Decisions as Spring bean to be readily used in various applications (mainly Camunda based stateful services).
This can be used to derive the email template and contents