package com.att.oce.email.service;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionRuleResult;
import org.camunda.bpm.dmn.engine.DmnDecisionTableResult;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.camunda.bpm.engine.variable.VariableMap;
import org.camunda.bpm.engine.variable.Variables;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.email.EmailRulesConfig;
import com.att.oce.email.constants.EmailConstants;

/**
 * Test class to validate Email decision rules.
 * 
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {EmailRuleServiceTest.class, EmailRulesConfig.class})
public class EmailRuleServiceTest {

	/**
	 * Env variable OCE_RESOURCES_HOME is used to read resources file.
	 *  -DOCE_RESOURCES_HOME= <path to oce-resources/src/main/resources>
	 */
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "src/main/resources/");
		System.out.println(System.getProperty("OCE_RESOURCES_HOME"));
	} 
	
	@Autowired
	private DmnEngine dmnEngine;
	
	@Bean
	public static DmnEngine dmnEngine() {
		// create default DMN engine configuration
		DmnEngineConfiguration configuration = DmnEngineConfiguration
		  .createDefaultDmnEngineConfiguration();
		DmnEngine dmnEngine = configuration.buildEngine();
		return dmnEngine;
	}
	
	@Autowired
	private EmailRuleService emailRuleService;
	
	/*@Resource(name = "emailRuleService")
	private EmailRuleService emailRuleService;*/
	
	@Test
	public void testEmailDecision() throws IOException {
		String inputJson = readFile("src/test/resources/orderInput.json", StandardCharsets.UTF_8);
		HashMap<String,Object> emailRuleData = emailRuleService.evaluateEmailRule(inputJson);
		Assert.assertEquals("DE-SMB-TEMP-CANCELED", emailRuleData.get("emailTemplate"));
	}

	public String readFile(String path, Charset encoding) 
			  throws IOException 
	{
	  byte[] encoded = Files.readAllBytes(Paths.get(path));
	  return new String(encoded, encoding);
	}
}
