package com.att.oce.email;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jayway.jsonpath.DocumentContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {OrderTransformer.class})
public class OrderTransformerTest {

	@Autowired
	private OrderTransformer orderTransformer;
	
	@Test
	public void testTransformOrder() throws IOException{
		
		String input = readFile("src/test/resources/sampleorder.json", StandardCharsets.UTF_8);
		
		DocumentContext orderDoc = orderTransformer.transformOrder(input);
		
		System.out.println("Tranformed order : \n "+orderDoc.jsonString());
		
		//TODO Add Assert statements
	}
	
	public String readFile(String path, Charset encoding) 
			  throws IOException 
	{
	  byte[] encoded = Files.readAllBytes(Paths.get(path));
	  return new String(encoded, encoding);
	}
}
