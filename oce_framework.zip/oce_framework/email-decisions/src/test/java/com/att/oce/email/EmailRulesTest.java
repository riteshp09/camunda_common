package com.att.oce.email;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionRuleResult;
import org.camunda.bpm.dmn.engine.DmnDecisionTableResult;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.camunda.bpm.engine.variable.VariableMap;
import org.camunda.bpm.engine.variable.Variables;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.email.EmailRulesConfig;

/**
 * Test class to validate Email decision rules.
 * 
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {EmailRulesTest.class, EmailRulesConfig.class})
public class EmailRulesTest {

	/**
	 * Env variable OCE_RESOURCES_HOME is used to read resources file.
	 *  -DOCE_RESOURCES_HOME= <path to oce-resources/src/main/resources>
	 */
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "src/test/resources/");
		System.out.println(System.getProperty("OCE_RESOURCES_HOME"));
	} 
	
	@Autowired
	private DmnEngine dmnEngine;
	
	@Bean
	public static DmnEngine dmnEngine() {
		// create default DMN engine configuration
		DmnEngineConfiguration configuration = DmnEngineConfiguration
		  .createDefaultDmnEngineConfiguration();
		DmnEngine dmnEngine = configuration.buildEngine();
		return dmnEngine;
	}
	//This should be the bean name defined in Config
	@Resource(name = "emailRuleDecisions")
	private DmnDecision emailRuleDecision;
	
	@Test
	public void testDmnEngineInjection() {
		Assert.assertNotNull(dmnEngine);
	}
	
	@Test
	public void testRetryDecisionTableInjection() {
		Assert.assertNotNull(emailRuleDecision);		
		Assert.assertTrue(emailRuleDecision.isDecisionTable());
	}
	
	@Test
	public void testEmailDecision() {
		
		VariableMap variables = Variables.createVariables()
			.putValue("status", "CANCELED")
			.putValue("substatus", "DUPLICATE_ORDER")
			.putValue("channel", "DE-SMB")
			.putValue("losgtype", "NEW")
			.putValue("productcategory", "APP")
			.putValue("language", "ENGLISH");
		
		DmnDecisionTableResult results = dmnEngine
					.evaluateDecisionTable(emailRuleDecision, variables);
		
		//Assert that only one result has matched
		Assert.assertEquals(1, results.size());
		
		
		DmnDecisionRuleResult result = results.getFirstResult();		
		System.out.println("Result : "+result.get("emailTemplate"));
		//assert that it only has 1 entry
		Assert.assertEquals(1, result.size());		
		//assert that returned entry is for "numOfRetries" and is 0
		Assert.assertEquals("DE-SMB-TEMP-CANCELED", result.get("emailTemplate"));
	}

}
