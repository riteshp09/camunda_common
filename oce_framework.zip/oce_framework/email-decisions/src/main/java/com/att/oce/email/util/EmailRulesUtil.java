package com.att.oce.email.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public final class EmailRulesUtil {

	private static String OCE_RESOURCES_HOME = System.getProperty("OCE_RESOURCES_HOME");
	
	public static Properties loadProperties(String fileName) {
		Properties prop = new Properties();
		InputStream input = null;
		try {
			File file = new File(OCE_RESOURCES_HOME + fileName);	
			input = new FileInputStream(file);
			prop.load(input);

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return prop;
	}
	
	
	public static HashMap<String,String> loadProperties(Properties prop,String fieldName) {
		HashMap<String,String> fieldPropertyMap = null;
		try {
			if(null != prop.getProperty(fieldName)){
				fieldPropertyMap = new HashMap<String,String>();
				for(String allProps : prop.getProperty(fieldName).split(",")){
					if(null != allProps){
						fieldPropertyMap.put(allProps.split("=")[0], allProps.split("=")[1]);
					}
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			
		}
		return fieldPropertyMap;
	}
	
}
