package com.att.oce.email.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import java.util.Properties;
import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionRuleResult;
import org.camunda.bpm.dmn.engine.DmnDecisionTableResult;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.camunda.bpm.engine.variable.VariableMap;
import org.camunda.bpm.engine.variable.Variables;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

import com.att.oce.email.constants.EmailConstants;
import com.att.oce.email.util.EmailRulesUtil;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import net.minidev.json.JSONArray;

public class EmailRuleServiceImpl implements EmailRuleService {

	@Autowired
	private DmnEngine dmnEngine;
	
	private static Properties props;
	
	@Bean
	public static DmnEngine dmnEngine() {
		// create default DMN engine configuration
		DmnEngineConfiguration configuration = DmnEngineConfiguration
		  .createDefaultDmnEngineConfiguration();
		return configuration.buildEngine();
	}
	//This should be the bean name defined in Config
	@Resource(name = "emailRuleDecisions")
	private DmnDecision emailRuleDecision;
	
	public EmailRuleServiceImpl(){
		init();
		props = EmailRulesUtil.loadProperties("emailrules.properties");
	}
	
	
	/*
	 * This method is used to Evaluate the email rules based on the order input and return the Email templates and Contents
	 * 
	 * @param orderJson
	 * @return HashMap<String,Object>  
	 */
	public HashMap<String,Object> evaluateEmailRule(String orderJson) {
		
		List<VariableMap> emailRuleInputVariables = prepareEmailRuleInput(orderJson);
		return fetchEmailRuleAndContent(emailRuleInputVariables);
				
	}
	/*
	 * This method is used to Perpare the Input variables required to be passed to the email decision rule.
	 * 
	 * @param orderJson
	 * @return List<VariableMap>
	 */
	private List<VariableMap> prepareEmailRuleInput(String orderJson){
		DocumentContext orderJsonContext = JsonPath.parse(orderJson);
		//List which holds the Variable which has all the Input required for email decision rule 
		List<VariableMap> emailRuleInputVariables = null; 		
		JSONArray groupsList = orderJsonContext.read(props.getProperty(EmailConstants.GROUP_PATH));
		HashMap<String,String> orderLevelParams = EmailRulesUtil.loadProperties(props,"decisionRuleOrderLevel");
		HashMap<String,String> groupLevelParams = EmailRulesUtil.loadProperties(props,"decisionRuleGroupLevel");
		
		//Prepare the VariableMap for each of the group - Rule needs to be executed for each group individually 
		for(Object group : groupsList){
			if(null == emailRuleInputVariables){
				emailRuleInputVariables = new ArrayList<VariableMap>();
			}
			//Populate Order level and group level inputs into the VariableMap
			VariableMap variableMap = Variables.createVariables();
			//Populate order level params to the VariableMap
			Iterator<Entry<String, String>> it = orderLevelParams.entrySet().iterator();
			    while (it.hasNext()) {
			        @SuppressWarnings("rawtypes")
					Map.Entry pair = (Map.Entry)it.next();
			        variableMap.put(pair.getKey().toString(), orderJsonContext.read(pair.getValue().toString()));
			    }
			  //Populate Group level params to the VariableMap
		    it = groupLevelParams.entrySet().iterator();
		    while (it.hasNext()) {
		        @SuppressWarnings("rawtypes")
				Map.Entry pair = (Map.Entry)it.next();
		        variableMap.put(pair.getKey().toString(), JsonPath.parse(group).read(pair.getValue().toString()));
		    }        
			emailRuleInputVariables.add(variableMap);
		}
		return emailRuleInputVariables;
	}
	
	/*
	 * This method is used to execute the decision rule and return the Template and Content.
	 * 
	 * @param List<VariableMap>
	 * @return HashMap<String,Object>
	 */
	private HashMap<String,Object> fetchEmailRuleAndContent(List<VariableMap> emailRuleInputVariables){
		HashMap<String,String> groupContentInfo =  new HashMap<String,String>();
		List<String> emailTemplateNameList = new ArrayList<String>();
		HashMap<String,Object> emailRuleResults = new HashMap<String,Object>();
		
		//Evaluate the decision rule for each of the VariableMap - Rule needs to be executed for each group individually 
		for(VariableMap emailRuleInputVariable : emailRuleInputVariables){
			//Run the DMN Decision engine
			DmnDecisionTableResult results = dmnEngine
					.evaluateDecisionTable(emailRuleDecision, emailRuleInputVariable);
			
			if(null != results && null != results.getFirstResult()){
				DmnDecisionRuleResult result = results.getFirstResult();
				//Populate TemplateName from the DMN results for each group
				if(null != result.get(EmailConstants.EMAIL_TEMPLATE) && !emailTemplateNameList.contains(result.get(EmailConstants.EMAIL_TEMPLATE))){
					emailTemplateNameList.add(result.get(EmailConstants.EMAIL_TEMPLATE).toString());
				}
				//Populate ContentId from the DMN results - Content can be different for each group and we need to store all the contents
				if(null != result.get(EmailConstants.EMAIL_CONTENT) && null != emailRuleInputVariable.get(EmailConstants.GROUP_ID)){
					groupContentInfo.put(emailRuleInputVariable.get(EmailConstants.GROUP_ID).toString(), result.get(EmailConstants.EMAIL_CONTENT).toString());
				}
			}
		}
		
		if(null != emailTemplateNameList && emailTemplateNameList.size() > 0){
			//Check if the template obtained is Unique for each group - If not unique, use default Mixed template
			if(emailTemplateNameList.size() == 1){
				emailRuleResults.put(EmailConstants.EMAIL_TEMPLATE, emailTemplateNameList.get(0));
			}else{
				emailRuleResults.put(EmailConstants.EMAIL_TEMPLATE, props.getProperty(EmailConstants.MIXED_TEMPLATE));
			}
		}
		if(null != groupContentInfo && groupContentInfo.size() > 0){
			emailRuleResults.put(EmailConstants.EMAIL_CONTENT, groupContentInfo);
		}
		return emailRuleResults;
	}
	
	private static void init(){
		System.setProperty("OCE_RESOURCES_HOME", "src/main/resources/");
	}
	
	

	
}
