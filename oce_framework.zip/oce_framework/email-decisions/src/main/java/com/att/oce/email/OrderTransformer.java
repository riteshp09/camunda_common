package com.att.oce.email;

import static com.jayway.jsonpath.Criteria.where;
import static com.jayway.jsonpath.Filter.filter;

import java.util.List;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.Filter;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;

import net.minidev.json.JSONArray;

public class OrderTransformer {

	/**
	 * This method is used to transform the incoming order json by iterating each
	 * group and adds Account, LineItems, ScheduingInfo & ServiceAddress
	 * elements to it. This transformed will then be sent to the velocity engine
	 * along with the velocity email template
	 * 
	 * @param orderJson
	 * @return DocumentContext object that has the transform order  
	 */
	public DocumentContext transformOrder(String orderJson) {

		DocumentContext orderdoc = JsonPath.parse(orderJson);
		
		List<String> groupIdList = orderdoc.read("$.Order.Groups.Group..Id");
		
		for(String groupId : groupIdList ){
			
			resolveAccounts(orderdoc, groupId);
			resolveLineItems(orderdoc, groupId);
			resolveSchedulingInfos(orderdoc, groupId);
			resolveServiceAddress(orderdoc, groupId);
		}
		
		return orderdoc;
	}
	
	/**
	 * This method is used to get the Account information for each group thats been reffered from.
	 * 
	 * @param doc - This input parameter contains the input order document context
	 * @param groupId - This parameter is used for evaluate the group in the order
	 * @return DocumentContext - This method returns the Document object with the Account element added to the group  
	 */
	public DocumentContext resolveAccounts(DocumentContext doc, String groupId) { 

		//String accountRefPath = props.getProperty("accountRef");\
		JSONArray accountRef = null;
		Object account = null;
		
		try{
			accountRef = doc
					.read("$.Order.Groups.Group[?(@.Id == '" + groupId + "')].GroupCharacteristics.LoSGCharacteristics.AccountRef"); // TODO Move all the JSONPath expressions to properties file
			if(null != accountRef && !accountRef.isEmpty()){
				account = doc.read("$.Order.Accounts.Account[?(@.Id == '" + accountRef.get(0) + "')]");// TODO Add null check

				if(null != account){
					doc.put("$.Order.Groups.Group[?(@.Id == '" + groupId + "')].GroupCharacteristics.LoSGCharacteristics", "Account", account); // add this under Groups.Group
				}
			}
		}catch(PathNotFoundException e){
			
		}

		return doc;
	}
	
	/**
	 * This method is used to get all the LineItems that are reffering the current group and adds it to the group.
	 * 
	 * @param doc - This input parameter contains the input order document context
	 * @param groupId2 - This parameter is used for evaluate the group in the order
	 * @return DocumentContext - This method returns the Document object with the LineItems element added to the group  
	 */
	public DocumentContext resolveLineItems(DocumentContext doc, String groupId) {

		List<Object> lineItemList = null;
		try{

			if(null != groupId){
				Filter groupRef = filter(where("GroupRefs.GroupRef").contains(groupId));

				lineItemList = doc.read("$.Order.LineItems.LineItem[?]", groupRef);
				
				if(null != lineItemList && !lineItemList.isEmpty()){
					doc.put("$.Order.Groups.Group[?(@.Id == '" + groupId + "')].GroupCharacteristics.LoSGCharacteristics", "LineItems", lineItemList);
				}
			}
		}catch(PathNotFoundException e){
			
		}

		return doc;
	}
	
	/**
	 * This method is used to get all the SchedulingInfo that is reffered from the current group and adds it to the group.
	 * 
	 * @param doc - This input parameter contains the input order document context
	 * @param groupId - This parameter is used for evaluate the group in the order
	 * @return DocumentContext - This method returns the Document object with the SchedulingInfo element added to the group. 
	 */
	public DocumentContext resolveSchedulingInfos(DocumentContext doc, String groupId) {

		JSONArray schedulingRef = null;
		Object schedulingInfo = null;

		try {
			schedulingRef = doc
					.read("$.Order.Groups.Group[?(@.Id == '" + groupId + "')].GroupCharacteristics.LoSGCharacteristics.SchedulingInfoRef");
			if (null != schedulingRef && !schedulingRef.isEmpty()) {

				schedulingInfo = doc.read("$.Order.SchedulingInfos.SchedulingInfo[?(@.Id == '" + schedulingRef.get(0) + "')]");

				if (null != schedulingInfo ) {
					doc.put("$.Order.Groups.Group[?(@.Id == '" + groupId + "')].GroupCharacteristics.LoSGCharacteristics",
							"SchedulingInfo", schedulingInfo);
				}
			}
		} catch (PathNotFoundException e) {
			//e.printStackTrace();
		}

		return doc;
	}
	
	/**
	 * This method is used to get all the Service Addresses that is reffered from the current group and adds it to the group.
	 * 
	 * @param doc - This input parameter contains the input order document context
	 * @param groupId - This parameter is used for evaluate the group in the order
	 * @return DocumentContext - This method returns the Document object with the ServiceAddresses element added to the group. 
	 */
	public DocumentContext resolveServiceAddress(DocumentContext doc, String groupId) {

		JSONArray serviceLocationRef = null;
		Object address = null;
		try {
			serviceLocationRef = doc.read(
					"$.Order.Groups.Group[?(@.Id == '" + groupId + "')].GroupCharacteristics.LoSGCharacteristics.ServiceLocationRef");
			if (null != serviceLocationRef && !serviceLocationRef.isEmpty()) {
				address = doc.read("$.Order.Addresses.Address[?(@.Id == '" + serviceLocationRef.get(0) + "')]");

				if (null != address) {
					doc.put("$.Order.Groups.Group[?(@.Id == '" + groupId + "'].GroupCharacteristics.LoSGCharacteristics",
							"ServiceAddress", address);
				}
			}
		} catch (PathNotFoundException e) {
			//e.printStackTrace();
		}

		return doc;
	}
}
