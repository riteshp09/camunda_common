package com.att.oce.email.constants;

import java.io.File;
import java.io.FileNotFoundException;

import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.model.dmn.Dmn;
import org.camunda.bpm.model.dmn.DmnModelInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.att.oce.email.service.EmailRuleService;
import com.att.oce.email.service.EmailRuleServiceImpl;

public final class EmailConstants {

	public static final String EMAIL_TEMPLATE="emailTemplate";
	public static final String EMAIL_CONTENT="emailContent";
	public static final String MIXED_TEMPLATE = "MIXED_TEMPLATE";
	public static final String GROUP_ID = "groupId";
	public static final String GROUP_PATH = "groupsPath";


	
}
