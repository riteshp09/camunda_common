package com.att.oce.email.service;

import java.util.HashMap;

import org.springframework.stereotype.Service;

@Service("emailRuleService")
public interface EmailRuleService {

	HashMap<String,Object> evaluateEmailRule(String orderJson);
	
}
