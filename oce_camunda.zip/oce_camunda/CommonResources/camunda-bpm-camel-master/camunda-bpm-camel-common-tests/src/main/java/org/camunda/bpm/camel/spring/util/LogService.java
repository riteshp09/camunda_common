package org.camunda.bpm.camel.spring.util;

public interface LogService {
  public void debug(Object msg);
  public void info(Object msg);
}
