package org.camunda.bpm.camel.cdi;

import javax.inject.Named;

import org.camunda.bpm.camel.spring.util.LogServiceImpl;

@Named("log")
public class LogServiceCdiImpl extends LogServiceImpl {

}
