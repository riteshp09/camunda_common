package org.camunda.bpm.camel.spring;

import java.util.Map;

import org.apache.camel.CamelContext;
import org.camunda.bpm.camel.common.CamelService;
import org.camunda.bpm.camel.common.CamelServiceCommonImpl;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.impl.context.Context;
import org.camunda.bpm.engine.impl.pvm.delegate.ActivityExecution;

public class CamelServiceMockImpl extends CamelServiceCommonImpl {
	
	private Map<String,Object> mockResponses; 

	public Map<String, Object> getMockResponses() {
		return mockResponses;
	}

	public void setMockResponses(Map<String, Object> mockResponses) {
		this.mockResponses = mockResponses;
	}

	@Override
	public Object sendTo(String endpointUri) throws Exception {
		if (mockResponses == null)
			return null;
		ActivityExecution execution = Context.getBpmnExecutionContext()
		          .getExecution();
		if (mockResponses.containsKey(execution.getCurrentActivityName()))
			return mockResponses.get(execution.getCurrentActivityName());
		if (mockResponses.containsKey(execution.getCurrentActivityId()))
			return mockResponses.get(execution.getCurrentActivityId());
		return null;
	}

	@Override
	public Object sendTo(String endpointUri, String processVariables) throws Exception {
		if (mockResponses == null)
			return null;
		
		ActivityExecution execution = Context.getBpmnExecutionContext()
		          .getExecution();
		if (mockResponses.containsKey(execution.getCurrentActivityName()))
			return mockResponses.get(execution.getCurrentActivityName());
		if (mockResponses.containsKey(execution.getCurrentActivityId()))
			return mockResponses.get(execution.getCurrentActivityId());
		return null;
	}

	@Override
	public Object sendTo(String endpointUri, String processVariables, String correlationKey) throws Exception {
		if (mockResponses == null)
			return null;
		
		ActivityExecution execution = Context.getBpmnExecutionContext()
		          .getExecution();
		if (mockResponses.containsKey(execution.getCurrentActivityName()))
			return mockResponses.get(execution.getCurrentActivityName());
		if (mockResponses.containsKey(execution.getCurrentActivityId()))
			return mockResponses.get(execution.getCurrentActivityId());
		return null;
	}

	@Override
	public void setProcessEngine(ProcessEngine processEngine) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setCamelContext(CamelContext camelContext) {
		// TODO Auto-generated method stub
		
	}
	
}
