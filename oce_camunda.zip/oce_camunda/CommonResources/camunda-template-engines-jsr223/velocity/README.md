# camunda-template-engine-velocity

A simple [script engine](http://docs.oracle.com/javase/7/docs/api/javax/script/ScriptEngine.html)
wrapper for the [Velocity](http://velocity.apache.org/) template engine.

