# camunda-template-engine-xquery-saxon

A simple [script engine](http://docs.oracle.com/javase/7/docs/api/javax/script/ScriptEngine.html)
wrapper for the [Saxon](http://saxon.sourceforge.net/) XQuery processor.

