package com.att.oce.internal.xmltojson;

/*
 * Created on Nov 9, 2009
 * By: H3
 */

import java.util.concurrent.ConcurrentHashMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
/**
 * Util class for doing those JAX-B kind of things.
 * @author H3
 */
public class JAXBUtil
{
  /** Thread Sync Object */
  private final static Object mSYNC1 = new Object();
  
  /** Context Map */
  private static ConcurrentHashMap<String, JAXBContext> mContextMap = new ConcurrentHashMap<String, JAXBContext>();
  /** QName map for quick lookup. */
  
 
  public  static JAXBContext getContext(Class<?> c) throws JAXBException
  	{
	 String packageName = c.getPackage().getName();
    if(mContextMap.containsKey(packageName))
      return mContextMap.get(packageName);
    
    JAXBContext output;
    synchronized(mSYNC1)
    {
      if(mContextMap.containsKey(packageName))
      {
        mSYNC1.notify();
        return mContextMap.get(packageName);
      }
      
      output = JAXBContext.newInstance(c);
      mContextMap.put(packageName, output);
      mSYNC1.notify();
    }
    
    return output;
   }
 }
