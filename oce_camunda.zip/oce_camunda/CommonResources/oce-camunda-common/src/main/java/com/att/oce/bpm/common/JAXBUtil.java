/*
 * Created on Nov 9, 2009
 * By: H3
 */
package com.att.oce.bpm.common;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchema;
import javax.xml.bind.annotation.XmlType;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Element;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.AnnotationIntrospector;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.xc.JaxbAnnotationIntrospector;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.att.oce.v10.internal.order.model.Order;
import com.fasterxml.jackson.core.JsonProcessingException;

/**
 * This class is used to marshal JAXB objects to XML, and unmarshal XML to JAXB
 * objects.
 * 
 * It manages a static map of JAXBContext objects, keyed by the package name, to
 * make getting the JAXBContext object a little more convenient. Note that this
 * map object is not protected by a synchronized block. There is no
 * thread-safety issue here, as the map is a ConcurrentHashMap object, which
 * allows concurrent access. Without a synchronized block, it's possible that
 * multiple threads entering this for the same package initially may result in
 * the creation of more than one JAXBContext object for the same package. Only
 * one will be stored permanently in the map, and any following requests for the
 * same package will not have to enter a synchronized block, which will be more
 * efficient.
 * 
 * @author dk068x
 * @author zw251y
 * 
 */
public class JAXBUtil {

	private static Logger logger = Logger.getLogger(JAXBUtil.class.getName());
	private static ConcurrentHashMap<String, JAXBContext> contextsMap = new ConcurrentHashMap<String, JAXBContext>();
	private static ConcurrentHashMap<String, String> namespacesMap = new ConcurrentHashMap<String, String>();

	//public static final JAXBElement<Fault> faultElem = new com.att.org.xmlsoap.schemas.soap.envelope.ObjectFactory().createFault(null);

	/*private static JAXBContext getContext(String packageName) throws JAXBException {
		if (contextsMap.containsKey(packageName))
			return contextsMap.get(packageName);
		// We have to override the default classloader because apparently the default classloader may not be able to
		// see the ObjectFactory class.
		JAXBContext result = JAXBContext.newInstance(packageName, JAXBUtil.class.getClassLoader());
		contextsMap.put(packageName, result);
		return result;
	}*/
	
	
	 /** Thread Sync Object */
	  private final static Object mSYNC1 = new Object();
	  
	  /** Context Map */
	  private static ConcurrentHashMap<String, JAXBContext> mContextMap = new ConcurrentHashMap<String, JAXBContext>();
	  /** QName map for quick lookup. */
	  
	 
	  public  static JAXBContext getContext(Class<?> c) throws JAXBException
	  	{
		 String packageName = c.getPackage().getName();
	    if(mContextMap.containsKey(packageName))
	      return mContextMap.get(packageName);
	    
	    JAXBContext output;
	    synchronized(mSYNC1)
	    {
	      if(mContextMap.containsKey(packageName))
	      {
	        mSYNC1.notify();
	        return mContextMap.get(packageName);
	      }
	      
	      output = JAXBContext.newInstance(c);
	      mContextMap.put(packageName, output);
	      mSYNC1.notify();
	    }
	    
	    return output;
	   }

	public static <T> String marshal(T obj, boolean formatOutput) throws JAXBException {
		return marshall(obj, formatOutput);
		//	    return marshal(toJAXBObject(obj), formatOutput);
	}

	protected static <T> Marshaller createMarshaller(T obj, boolean formatOutput) throws JAXBException {
		JAXBContext context = JAXBContext.newInstance(obj.getClass());
		Marshaller m = context.createMarshaller();
		m.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, formatOutput);
		/*m.setProperty("com.sun.xml.bind.marshaller.characterEscapeHandler",
            new CharacterEscapeHandler() {
                public void escape(char[] ch, int start, int length,
                        boolean isAttVal, Writer writer)
                        throws IOException {
                    writer.write(ch, start, length);
                }
            });*/

		m.setEventHandler(new javax.xml.bind.helpers.DefaultValidationEventHandler());
		return m;
	}

	protected static Marshaller createMarshaller(JAXBElement<?> obj, boolean formatOutput) throws JAXBException {
		JAXBContext context = getContext(obj.getValue().getClass());
		Marshaller m = context.createMarshaller();
		m.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, formatOutput);
		/* m.setProperty("com.sun.xml.internal.bind.characterEscapeHandler",
            new CharacterEscapeHandler() {
                public void escape(char[] ch, int start, int length,
                        boolean isAttVal, Writer writer)
                        throws IOException {
                    writer.write(ch, start, length);
                }
            });*/

		m.setEventHandler(new javax.xml.bind.helpers.DefaultValidationEventHandler());
		return m;
	}

	public static String marshal(JAXBElement<?> obj, boolean formatOutput) throws JAXBException {
		/*JAXBContext context = getContext(obj.getValue().getClass().getPackage().getName());
		Marshaller m = context.createMarshaller();
		m.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, formatOutput);*/
		Marshaller m = createMarshaller(obj, formatOutput);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		//		m.setEventHandler(new javax.xml.bind.helpers.DefaultValidationEventHandler()); // temp debug
		m.marshal(obj, baos);
		// Notice the dropping of IOException for flush and close. There is no
		// possibility to get this marshalling
		// an object to a byte array.
		try {
			baos.flush();
		} catch (IOException ex) {
		}
		String result = baos.toString();
		try {
			baos.close();
		} catch (IOException ex) {
		}

		return result;
	}

	public static <T> String marshall(T obj, boolean formatOutput) throws JAXBException {

		Marshaller m = createMarshaller(obj, formatOutput);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		m.marshal(obj, baos);

		try {
			baos.flush();
		} catch (IOException ex) {
		}
		String result = baos.toString();
		try {
			baos.close();
		} catch (IOException ex) {
		}

		return result;

	}

	public static <T> JAXBElement<T> unmarshal(Node node, Class<T> clazz) throws JAXBException {
		Unmarshaller unmarshaller = (Unmarshaller) getContext(clazz.getClass());
		return unmarshaller.unmarshal(node, clazz);
	}

	public static String findNamespace(Object jaxbObj) {
		String className = jaxbObj.getClass().getName();
		if (namespacesMap.containsKey(className))
			return namespacesMap.get(className);
		String result = jaxbObj.getClass().getPackage().getAnnotation(XmlSchema.class).namespace();
		namespacesMap.put(className, result);
		return result;
	}

	/**
	 * This is called to do a cheap schema validation on an object tree. It only
	 * checks the "required" flag on "@XmlElement" annotations. If the field is
	 * required, but the value is null, it will add it to the list of
	 * "unsetRequiredFields". It will only validate classes in two packages, the
	 * package of the given object, and the "cingularDataModel" package. This
	 * limitation is there because if you didn't limit it to certain packages,
	 * it would descend very deeply into classes that very likely will not have
	 * "@XmlElement" annotations.
	 * 
	 * @param object
	 * @param interfaceName
	 * @throws SharedServicesException
	 */
	//	public static void validateUnsetRequiredFields(Object object, String interfaceName, boolean logDebug) throws SharedServicesException {
	//		try {
	//			String missingFieldsList = JAXBUtil.listUnsetRequiredFields(object, logDebug);
	//			if (missingFieldsList != null)
	//				throw new SharedServicesException(interfaceName, "Missing fields in response: " + missingFieldsList);
	//		} catch (IllegalArgumentException ex) {
	//			throw new SharedServicesException(interfaceName, ex);
	//		} catch (IllegalAccessException ex) {
	//			throw new SharedServicesException(interfaceName, ex);
	//		}
	//	}

	/**
	 * This is called to do a cheap schema validation on an object tree. It only
	 * checks the "required" flag on "@XmlElement" annotations. If the field is
	 * required, but the value is null, it will add it to the list of
	 * "unsetRequiredFields". It will only validate classes that are one of the
	 * packages provided on the initial call. This limitation is there because
	 * if you didn't limit it to certain packages, it would descend very deeply
	 * into classes that very likely will not have "@XmlElement" annotations.
	 * 
	 * @param object
	 * @param packages
	 * @return
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	public static String listUnsetRequiredFields(Object object, boolean logDebug) throws IllegalArgumentException, IllegalAccessException {
		String result = null;

		long startMillis = System.currentTimeMillis();

		Set<Object> checkedObjects = new HashSet<Object>();

		List<String> unsetRequiredFields = JAXBUtil.validateRequired(object, checkedObjects);
		if (unsetRequiredFields.size() > 0) {
			StringBuilder sb = new StringBuilder();
			for (String fieldName : unsetRequiredFields)
				sb.append(fieldName + ", ");

			result = sb.toString().substring(0, sb.length() - 2);
		}

		long endMillis = System.currentTimeMillis();

		if (logDebug)
			logger.info(new Date().toString() + ": time to validate required fields for class \"" + object.getClass().getName() + "\" is " + (endMillis - startMillis)
					+ " ms.");

		return result;
	}

	/**
	 * This is the recursive method called by "listUnsetRequiredFields()". It
	 * first will only do anything if the class has a "XmlType" annotation on
	 * it. Then, it checks to see if this object has already been checked while
	 * validating this tree. Then, for each field, if it's null and required, it
	 * will add it to the missing fields list. If it's not null, and it's not a
	 * "primitive" class (String, Integer, Long, etc.), then we either recurse
	 * into the field, or if it's a collection, we recurse into each item in the
	 * collection. Note that we don't care if an item in a collection is null,
	 * only if a required field in an item in a collection is null (and
	 * required).
	 * 
	 * The name of the field put into the list should have useful information to
	 * help you navigate into the tree. For instance, if it's a child of another
	 * object, then "parent.field" will be in the list (which goes as deep as
	 * the field goes). If it's a field of a collection item, it will show the
	 * name of the collection field, followed by the bracketed index, followed
	 * by the field name.
	 * 
	 * @param object
	 * @param packages
	 * @return
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	public static List<String> validateRequired(Object object, Set<Object> checkedObjects) throws IllegalArgumentException, IllegalAccessException {
		List<String> unsetRequiredFields = new ArrayList<String>();

		if (object.getClass().getAnnotation(XmlType.class) != null && !checkedObjects.contains(object)) {
			checkedObjects.add(object);
			for (Field field : JAXBUtil.getDeclaredFields(object.getClass())) {
				Object fieldValue = field.get(object);
				XmlElement xmlElementAnnotation = field.getAnnotation(XmlElement.class);
				if (xmlElementAnnotation != null && xmlElementAnnotation.required() && fieldValue == null)
					unsetRequiredFields.add(field.getName());
				else if (fieldValue != null && (fieldValue.getClass() != String.class) && (fieldValue.getClass() != Boolean.class) && (fieldValue.getClass() != Long.class)
						&& (fieldValue.getClass() != Integer.class)) {
					if (fieldValue instanceof Collection<?>) {
						Collection<?> collection = (Collection<?>) fieldValue;
						int ctr = 0;
						for (Object collectionItem : collection) {
							for (String fieldName : validateRequired(collectionItem, checkedObjects))
								unsetRequiredFields.add(field.getName() + "[" + ctr + "]" + "." + fieldName);
							++ctr;
						}
					} else {
						for (String fieldName : validateRequired(fieldValue, checkedObjects))
							unsetRequiredFields.add(field.getName() + "." + fieldName);
					}
				}
			}
		}

		return unsetRequiredFields;
	}

	/**
	 * Returns the declared fields of a class, either from the cached map of
	 * them, or by direct access to the class.
	 * 
	 * @param clazz
	 * @return
	 */
	static List<Field> getDeclaredFields(Class<?> clazz) {
		// Notice that this method is NOT synchronized. We prevent ConcurrentModificationException by putting the
		// object into the map after the object is fully built (previous code was putting it into the map first, then
		// adding the fields, which resulted in CMEs under high load).  If we put the object into the map before adding all
		// of its entries, then a concurrent call to the method could get the object that is still being added to,
		// which would result in the ConcurrentModificationException.  Also note that this map is a ConcurrentHashMap,
		// all of whose methods are thread-safe.
		// The possibility exists that multiple concurrent calls to this method with the same clazz value, all occurring
		// very soon after system startup, could all return "null" from the map lookup and proceed into the body of the
		// "if".  They will all construct a list with the same objects, and each of them will put their constructed
		// object into the map and return that object from this method.  The last one wins.  There is also no harm that
		// all of those initial calls with the same clazz value will be returning different objects, as they are still
		// equivalent lists containing the same objects.
		List<Field> result = JAXBUtil.fieldListMap.get(clazz);
		if (result == null) {
			result = new ArrayList<Field>();
			for (Field field : clazz.getDeclaredFields()) {
				field.setAccessible(true);
				// Don't bother with enum constants or statics.
				if (!field.isEnumConstant() && ((field.getModifiers() & Modifier.STATIC) == 0))
					result.add(field);
			}
			JAXBUtil.fieldListMap.put(clazz, result);
		}

		return result;
	}

	/**
	 * Convert an object to the xml string of its JAXB marshaled object.
	 * 
	 * @author zw251y
	 * 
	 * @param obj
	 *            an object that is is an stance of an JAXB binding class
	 *            generated from some xsd.
	 * 
	 * @return xml string.
	 * @throws JAXBException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static String toXML(Object obj) throws JAXBException {
		Class clazz = obj.getClass();
		JAXBContext jc = JAXBContext.newInstance(clazz);
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		StringWriter sw = new StringWriter();

		if (clazz.getAnnotation(XmlRootElement.class) != null) {
			m.marshal(obj, sw);
		} else {
			String qName = ((XmlType) clazz.getAnnotation(XmlType.class)).namespace();
			JAXBElement<Object> w = new JAXBElement(new QName(qName, clazz.getSimpleName()), clazz, obj);
			m.marshal(w, sw);
		} 
		return sw.toString();

	}

	/**
	 * Convert an JAXB binding object to its JAXB marshaled object.
	 * 
	 * @author zw251y
	 * 
	 * @param obj
	 *            an object that is is an stance of an JAXB binding class
	 *            generated from OrderGateway xsd..
	 * 
	 * @return JAXBElement object.
	 * @throws JAXBException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static <T> JAXBElement<T> toJAXBObject(Object obj) throws JAXBException {
		Class clazz = obj.getClass();

		String qName = ((XmlType) clazz.getAnnotation(XmlType.class)).namespace();

		JAXBElement<T> jsr = new JAXBElement(new QName(qName, clazz.getSimpleName()), clazz, null, obj);
		return jsr;
	}

	/**
	 * Convert an object to the xml string of its JAXB marshaled object.
	 * 
	 * @author zw251y
	 * 
	 * @param obj
	 *            an object that is is an stance of an JAXB binding class
	 *            generated from OrderGateway xsd..
	 * 
	 * @return JAXBElement object.
	 * @throws JAXBException
	 */
	@SuppressWarnings({ "unchecked"})
	public static <T> JAXBElement<T> unmarshal(String xml, Class<T> clazz) throws JAXBException {

		JAXBContext jc = JAXBContext.newInstance(clazz.getPackage().getName());

		Unmarshaller m = jc.createUnmarshaller();

		return (JAXBElement<T>) m.unmarshal(new StringReader(xml));

	}

	public static <T> T unmarshalObj(String xml, Class<T> clazz) throws JAXBException {

		JAXBContext jc = JAXBContext.newInstance(clazz.getPackage().getName());

		Unmarshaller m = jc.createUnmarshaller();

		return (T)m.unmarshal(new StringReader(xml));

	}

	/**
	 * Maps class to list of declared fields in the class, to optimize
	 * "listUnsetRequiredFields".
	 */
	static Map<Class<?>, List<Field>> fieldListMap = new ConcurrentHashMap<Class<?>, List<Field>>();

	public static <T> T unmarshalObj(DOMSource sourceElm, Class<T> clazz) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(clazz);
		Unmarshaller unmarshaller = jc.createUnmarshaller();

		JAXBElement<T> je = unmarshaller.unmarshal(sourceElm,clazz);

		return je.getValue();
	}
	
	public static Document getXMLDocument(String xmlString) throws SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder = null;
		try {
		    builder = factory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
		    logger.info("Error creating xmlDoc from soap response in DeviceAlreadyUnlockValidator "+e.getMessage());  
		}
		Document xmlDocument = builder.parse(new ByteArrayInputStream(xmlString.getBytes()));
		return xmlDocument;
	}
	
	public static Node getDocumentElement(Document d, String namespace, String nodeName) {
		return d.getElementsByTagNameNS(namespace, nodeName).item(0);
	}
	
	public static String getDocumentElementValue(Document d, String namespace, String nodeName) {
        Node node = d.getElementsByTagNameNS(namespace, nodeName).item(0);
        return node.getTextContent();
	}
	
	public static String convertDocumentToString(Document doc) {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer;
        try {
            transformer = tf.newTransformer();
            // below code to remove XML declaration
            // transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(writer));
            String output = writer.getBuffer().toString();
            return output;
        } catch (TransformerException e) {
            e.printStackTrace();
        }
        
        return null;
    }
	public static String getElementValue(Element element, String namespace, String nodeName) {
		 Node node = element.getElementsByTagNameNS(namespace, nodeName).item(0);
		return (node != null) ? node.getTextContent() : "";
	}
	
	
	public static String convertDocumentToString(Node node) {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer;
        try {
            transformer = tf.newTransformer();
            // below code to remove XML declaration
            // transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(node), new StreamResult(writer));
            String output = writer.getBuffer().toString();
            return output;
        } catch (TransformerException e) {
            e.printStackTrace();
        }
        
        return null;
    }
	
	
	
	/**
	 * method to transform order xml into json string.
	 */
	public static String xmlToJson(String messageStr) throws JAXBException, JsonProcessingException
	{

		int from = messageStr.indexOf("<Order>", 0);
		int to = messageStr.indexOf("</Order>", 0);
		String orderXml = messageStr.substring(from, to+8);
		orderXml = orderXml.replace("<Order>", "<Order xmlns=\"http://oce.att.com/OCE/Namespaces/Types/Private/OCEDataModel.xsd\">");
		Order order = VelocityHelper.unmarshlXmlToObject(orderXml);
		String json = toJsonString(order);
		System.out.println("Order JSON : "+ json);
		System.out.println("VT JSON : " + VelocityHelper.marshalToJson(order));
		if(json.contains("{http://oce.att.com/OCE/Namespaces/Types/Private/OCEDataModel.xsd}GroupRef")){
			int grouprefstart=json.indexOf("\"GroupRef\"", 0);
			int grouprefend=json.indexOf("typeSubstituted", 0);
			String groupref=json.substring(grouprefstart, grouprefend+23);
			System.out.println(groupref);
			if(groupref.contains("\"value\"")){
				int grprefstrart=groupref.indexOf("value",0);
				String grouprefval=groupref.substring(grprefstrart+8,grprefstrart+16);
				System.out.println(grouprefval);
				json=json.replace(groupref, "\"GroupRef\":[\""+grouprefval+"\"]");
			}

		}

		return json;
	}
	
	private static ObjectMapper objectMapper;
	
	public static <T> Object toObject(String json, Class T) throws JsonParseException, JsonMappingException, IOException {
		return getObjectMapper().readValue(json, T);
	}
	
	public static ObjectMapper getObjectMapper() {
		if(objectMapper == null) {
			objectMapper = createObjectMapper();
		}
		return objectMapper;
	}
	
	private static synchronized ObjectMapper createObjectMapper() {
		objectMapper = new ObjectMapper();
		AnnotationIntrospector introspector = new JaxbAnnotationIntrospector();
		objectMapper.getDeserializationConfig().setAnnotationIntrospector(introspector);
		objectMapper.getSerializationConfig().setAnnotationIntrospector(introspector);
		return objectMapper;
	}
	
	public static String toJsonString(Object object) {
		String json = "";
		try {
			json = getObjectMapper().writeValueAsString(object);
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return json;
	}
	
	
}
