package com.att.camunda.camel;

import java.io.IOException;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.converter.stream.InputStreamCache;

public abstract class AbstractCamelConsumer implements CamelBean {
	
	private String messageBody;
	private Exchange exchange;
	private Message message;
	
	public Object getMessageHeaderValue(String headerName) {
		return message.getHeaders().get(headerName);
	}
	
	public Object getExchangePropertyValue(String propertyName) {
		return exchange.getProperties().get(propertyName);
	}
	
	public void setExchangeProperty(String propertyName, Object value) {
		exchange.setProperty(propertyName, value);
	}
	
	public String getMessage() {
		return messageBody;
	}

	public void setMessage(Object msg) {
		message.setBody(msg);
		exchange.setOut(message);
	}

	public Exchange getExchange() {
		return exchange;
	}

	public void execute(Exchange e) {
		try {
			this.exchange =e;
			message = exchange.getIn();
			messageBody = readExchangeMessage();
			processMessage();
		} catch (IOException e1) {
			messageBody ="";
			e1.printStackTrace();
		}
	}
	
	abstract public void processMessage();
	
	protected String readExchangeMessage() throws IOException {
		String inMessageStr = null;
		Message msg = exchange.getIn();
		if (msg.getBody() instanceof String) {
			inMessageStr = (String) msg.getBody();
		} else {
			InputStreamCache msgCache = (InputStreamCache) msg.getBody();
			byte[] content = new byte[msgCache.available()];
			msgCache.read(content);
			inMessageStr = new String(content);
		}
		return inMessageStr;
	}

}
