package com.att.oce.bpm.common;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationModule;
import com.att.oce.internal.xmltojson.JAXBUtil;
import com.att.oce.v10.internal.order.model.Order;
/**
 * Hello world!
 *
 */
public class VelocityHelper 
{
	private static SimpleDateFormat xmlDateTimeformat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");  //2016-10-24T10:52:19.064Z 2016-10-25T12:42:24.836-0500 
	private static SimpleDateFormat noteTextDateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static VelocityEngine velocityEngine = null;
	private static VelocityContext velocityContext = null;
//	private static StringWriter writer = new StringWriter();

	static {
		velocityEngine  = new VelocityEngine();
		velocityEngine.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
		velocityEngine.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
		velocityEngine.init();
	}

	public static String renderDynamicTemplate(Map<String, String> paramMap, String templateString) {
		StringWriter writer = new StringWriter();
		try {
			velocityContext = new VelocityContext();
			for (String key : paramMap.keySet()) {
				velocityContext.put(key, paramMap.get(key));
			}
			boolean flag = velocityEngine.evaluate(velocityContext, writer, "", templateString);
			if (flag) {
				return writer.getBuffer().toString();
			} else
				return templateString;
		} finally {
			velocityContext = null;
			try {
				writer.close();
				writer = null;
			} catch (IOException e) {
				System.out.println("VelocityHelper ::: Error closing String Writter :: " + e.getMessage());
			}
		}

	}

	public static String getXmlDateTime(){
		return xmlDateTimeformat.format(new Date());
	}

	public static String getNoteTextDateTime(Date date){
		return xmlDateTimeformat.format(date);
	}

	public static String getUUId(){
		return java.util.UUID.randomUUID().toString();
	}



	public static StringBuilder toJsonString(Object object){
		if (object instanceof Map<?,?>){
			return new StringBuilder(new JSONObject((Map)object).toString());
		}
		return new StringBuilder("");
	}

	/*public static StringBuilder toAmol(Object object){
    	if (object instanceof Map<?,?>){
    		Map<String, Object> wrapMap = new HashMap<String, Object>();
    		wrapMap.put("Order", object);
    		return new StringBuilder(new JSONObject((Map)wrapMap).toString());
    	}
    	return new StringBuilder("");
    }*/


	public static Map<String, Object> jsonToMap(String json)  {
		return toMap(new JSONObject(json));
	}

	public static Map<String, Object> jsonToMap(JSONObject json)  {
		Map<String, Object> retMap = new LinkedHashMap<String, Object>();

		if(json != JSONObject.NULL) {
			retMap = toMap(json);
		}
		return retMap;
	}

	private static Map<String, Object> toMap(JSONObject object)  {
		Map<String, Object> map = new LinkedHashMap<String, Object>();

		Iterator<String> keysItr = object.keys();
		while(keysItr.hasNext()) {
			String key = keysItr.next();
			Object value = object.get(key);

			if(value instanceof JSONArray) {
				value = toList((JSONArray) value);
			}

			else if(value instanceof JSONObject) {
				value = toMap((JSONObject) value);
			} 
			if(!value.equals(JSONObject.NULL))
				map.put(key, value);
		}
		return map;
	}

	private static List<Object> toList(JSONArray array)  {
		List<Object> list = new ArrayList<Object>();
		for(int i = 0; i < array.length(); i++) {
			Object value = array.get(i);
			if(value instanceof JSONArray) {
				value = toList((JSONArray) value);
			}

			else if(value instanceof JSONObject) {
				value = toMap((JSONObject) value);
			}
			list.add(value);
		}
		return list;
	}

	/**
	 * 
	 * @param object
	 * @return
	 * @throws JSONException
	 */
	@SuppressWarnings("rawtypes")
	public static StringBuilder jsonToXML(Object object) throws JSONException { 
		if (object!=null && !object.equals("")){ 

			JSONObject json = new JSONObject((String)object); 
			String xml = XML.toString(json);

			return new StringBuilder(xml); 
		} 
		return new StringBuilder(""); 
	}

	public static Order unmarshlXmlToObject(String xml) throws JAXBException{

		StringReader reader = new StringReader(xml);

		//UnMarshall XMl to V2.1 order
		JAXBContext jaxbContextMarshal = JAXBUtil.getContext(Order.class);
		 
		Unmarshaller unmarshaller = jaxbContextMarshal.createUnmarshaller();
		Order order = (Order) unmarshaller.unmarshal(reader);

		return order;
	}

	public static String marshalToJson(Order order) throws JsonProcessingException{

		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		//mapper.enable(SerializationFeature.INDENT_OUTPUT);
		mapper.enable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		SimpleDateFormat dateFormat = new SimpleDateFormat ("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		mapper.setDateFormat(dateFormat);
		JaxbAnnotationModule jaxbModule = new JaxbAnnotationModule();
		mapper.registerModule(jaxbModule);

		return mapper.writeValueAsString(order);

	}


}
