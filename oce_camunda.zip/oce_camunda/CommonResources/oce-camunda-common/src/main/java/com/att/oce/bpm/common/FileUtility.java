package com.att.oce.bpm.common;

/**
 * Class to provide common utility functions for reading/writting the files
 * Also, used to load the properties.
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

public class FileUtility {
	
	private static FileUtility instance;
	
	private FileUtility() {
		
	}
	
	public static FileUtility getInstance() {
		if(instance == null) {
			instance = new FileUtility();
		}
		return instance;
	}
	
	/**
	 * Return the file content of give file name.
	 * File must be in classpath.
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public String getFileContent(String fileName) throws IOException {
		InputStream stream = getClass().getClassLoader().getResourceAsStream(fileName);
		
		byte[] data = new byte[stream.available()];
		stream.read(data);
		
		/*BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder out = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			out.append(line);
		}
		
		is.close();
		reader.close();*/
		
		return new String(data);
	}
	
	public InputStream getInputStream(String fileName) {
		return getClass().getClassLoader().getResourceAsStream(fileName);
	}
	
	/**
	 * Load the properties from properties file.
	 * File must be in classpath.
	 * @param propFileName
	 * @return
	 * @throws IOException
	 */
	public Properties loadProperties(String propFileName) throws IOException {
		InputStream propIs = getClass().getClassLoader().getResourceAsStream(propFileName);
		
		Properties props = new Properties();
		props.load(propIs);
		
		propIs.close();
		
		return props;
	}

}
