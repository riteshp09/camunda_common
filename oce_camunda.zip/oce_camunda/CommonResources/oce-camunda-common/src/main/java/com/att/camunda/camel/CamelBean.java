package com.att.camunda.camel;

import org.apache.camel.Exchange;

public interface CamelBean {
	
	public void execute(Exchange e);
	
	public void processMessage();

}
