package com.att.oce.bpm.camunda.engine.plugins;

import java.util.ArrayList;
import java.util.List;

import org.camunda.bpm.engine.impl.bpmn.parser.BpmnParseListener;
import org.camunda.bpm.engine.impl.cfg.AbstractProcessEnginePlugin;
import org.camunda.bpm.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.camunda.bpm.engine.impl.cfg.ProcessEnginePlugin;

import com.att.oce.bpm.listeners.ProgressLoggingSupportParseListener;

/**
 * <p>
 * {@link ProcessEnginePlugin} enabling the progress logging support parse
 * listener support.
 * </p>
 *
 * @author kristin.polenz
 *
 */
public class ProgressLoggingSupportParseListenerPlugin extends AbstractProcessEnginePlugin {

	@Override
	public void preInit(ProcessEngineConfigurationImpl processEngineConfiguration) {
		try {
			List<BpmnParseListener> preParseListeners = processEngineConfiguration.getCustomPreBPMNParseListeners();
			if (preParseListeners == null) {
				preParseListeners = new ArrayList<BpmnParseListener>();
				processEngineConfiguration.setCustomPreBPMNParseListeners(preParseListeners);
			}
			preParseListeners.add(new ProgressLoggingSupportParseListener());
		} catch(Exception e){
			e.printStackTrace();
		}
	}

}
