package com.att.oce.bpm.listeners;

import org.camunda.bpm.engine.delegate.ExecutionListener;
import org.camunda.bpm.engine.impl.bpmn.parser.AbstractBpmnParseListener;
import org.camunda.bpm.engine.impl.pvm.PvmEvent;
import org.camunda.bpm.engine.impl.pvm.process.ActivityImpl;
import org.camunda.bpm.engine.impl.pvm.process.ScopeImpl;
import org.camunda.bpm.engine.impl.util.xml.Element;

/**
 * BPMN Parse Listener to parse extension properties on service task
 *
 * @author kristin.polenz
 *
 */
public class ProgressLoggingSupportParseListener extends AbstractBpmnParseListener {

	protected ExecutionListener ACTIVITY_INSTANCE_START_LISTENER;
	protected ExecutionListener ACTIVITY_INSTANCE_END_LISTENER;

	protected void initExecutionListeners() {

		ACTIVITY_INSTANCE_START_LISTENER = new ActivityLoggingExecutionListener();
		ACTIVITY_INSTANCE_END_LISTENER = new ActivityLoggingExecutionListener();

	}

	public ProgressLoggingSupportParseListener() {
		initExecutionListeners();
	}

	@Override
	public void parseServiceTask(Element serviceTaskElement, ScopeImpl scope, ActivityImpl activity) {
		activity.addBuiltInListener(PvmEvent.EVENTNAME_START, ACTIVITY_INSTANCE_START_LISTENER);
		activity.addBuiltInListener(PvmEvent.EVENTNAME_END, ACTIVITY_INSTANCE_END_LISTENER);
	}

	@Override
	public void parseScriptTask(Element scriptTaskElement, ScopeImpl scope, ActivityImpl activity) {
		activity.addBuiltInListener(PvmEvent.EVENTNAME_START, ACTIVITY_INSTANCE_START_LISTENER);
		activity.addBuiltInListener(PvmEvent.EVENTNAME_END, ACTIVITY_INSTANCE_END_LISTENER);
	}

}
