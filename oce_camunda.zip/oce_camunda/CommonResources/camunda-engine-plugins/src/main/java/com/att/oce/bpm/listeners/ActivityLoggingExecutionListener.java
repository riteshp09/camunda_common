package com.att.oce.bpm.listeners;

import java.util.ArrayList;
import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.ExecutionListener;

/**
 * Execution listener to log property extension value
 *
 * @author kristin.polenz
 *
 */
public class ActivityLoggingExecutionListener implements ExecutionListener {

  private final Logger LOGGER = Logger.getLogger(this.getClass().getName());
  
  public static ArrayList<String> activities = new ArrayList<>();
  
  public void notify(DelegateExecution execution) throws Exception {
    LOGGER.info(execution.getActivityInstanceId()+"~"+execution.getCurrentActivityName());
    activities.add(execution.getCurrentActivityName());
  }

}
