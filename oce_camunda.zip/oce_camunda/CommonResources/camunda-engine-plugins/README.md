# Camunda Engine Plugins

This respository is used to define engine plugins.

# ProgressLoggingSupportParseListenerPlugin
This logs all the script and service activity executed in the engine, also keeps a log in a string list.
This is to be used for unit test cases to check the intermediate status of the activity.

