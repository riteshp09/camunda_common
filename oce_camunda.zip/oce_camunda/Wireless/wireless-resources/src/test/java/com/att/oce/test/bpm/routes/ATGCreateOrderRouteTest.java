package com.att.oce.test.bpm.routes;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.ExchangeBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.ModelCamelContext;
import org.apache.camel.test.spring.CamelSpringDelegatingTestContextLoader;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.springframework.context.annotation.Configuration;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.json.JSONException;
import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.context.annotation.Bean;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.apache.camel.spring.javaconfig.SingleRouteCamelConfiguration;
import com.att.oce.beans.config.APIResultConfig;
import com.att.oce.bpm.common.MapBuilder;
import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.bpm.routes.ATGCreateOrderRouteBuilder;
import com.att.oce.bpm.transformations.ATGCreateOrderTransformation;
import com.att.oce.beans.config.OceConfig;
import com.att.oce.config.components.GlobalProperties;
import com.att.oce.config.components.URNResolver;

@RunWith(CamelSpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ATGCreateOrderRouteTest.TestConfig.class, OceConfig.class, APIResultConfig.class,
		ATGCreateOrderTransformation.class, GlobalProperties.class,
		URNResolver.class }, loader = CamelSpringDelegatingTestContextLoader.class)

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ATGCreateOrderRouteTest {

	@Configuration
	public static class TestConfig extends SingleRouteCamelConfiguration {
		@Bean
		@Override
		public RouteBuilder route() {
			return new ATGCreateOrderRouteBuilder();
		}

		@Bean
		public static DmnEngine dmnEngine() {
			// create default DMN engine configuration
			DmnEngineConfiguration configuration = DmnEngineConfiguration.createDefaultDmnEngineConfiguration();

			// build a new DMN engine
			DmnEngine dmnEngine = configuration.buildEngine();
			return dmnEngine;
		}

	}

	@Produce(uri = "direct:atg")
	protected ProducerTemplate prodTemplate;

	@BeforeClass
	public static void init() {
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireless");
		System.setProperty("OCE_RESOURCES_HOME", "./../../../oce_framework/oce-resources/src/main/resources/");
	}

	@DirtiesContext
	@Test
	public void testRoute() throws Exception {
		
		File file = new File("./src/test/resources/data/createOrderResponse.json");		
		final FileInputStream fis = new FileInputStream(file);
		
		prodTemplate.getCamelContext().getRouteDefinitions().get(0)
		.adviceWith(prodTemplate.getCamelContext().adapt(ModelCamelContext.class), new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				interceptSendToEndpoint("http://headeruri?throwExceptionOnFailure=false").skipSendToOriginalEndpoint().setBody(constant(fis));
			}
		});

		Exchange e = prodTemplate.send("direct:atg",
				ExchangeBuilder.anExchange(prodTemplate.getCamelContext())
				.withBody(MapBuilder.build()
				.add("imspGroup", "GROUP_01")		
				.add("order", TestOrderBuilder.build("order_d5.json").getMapofMaps()).get())
				.withProperty("executionContext", MapBuilder.build().add("test", "testvalue").get()).build());
		
        System.out.println("Response from Camel to BPMN:"+e.getProperty("executionContext"));
        
	}

}