package com.att.oce.test.bpm.common;


import com.att.oce.bpm.common.OceEnums;


import org.junit.Test;
import org.junit.Assert;

public class OceEnumsTest {

	@Test
	public void test_getCSIAccountType_OCE_TO_CSI()
	{
		String expected = "I";
		String actual = OceEnums.getCSIAccountType("INDIVIDUAL");
		Assert.assertEquals(expected, actual);
	}
	
	@Test
	public void test_getCSIAccountType_CSI_OCE()
	{
		String expected = "INDIVIDUAL";
		String actual = OceEnums.getOCEAccountType("I");
		Assert.assertEquals(expected, actual);
	}
	
}
