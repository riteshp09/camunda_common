package com.att.oce.test.bpm.routes;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.ExchangeBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.ModelCamelContext;
import org.apache.camel.test.spring.CamelSpringDelegatingTestContextLoader;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.springframework.context.annotation.Configuration;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.json.JSONException;
import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.context.annotation.Bean;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.apache.camel.spring.javaconfig.SingleRouteCamelConfiguration;
import com.att.oce.beans.config.APIResultConfig;
import com.att.oce.bpm.common.MapBuilder;
import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.bpm.routes.ATGGetOrderRouteBuilder;
import com.att.oce.bpm.transformations.ATGGetOrderTransformation;
import com.att.oce.beans.config.OceConfig;
import com.att.oce.config.components.GlobalProperties;
import com.att.oce.config.components.URNResolver;

@RunWith(CamelSpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ATGGetOrderRouteTest.TestConfig.class, OceConfig.class, APIResultConfig.class,
		ATGGetOrderTransformation.class, GlobalProperties.class,
		URNResolver.class }, loader = CamelSpringDelegatingTestContextLoader.class)

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ATGGetOrderRouteTest {

	@Configuration
	public static class TestConfig extends SingleRouteCamelConfiguration {
		@Bean
		@Override
		public RouteBuilder route() {
			return new ATGGetOrderRouteBuilder();
		}

		@Bean
		public static DmnEngine dmnEngine() {
			// create default DMN engine configuration
			DmnEngineConfiguration configuration = DmnEngineConfiguration.createDefaultDmnEngineConfiguration();

			// build a new DMN engine
			DmnEngine dmnEngine = configuration.buildEngine();
			return dmnEngine;
		}

	}

	@Produce(uri = "direct:atg:get")
	protected ProducerTemplate prodTemplate;

	@BeforeClass
	public static void init() {
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireless");
		System.setProperty("OCE_RESOURCES_HOME", "./../../../oce_framework/oce-resources/src/main/resources/");
	}

	@DirtiesContext
	@Test
	public void testRoute() throws Exception {
		
		/*prodTemplate.getCamelContext().getRouteDefinitions().get(0)
		.adviceWith(prodTemplate.getCamelContext().adapt(ModelCamelContext.class), new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				interceptSendToEndpoint("http://headeruri?throwExceptionOnFailure=false")
						.skipSendToOriginalEndpoint().setBody(constant(TestOrderBuilder
								.build("data/atg/createOrderResponse.json").toString()));
				onCompletion().to("mock:result:check");
			}
		});
*/
		
		prodTemplate.getCamelContext().getRouteDefinitions().get(0)
		.adviceWith(prodTemplate.getCamelContext().adapt(ModelCamelContext.class), new RouteBuilder() {
			@Override
			public void configure() throws Exception {
				interceptSendToEndpoint("http://headeruri?throwExceptionOnFailure=false")
				.skipSendToOriginalEndpoint().setBody(constant(TestOrderBuilder
						.build("data/atg/getOrderResponse.json").toString()));
				
			}
		});
		
		
		Exchange e = prodTemplate.send("direct:atg:get", new ExchangeProcessor());
		
        System.out.println("Response from Camel to BPMN:"+e.getProperty("executionContext"));
        
	}
	
	class ExchangeProcessor implements Processor {

		public void process(Exchange inExchange) throws JSONException {

			HashMap<String, Object> orderMap = (HashMap<String, Object>) TestOrderBuilder
					.build("data/oceOrderPayload.json").getMapofMaps();

			Map<String, Object> variables = new HashMap<String, Object>();
			variables.put("order", orderMap);
			inExchange.setProperty("executionContext", new HashMap<String, Object>());
			inExchange.getIn().setBody(variables);
		}
	}

}