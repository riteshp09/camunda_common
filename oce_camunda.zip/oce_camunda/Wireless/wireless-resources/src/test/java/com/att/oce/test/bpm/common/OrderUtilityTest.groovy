package com.att.oce.test.bpm.common


import org.junit.*
import com.att.oce.bpm.common.util.OrderUtility
import com.att.oce.bpm.camel.converters.OceJsonConverters
import com.att.oce.bpm.common.TestOrderBuilder

class OrderUtilityTest {
	
	
	def testOrder =  TestOrderBuilder.build("oceOrder.json").mapofMaps
	def testOrder1 = TestOrderBuilder.build("oceOrder_deenrollment_transaction.json").mapofMaps
	def testOrder2 = TestOrderBuilder.build("oceOrder_multiline.json").mapofMaps
	
	
	
	@Test
	void test_contains()
	{
		def list = new ArrayList()
		list.add("1")
		list.add("2")
		list.add("3")
			
		def searchString1 = "1"		
		def searchString2 = "4"
		
		assert OrderUtility.contains(list,searchString1) : "Not Matching"
		assert !OrderUtility.contains(list,searchString2) : "Not Matching"
		
	}
	
	@Test
	void test_getLosgCountAndgetLosgsFromOrder()
	{
		
		def losgCount = OrderUtility.getLosgCount(testOrder.Order)
		def losgs = OrderUtility.getLosgsFromOrder(testOrder.Order)
		
		assert (losgCount >= 1 && losgCount == losgs.size() && losgs.get(0).Type == "LINE_OF_SERVICE" ) : "LOSGs are not matching"
	}

}
