package com.att.oce.test.bpm.common;

import static org.junit.Assert.*;

import java.io.File;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.bpm.transformations.ATGCreateOrderTransformation;

import groovy.json.JsonSlurper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {ATGCreateOrderTransformation.class})
public class OrderUtiltest {

	@Autowired ATGCreateOrderTransformation orderUtil;
	
	@Test
	public void testvalidateCancelledOrder() {
		File inputFile = new File("./src/test/resources/data/CancelledOrder.json");
		Map<String,Object> Order = (Map<String, Object>) new JsonSlurper().parse(inputFile);
		assertEquals(true,orderUtil.validateCancelledOrder(Order));
	}

}
