package com.att.oce.bpm.common;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;

public abstract class ConnectedCarTransformationService extends TransformationService{
	private static String HTTP_METHOD_POST = "POST";
	private static String HTTP_CONTENT_TYPE_JSON = "application/json";

	protected Map<String,Object> createMessageHeader(Map<String,Object> order) {
		return getMap( "trackingMessageHeader",getMap( 
				"version" , globalConfig.csiVersion,
				"messageId" , order.get("RequestId").toString()+order.get("CustomerOrderNumber").toString()+java.util.UUID.randomUUID().toString(),
				"originatorId" , globalConfig.csiOriginatorId,
				"dateTimeStamp" , getXmlDateTime()),
		 "securityMessageHeader" , getMap(
			 	"userName" , globalConfig.csiUserName,
				"userPassword" , globalConfig.csiPassword),
		 "sequenceMessageHeader" , getMap(
			  	"sequenceNumber" , 1,
			    "totalInSequence" , 1)
		);
	}

	protected Map<String,Object> createMessageHeaderOCE(Map<String,Object> order) {
		return getMap( "trackingMessageHeader",getMap( 
				"version" , globalConfig.csiVersion,
				"messageId" , order.get("RequestId").toString()+order.get("CustomerOrderNumber").toString()+java.util.UUID.randomUUID().toString(),
				"originatorId" , globalConfig.csiOriginatorId,
				"dateTimeStamp" , getXmlDateTime()),
		 "securityMessageHeader" , getMap(
			 	"userName" , globalConfig.csiOceUserName,
				"userPassword" , globalConfig.csiOcePassword),
		 "sequenceMessageHeader" , getMap(
			  	"sequenceNumber" , 1,
			    "totalInSequence" , 1)
		);
	}
	protected void setATGHttpHeaders(Exchange exchange,boolean update){
		exchange.getIn().getHeaders().put("CamelHttpMethod",HTTP_METHOD_POST);
		exchange.getIn().getHeaders().put("Accept",HTTP_CONTENT_TYPE_JSON);
		exchange.getIn().getHeaders().put("Content-Type",HTTP_CONTENT_TYPE_JSON);
	}

}
