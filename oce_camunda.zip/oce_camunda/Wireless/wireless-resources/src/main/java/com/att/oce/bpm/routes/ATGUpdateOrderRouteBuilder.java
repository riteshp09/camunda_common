package com.att.oce.bpm.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.bpm.transformations.ATGUpdateOrderTransformation;

@Component("atgUpdateOrderRouteBuilder")
public class ATGUpdateOrderRouteBuilder extends RouteBuilder{

	@Override
	public void configure() throws Exception {		
		from("direct:atg:update")
		.bean(ATGUpdateOrderTransformation.class,"transform")
		.bean(AuditLogHelper.class,"logRequest")
		.to("http://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.bean(AuditLogHelper.class,"logResponse")
		.bean(ATGUpdateOrderTransformation.class,"processResponse")
		.setId("atgUpdateOrderRouteBuilder");
	}

}
