package com.att.oce.bpm.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.bpm.transformations.FraudServiceTransformation;

@Component("fraudServiceRouteBuilder")
public class FraudServiceRouteBuilder extends RouteBuilder{

	@Override
	public void configure() throws Exception {		
		from("direct:fraud")
		.bean(FraudServiceTransformation.class,"transform")
		.to("velocity:vm/fraudvalidation.vm?propertiesFile=/props/velocity-template.properties")
		.bean(AuditLogHelper.class,"logRequest")		
		.to("http://headeruri?throwExceptionOnFailure=false")
		.convertBodyTo(String.class)
		.bean(AuditLogHelper.class,"logResponse")
		.bean(FraudServiceTransformation.class,"processResponse")
		.setGroup("FraudServiceRouteBuilder");
		
	}

}
