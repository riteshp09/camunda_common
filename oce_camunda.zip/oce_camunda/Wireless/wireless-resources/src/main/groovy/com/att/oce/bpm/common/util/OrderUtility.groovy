package com.att.oce.bpm.common.util

import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.util.json.JSONObject
import org.camunda.bpm.engine.impl.util.json.XML
import com.att.oce.bpm.camel.converters.OceJsonConverters
import com.att.oce.bpm.common.OceConstants
import com.att.oce.bpm.error.APIFailedException
import groovy.util.slurpersupport.GPathResult

class OrderUtility {

	/*
	 * This function will return the List of LoSG's present in the given order
	 */
	static def getLosgsFromOrder(orderMap) {
		def groupList = orderMap.Groups.Group

		//Getting the LOSGs in a list
		def losgs = new ArrayList()
		for(def i=0;i<groupList.size();i++){
			def groupMap=groupList.get(i)
			if(groupMap.Type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE ){
				losgs.add(groupMap)
			}
		}
		return losgs
	}

	/*
	 * This function will return the count of number of LoSG's present in the given order
	 */
	static def getLosgCount(orderMap){

		def groupList=orderMap.Groups.Group

		//Getting the LOSG count
		def losgCount=0
		for(def i=0;i<groupList.size();i++){
			def groupMap=groupList.get(i)

			if(groupMap.Type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE ){
				losgCount++
			}
		}
		return losgCount
	}

	/*
	 * This function will take a LOSG as argument
	 * returns true if the LOSG is in terminal status, else false
	 */
	static def isTerminalLOSGStatus(losg){
		def terminalStatus = new ArrayList<String>()
		terminalStatus.add("COMPLETED")
		terminalStatus.add("CANCELED")


		def isTerminalStatus = false
		if(losg.Type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE
		&& contains(terminalStatus,losg.GroupCharacteristics.LoSGCharacteristics.LoSGStatus.Status)){
			isTerminalStatus = true
		}

		return isTerminalStatus
	}

	/*
	 * This function will take a List as first argument and String to search as second argument
	 * returns true if search string is found in the list, else false
	 */
	static def contains(list, name) {
		for (String item : list) {
			if (item.equals(name)) {
				return true;
			}
		}
		return false;
	}

	/*
	 * This function will return the Group's which are not in terminal status
	 */
	static def getNonTerminalLoSGs(order){
		def groupList = order.Groups.Group
		def nonTerminalLosgs = new ArrayList()

		for(def i=0;i<groupList.size();i++)	{
			def losg = groupList.get(i)

			if(isTerminalLOSGStatus(losg) == false ){
				nonTerminalLosgs.add(losg)
			}
		}

		return nonTerminalLosgs
	}

	/*
	 * This function will convert the provided JSON Map into XML String
	 * 
	 */
	static def convertJsonToXml(Map<String,Object> jsonMap){
		def jsonObject = new JSONObject(jsonMap)
		def xmlString = XML.toString(jsonObject)
		return xmlString
	}

	/*
	 * This function will construct the APIFailedException object
	 * @param csiAPIResponse GPathResult
	 * @param apiName String
	 * @return exception APIFailedException
	 */
	static def getAPIExceptionForCSI(GPathResult csiApiResponse,String apiName){
		APIFailedException exception = new APIFailedException()
		exception.api = apiName
		exception.code = csiApiResponse.Body.Fault.detail.CSIApplicationException.Response.code
		exception.codeDescription = csiApiResponse.Body.Fault.detail.CSIApplicationException.Response.description
		exception.subCode = csiApiResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code
		exception.subCodeDescription = csiApiResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
		return exception
	}

	/*
	 * This function will construct the APIFailedException object
	 * @param code String
	 * @param apiName String
	 * @return exception APIFailedException
	 */
	static def getAPIException(String code,String apiName){
		def codeDescription
		if(code == OceConstants.SUCCESS_CODE_0){
			codeDescription = OceConstants.SUCCESS
		}else if (code == OceConstants.ERROR_CODE_200){
			codeDescription = OceConstants.ERROR
		}else{
			codeDescription = OceConstants.NOT_APPLICABLE
		}

		APIFailedException exception = new APIFailedException()
		exception.api = apiName
		exception.code = code
		exception.codeDescription = codeDescription

		return exception
	}
}
