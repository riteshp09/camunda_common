package com.att.oce.bpm.transformations

import com.att.oce.bpm.common.OceConstants
import com.att.oce.bpm.common.OceLiterals
import com.att.oce.bpm.common.OceEnums
import com.att.oce.bpm.common.util.OrderUtility
import com.att.oce.bpm.common.ConnectedCarTransformationService
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.config.components.GlobalProperties
import groovy.json.JsonSlurper
import groovy.util.slurpersupport.GPathResult
import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.camunda.bpm.engine.impl.util.json.JSONObject
import org.camunda.bpm.engine.impl.util.json.XML
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.PropertySource
import org.springframework.core.io.Resource
import org.springframework.stereotype.Component

import com.att.oce.bpm.camel.converters.OceJsonConverters

@Component('atgGetOrderTransformation')
class ATGGetOrderTransformation extends ConnectedCarTransformationService{

	String url;


	@Override
	protected void setATGHttpHeaders(Exchange exchange,boolean update){
		exchange.getIn().getHeaders().put("CamelHttpMethod",OceConstants.HTTP_METHOD_GET);
		exchange.getIn().getHeaders().put("Accept",OceConstants.HTTP_CONTENT_TYPE_JSON);
		exchange.getIn().getHeaders().put("Content-Type",OceConstants.HTTP_CONTENT_TYPE_JSON);
	}
	
	/*
	 * This function will do the transformation for ATG Get Order
	 * @param exchange of type Camel Exchange
	 * */
	public def transform(Exchange exchange){

		exchange.properties.order = exchange.in.body.order

		this.setATGHttpHeaders(exchange,false)
		exchange.in.headers.put("CamelHttpUri",super.resolveURN('urn:atg:api',url)+"/"+exchange.in.body.order.OCEOrderNumber)
		exchange.out.headers = exchange.in.headers
		exchange.out.body = ""
	}


	/*
	 * This function will take the ATG response  and do necessary processing
	 * Will update order payload during success or return the APIFailedException object in case of Soap Fault
	 * @param exchange - Camel Exchange
	 * */
	def processResponse(Exchange exchange) throws Exception{
		def atgResponse = new JsonSlurper().parseText(exchange.in.body)
		def orderMap = exchange.properties.order

		return updateOrder(orderMap,atgResponse,exchange)
	}

	def updateOrder(orderMap,atgResponse,exchange) throws Exception{
		orderMap = atgResponse.OrderDetails ? atgResponse.OrderDetails[0].Order : orderMap
		def atleastOneNonCanceledLinePresent = true
		orderMap.Groups.Group.find{
			if(it.GroupCharacteristics.LoSGCharacteristics && it.GroupCharacteristics.LoSGCharacteristics.LoSGStatus.Status != OceConstants.LOSG_STATUS_CANCELED ){
				atleastOneNonCanceledLinePresent = true
				return true
			}else{
				return false
			}
		}

		def executionContext = exchange.properties.executionContext
		if(!atleastOneNonCanceledLinePresent){			
			executionContext.put("orderCancel",true)			
		}else{
			executionContext.put("orderCancel",false)
		}
		exchange.properties.executionContext = executionContext
		return orderMap
	}
}
