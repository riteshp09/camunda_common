package com.att.oce.bpm.transformations

import com.att.oce.bpm.common.OceConstants
import com.att.oce.bpm.common.OceLiterals
import com.att.oce.bpm.common.OceEnums
import com.att.oce.bpm.common.util.OrderUtility
import com.att.oce.bpm.common.ConnectedCarTransformationService
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.config.components.GlobalProperties
import groovy.json.JsonSlurper
import groovy.util.slurpersupport.GPathResult

import java.util.HashMap
import java.util.Map

import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.camunda.bpm.engine.impl.util.json.JSONObject
import org.camunda.bpm.engine.impl.util.json.XML
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.PropertySource
import org.springframework.core.io.Resource
import org.springframework.stereotype.Component

import com.att.oce.bpm.camel.converters.OceJsonConverters

@Component('fraudServiceTransformation')
class FraudServiceTransformation extends ConnectedCarTransformationService{

	String url;

	@Override
	String getApiName(){
		return OceConstants.API_NAME_FRAUD_VALIDATION_SERVICE
	}


	/*
	 * This function will do the transformation for Fraud Service
	 * @param exchange of type Camel Exchange
	 * */
	public void transform(Exchange exchange){

		exchange.properties.order = exchange.in.body.order

		def oceJsonMap = exchange.in.body.order
		def oceXmlOrder = XML.toString(new JSONObject(oceJsonMap))
		
		exchange.out.body = oceXmlOrder
		super.setCSIHttpHeaders(exchange)
		exchange.in.headers.put("CamelHttpUri",resolveURN('urn:brms:services',url))
		//exchange.in.headers.put("CamelHttpUri","http://zlt08652.vci.att.com:7605/BRMSServices/brmsService")
		exchange.out.headers = exchange.in.headers
		exchange.properties.put("OceCSIApiName", OceConstants.API_NAME_FRAUD_VALIDATION_SERVICE )
	}


	/*
	 * This function will take the Fraud response  and do necessary processing
	 * Will update order payload during success or return the APIFailedException object in case of Soap Fault
	 * @param exchange - Camel Exchange
	 * */
	def processResponse(Exchange exchange) throws APIFailedException{
		def fraudResponse = new XmlSlurper().parseText(exchange.in.body)
		def orderMap = exchange.properties.order

		//Delete the Properties which are no longer required
		exchange.removeProperty("order")

		return updateOrder(orderMap,fraudResponse.Body.executeFraudChecksResponse,exchange)
	}

	def updateOrder(order,fraudResponse,exchange){
		Map<String, Object> orderMap = updateStatus(order,fraudResponse,exchange)

		def orderAdditionalDetails = (orderMap.AdditionalDetails && orderMap.AdditionalDetails.AdditionalDetail) ? orderMap.AdditionalDetails.AdditionalDetail : []

		def fraudAdditionalDetailsList = []
		if(fraudResponse.return.StatusDetails.AdditionalDetails && fraudResponse.return.StatusDetails.AdditionalDetails.AdditionalDetail.size() > 0){
			fraudResponse.return.StatusDetails.AdditionalDetails.AdditionalDetail.each{ aDetail ->					
				fraudAdditionalDetailsList << [Type:aDetail.Type.text(),Code:aDetail.Code.text(),Value:aDetail.Value.text()]
			}
		}
		
		def AdditionalDetails = [AdditionalDetail:
			orderAdditionalDetails + fraudAdditionalDetailsList]
		orderMap.put("AdditionalDetails", AdditionalDetails)

		exchange.in.body = orderMap
		//return orderMap
	}

	def updateStatus(orderMap,fraudResponse,exchange){
		def e = new APIFailedException()
		def loSGStatus
		if( fraudResponse.return.StatusDetails && fraudResponse.return.StatusDetails.Status.text().length() > 0){
			loSGStatus = [Status:fraudResponse.return.StatusDetails.Status.text(), SubStatus:fraudResponse.return.StatusDetails.SubStatus.text()]
			e = OrderUtility.getAPIException(OceConstants.ERROR_CODE_200,this.getApiName())
			exchange.setException(e)
		}else if(fraudResponse.return.size() > 0 ){
			loSGStatus = [Status:OceConstants.LOSGSTATUS_SYS_PROCESSING, SubStatus:OceConstants.LOSGSUBSTATUS_FRAUD_APPROVED]
			e = OrderUtility.getAPIException(OceConstants.SUCCESS_CODE_0,this.getApiName())
		}else{
			loSGStatus = [Status:OceConstants.LOSGSTATUS_IN_QUEUE, SubStatus:OceConstants.LOSGSUBSTATUS_FRAUD_REVIEW_MED]
			e = OrderUtility.getAPIException(OceConstants.ERROR_CODE_200,this.getApiName())
			exchange.setException(e)
		}

		orderMap.Groups.Group.each{ losg ->
			if(losg.GroupCharacteristics.LoSGCharacteristics){
				losg.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",loSGStatus)
			}
		}

		super.addTransactionHistory(exchange,e)

		return orderMap
	}
}
