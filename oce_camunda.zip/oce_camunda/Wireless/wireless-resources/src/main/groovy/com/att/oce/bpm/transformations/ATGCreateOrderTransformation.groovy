package com.att.oce.bpm.transformations

import com.att.oce.bpm.common.OceConstants
import com.att.oce.bpm.common.OceLiterals
import com.att.oce.bpm.common.OceEnums
import com.att.oce.bpm.common.util.OrderUtility
import com.att.oce.bpm.common.ConnectedCarTransformationService
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.config.components.GlobalProperties
import groovy.json.JsonSlurper
import groovy.util.slurpersupport.GPathResult
import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.camunda.bpm.engine.impl.util.json.JSONObject
import org.camunda.bpm.engine.impl.util.json.XML
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.PropertySource
import org.springframework.core.io.Resource
import org.springframework.stereotype.Component

import com.att.oce.bpm.camel.converters.OceJsonConverters

@Component('atgCreateOrderTransformation')
class ATGCreateOrderTransformation extends ConnectedCarTransformationService{

	String url;

	/*
	 * This function will do the transformation for ATG Create Order service
	 * @param exchange of type Camel Exchange
	 * */
	public def transform(Exchange exchange){

		exchange.properties.order = exchange.in.body.order
		def oceJsonMap = exchange.in.body.order
		def atgOrderMap = [Order:oceJsonMap]

		def order = new JSONObject(atgOrderMap).toString()
		super.setATGHttpHeaders(exchange,false)
		exchange.in.headers.put("CamelHttpUri",super.resolveURN('urn:atg:api',url))
		return order
	}


	/*
	 * This function will take the ATG create order response  and do necessary processing
	 * Will update order payload during success or return the APIFailedException object in case of Soap Fault
	 * @param exchange - Camel Exchange
	 * */
	def processResponse(Exchange exchange) {
		def atgResponse = new JsonSlurper().parseText(exchange.in.body)
		def orderMap = exchange.properties.order

		//Delete the Properties which are no longer required
		exchange.removeProperty("order")

		Map<String,Object> updatedOrder = updateOrder(orderMap,atgResponse,exchange)
		exchange.in.body = updatedOrder
		//exchange.out.body = updatedOrder
		//return updatedOrder
	}

	def updateOrder(orderMap,atgResponse,exchange){		
		orderMap.put("OCEOrderNumber",atgResponse.OrderNumber)
		return orderMap
	}
	
	def validateOrderForFalloutManagement(def apiName, def executionContext) {
		def result = false
		def transactionHistory = executionContext.transactionHistory
		def statusList = transactionHistory.findAll {t -> t.api == apiName}.collect{it.status}

		if(statusList.contains(OceConstants.LOSG_STATUS_IN_QUEUE))
			result = true
		
		return result
	}

	def validateCancelledOrder(def Order) {
		def result

		List<String> Status = new ArrayList<String>();
		Status.add("CANCELED");

		def groupList = Order.Groups.Group.findAll  {g -> g.Type == OceConstants.GROUP_TYPE}.collect{it}

		List<String> cancelLoSGList = new ArrayList<String>();

		for(def group in groupList) {
			if(group.Type.equals(OceConstants.GROUP_TYPE) &&
			group.GroupCharacteristics && group.GroupCharacteristics.LoSGCharacteristics &&
			group.GroupCharacteristics.LoSGCharacteristics.LoSGType.equals(OceConstants.LOSGTYPE_CHANGE) &&
			(Status.contains(group.GroupCharacteristics.LoSGCharacteristics.LoSGStatus.Status))) {
				cancelLoSGList.add(group);
			}
		}

		if(groupList.size() == cancelLoSGList.size())
			result = true
		else
			result = false

		return result
	}

}
