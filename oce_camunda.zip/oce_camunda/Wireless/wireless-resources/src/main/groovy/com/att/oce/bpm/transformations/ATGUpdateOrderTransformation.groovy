package com.att.oce.bpm.transformations

import com.att.oce.bpm.common.OceConstants
import com.att.oce.bpm.common.OceLiterals
import com.att.oce.bpm.common.OceEnums
import com.att.oce.bpm.common.util.OrderUtility
import com.att.oce.bpm.common.ConnectedCarTransformationService
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.config.components.GlobalProperties
import groovy.json.JsonSlurper
import groovy.util.slurpersupport.GPathResult

import java.util.List

import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.camunda.bpm.engine.impl.util.json.JSONObject
import org.camunda.bpm.engine.impl.util.json.XML
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.PropertySource
import org.springframework.core.io.Resource
import org.springframework.stereotype.Component


import com.att.oce.bpm.camel.common.ExchangeUtils
import com.att.oce.bpm.camel.converters.OceJsonConverters

@Component('atgUpdateOrderTransformation')
class ATGUpdateOrderTransformation extends ConnectedCarTransformationService{

	String url;

	/*
	 * This function will do the transformation for Fraud Service
	 * @param exchange of type Camel Exchange
	 * */
	public def transform(Exchange exchange){

		exchange.properties.order = exchange.in.body.order
		def oceJsonMap = exchange.in.body.order
		def executionContext = exchange.properties.executionContext
		def oceUpdatedOrder = updateLoSGStatus(oceJsonMap,executionContext)
		def transactionLogsList = createTransactionLogs(oceJsonMap,executionContext)
		def atgOrderMap = [Order:oceUpdatedOrder]
		def transactionLogsMap = [TransactionLogs:transactionLogsList]
		def transactionLogs = new JSONObject(transactionLogsMap).toString()
		def order = new JSONObject(atgOrderMap).toString()
		def atgUpdateReq = order+transactionLogs
		
		super.setATGHttpHeaders(exchange,false)
		exchange.in.headers.put("CamelHttpUri",super.resolveURN('urn:atg:api',url))
		//exchange.in.headers.put("CamelHttpUri","http://zld02786.vci.att.com:7605/oce/api/orders")
		return atgUpdateReq
	}


	/*
	 * This function will take the Fraud response  and do necessary processing
	 * Will update order payload during success or return the APIFailedException object in case of Soap Fault
	 * @param exchange - Camel Exchange
	 * */
	def processResponse(Exchange exchange) {
		def atgResponse = new JsonSlurper().parseText(exchange.in.body)
		def orderMap = exchange.properties.order

		//Delete the Properties which are no longer required
		exchange.removeProperty("order")

		Map<String,Object> updatedOrder = updateOrder(orderMap,atgResponse,exchange)
		exchange.in.body = updatedOrder
		//exchange.out.body = updatedOrder
		//return updatedOrder
	}

	def updateOrder(orderMap,atgResponse,exchange){		
		orderMap.put("OCEOrderNumber",atgResponse.OrderNumber)
		return orderMap
	}
	
	
	def createTransactionLogs(Order,executionContext){
		
		def transactionLogsList = new ArrayList()
		
		def group = OrderUtility.getLosgsFromOrder(Order)
		def orderId = Order.OCEOrderNumber ? Order.OCEOrderNumber : Order.ParentOrderNumber
		def service = group ? group.GroupCharacteristics.LoSGCharacteristics.ProductCategory.join(",") : Order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.ProductCategory.join(",")
		def servicetype = group ? group.GroupCharacteristics.LoSGCharacteristics.LoSGType.join(",") : Order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.LoSGType.join(",")
		def number = (group && group.GroupCharacteristics.LoSGCharacteristics.ConnectedCarLOSChars.MobileNumber ) ? group.GroupCharacteristics.LoSGCharacteristics.ConnectedCarLOSChars.MobileNumber : Order.CustomerOrderNumber
		def losgRefId = group ? group.GroupCharacteristics.LoSGCharacteristics.LoSGReferenceId.join(",") : Order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.LoSGReferenceId.join(",")
		
		Map<String,Object> transactionLogs = new HashMap<String, Object>();
		List<Map<String,Object>> transactionHistory = (List<Map<String,Object>>) executionContext.transactionHistory;
		
		for (Object transHis: transactionHistory) {
		
			def datetime = transHis.time ? transHis.time : dateTimeFormat.format(new Date())
		
			transactionLogs.put(OceLiterals.KEY_START_TIME,datetime)
			transactionLogs.put(OceLiterals.KEY_END_TIME,datetime)
			transactionLogs.put(OceLiterals.KEY_STATUS, transHis.status)
			transactionLogs.put(OceLiterals.KEY_SUB_STATUS,transHis.subStatus)
			transactionLogs.put(OceLiterals.KEY_ORDER_ID,orderId)
			transactionLogs.put(OceLiterals.KEY_SERVICE,service)
			transactionLogs.put(OceLiterals.KEY_SERVICE_TYPE,servicetype)
			transactionLogs.put(OceLiterals.KEY_NUMBER,number)
			transactionLogs.put(OceLiterals.KEY_LOSG_REFERENCE_ID,losgRefId)
			transactionLogs.put(OceLiterals.KEY_CHANGED_LOSG_REFERENCE_ID,losgRefId)
			//transLogTemplate.put(OceConstants.KEY_MARKER_KEY,"SYSTEM")
			//transLogTemplate.put(OceConstants.KEY_MARKER_TYPE1,"Order Update")
			
			transactionLogsList.add(transactionLogs)
		}
		
		return transactionLogsList
	}	
	
	def updateLoSGStatus(order,executionContext){
		def transactionHistory = executionContext.transactionHistory
		def loSGStatus
		if( transactionHistory != null){
			loSGStatus = [Status:transactionHistory.last().status, SubStatus:transactionHistory.last().subStatus]
		}

		order.Groups.Group.each{ losg ->
			if(losg.GroupCharacteristics.LoSGCharacteristics){
				losg.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",loSGStatus)
			}
		}
		return order
	}
		
}
