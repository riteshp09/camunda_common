Place any docs here that you want to access within the ajsc upon deployment of your service.
