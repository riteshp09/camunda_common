/*
-- Query: SELECT * FROM camundabpm.oce_ru_make_model
LIMIT 0, 5000

-- Date: 2017-03-24 18:53
*/
SET SCAN OFF;

-- INSERT QUERY NO: 1 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352250010000000_352250019999999', 'Motorola', 'L7', 'SLVR L7', 352250010000000, 352250019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350324000000000_350324999999999', 'Sony', 'T68m', 'T68m', 350324000000000, 350324999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 3 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351807040000000_351807049999999', 'HTC', 'T8788', 'Surround', 351807040000000, 351807049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 4 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352008060000000_352008069999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 352008060000000, 352008069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 5 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013044000000000_013044009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13044000000000, 13044009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 6 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353120000000000_353120009999999', 'Motorola', 'A630', 'A630', 353120000000000, 353120009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 7 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352040070000000_352040079999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 352040070000000, 352040079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 8 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356949040000000_356949049999999', 'Samsung', 'SGH-i857', 'Double Time', 356949040000000, 356949049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 9 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359093020000000_359093029999999', 'BlackBerry', 'BOLD 9000 NC', 'Bold 9000', 359093020000000, 359093029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 10 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351937040000000_351937049999999', 'BlackBerry', 'BOLD 9700', 'Bold 9700', 351937040000000, 351937049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 11 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352617040000000_352617049999999', 'Samsung', 'SGH-A177', 'SGH-A177', 352617040000000, 352617049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 12 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355142010000000_355142019999999', 'ZTE', 'Z667', 'Avant 667', 355142010000000, 355142019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 13 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010134000000000_010134999999999', 'Siemens', 'C56', 'C56', 10134000000000, 10134999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 14 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011354000000000_011354999999999', 'Samsung', 'SGH-A127', 'SGH-A127', 11354000000000, 11354999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 15 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013528000000000_013528009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13528000000000, 13528009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 16 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010334000000000_010334999999999', 'Nokia', '6010', '6010', 10334000000000, 10334999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 17 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354104080000000_354104089999999', 'LG', 'B470', 'B470', 354104080000000, 354104089999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 18 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012141000000000_012141009999999', 'Pantech', 'P7040', 'Link', 12141000000000, 12141009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 19 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353664000000000_353664009999999', 'Siemens', 'CT66', 'CT66', 353664000000000, 353664009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 20 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010782000000000_010782999999999', 'LG', 'C2000', 'C2000', 10782000000000, 10782999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 21 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012857000000000_012857009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12857000000000, 12857009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 22 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012851000000000_012851009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12851000000000, 12851009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 23 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011610000000000_011610009999999', 'Pantech', 'C530', 'Slate', 11610000000000, 11610009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 24 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013904000000000_013904009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13904000000000, 13904009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 25 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352565010000000_352565019999999', 'Samsung', 'SGH-zx20 HAC M-T', 'SGH-zx20 HAC M-T', 352565010000000, 352565019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 26 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355826080000000_355826089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7', 355826080000000, 355826089999999, 'Continue', ''
);

-- INSERT QUERY NO: 27 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011493000000000_011493009999999', 'Palm', 'T850UNA', 'Treo Pro', 11493000000000, 11493009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 28 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'869265010000000_869265019999999', 'ZTE', 'Z222', 'Z222', 869265010000000, 869265019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 29 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014163000000000_014163009999999', 'ASUS', 'T00S', 'T00S', 14163000000000, 14163009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 30 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354455040000000_354455049999999', 'HTC', 'PD98120', 'Inspire', 354455040000000, 354455049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 31 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353349070000000_353349079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353349070000000, 353349079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 32 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013992000000000_013992009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13992000000000, 13992009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 33 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354907080000000_354907089999999', 'Samsunsg', 'Galaxy S& Edge', 'Galaxy S7 Edge', 354907080000000, 354907089999999, 'Continue', ''
);

-- INSERT QUERY NO: 34 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013972000000000_013972009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13972000000000, 13972009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 35 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'868384000000000_868384009999999', 'Huawei', 'S7-312u', 'S7-312u', 868384000000000, 868384009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 36 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013068000000000_013068009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13068000000000, 13068009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 37 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354387060000000_354387069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 354387060000000, 354387069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 38 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011487000000000_011487999999999', 'LG', 'CU720', 'Shine', 11487000000000, 11487999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 39 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358445070000000_358445079999999', 'Samsung', 'SM-G935A', 'Galaxy S7 Edge', 358445070000000, 358445079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 40 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012957000000000_012957009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12957000000000, 12957009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 41 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354403060000000_354403069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354403060000000, 354403069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 42 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'449276000000000_449276999999999', 'Motorola', 'V.66', 'V.66', 449276000000000, 449276999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 43 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010061000000000_010061999999999', 'Motorola', 'V2282', 'V2282', 10061000000000, 10061999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 44 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359652060000000_359652069999999', 'Samsung', 'SM-G920A', 'Galaxy S6', 359652060000000, 359652069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 45 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352692040000000_352692049999999', 'Nokia', '6350', '6350', 352692040000000, 352692049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 46 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013502000000000_013502009999999', 'LG', 'C395', 'Xpression', 13502000000000, 13502009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 47 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352520000000000_352520999999999', 'Nokia', '3200', '3200', 352520000000000, 352520999999999, 'Continue', ''
);

-- INSERT QUERY NO: 48 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352079070000000_352079079999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 352079070000000, 352079079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 49 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012367000000000_012367000999999', 'Pantech', 'P7040P', 'Link', 12367000000000, 12367000999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 50 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352080070000000_352080079999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 352080070000000, 352080079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 51 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011250000000000_011250999999999', 'Motorola', 'C139 att', 'C139 att', 11250000000000, 11250999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 52 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010489000000000_010489999999999', 'Sony', 'T237', 'T237', 10489000000000, 10489999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 53 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013675000000000_013675009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13675000000000, 13675009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 54 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013052000000000_013052009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13052000000000, 13052009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 55 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356211050000000_356211059999999', 'Samsung', 'SGH-i217', 'SGH-i217', 356211050000000, 356211059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 56 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356042000000000_356042009999999', 'Motorola', 'V3', 'V3', 356042000000000, 356042009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 57 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012751000000000_012751009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12751000000000, 12751009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 58 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357260050000000_357260059999999', 'Nokia', '925', 'Lumia 925', 357260050000000, 357260059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 59 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353425060000000_353425069999999', 'Samsung', 'SM-G870A', 'K Active', 353425060000000, 353425069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 60 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358556070000000_358556079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 358556070000000, 358556079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 61 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358884000000000_358884009999999', 'HP', 'iPAQ-J 6920', 'iPAQ-J 6920', 358884000000000, 358884009999999, 'Continue', ''
);

-- INSERT QUERY NO: 62 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358598070000000_358598079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 358598070000000, 358598079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 63 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011613000000000_011613009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11613000000000, 11613009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 64 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354443060000000_354443069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354443060000000, 354443069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 65 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353107000000000_353107009999999', 'Motorola', 'V600', 'V600', 353107000000000, 353107009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 66 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'001000137000000_001000137999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 1000137000000, 1000137999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 67 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353297070000000_353297079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353297070000000, 353297079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 68 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013886000000000_013886009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13886000000000, 13886009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 69 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359212070000000_359212079999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 359212070000000, 359212079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 70 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355957060000000_355957069999999', 'Samsung', 'SM-G850A', 'Galaxy Alpha', 355957060000000, 355957069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 71 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010014000000000_010014999999999', 'Motorola', 'Select 2000e', 'Select 2000e', 10014000000000, 10014999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 72 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013262000000000_013262009999999', 'Pantech', 'P9090', 'P9090', 13262000000000, 13262009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 73 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354255020000000_354255029999999', 'Samsung', 'SGH-A437', 'SGH-A437', 354255020000000, 354255029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 74 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011402000000000_011402999999999', 'LG', 'CU915', 'CU915', 11402000000000, 11402999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 75 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351538000000000_351538009999999', 'Motorola', 'V3i', 'V3i', 351538000000000, 351538009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 76 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355605000000000_355605009999999', 'Motorola', 'V551', 'V551', 355605000000000, 355605009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 77 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359100050000000_359100059999999', 'Samsung', 'SGH-i257', 'SGH-i257', 359100050000000, 359100059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 78 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012964000000000_012964009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12964000000000, 12964009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 79 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355374080000000_355374089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7', 355374080000000, 355374089999999, 'Continue', ''
);

-- INSERT QUERY NO: 80 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357944000000000_357944009999999', 'Nokia', 'N80', 'N80', 357944000000000, 357944009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 81 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013929000000000_013929009999999', 'Alcatel', '4015T', '4015T', 13929000000000, 13929009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 82 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355006000000000_355006009999999', 'Nokia', '3220', '3220', 355006000000000, 355006009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 83 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354483060000000_354483069999999', 'Samsung', 'SM-N910A', 'Galaxy Note 4', 354483060000000, 354483069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 84 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354451060000000_354451069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 354451060000000, 354451069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 85 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012535000000000_012535009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12535000000000, 12535009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 86 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013779000000000_013779009999999', 'Pantech', 'P2050', 'Breeze IV', 13779000000000, 13779009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 87 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012023000000000_012023009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 12023000000000, 12023009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 88 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354815012000001_354815019999999', 'Nokia', 'N75', 'N75', 354815012000001, 354815019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 89 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014326000000000_014326009999999', 'Sonim', 'XP7700', 'XP7700', 14326000000000, 14326009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 90 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355655010000000_355655019999999', 'Samsung', 'SGH-A727', 'SGH-A727', 355655010000000, 355655019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 91 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013002000000000_013002009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13002000000000, 13002009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 92 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012159000000000_012159009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12159000000000, 12159009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 93 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013042000000000_013042009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13042000000000, 13042009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 94 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'866099020000000_866099029999999', 'ZTE', 'Z222', 'Z222', 866099020000000, 866099029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 95 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'863487010000000_863487019999999', 'ZTE', 'Z431', 'Z431', 863487010000000, 863487019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 96 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355324080000000_355324089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355324080000000, 355324089999999, 'Continue', ''
);

-- INSERT QUERY NO: 97 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359080000000000_359080009999999', 'Sony', 'Z520a', 'Z520a', 359080000000000, 359080009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 98 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353804080000000_353804089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 353804080000000, 353804089999999, 'Continue', ''
);

-- INSERT QUERY NO: 99 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010617000000000_010617999999999', 'LG', '1400i', '1400i', 10617000000000, 10617999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 100 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013237000000000_013237009999999', 'LG', 'P870', 'Escape', 13237000000000, 13237009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 101 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013429000000000_013429009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13429000000000, 13429009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 102 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011131000000000_011131999999999', 'Pantech', 'C3b', 'C3b', 11131000000000, 11131999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 103 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352637070000000_352637079999999', 'HTC', '2PQ9120', '2PQ9120', 352637070000000, 352637079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 104 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013038000000000_013038009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13038000000000, 13038009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 105 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359325060000000_359325069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 359325060000000, 359325069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 106 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011410000000000_011410999999999', 'Motorola', 'C168i', 'C168i', 11410000000000, 11410999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 107 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357288040000000_357288049999999', 'Samsung', 'SGH-i727', 'Galaxy S II Skyrocket', 357288040000000, 357288049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 108 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357812020000000_357812029999999', 'Samsung', 'SGH-A737', 'SGH-A737', 357812020000000, 357812029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 109 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013065000000000_013065009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13065000000000, 13065009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 110 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356556080000000_356556089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 356556080000000, 356556089999999, 'Continue', ''
);

-- INSERT QUERY NO: 111 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010736000000000_010736999999999', 'LG', 'CU320', 'CU320', 10736000000000, 10736999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 112 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352066060000000_352066069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 352066060000000, 352066069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 113 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010712000000000_010712999999999', 'Nokia', '6030', '6030', 10712000000000, 10712999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 114 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013611000000000_013611009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13611000000000, 13611009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 115 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359319060000000_359319069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 359319060000000, 359319069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 116 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013004000000000_013004009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13004000000000, 13004009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 117 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354941030000000_354941039999999', 'Samsung', 'SGH-A867', 'Eternity', 354941030000000, 354941039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 118 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011666000000000_011666009999999', 'LG', 'CU515', 'CU515', 11666000000000, 11666009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 119 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010851000000000_010851999999999', 'LG', 'CU500', 'CU500', 10851000000000, 10851999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 120 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350471000000000_350471999999999', 'Samsung', 'SGH-S308', 'SGH-S308', 350471000000000, 350471999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 121 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359167070000000_359167079999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 359167070000000, 359167079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 122 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'866737020000000_866737029999999', 'ZTE', 'Z812', 'Maven Blue', 866737020000000, 866737029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 123 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354220070000000_354220079999999', 'Samsung', 'SM-R750A', 'Gear S', 354220070000000, 354220079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 124 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013989000000000_013989009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13989000000000, 13989009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 125 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355787070000000_355787079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 355787070000000, 355787079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 126 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011578000000000_011578009999999', 'LG', 'CB630', 'Invision', 11578000000000, 11578009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 127 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'980028000000000_980028009999999', 'Motorola', 'ES405b', 'Motorola ES400', 980028000000000, 980028009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 128 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012755000000000_012755009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12755000000000, 12755009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 129 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010479000000000_010479999999999', 'Samsung', 'X427M', 'X427M', 10479000000000, 10479999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 130 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012842000000000_012842009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12842000000000, 12842009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 131 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357733050000000_357733059999999', 'Samsung', 'SGH-i527', 'Galaxy Mega', 357733050000000, 357733059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 132 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013893000000000_013893009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13893000000000, 13893009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 133 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010137000000000_010137999999999', 'Nokia', '6590i', '6590i', 10137000000000, 10137999999999, 'Continue', ''
);

-- INSERT QUERY NO: 134 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352268050000000_352268059999999', 'Sony', 'LT28at', 'Xperia Ion', 352268050000000, 352268059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 135 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352332080000000_352333089999999', 'Samsung', 'SM-G891A', 'Galaxy S7 Edge', 352333080000000, 352333089999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 136 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013033000000000_013033009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13033000000000, 13033009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 137 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355437070000000_355437079999999', 'Apple', 'iPhone SE A1662', 'iPhone SE', 355437070000000, 355437079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 138 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359231060000000_359231069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359231060000000, 359231069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 139 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010170000000000_010170999999999', 'Motorola', 'T720', 'T720', 10170000000000, 10170999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 140 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355720070000000_355720079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 355720070000000, 355720079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 141 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011745000000000_011745009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11745000000000, 11745009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 142 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011917000000000_011917009999999', 'Pantech', 'C740', 'Matrix', 11917000000000, 11917009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 143 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011323000000000_011323009999999', 'Motorola', 'C139 att', 'C139 att', 11323000000000, 11323009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 144 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014641000000000_014641009999999', 'Kyocera', 'E6820', 'E6820', 14641000000000, 14641009999999, 'Continue', ''
);

-- INSERT QUERY NO: 145 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010168000000000_010168999999999', 'Motorola', 'V70 1900', 'V70 1900', 10168000000000, 10168999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 146 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352269050000000_352269059999999', 'Motorola', 'ET1N2', 'ET1N2', 352269050000000, 352269059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 147 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010742000000000_010742999999999', 'LG', 'C2000', 'C2000', 10742000000000, 10742999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 148 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013177000000000_013177009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13177000000000, 13177009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 149 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354907070000000_354907079999999', 'Samsung', 'SM-T677A', 'Galaxy View', 354907070000000, 354907079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 150 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'869627020000000_869627029999999', 'ZTE', 'Z832', 'Sonata 3', 869627020000000, 869627029999999, 'Continue', ''
);

-- INSERT QUERY NO: 151 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013275000000000_013275009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13275000000000, 13275009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 152 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358594070000000_358594079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 358594070000000, 358594079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 153 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358333030000000_358333039999999', 'Motorola', 'MB508', 'FLIPSIDE', 358333030000000, 358333039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 154 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353920060000000_353920069999999', 'Samsung', 'SM-G900A', 'Galaxy S5', 353920060000000, 353920069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 155 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356983030000000_356983039999999', 'Samsung', 'SGH-i637', 'Jack', 356983030000000, 356983039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 156 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010560000000000_010560999999999', 'Nokia', '6010', '6010', 10560000000000, 10560999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 157 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355538020000000_355538029999999', 'Motorola', 'VC6096', 'VC6096', 355538020000000, 355538029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 158 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352507000000000_352507999999999', 'Motorola', 'V3', 'V3', 352507000000000, 352507999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 159 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012658000000000_012658009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12658000000000, 12658009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 160 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010497000000000_010497999999999', 'Nokia', '1100', '1100', 10497000000000, 10497999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 161 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358294000000000_358294999999999', 'Samsung', 'SGH-A437', 'SGH-A437', 358294000000000, 358294999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 162 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353809080000000_353809089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353809080000000, 353809089999999, 'Continue', ''
);

-- INSERT QUERY NO: 163 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355070010000000_355070019999999', 'Motorola', 'V3r', 'V3r', 355070010000000, 355070019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 164 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359412000000000_359412999999999', 'Motorola', 'KRZR att', 'KRZR att', 359412000000000, 359412999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 165 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013192000000000_013192009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13192000000000, 13192009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 166 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356424070000000_356424079999999', 'Samsung', 'SM-G890A', 'Galaxy S6 Active', 356424070000000, 356424079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 167 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357130050000000_357130059999999', 'Samsung', 'SM-G730A', 'Galaxy SIII Mini', 357130050000000, 357130059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 168 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011226000000000_011226999999999', 'LG', 'CU400 att', 'CU400', 11226000000000, 11226999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 169 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012850000000000_012850009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12850000000000, 12850009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 170 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351504030000000_351504039999999', 'Motorola', 'IZAR V3xxR OrNand', 'IZAR V3xxR OrNand', 351504030000000, 351504039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 171 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013051000000000_013051009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13051000000000, 13051009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 172 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013049000000000_013049009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13049000000000, 13049009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 173 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013523000000000_013523009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13523000000000, 13523009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 174 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354041070000000_354041079999999', 'Samsung', 'SM-T817A', 'Galaxy Tab S2', 354041070000000, 354041079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 175 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357044030000000_357044039999999', 'Samsung', 'SGH-A887', 'Solstice', 357044030000000, 357044039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 176 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010480000000000_010480999999999', 'Samsung', 'X427M', 'X427M', 10480000000000, 10480999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 177 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013336000000000_013336009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13336000000000, 13336009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 178 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012032000000000_012032009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12032000000000, 12032009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 179 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357724080000000_357724089999999', 'Samsung', 'SM-G955U', 'Samsung Galaxy S8', 357724080000000, 357724089999999, 'Continue', ''
);

-- INSERT QUERY NO: 180 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359675010000000_359675059999999', 'BlackBerry', 'PEARL', 'Pearl', 359675010000000, 359675059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 181 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013809000000000_013809009999999', 'LG', 'A380', 'A380', 13809000000000, 13809009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 182 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011333000000000_011333999999999', 'LG', 'CU920 VU', 'VU', 11333000000000, 11333999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 183 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354955070000000_354955079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 354955070000000, 354955079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 184 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010592000000000_010592999999999', 'Sony', 'Z500a', 'Z500a', 10592000000000, 10592999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 185 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012966000000000_012966009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12966000000000, 12966009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 186 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010476000000000_010476999999999', 'LG', 'L1400', 'L1400', 10476000000000, 10476999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 187 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011174000000000_011174002085599', 'Nokia', '2610', '2610', 11174000000000, 11174002085599, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 188 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355332080000000_355332089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355332080000000, 355332089999999, 'Continue', ''
);

-- INSERT QUERY NO: 189 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012210000000000_012210009999999', 'LG', 'GU295', 'GU295', 12210000000000, 12210009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 190 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350183000000000_350183999999999', 'Samsung', 'SGH-N105', 'SGH-N105', 350183000000000, 350183999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 191 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353342070000000_353342079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353342070000000, 353342079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 192 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013048000000000_013048009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13048000000000, 13048009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 193 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012988000000000_012988009999999', 'Pantech', 'P2030', 'Breeze III', 12988000000000, 12988009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 194 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356559080000000_356559089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 356559080000000, 356559089999999, 'Continue', ''
);

-- INSERT QUERY NO: 195 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352081070000000_352081079999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 352081070000000, 352081079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 196 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354891070000000_354891079999999', 'LG', 'MQ4', 'L51AL', 354891070000000, 354891079999999, 'Continue', ''
);

-- INSERT QUERY NO: 197 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014318000000000_014318009999999', 'TCL Communication', '9020A', 'Trek HD', 14318000000000, 14318009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 198 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'869851020000000_869851029999999', 'Huawei', 'Honor 5x', 'Honor 5x', 869851020000000, 869851029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 199 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353512070000000_353512079999999', 'Samsung', 'SM-G928A', 'Galaxy S6 Edge Plus', 353512070000000, 353512079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 200 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014576000000000_014576009999999', 'LG', 'B471', 'B471', 14576000000000, 14576009999999, 'Continue', ''
);

-- INSERT QUERY NO: 201 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357779000000000_357779009999999', 'BlackBerry', '7290', '7290', 357779000000000, 357779009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 202 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010507000000000_010507999999999', 'Sony', 'S710a', 'S710a', 10507000000000, 10507999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 203 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'004402136490000_004402137615999', 'Nokia', '9000', '9000', 4402136490000, 4402137615999, 'Continue', ''
);

-- INSERT QUERY NO: 204 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359250066000000_359250066499999', 'Apple', 'iPhone 7 A1660', 'IPHONE 7 A1660', 359250066000000, 359250066499999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 205 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'449090000000000_449090999999999', 'Motorola', 'L7189', 'L7189', 449090000000000, 449090999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 206 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355267050000000_355267059999999', 'Samsung', 'SGH-A847', 'Rugby II', 355267050000000, 355267059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 207 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356638040000000_356638049999999', 'Samsung', 'SGH-i897', 'Captivate', 356638040000000, 356638049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 208 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012935000000000_012935009999999', 'LG', 'A340', 'A340', 12935000000000, 12935009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 209 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353821080000000_353821089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353821080000000, 353821089999999, 'Continue', ''
);

-- INSERT QUERY NO: 210 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353812080000000_353812089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353812080000000, 353812089999999, 'Continue', ''
);

-- INSERT QUERY NO: 211 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351895070000000_351895079999999', 'LG', 'V930', 'V930', 351895070000000, 351895079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 212 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013432000000000_013432009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13432000000000, 13432009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 213 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010141000000000_010141999999999', 'BlackBerry', '6210', '6210', 10141000000000, 10141999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 214 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013938000000000_013938009999999', 'Lenovo', 'Thinkpad 10', 'Thinkpad 10', 13938000000000, 13938009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 215 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013332000000000_013332009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13332000000000, 13332009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 216 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357456020000000_357456029999999', 'BlackBerry', '8110 OYST PRL', 'Pearl', 357456020000000, 357456029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 217 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012160000000000_012160009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12160000000000, 12160009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 218 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358843060000000_358843069999999', 'Samsung', 'SM-G920A', 'Galaxy S6', 358843060000000, 358843069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 219 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359746040000000_359746049999999', 'Nokia', '900', 'Lumia 900', 359746040000000, 359746049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 220 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355383030000000_355383039999999', 'BlackBerry', 'CURVE 8900', 'Curve 8900', 355383030000000, 355383039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 221 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012338000000000_012338009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12338000000000, 12338009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 222 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359175070000000_359175079999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7 Plus A1661', 359175070000000, 359175079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 223 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357203050000000_357203059999999', 'HTC', '0P9O110', 'Desire 610', 357203050000000, 357203059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 224 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012550000000000_012550009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12550000000000, 12550009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 225 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354954070000000_354954079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 354954070000000, 354954079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 226 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355491040000000_355491049999999', 'Motorola', 'MZ605', 'MZ605', 355491040000000, 355491049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 227 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353665000000000_353665009999999', 'Siemens', 'CT66', 'CT66', 353665000000000, 353665009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 228 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359315010000000_359315019999999', 'BlackBerry', '8310', 'Curve 8310', 359315010000000, 359315019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 229 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010743000000000_010743999999999', 'LG', 'C1500', 'C1500', 10743000000000, 10743999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 230 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355748020000000_355748029999999', 'Nokia', '6650', '6650', 355748020000000, 355748029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 231 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353253070000000_353253079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353253070000000, 353253079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 232 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359320060000000_359320069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 359320060000000, 359320069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 233 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010650000000000_010650999999999', 'LG', 'CE500', 'CE500', 10650000000000, 10650999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 234 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010287000000000_010287999999999', 'Siemens', 'SL56', 'SL56', 10287000000000, 10287999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 235 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355839080000000_355839089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7', 355839080000000, 355839089999999, 'Continue', ''
);

-- INSERT QUERY NO: 236 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353293070000000_353293079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353293070000000, 353293079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 237 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010115000000000_010115999999999', 'BlackBerry', '6710', '6710', 10115000000000, 10115999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 238 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010249000000000_010249999999999', 'Sony', 'T62U', 'T62U', 10249000000000, 10249999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 239 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359615000000000_359615999999999', 'Motorola', 'RAZR 06 V3', 'RAZR 06 V3', 359615000000000, 359615999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 240 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356285070000000_356285079999999', 'LG', 'V520', 'G Pad X 8.0', 356285070000000, 356285079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 241 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010518000000000_010518999999999', 'LG', 'C1300', 'C1300', 10518000000000, 10518999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 242 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358596070000000_358596079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 358596070000000, 358596079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 243 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355310080000000_355310089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355310080000000, 355310089999999, 'Continue', ''
);

-- INSERT QUERY NO: 244 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013669000000000_013669009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13669000000000, 13669009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 245 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357760040000000_357760049999999', 'HTC', 'PI39100', 'Titan', 357760040000000, 357760049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 246 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012541000000000_012541009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12541000000000, 12541009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 247 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352280030000000_352280039999999', 'Motorola', 'VA76r Tundra', 'Tundra', 352280030000000, 352280039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 248 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357685000000000_357685009999999', 'Motorola', 'V3', 'V3', 357685000000000, 357685009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 249 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'990004296970000_990004296999999', 'HTC', '801e', 'One 801e', 990004296970000, 990004296999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 250 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013535000000000_013535009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13535000000000, 13535009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 251 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'449268000000000_449268999999999', 'Motorola', 'A009', 'A009', 449268000000000, 449268999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 252 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353423050000000_353423059999999', 'HP', '900', 'Elite Pad 900', 353423050000000, 353423059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 253 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353742060000000_353742069999999', 'Samsung', 'SM-T807A', 'Galaxy Tab S', 353742060000000, 353742069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 254 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011933000000000_011933009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11933000000000, 11933009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 255 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359230060000000_359230069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359230060000000, 359230069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 256 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012846000000000_012846009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12846000000000, 12846009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 257 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010166000000000_010166999999999', 'Nokia', '3595', '3595', 10166000000000, 10166999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 258 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013808000000000_013808009999999', 'LG', 'C410', 'Xpression 2', 13808000000000, 13808009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 259 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012422000000000_012422009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12422000000000, 12422009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 260 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354673020000000_354673029999999', 'Motorola', 'IZAR V3xx', 'MOTORAZR V3xx', 354673020000000, 354673029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 261 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010222000000000_010222999999999', 'LG', 'G4010', 'G4010', 10222000000000, 10222999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 262 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010213000000000_010213999999999', 'Siemens', 'A56', 'A56', 10213000000000, 10213999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 263 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'990001720000000_990001729999999', 'Teleepoch', 'M3620', 'AT&T Cingular Flip', 990001720000000, 990001729999999, 'Continue', ''
);

-- INSERT QUERY NO: 264 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355843080000000_355843089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7', 355843080000000, 355843089999999, 'Continue', ''
);

-- INSERT QUERY NO: 265 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013031000000000_013031009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13031000000000, 13031009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 266 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012861000000000_012861009999999', 'Pantech', 'P4100', 'Element', 12861000000000, 12861009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 267 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010130000000000_010130999999999', 'Motorola', 'T720 with EOTD', 'T720 with EOTD', 10130000000000, 10130999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 268 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359485020000000_359485029999999', 'BlackBerry', 'CURVE 8900', 'Curve 8900', 359485020000000, 359485029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 269 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351555050000000_351555059999999', 'Samsung', 'SGH-i827', 'SGH-i827', 351555050000000, 351555059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 270 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013277000000000_013277009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13277000000000, 13277009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 271 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011798000000000_011798009999999', 'Samsung', 'SGH-A167', 'SGH-A167', 11798000000000, 11798009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 272 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011657000000000_011657009999999', 'Pantech', 'C630', 'C630', 11657000000000, 11657009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 273 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012416000000000_012416009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12416000000000, 12416009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 274 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359316010000000_359316019999999', 'BlackBerry', '8310 RED', 'Curve 8310', 359316010000000, 359316019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 275 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357159000020001_357159009999999', 'Samsung', 'ZX10', 'ZX10', 357159000020001, 357159009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 276 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359090010000000_359090019999999', 'BlackBerry', '8300', 'Curve 8300', 359090010000000, 359090019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 277 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354404060000000_354404069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354404060000000, 354404069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 278 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012025000000000_012025009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12025000000000, 12025009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 279 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012549000000000_012549009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12549000000000, 12549009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 280 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357968080000000_357968089999999', 'Samsung', 'SM-R775A', 'Classic', 357968080000000, 357968089999999, 'Continue', ''
);

-- INSERT QUERY NO: 281 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351766000000000_351766999999999', 'Motorola', 'V.66', 'V.66', 351766000000000, 351766999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 282 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354439050000000_354439059999999', 'HTC', 'PN07120', 'ONE', 354439050000000, 354439059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 283 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356715070000000_356715079999999', 'Samsung', 'SM-N920A', 'Galaxy Note 5', 356715070000000, 356715079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 284 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010114000000000_010114999999999', 'Nokia', '6590i', '6590i', 10114000000000, 10114999999999, 'Continue', ''
);

-- INSERT QUERY NO: 285 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012209000000000_012209009999999', 'LG', 'GW370', 'Neon II', 12209000000000, 12209009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 286 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355460010000000_355460019999999', 'Samsung', 'SGH-i607 att', 'BlackJack', 355460010000000, 355460019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 287 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355767010000000_355767019999999', 'BlackBerry', 'Pearl Red 8100c', 'Pearl', 355767010000000, 355767019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 288 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012838000000000_012838009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12838000000000, 12838009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 289 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013190000000000_013190009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13190000000000, 13190009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 290 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013982000000000_013982009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13982000000000, 13982009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 291 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352131070000000_352131079999999', 'Samsung', 'SM-G890A', 'Galaxy S6 Active', 352131070000000, 352131079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 292 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010250000000000_010250999999999', 'Siemens', 'A56', 'A56', 10250000000000, 10250999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 293 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357757080000000_357757089000000', 'Samsung', 'SM-G955U', '357757080000000', 357757080000000, 357757089000000, 'Continue', ''
);

-- INSERT QUERY NO: 294 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353898010000000_353898019999999', 'Samsung', 'SGH-A727', 'SGH-A727', 353898010000000, 353898019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 295 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013265000000000_013265009999999', 'Apple', 'IPHONE 4 Model A1332', 'IPHONE 4', 13265000000000, 13265009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 296 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358356010000000_358356019999999', 'Motorola', 'MC7506', 'MC7506', 358356010000000, 358356019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 297 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012166000000000_012166004999999', 'Palm', 'P121UNA', 'Pixi Plus', 12166000000000, 12166004999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 298 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355314080000000_355314089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355314080000000, 355314089999999, 'Continue', ''
);

-- INSERT QUERY NO: 299 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357742050000000_357742059999999', 'Samsung', 'SGH-i527', 'Galaxy Mega', 357742050000000, 357742059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 300 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012937000000000_012937009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 12937000000000, 12937009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 301 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013788000000000_013788009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13788000000000, 13788009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 302 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013984000000000_013984009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13984000000000, 13984009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 303 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012844000000000_012844009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12844000000000, 12844009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 304 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010800000000000_010800009999999', 'Sonim', 'XP5560-A-R4', 'XP5560-A-R4', 10800000000000, 10800009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 305 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358804000000000_358804009999999', 'Nokia', '6102i', '6102i', 358804000000000, 358804009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 306 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010087000000000_010087999999999', 'Samsung', 'SGH-Q105', 'SGH-Q105', 10087000000000, 10087999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 307 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'867686020000000_867686029999999', 'Huawei', 'H1511 Nin-A1', 'Google Nexus 6P', 867686020000000, 867686029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 308 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359234060000000_359234069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359234060000000, 359234069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 309 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013007000000000_013007009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13007000000000, 13007009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 310 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014054000000000_014054009999999', 'Sonim', 'XP6700', 'XP6700', 14054000000000, 14054009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 311 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356493060000000_356493069999999', 'Microsoft Mobile', '640XL NYPD', 'Lumia 640XL NYPD', 356493060000000, 356493069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 312 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358281010000000_358281019999999', 'BlackBerry', '8320', 'Curve 8320', 358281010000000, 358281019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 313 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355841080000000_355841089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7', 355841080000000, 355841089999999, 'Continue', ''
);

-- INSERT QUERY NO: 314 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351513030000000_351513039999999', 'Motorola', 'Q9h', 'Q9h', 351513030000000, 351513039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 315 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352424040000000_352424049999999', 'Samsung', 'SGH-A187', 'SGH-A187', 352424040000000, 352424049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 316 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358371060000000_358371069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 358371060000000, 358371069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 317 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359305010000000_359305019999999', 'Samsung', 'SGH-A727', 'SGH-A727', 359305010000000, 359305019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 318 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011039000000000_011039999999999', 'Pantech', 'C3', 'C3', 11039000000000, 11039999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 319 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013693000000000_013693009999999', 'Sonim', 'XP1520', 'XP1520', 13693000000000, 13693009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 320 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012481000000000_012481009999999', 'Samsung', 'SGH-A197', 'SGH-A197', 12481000000000, 12481009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 321 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359321060000000_359321069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 359321060000000, 359321069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 322 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351851070000000_351851079999999', 'Microsoft Mobile', 'RM-1118', 'Lumia 950', 351851070000000, 351851079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 323 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353073070000000_353073079999999', 'LG', 'H740', 'G Vista 2', 353073070000000, 353073079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 324 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013431000000000_013431009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13431000000000, 13431009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 325 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353626070000000_353626079999999', 'LG', 'H790', 'Google Nexus 5X', 353626070000000, 353626079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 326 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352616080000000_352616089999999', 'Samsung', 'GSM-T818A', 'Galaxy Tab S2', 352616080000000, 352616089999999, 'Continue', ''
);

-- INSERT QUERY NO: 327 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013125000000000_013125009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13125000000000, 13125009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 328 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013114000000000_013114009999999', 'Pantech', 'P6030', 'Renue', 13114000000000, 13114009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 329 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011950000000000_011950009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 11950000000000, 11950009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 330 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013066000000000_013066009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13066000000000, 13066009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 331 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010928000000000_010928999999999', 'Nokia', '6030', '6030', 10928000000000, 10928999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 332 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357466050000000_357466059999999', 'HTC', '0P3P500', '0P3P500', 357466050000000, 357466059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 333 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355494010000000_355494019999999', 'Samsung', 'SGH-D807', 'SGH-D807', 355494010000000, 355494019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 334 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358355060000000_358355069999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 358355060000000, 358355069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 335 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356567080000000_356567089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 356567080000000, 356567089999999, 'Continue', ''
);

-- INSERT QUERY NO: 336 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353255070000000_353255079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353255070000000, 353255079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 337 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355632000000000_355632009999999', 'Siemens', 'TC65 Terminal', 'TC65 Terminal', 355632000000000, 355632009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 338 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355644040000000_355644049999999', 'Samsung', 'SGH-i917', 'Focus', 355644040000000, 355644049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 339 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352671040000000_352671049999999', 'Samsung', 'SGH-A817', 'Solstice II', 352671040000000, 352671049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 340 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013186000000000_013186009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13186000000000, 13186009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 341 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354664020000000_354664029999999', 'Motorola', 'RAZR 06 V3', 'RAZR 06 V3', 354664020000000, 354664029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 342 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359160070000000_359160079999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 359160070000000, 359160079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 343 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357114040000000_357114049999999', 'Acer', 'A501-10S16u', 'Iconia Tab', 357114040000000, 357114049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 344 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010558000000000_010558999999999', 'Nokia', '6010', '6010', 10558000000000, 10558999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 345 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355358080000000_355358089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 355358080000000, 355358089999999, 'Continue', ''
);

-- INSERT QUERY NO: 346 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013997000000000_013997009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13997000000000, 13997009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 347 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359297060000000_359297069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359297060000000, 359297069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 348 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014685000000000_014685009999999', 'Alcatel', '4044O', 'Feature Phon VoLTE', 14685000000000, 14685009999999, 'Continue', ''
);

-- INSERT QUERY NO: 349 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012197000000000_012197009999999', 'Sony', 'U5at', 'Vivaz', 12197000000000, 12197009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 350 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014638000000000_014638009999999', 'KYOCERA', 'Kyocera', 'KYOCERA-Kyocera', 14638000000000, 14638009999999, 'Continue', ''
);

-- INSERT QUERY NO: 351 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352702050000000_352702059999999', 'Samsung', 'SGH-i547', 'Galaxy Rugby Pro', 352702050000000, 352702059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 352 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356990060000000_356990069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 356990060000000, 356990069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 353 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'864721020000000_864721029999999', 'ZTE', 'Z992', 'Z992', 864721020000000, 864721029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 354 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358424000000000_358424009999999', 'Motorola', 'MC7094', 'MC7094', 358424000000000, 358424009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 355 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011673000000000_011673009999999', 'Nokia', '2610', '2610', 11673000000000, 11673009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 356 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012656000000000_012656009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12656000000000, 12656009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 357 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010324000000000_010324999999999', 'Nokia', '3595', '3595', 10324000000000, 10324999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 358 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010529000000000_010529999999999', 'Samsung', 'C207', 'C207', 10529000000000, 10529999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 359 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010033000000000_010033999999999', 'Motorola', 'MicroTAC Select 6000e', 'MicroTAC Select 6000e', 10033000000000, 10033999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 360 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355429050000000_355429059999999', 'Samsung', 'SGH-i317', 'Galaxy Note II', 355429050000000, 355429059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 361 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355825080000000_355825089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7', 355825080000000, 355825089999999, 'Continue', ''
);

-- INSERT QUERY NO: 362 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354255050000000_354255059999999', 'Samsung', 'SGH-A157', 'SGH-A157', 354255050000000, 354255059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 363 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358358060000000_358358069999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 358358060000000, 358358069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 364 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013615000000000_013615009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13615000000000, 13615009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 365 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355832080000000_355832089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7', 355832080000000, 355832089999999, 'Continue', ''
);

-- INSERT QUERY NO: 366 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010172000000000_010172999999999', 'Samsung', 'SGH-E400', 'SGH-E400', 10172000000000, 10172999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 367 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356567050000000_356567059999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 356567050000000, 356567059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 368 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012496000000000_012496009999999', 'Sony', 'x10a', 'Xperia X10', 12496000000000, 12496009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 369 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355311080000000_355311089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355311080000000, 355311089999999, 'Continue', ''
);

-- INSERT QUERY NO: 370 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351799020000000_351799029999999', 'Motorola', 'RAZR 06 V3', 'RAZR 06 V3', 351799020000000, 351799029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 371 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355725070000000_355725079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 355725070000000, 355725079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 372 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356987060000000_356987069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 356987060000000, 356987069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 373 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352133070000000_352133079999999', 'Samsung', 'SM-G900A', 'Galaxy S5', 352133070000000, 352133079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 374 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352515000000000_352515009999999', 'Nokia', '3100', '3100', 352515000000000, 352515009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 375 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358555070000000_358555079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 358555070000000, 358555079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 376 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355428050000000_355428059999999', 'Samsung', 'SGH-i317', 'Galaxy Note II', 355428050000000, 355428059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 377 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010163000000000_010163999999999', 'Motorola', 'C350g', 'C350g', 10163000000000, 10163999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 378 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013057000000000_013057009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13057000000000, 13057009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 379 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355361080000000_355361089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 355361080000000, 355361089999999, 'Continue', ''
);

-- INSERT QUERY NO: 380 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358597070000000_358597079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 358597070000000, 358597079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 381 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013756000000000_013756009999999', 'Alcatel', 'OT871A', '871A', 13756000000000, 13756009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 382 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011081000000000_011081999999999', 'LG', 'CG225', 'CG225', 11081000000000, 11081999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 383 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356566050000000_356566059999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 356566050000000, 356566059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 384 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014376004000000_014376009999999', 'Microsoft', '1657', 'Surface 3', 14376004000000, 14376009999999, 'Continue', ''
);

-- INSERT QUERY NO: 385 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355925050000000_355925059999999', 'Nokia', '520', 'Lumia 520', 355925050000000, 355925059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 386 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010323000000000_010323999999999', 'Nokia', '3595', '3595', 10323000000000, 10323999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 387 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357888000000000_357888009999999', 'BlackBerry', '8700c', '8700c', 357888000000000, 357888009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 388 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011937000000000_011937009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11937000000000, 11937009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 389 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355678070000000_355678079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 355678070000000, 355678079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 390 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012654000000000_012654009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12654000000000, 12654009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 391 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012418000000000_012418009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12418000000000, 12418009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 392 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356204060000000_356204069999999', 'Samsung', 'SM-N910A', 'Galaxy Note 4', 356204060000000, 356204069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 393 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355021030000000_355021039999999', 'BlackBerry', '8310', 'Curve 8310', 355021030000000, 355021039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 394 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357738050000000_357738059999999', 'Samsung', 'SGH-i537', 'Galaxy S4 Active', 357738050000000, 357738059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 395 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010768000000000_010768009999999', 'Nokia', '6061', '6061', 10768000000000, 10768009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 396 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355718070000000_355718079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 355718070000000, 355718079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 397 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010373000000000_010373999999999', 'Nokia', '1100', '1100', 10373000000000, 10373999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 398 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010212000000000_010212999999999', 'Siemens', 'A56', 'A56', 10212000000000, 10212999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 399 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359164070000000_359164079999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 359164070000000, 359164079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 400 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359881040000000_359881049999999', 'Samsung', 'SGH-i677', 'Focus Flash', 359881040000000, 359881049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 401 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353429050000000_353429059999999', 'HTC', 'PM63100', 'One X +', 353429050000000, 353429059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 402 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356696050000000_356696059999999', 'Nokia', '520', 'Lumia 520', 356696050000000, 356696059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 403 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012983000000000_012983009999999', 'Lenovo', 'ThinkPad Tablet', 'ThinkPad Tablet', 12983000000000, 12983009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 404 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353666000000000_353666009999999', 'Siemens', 'CT66', 'CT66', 353666000000000, 353666009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 405 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013592000000000_013592009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13592000000000, 13592009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 406 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012539000000000_012539009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12539000000000, 12539009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 407 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351574040000000_351574049999999', 'Motorola', 'MB520', 'BRAVO', 351574040000000, 351574049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 408 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355800070000000_355800079999999', 'Apple', 'iPhone SE A1662', 'iPhone SE', 355800070000000, 355800079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 409 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013981000000000_013981009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13981000000000, 13981009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 410 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359631040000000_359631049999999', 'Samsung', 'SGH-i827', 'SGH-i827', 359631040000000, 359631049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 411 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359279050000000_359279059999999', 'Motorola', 'XT1097', 'Motorola X', 359279050000000, 359279059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 412 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357647000000000_357647009999999', 'BlackBerry', '8700c', '8700c', 357647000000000, 357647009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 413 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356809020000000_356809029999999', 'Nokia', '6085', '6085', 356809020000000, 356809029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 414 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011970000000000_011970009999999', 'Nokia', '2330', '2330', 11970000000000, 11970009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 415 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010234000000000_010234009999999', 'Nokia', '6340i', '6340i', 10234000000000, 10234009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 416 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012161000000000_012161009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12161000000000, 12161009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 417 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352335000000000_352335015999999', 'Sony', 'W300i', 'W300i', 352335000000000, 352335015999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 418 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010205000000000_010205999999999', 'Motorola', 'C350', 'C350', 10205000000000, 10205999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 419 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351623070000000_351623079999999', 'BlackBerry', 'STV100-1', 'Blackberry Priv', 351623070000000, 351623079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 420 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010209000000000_010209999999999', 'Sony', 'T226', 'T226', 10209000000000, 10209999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 421 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359239060000000_359239069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359239060000000, 359239069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 422 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013667000000000_013667009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13667000000000, 13667009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 423 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012537000000000_012537009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12537000000000, 12537009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 424 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359179070000000_359179079999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7 Plus A1661', 359179070000000, 359179079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 425 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350326000000000_350326999999999', 'Sony', 'T68m', 'T68m', 350326000000000, 350326999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 426 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013276000000000_013276009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13276000000000, 13276009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 427 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013183000000000_013183009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13183000000000, 13183009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 428 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358940040000000_358940049999999', 'Samsung', 'SGH-i927', 'Captivate Glide', 358940040000000, 358940049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 429 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354444060000000_354444069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354444060000000, 354444069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 430 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354889060000000_354889069999999', 'Samsung', 'SM-T707A', 'Galaxy Tab S', 354889060000000, 354889069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 431 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353456020000000_353456029999999', 'Samsung', 'SGH-A237', 'SGH-A237', 353456020000000, 353456029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 432 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013436000000000_013436009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13436000000000, 13436009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 433 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356988060000000_356988069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 356988060000000, 356988069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 434 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359657030000000_359657039999999', 'Samsung', 'SGH-A887', 'Solstice', 359657030000000, 359657039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 435 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011684000000000_011684009999999', 'Nokia', '2610', '2610', 11684000000000, 11684009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 436 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351966050000000_351966059999999', 'Nokia', '900', 'Lumia 900', 351966050000000, 351966059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 437 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014047000000000_014047009999999', 'LG', 'C395', 'Xpression', 14047000000000, 14047009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 438 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011629000000000_011629009999999', 'Sony', 'W580i', 'W580i', 11629000000000, 11629009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 439 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013232000000000_013232009999999', 'Samsung', 'XE500T1C-HA1US', 'ATIV Smart PC', 13232000000000, 13232009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 440 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352015070000000_352015079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 352015070000000, 352015079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 441 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012294000000000_012294009999999', 'LG', 'GT365', 'NEON', 12294000000000, 12294009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 442 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013134000000000_013134009999999', 'Pantech', 'P7040P', 'Link', 13134000000000, 13134009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 443 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353841080000000_353841089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 353841080000000, 353841089999999, 'Continue', ''
);

-- INSERT QUERY NO: 444 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011298000000000_011298999999999', 'LG', 'CE110', 'CE110', 11298000000000, 11298999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 445 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010096000000000_010096999999999', 'Samsung', 'SGH-R225M', 'SGH-R225M', 10096000000000, 10096999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 446 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355835080000000_355835089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7', 355835080000000, 355835089999999, 'Continue', ''
);

-- INSERT QUERY NO: 447 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359323060000000_359323069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 359323060000000, 359323069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 448 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013673000000000_013673009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13673000000000, 13673009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 449 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012702000000000_012702009999999', 'LG', 'P506', 'P506', 12702000000000, 12702009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 450 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359201010000000_359201019999999', 'Motorola', 'IZAR V3xx', 'MOTORAZR V3xx', 359201010000000, 359201019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 451 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011488000000000_011488999999999', 'LG', 'CU915', 'CU915', 11488000000000, 11488999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 452 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013056000000000_013056009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13056000000000, 13056009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 453 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356639080000000_356639089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 356639080000000, 356639089999999, 'Continue', ''
);

-- INSERT QUERY NO: 454 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353805080000000_353805089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 353805080000000, 353805089999999, 'Continue', ''
);

-- INSERT QUERY NO: 455 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359205070000000_359205079999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 359205070000000, 359205079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 456 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351879040000000_351879049999999', 'Samsung', 'SGH-A927', 'Flight II', 351879040000000, 351879049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 457 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353842080000000_353842089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 353842080000000, 353842089999999, 'Continue', ''
);

-- INSERT QUERY NO: 458 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010142000000000_010142999999999', 'Motorola', 'T720 no EOTD', 'T720 no EOTD', 10142000000000, 10142999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 459 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010326000000000_010326999999999', 'Nokia', '3595', '3595', 10326000000000, 10326999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 460 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350643000000000_350643999999999', 'Motorola', 'V70', 'V70', 350643000000000, 350643999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 461 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355864070000000_355864079999999', 'Samsung', 'SM-G892A', 'PDA Android LTE', 355864070000000, 355864079999999, 'Continue', ''
);

-- INSERT QUERY NO: 462 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010331000000000_010331999999999', 'Samsung', 'SGH-X427', 'SGH-X427', 10331000000000, 10331999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 463 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353815080000000_353815089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353815080000000, 353815089999999, 'Continue', ''
);

-- INSERT QUERY NO: 464 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356485000000000_356485009999999', 'Motorola', 'V557', 'V557', 356485000000000, 356485009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 465 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013983000000000_013983009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13983000000000, 13983009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 466 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354408060000000_354408069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354408060000000, 354408069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 467 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354956070000000_354956079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 354956070000000, 354956079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 468 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356483020000000_356483029999999', 'Sony', 'W760a', 'W760a', 356483020000000, 356483029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 469 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011923000000000_011923009999999', 'Pantech', 'C790', 'Reveal', 11923000000000, 11923009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 470 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013848000000000_013848009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13848000000000, 13848009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 471 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358718050000000_358718059999999', 'HTC', '0P6B120', 'One M8', 358718050000000, 358718059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 472 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012153000000000_012153009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12153000000000, 12153009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 473 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011268000000000_011268999999999', 'LG', 'CE110', 'CE110', 11268000000000, 11268999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 474 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359722050000000_359722059999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 359722050000000, 359722059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 475 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012427000000000_012427009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12427000000000, 12427009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 476 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356611040000000_356611049999999', 'ZTE', 'Z331', 'Z331', 356611040000000, 356611049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 477 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013050000000000_013050009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13050000000000, 13050009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 478 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359706060000000_359706069999999', 'Samsung', 'SM-G925A', 'Galaxy S6 Edge', 359706060000000, 359706069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 479 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012315000000000_012315009999999', 'Samsung', 'SGH-A197', 'SGH-A197', 12315000000000, 12315009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 480 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354116050000000_354116059999999', 'Nokia', '820', 'Lumia 820', 354116050000000, 354116059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 481 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352006060000000_352006069999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 352006060000000, 352006069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 482 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358595070000000_358595079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 358595070000000, 358595079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 483 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354885070000000_354885079999999', 'LG', 'K371', 'K371', 354885070000000, 354885079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 484 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358541070000000_358541079999999', 'Apple', 'iPhone SE A1662', 'iPhone SE', 358541070000000, 358541079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 485 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356640080000000_356640089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 356640080000000, 356640089999999, 'Continue', ''
);

-- INSERT QUERY NO: 486 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010327000000000_010327999999999', 'Nokia', '3595', '3595', 10327000000000, 10327999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 487 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012963000000000_012963009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12963000000000, 12963009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 488 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353261070000000_353261079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353261070000000, 353261079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 489 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010181000000000_010181999999999', 'Nokia', '3590', '3590', 10181000000000, 10181999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 490 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355909020000000_355909029999999', 'Motorola', 'IZAR V3xx', 'MOTORAZR V3xx', 355909020000000, 355909029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 491 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355351080000000_355351089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus', 355351080000000, 355351089999999, 'Continue', ''
);

-- INSERT QUERY NO: 492 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356800040000000_356800049999999', 'ZTE', 'Z990', 'Avail', 356800040000000, 356800049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 493 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351973040000000_351973049999999', 'BlackBerry', '9100', 'Pearl', 351973040000000, 351973049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 494 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'990000850000000_990000854999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 990000850000000, 990000854999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 495 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011071000000000_011071999999999', 'LG', 'CU400', 'CU400', 11071000000000, 11071999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 496 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012645000000000_012645009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12645000000000, 12645009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 497 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014097000000000_014097009999999', 'LG', 'V410', 'G Pad 7.0', 14097000000000, 14097009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 498 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013179000000000_013179009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13179000000000, 13179009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 499 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013199000000000_013199009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13199000000000, 13199009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 500 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354439010000000_354439019999999', 'Motorola', 'MC3504', 'MC3504', 354439010000000, 354439019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 501 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351713080300000_351713089999999', 'Samsung', 'SM-G891A', 'Galaxy S7 Active', 351713080300000, 351713089999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 502 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013378000000000_013378009999999', 'Samsung', 'XE500T1C-HA1US', 'ATIV Smart PC', 13378000000000, 13378009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 503 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355979080000000_355979089999999', 'Samsung', 'SM-G955U', 'Samsung Galaxy S8 Plus', 355979080000000, 355979089999999, 'Continue', ''
);

-- INSERT QUERY NO: 504 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351083000000000_351083999999999', 'Siemens', 'S55', 'S55', 351083000000000, 351083999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 505 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011664000000000_011664009999999', 'Nokia', '2610', '2610', 11664000000000, 11664009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 506 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014389000000000_014389009999999', 'Alcatel', 'A463BG', 'One Touch', 14389000000000, 14389009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 507 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013180000000000_013180009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13180000000000, 13180009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 508 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012960000000000_012960009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12960000000000, 12960009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 509 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012529000000000_012529009999999', 'Pantech', 'P8000', 'Crossover', 12529000000000, 12529009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 510 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359522020000000_359522029999999', 'Samsung', 'SGH-i637', 'Jack', 359522020000000, 359522029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 511 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357960000000000_357960009999999', 'Nokia', '3120', '3120', 357960000000000, 357960009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 512 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356112050000000_356112059999999', 'BlackBerry', 'SQN100-1', 'Q10', 356112050000000, 356112059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 513 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357741060000000_357741069999999', 'Samsung', 'SM-G925A', 'Galaxy S6 Edge', 357741060000000, 357741069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 514 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353292010000000_353292019999999', 'Motorola', 'IZAR V3xx', 'MOTORAZR V3xx', 353292010000000, 353292019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 515 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010010000000000_010010999999999', 'Motorola', 'Select 3000', 'Select 3000', 10010000000000, 10010999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 516 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355993010000000_355993019999999', 'Samsung', 'SGH-A737', 'SGH-A737', 355993010000000, 355993019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 517 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'861362000000000_861362019999999', 'Huawei', 'U2800A', 'U2800A', 861362000000000, 861362019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 518 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013828000000000_013828009999999', 'Alcatel', 'OT510A', '510A', 13828000000000, 13828009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 519 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011773000000000_011773009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11773000000000, 11773009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 520 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355686070000000_355686079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 355686070000000, 355686079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 521 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358355010000000_358355019999999', 'Motorola', 'MC7596', 'MC7596', 358355010000000, 358355019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 522 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013617000000000_013617009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13617000000000, 13617009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 523 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357239030000000_357239039999999', 'BlackBerry', 'CURVE 8900', 'Curve 8900', 357239030000000, 357239039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 524 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010605000000000_010605999999999', 'LG', 'C1300i', 'C1300i', 10605000000000, 10605999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 525 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353278010000000_353278019999999', 'Motorola', 'V190', 'V190', 353278010000000, 353278019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 526 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012845000000000_012845009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12845000000000, 12845009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 527 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010273000000000_010273999999999', 'Sony', 'T237', 'T237', 10273000000000, 10273999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 528 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354410060000000_354410069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354410060000000, 354410069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 529 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012660000000000_012660009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12660000000000, 12660009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 530 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356563080000000_356563089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 356563080000000, 356563089999999, 'Continue', ''
);

-- INSERT QUERY NO: 531 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355721070000000_355721079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 355721070000000, 355721079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 532 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358269000000000_358269009999999', 'Motorola', 'V3', 'V3', 358269000000000, 358269009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 533 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011641000000000_011641009999999', 'Motorola', 'C139 att', 'C139 att', 11641000000000, 11641009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 534 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353502060000000_353502069999999', 'Samsung', 'SM-G900A', 'Galaxy S5', 353502060000000, 353502069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 535 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010183000000000_010183999999999', 'Nokia', '3590', '3590', 10183000000000, 10183999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 536 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013204000000000_013204009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13204000000000, 13204009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 537 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010200000000000_010200999999999', 'Nokia', '6340i', '6340i', 10200000000000, 10200999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 538 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356888060000000_356888069999999', 'Samsung', 'SM-G900A', 'Galaxy S5', 356888060000000, 356888069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 539 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013328000000000_013328009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13328000000000, 13328009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 540 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013440000000000_013440009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13440000000000, 13440009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 541 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358259000000000_358259009999999', 'Motorola', 'V551', 'V551', 358259000000000, 358259009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 542 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011812000000000_011812009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11812000000000, 11812009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 543 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353326070000000_353326079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353326070000000, 353326079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 544 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357505060000000_357505069999999', 'LG', 'H950', 'G Flex2', 357505060000000, 357505069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 545 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010627000000000_010627999999999', 'LG', 'F7200', 'F7200', 10627000000000, 10627999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 546 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356568080000000_356568089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 356568080000000, 356568089999999, 'Continue', ''
);

-- INSERT QUERY NO: 547 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353296070000000_353296079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353296070000000, 353296079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 548 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359130071500000_359130071999999', 'Apple', 'iPad 9.7 A1823', 'iPad 9', 359130071500000, 359130071999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 549 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356028020000000_356028029999999', 'BlackBerry', 'PEARL 8220', 'Pearl Flip 8220', 356028020000000, 356028029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 550 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357564020000000_357564029999999', 'BlackBerry', '8110 Pearl', 'Pearl', 357564020000000, 357564029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 551 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352016070000000_352016079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 352016070000000, 352016079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 552 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'001000146000000_001000146999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 1000146000000, 1000146999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 553 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356323030000000_356323039999999', 'Samsung', 'SGH-A697', 'Sunburst', 356323030000000, 356323039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 554 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013678000000000_013678009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13678000000000, 13678009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 555 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010634007662509_010634999999999', 'Motorola', 'V173', 'V173', 10634007662509, 10634999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 556 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358786010000000_358786019999999', 'Motorola', 'Q9', 'MOTO Q', 358786010000000, 358786019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 557 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010345000000000_010345999999999', 'LG', 'L1200', 'L1200', 10345000000000, 10345999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 558 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010999000000000_010999009999999', 'Pantech', 'C-300', 'C300', 10999000000000, 10999009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 559 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358266000000000_358266009999999', 'Motorola', 'V3', 'V3', 358266000000000, 358266009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 560 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356123050000000_356123059999999', 'Motorola', 'MC67ND', 'MC67ND', 356123050000000, 356123059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 561 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012738000000000_012738009999999', 'Pantech', 'P5000', 'P5000', 12738000000000, 12738009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 562 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011396000000000_011396999999999', 'Samsung', 'SGH-A117', 'SGH-A117', 11396000000000, 11396999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 563 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359158020000000_359158029999999', 'BlackBerry', '8310', 'Curve 8310', 359158020000000, 359158029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 564 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011774000000000_011774009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11774000000000, 11774009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 565 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'990004290000000_990004296969999', 'HTC', '801n', 'One 801n', 990004290000000, 990004296969999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 566 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354444000000000_354444009999999', 'Motorola', 'V180', 'V180', 354444000000000, 354444009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 567 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013267000000000_013267009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13267000000000, 13267009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 568 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351675060000000_351675069999999', 'Samsung', 'SM-G900A', 'Galaxy S5', 351675060000000, 351675069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 569 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012824000000000_012824009999999', 'HP', 'HSTNH-F30CN', 'HSTNH-F30CN', 12824000000000, 12824009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 570 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359233060000000_359233069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359233060000000, 359233069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 571 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355573030000000_355573039999999', 'Samsung', 'SGH-A897', 'Mythic', 355573030000000, 355573039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 572 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012574000000000_012574009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12574000000000, 12574009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 573 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'867979020000000_867979029999999', 'Huawei', 'H1511 Nin-A12', 'Google Nexus 6P', 867979020000000, 867979029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 574 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013590000000000_013590009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13590000000000, 13590009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 575 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355328080000000_355328089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355328080000000, 355328089999999, 'Continue', ''
);

-- INSERT QUERY NO: 576 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011645000000000_011645009999999', 'Motorola', 'C168i', 'C168i', 11645000000000, 11645009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 577 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354452060000000_354452069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 354452060000000, 354452069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 578 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350947000000000_350947999999999', 'Samsung', 'SGH-S100', 'SGH-S100', 350947000000000, 350947999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 579 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012644000000000_012644009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12644000000000, 12644009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 580 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356564080000000_356564089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 356564080000000, 356564089999999, 'Continue', ''
);

-- INSERT QUERY NO: 581 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353298070000000_353298079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353298070000000, 353298079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 582 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012055000000000_012055009999999', 'Pantech', 'C740', 'Matrix', 12055000000000, 12055009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 583 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011949000000000_011949009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 11949000000000, 11949009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 584 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357522040000000_357522049999999', 'Samsung', 'SGH-i807', 'SGH-i807', 357522040000000, 357522049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 585 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013208000000000_013208009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13208000000000, 13208009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 586 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014285000000000_014285009999999', 'Amazon', 'SD4930UR Fire', 'Amazon Fire', 14285000000000, 14285009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 587 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359458010000000_359458049999999', 'Samsung', 'SGH-i607', 'BlackJack', 359458010000000, 359458049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 588 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013201000000000_013201009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13201000000000, 13201009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 589 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350636000000000_350636999999999', 'Motorola', 'V66', 'V66', 350636000000000, 350636999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 590 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357593040000000_357593049999999', 'Sony', 'R800at', 'Xperia PLAY', 357593040000000, 357593049999999, 'Continue', ''
);

-- INSERT QUERY NO: 591 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352481020000000_352481029999999', 'Motorola', 'V9x OrNand', 'MOTORAZR2 V9', 352481020000000, 352481029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 592 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011991000000000_011991009999999', 'LG', 'GT950', 'Arena', 11991000000000, 11991009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 593 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'867118020000000_867118029999999', 'Huawei', 'RIO-L03', 'GX8', 867118020000000, 867118029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 594 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357966040000000_357966049999999', 'BlackBerry', '9900', 'Bold 9900', 357966040000000, 357966049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 595 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010006000000000_010006999999999', 'Motorola', 'Spirit 1500', 'Spirit 1500', 10006000000000, 10006999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 596 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354621030000000_354621039999999', 'Samsung', 'SGH-A797', 'Flight', 354621030000000, 354621039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 597 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012011000000000_012011009999999', 'LG', 'GR500', 'Xenon', 12011000000000, 12011009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 598 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351904020000000_351904029999999', 'PCD', 'GTX75', 'Quickfire', 351904020000000, 351904029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 599 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011088000000000_011089999999999', 'Motorola', 'C139', 'C139', 11088000000000, 11089999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 600 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356699050000000_356699059999999', 'Nokia', '1020', 'Lumia 1020', 356699050000000, 356699059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 601 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010133000000000_010133999999999', 'Samsung', 'SGH-S105', 'SGH-S105', 10133000000000, 10133999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 602 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350893000000000_350893999999999', 'Nokia', '7210', '7210', 350893000000000, 350893999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 603 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351194000000000_351194999999999', 'Samsung', 'SGH-V100', 'SGH-V100', 351194000000000, 351194999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 604 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352920020000000_352920029999999', 'Nokia', '6085', '6085', 352920020000000, 352920029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 605 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011985000000000_011985009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 11985000000000, 11985009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 606 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012750000000000_012750009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12750000000000, 12750009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 607 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'869082010000000_869082019999999', 'ZTE', 'Z221', 'Z221', 869082010000000, 869082019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 608 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012426000000000_012426009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12426000000000, 12426009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 609 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357155020000000_357155029999999', 'BlackBerry', '8310 ORANGE', 'Curve 8310', 357155020000000, 357155029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 610 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011385000000000_011385999999999', 'Samsung', 'SGH-A117', 'SGH-A117', 11385000000000, 11385999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 611 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356573080000000_356573089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 356573080000000, 356573089999999, 'Continue', ''
);

-- INSERT QUERY NO: 612 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012024000000000_012024009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 12024000000000, 12024009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 613 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355876060000000_355876069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 355876060000000, 355876069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 614 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010138000000000_010138999999999', 'Nokia', '6590i', '6590i', 10138000000000, 10138999999999, 'Continue', ''
);

-- INSERT QUERY NO: 615 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353014050000000_353014059999999', 'Samsung', 'SGH-i747', 'Galaxy S III', 353014050000000, 353014059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 616 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013207000000000_013207009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13207000000000, 13207009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 617 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355348080000000_355348089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 355348080000000, 355348089999999, 'Continue', ''
);

-- INSERT QUERY NO: 618 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359170070000000_359170079999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 359170070000000, 359170079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 619 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013661000000000_013661009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13661000000000, 13661009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 620 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359758020000000_359758029999999', 'Samsung', 'SGH-A767', 'Propel', 359758020000000, 359758029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 621 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011460000000000_011460999999999', 'Motorola', 'C168i', 'C168i', 11460000000000, 11460999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 622 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012936000000000_012936009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 12936000000000, 12936009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 623 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'869142020000000_869142029999999', 'ZTE', 'MF923', 'VELOCITY', 869142020000000, 869142029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 624 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359169070000000_359169079999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 359169070000000, 359169079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 625 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013534000000000_013534009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13534000000000, 13534009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 626 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353340070000000_353340079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353340070000000, 353340079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 627 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352968000000000_352968009999999', 'Nokia', '6820', '6820', 352968000000000, 352968009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 628 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351962010000000_351962019999999', 'Motorola', 'V3', 'V3', 351962010000000, 351962019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 629 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359127070000000_359127079999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 359127070000000, 359127079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 630 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351741050000000_351741059999999', 'Lenovo', 'Helix', 'Helix', 351741050000000, 351741059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 631 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357011030000000_357011039999999', 'Samsung', 'SGH-A877', 'Impression', 357011030000000, 357011039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 632 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013677000000000_013677009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13677000000000, 13677009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 633 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011742000000000_011742009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11742000000000, 11742009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 634 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355313080000000_355313089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 355313080000000, 355313089999999, 'Continue', ''
);

-- INSERT QUERY NO: 635 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356522050000000_356522059999999', 'Samsung', 'SGH-i257', 'SGH-i257', 356522050000000, 356522059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 636 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352022070000000_352022079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 352022070000000, 352022079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 637 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012158000000000_012158009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12158000000000, 12158009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 638 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354332030000000_354332039999999', 'Samsung', 'SGH-A257', 'Magnet', 354332030000000, 354332039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 639 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357425070000000_357425079999999', 'Samsung', 'SM-G930A', 'Galaxy S7', 357425070000000, 357425079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 640 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013268000000000_013268009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13268000000000, 13268009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 641 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353350070000000_353350079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353350070000000, 353350079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 642 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352039070000000_352039079999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 352039070000000, 352039079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 643 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354953070000000_354953079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 354953070000000, 354953079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 644 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010760000000000_010760999999999', 'Nokia', '6030', '6030', 10760000000000, 10760999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 645 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357325040000000_357325049999999', 'HTC', 'PH06130', 'Status', 357325040000000, 357325049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 646 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014489000000000_014489009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 14489000000000, 14489009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 647 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012758000000000_012758009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12758000000000, 12758009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 648 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012548000000000_012548009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12548000000000, 12548009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 649 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'001000147000000_001000147999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 1000147000000, 1000147999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 650 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356298040000000_356298049999999', 'HTC', 'PH39100', 'Vivid', 356298040000000, 356298049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 651 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359166070000000_359166079999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 359166070000000, 359166079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 652 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354417070000000_354417079999999', 'LG', 'LG328BG', 'B470', 354417070000000, 354417079999999, 'Continue', ''
);

-- INSERT QUERY NO: 653 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356560060000000_356560069999999', 'Samsung', 'SM-G850A', 'Galaxy Alpha', 356560060000000, 356560069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 654 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351508030000000_351508039999999', 'Motorola', 'Z9 OrNand', 'Z9 OrNand', 351508030000000, 351508039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 655 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011744000000000_011744009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11744000000000, 11744009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 656 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354448060000000_354448069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354448060000000, 354448069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 657 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352082070000000_352082079999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 352082070000000, 352082079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 658 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'861831000000000_861831009999999', 'ZTE', 'Z431', 'Z431', 861831000000000, 861831009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 659 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010672000000000_010672999999999', 'LG', 'C1300i', 'C1300i', 10672000000000, 10672999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 660 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011981000000000_011981009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 11981000000000, 11981009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 661 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012655000000000_012655009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12655000000000, 12655009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 662 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013986000000000_013986009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13986000000000, 13986009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 663 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014376002000000_014376003999999', 'Microsoft', '1657', 'Surface 3', 14376002000000, 14376003999999, 'Continue', ''
);

-- INSERT QUERY NO: 664 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357594020000000_357594029999999', 'Samsung', 'SGH-i617', 'BlackJack II', 357594020000000, 357594029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 665 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010346000000000_010346999999999', 'LG', 'C1300', 'C1300', 10346000000000, 10346999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 666 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010417000000000_010417999999999', 'Nokia', '6010', '6010', 10417000000000, 10417999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 667 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012021000000000_012021009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 12021000000000, 12021009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 668 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356090050000000_356090059999999', 'Samsung', 'SGH-i237', 'SGH-i237', 356090050000000, 356090059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 669 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013892000000000_013892009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13892000000000, 13892009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 670 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358321010000000_358321019999999', 'Motorola', 'RAZR 06 V3', 'RAZR 06 V3', 358321010000000, 358321019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 671 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355827080000000_355827089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7', 355827080000000, 355827089999999, 'Continue', ''
);

-- INSERT QUERY NO: 672 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011572000000000_011572009999999', 'Sony', 'W580i', 'W580i', 11572000000000, 11572009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 673 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358602070000000_358602079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 358602070000000, 358602079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 674 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356641080000000_356641089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 356641080000000, 356641089999999, 'Continue', ''
);

-- INSERT QUERY NO: 675 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356884010000000_356884019999999', 'Motorola', 'IZAR att', 'IZAR att', 356884010000000, 356884019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 676 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351975030000000_351975039999999', 'Nokia', '6350', '6350', 351975030000000, 351975039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 677 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014390000000000_014390009999999', 'Kyocera', 'E4710', 'E4710', 14390000000000, 14390009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 678 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'867938020000000_867938029999999', 'ZTE', 'Z716BL', 'PDA Android LTE', 867938020000000, 867938029999999, 'Continue', ''
);

-- INSERT QUERY NO: 679 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010169000000000_010169999999999', 'Motorola', 'T720-T720i with EOTD', 'T720-T720i with EOTD', 10169000000000, 10169999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 680 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353471030000000_353471039999999', 'BlackBerry', 'CURVE 8900', 'Curve 8900', 353471030000000, 353471039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 681 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353045060000000_353045069999999', 'Nokia', '520', 'Lumia 520', 353045060000000, 353045069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 682 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355028000000000_355028009999999', 'Nokia', '3120', '3120', 355028000000000, 355028009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 683 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012536000000000_012536009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12536000000000, 12536009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 684 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354904000000000_354904009999999', 'Motorola', 'V3', 'V3', 354904000000000, 354904009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 685 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010184000000000_010184999999999', 'Nokia', '3595', '3595', 10184000000000, 10184999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 686 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013334000000000_013334009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13334000000000, 13334009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 687 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352125060000000_352125069999999', 'Samsung', 'SM-P907A', 'SM-P907A', 352125060000000, 352125069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 688 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013593000000000_013593009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13593000000000, 13593009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 689 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354656020000000_354656029999999', 'Motorola', 'C168i', 'C168i', 354656020000000, 354656029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 690 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350907000000000_350907999999999', 'Motorola', 'C350g - Euro Model', 'C350g - Euro Model', 350907000000000, 350907999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 691 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358619000000000_358619009999999', 'Motorola', 'V190', 'V190', 358619000000000, 358619009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 692 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351631000000000_351631999999999', 'Siemens', 'SL55', 'SL55', 351631000000000, 351631999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 693 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013059000000000_013059009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13059000000000, 13059009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 694 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014484000000000_014484009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 14484000000000, 14484009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 695 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358158000000000_358158009999999', 'Samsung', 'SGH-D347', 'SGH-D347', 358158000000000, 358158009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 696 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011248000000000_011248999999999', 'Samsung', 'SGH-A127', 'SGH-A127', 11248000000000, 11248999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 697 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012033000000000_012033009999999', 'Pantech', 'P7000', 'Impact', 12033000000000, 12033009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 698 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010159000000000_010159999999999', 'Motorola', 'C331g', 'C331g', 10159000000000, 10159999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 699 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013884000000000_013884009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13884000000000, 13884009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 700 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013029000000000_013029009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13029000000000, 13029009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 701 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353877070000000_353877079999999', 'Samsung', 'SM-N920A', 'Galaxy Note 5', 353877070000000, 353877079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 702 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012745000000000_012745009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12745000000000, 12745009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 703 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010292000000000_010292999999999', 'BlackBerry', '6280', '6280', 10292000000000, 10292999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 704 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357816060000000_357816069999999', 'Microsoft Mobile', '640', 'Lumia 640', 357816060000000, 357816069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 705 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013614000000000_013614009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13614000000000, 13614009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 706 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354503010000000_354503019999999', 'Motorola', 'V9', 'MOTORAZR2 V9', 354503010000000, 354503019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 707 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353767070000000_353767079999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 353767070000000, 353767079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 708 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353091050000000_353091059999999', 'Samsung', 'SGH-i747', 'Galaxy S III', 353091050000000, 353091059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 709 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010215000000000_010215009999999', 'Palm', 'Treo 600', 'Treo 600', 10215000000000, 10215009999999, 'Continue', ''
);

-- INSERT QUERY NO: 710 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010223000000000_010223999999999', 'LG', 'G4050', 'G4050', 10223000000000, 10223999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 711 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013612000000000_013612009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13612000000000, 13612009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 712 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359437040000000_359437049999999', 'Samsung', 'SGH-i777', 'Galaxy S II', 359437040000000, 359437049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 713 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010394000000000_010394999999999', 'Sony', 'T226', 'T226', 10394000000000, 10394999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 714 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356570080000000_356570089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 356570080000000, 356570089999999, 'Continue', ''
);

-- INSERT QUERY NO: 715 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355436070000000_355436079999999', 'Apple', 'iPhone SE A1662', 'iPhone SE', 355436070000000, 355436079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 716 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352078070000000_352078079999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 352078070000000, 352078079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 717 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011160000000000_011160999999999', 'Pantech', 'C810', 'C810', 11160000000000, 11160999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 718 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359235060000000_359235069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359235060000000, 359235069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 719 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'867940020000000_867940029999999', 'ZTE', 'Z222', 'Z222', 867940020000000, 867940029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 720 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350639000000000_350639999999999', 'Motorola', 'T280i', 'T280i', 350639000000000, 350639999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 721 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013055000000000_013055009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13055000000000, 13055009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 722 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353104020000000_353104029999999', 'Nokia', '6085', '6085', 353104020000000, 353104029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 723 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359304060000000_359304069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359304060000000, 359304069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 724 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357173030000000_357173039999999', 'Dell', 'AERO3G-GR', 'AERO3G-GR', 357173030000000, 357173039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 725 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013062000000000_013062009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13062000000000, 13062009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 726 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357264000000000_357264009999999', 'Motorola', 'V551', 'V551', 357264000000000, 357264009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 727 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010559000000000_010559999999999', 'Nokia', '6010', '6010', 10559000000000, 10559999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 728 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013133000000000_013133009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13133000000000, 13133009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 729 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011364001271327_011364009999999', 'Apple', 'iPhone', 'iPhone', 11364001271327, 11364009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 730 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010748000000000_010748999999999', 'Sony', 'Z300a', 'Z300a', 10748000000000, 10748999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 731 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359042020000000_359042029999999', 'Samsung', 'SGH-A247', 'SGH-A247', 359042020000000, 359042029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 732 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354450060000000_354450069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354450060000000, 354450069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 733 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356903080000000_356903089999999', 'Samsung', 'SM-J120A', 'Samsung Galaxy Express 3', 356903080000000, 356903089999999, 'Continue', ''
);

-- INSERT QUERY NO: 734 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013271000000000_013271009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13271000000000, 13271009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 735 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013597000000000_013597009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13597000000000, 13597009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 736 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352622060000000_352622069999999', 'Samsung', 'SM-G870A', 'K Active', 352622060000000, 352622069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 737 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350467000000000_350467999999999', 'Samsung', 'SGH-S300', 'SGH-S300', 350467000000000, 350467999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 738 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012756000000000_012756009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12756000000000, 12756009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 739 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012368000000000_012368009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12368000000000, 12368009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 740 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012991000000000_012991009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12991000000000, 12991009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 741 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355786070000000_355786079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 355786070000000, 355786079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 742 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358664070000000_358664079999999', 'LG', 'K425', 'K10', 358664070000000, 358664079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 743 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012855000000000_012855009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12855000000000, 12855009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 744 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355084050000000_355084059999999', 'HP', '900', 'Elite Pad 900', 355084050000000, 355084059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 745 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013850000000000_013850009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13850000000000, 13850009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 746 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358389040000000_358389049999999', 'Samsung', 'SGH-A197', 'SGH-A197', 358389040000000, 358389049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 747 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359431030000000_359431039999999', 'BlackBerry', '8320', 'Curve 8320', 359431030000000, 359431039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 748 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012533000000000_012533009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12533000000000, 12533009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 749 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355575030000000_355575039999999', 'Samsung', 'SGH-A687', 'Strive', 355575030000000, 355575039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 750 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013045000000000_013045009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13045000000000, 13045009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 751 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357965040000000_357965049999999', 'BlackBerry', '9360', 'Curve 9360', 357965040000000, 357965049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 752 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012841000000000_012841009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12841000000000, 12841009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 753 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'457006000000000_457006999999999', 'Siemens', 'S16', 'S16', 457006000000000, 457006999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 754 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014350000000000_014350009999999', 'Alcatel', 'A460G', 'A460G', 14350000000000, 14350009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 755 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353000010000000_353000019999999', 'Samsung', 'SGH-X507', 'SGH-X507', 353000010000000, 353000019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 756 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358562070000000_358562079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 358562070000000, 358562079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 757 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359322060000000_359322069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 359322060000000, 359322069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 758 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011936000000000_011936009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11936000000000, 11936009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 759 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356568040000000_356568049999999', 'Huawei', 'U8800-51', 'Impulse', 356568040000000, 356568049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 760 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010983000000000_010983999999999', 'Motorola', 'C139', 'C139', 10983000000000, 10983999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 761 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010238000000000_010238999999999', 'BlackBerry', '7780', '7780', 10238000000000, 10238999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 762 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011771000000000_011771009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11771000000000, 11771009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 763 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353301070000000_353301079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353301070000000, 353301079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 764 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013530000000000_013530009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13530000000000, 13530009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 765 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010440000000000_010440999999999', 'Nokia', '1100', '1100', 10440000000000, 10440999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 766 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354049070000000_354049079999999', 'Samsung', 'SM-B780A', 'Rugby 4', 354049070000000, 354049079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 767 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355783070000000_355783079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 355783070000000, 355783079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 768 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012854000000000_012854009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12854000000000, 12854009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 769 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352005060000000_352005069999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 352005060000000, 352005069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 770 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359860040000000_359860049999999', 'ASUS', 'TF300TL', 'TF300TL', 359860040000000, 359860049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 771 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012743000000000_012743009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12743000000000, 12743009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 772 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359250064500000_359250064999999', 'Apple', 'iPhone 7 A1778', 'IPHONE 7 A1778', 359250064500000, 359250064999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 773 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011952000000000_011952009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 11952000000000, 11952009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 774 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010312000000000_010312999999999', 'LG', 'G4010', 'G4010', 10312000000000, 10312999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 775 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358253050000000_358253059999999', 'Motorola', 'V557', 'V557', 358253050000000, 358253059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 776 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012026000000000_012026009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12026000000000, 12026009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 777 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010027000000000_010027999999999', 'Siemens', 'S12', 'S12', 10027000000000, 10027999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 778 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011662000000000_011662009999999', 'Samsung', 'SGH-A137', 'SGH-A137', 11662000000000, 11662009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 779 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355322080000000_355322089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355322080000000, 355322089999999, 'Continue', ''
);

-- INSERT QUERY NO: 780 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352528000000000_352528009999999', 'Nokia', '3100', '3100', 352528000000000, 352528009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 781 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359177070000000_359177079999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7 Plus A1661', 359177070000000, 359177079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 782 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353932040000000_353932049999999', 'BlackBerry', '9300', 'Curve', 353932040000000, 353932049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 783 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012020000000000_012020009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 12020000000000, 12020009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 784 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012293000000000_012293009999999', 'LG', 'GT550', 'Encore', 12293000000000, 12293009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 785 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354001020000000_354001029999999', 'Motorola', 'MC5574', 'MC5574', 354001020000000, 354001029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 786 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012267000000000_012267009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12267000000000, 12267009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 787 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013538000000000_013538009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13538000000000, 13538009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 788 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010077000000000_010077999999999', 'BlackBerry', '5810', '5810', 10077000000000, 10077999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 789 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352566070000000_352566079999999', 'Samsung', 'SM-G928A', 'Galaxy S6 Edge Plus', 352566070000000, 352566079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 790 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351749040000000_351749049999999', 'Samsung', 'SGH-A777', 'SGH-A777', 351749040000000, 351749049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 791 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011563000000000_011563009999999', 'Samsung', 'SGH-A117', 'SGH-A117', 11563000000000, 11563009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 792 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359301060000000_359301069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359301060000000, 359301069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 793 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351543060000000_351543069999999', 'Samsung', 'SM-C105A', 'Galaxy S4 Zoom', 351543060000000, 351543069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 794 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013331000000000_013331009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13331000000000, 13331009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 795 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013965000000000_013965009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13965000000000, 13965009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 796 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012648000000000_012648009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12648000000000, 12648009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 797 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358253000000000_358253039999999', 'Motorola', 'V557', 'V557', 358253000000000, 358253039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 798 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356921010000000_356921019999999', 'BlackBerry', '8700c att', '8700c', 356921010000000, 356921019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 799 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011181000000000_011181002999999', 'LG', 'CG225 att', 'CG225', 11181000000000, 11181002999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 800 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356572080000000_356572089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 356572080000000, 356572089999999, 'Continue', ''
);

-- INSERT QUERY NO: 801 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010496000000000_010496999999999', 'Nokia', '6010', '6010', 10496000000000, 10496999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 802 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354731020000000_354731029999999', 'Samsung', 'SGH-i617', 'BlackJack II', 354731020000000, 354731029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 803 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356963060000000_356963069999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 356963060000000, 356963069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 804 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012961000000000_012961009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12961000000000, 12961009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 805 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353518000000000_353518009999999', 'Motorola', 'V400', 'V400', 353518000000000, 353518009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 806 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010093000000000_010093999999999', 'Nokia', '8390', '8390', 10093000000000, 10093999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 807 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355799070000000_355799079999999', 'Apple', 'iPhone SE A1662', 'iPhone SE', 355799070000000, 355799079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 808 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356939000000000_356939009999999', 'Samsung', 'X497', 'X497', 356939000000000, 356939009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 809 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013014000000000_013014009999999', 'Samsung', 'SGH-i757', 'Galaxy S II Skyrocket', 13014000000000, 13014009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 810 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010959000000000_010959009999999', 'Motorola', 'HC700', 'HC700', 10959000000000, 10959009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 811 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355404010000000_355404019999999', 'Samsung', 'SGH-C417', 'SGH-C417', 355404010000000, 355404019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 812 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359847040000000_359847049999999', 'Samsung', 'SGH-A157', 'SGH-A157', 359847040000000, 359847049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 813 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357165000000000_357165009999999', 'Samsung', 'SGH-A747', 'SGH-A747', 357165000000000, 357165009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 814 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355355080000000_355355089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 355355080000000, 355355089999999, 'Continue', ''
);

-- INSERT QUERY NO: 815 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353339070000000_353339079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353339070000000, 353339079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 816 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013071000000000_013071009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13071000000000, 13071009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 817 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353454000000000_353454999999999', 'Samsung', 'SGH-A717', 'SGH-A717', 353454000000000, 353454999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 818 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010174000000000_010174999999999', 'Nokia', '6800', '6800', 10174000000000, 10174999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 819 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012253000000000_012253009999999', 'Pantech', 'P9050', 'Laser', 12253000000000, 12253009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 820 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014736000000000_014736009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 14736000000000, 14736009999999, 'Continue', ''
);

-- INSERT QUERY NO: 821 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353608070000000_353608079999999', 'Samsung', 'SM-T377A', 'Galaxy Tab E', 353608070000000, 353608079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 822 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353752000000000_353752009999999', 'Nokia', '7610', '7610', 353752000000000, 353752009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 823 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358519000000000_358519009999999', 'Samsung', 'SGH-D807', 'SGH-D807', 358519000000000, 358519009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 824 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358733000000000_358733009999999', 'Samsung', 'X497', 'X497', 358733000000000, 358733009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 825 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350642000000000_350642999999999', 'Motorola', 'V66i', 'V66i', 350642000000000, 350642999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 826 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354259070000000_354259079999999', 'HTC', '2PS6500', '2PS6500', 354259070000000, 354259079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 827 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013171000000000_013171009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13171000000000, 13171009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 828 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010105000000000_010105999999999', 'Samsung', 'SGH-R225', 'SGH-R225', 10105000000000, 10105999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 829 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010031000000000_010031999999999', 'Motorola', 'Select 2000e', 'Select 2000e', 10031000000000, 10031999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 830 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358010050000000_358010059999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 358010050000000, 358010059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 831 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013501000000000_013501009999999', 'LG', 'A340', 'A340', 13501000000000, 13501009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 832 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359711060000000_359711069999999', 'Samsung', 'SM-R730A', 'Gear S2', 359711060000000, 359711069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 833 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352330080000000_352330089999999', 'Samsung', 'SM-G935A', 'Galaxy S7 Edge', 352330080000000, 352330089999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 834 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013274000000000_013274009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13274000000000, 13274009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 835 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355785070000000_355785079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 355785070000000, 355785079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 836 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358717060000000_358717069999999', 'HTC', '0PM912000', '0PM912000', 358717060000000, 358717069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 837 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353687000000000_353687009999999', 'Motorola', 'V400p', 'V400p', 353687000000000, 353687009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 838 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351873050000000_351873059999999', 'Samsung', 'SGH-i747', 'Galaxy S III', 351873050000000, 351873059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 839 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353341070000000_353341079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353341070000000, 353341079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 840 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354815000000000_354815012000000', 'Nokia', 'N75', 'N75', 354815000000000, 354815012000000, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 841 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011398000000000_011398999999999', 'Samsung', 'SGH-A117', 'SGH-A117', 11398000000000, 11398999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 842 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012572000000000_012572009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12572000000000, 12572009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 843 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354905000000000_354905009999999', 'Motorola', 'V551', 'V551', 354905000000000, 354905009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 844 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352002070000000_352002079999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 352002070000000, 352002079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 845 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355022070000000_355022079999999', 'Samsung', 'SM-J320A', 'SM-J320A', 355022070000000, 355022079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 846 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010252000000000_010252999999999', 'Samsung', 'X427', 'X427', 10252000000000, 10252999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 847 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013907000000000_013907009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13907000000000, 13907009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 848 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357567050000000_357567059999999', 'Samsung', 'SGH-A157', 'SGH-A157', 357567050000000, 357567059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 849 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012027000000000_012027009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12027000000000, 12027009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 850 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352437020030000_352437029999999', 'Samsung', 'SGH-A747', 'SGH-A747', 352437020030000, 352437029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 851 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359903040000000_359903049999999', 'Samsung', 'SGH-i727', 'Galaxy S II Skyrocket', 359903040000000, 359903049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 852 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013963000000000_013963009999999', 'Alcatel', 'OT871A', '871A', 13963000000000, 13963009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 853 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'864818010000000_864818019999999', 'ZTE', 'Z992', 'Z992', 864818010000000, 864818019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 854 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012940000000000_012940009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 12940000000000, 12940009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 855 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359401000000000_359401009999999', 'Motorola', 'L6', 'L6', 359401000000000, 359401009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 856 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013609000000000_013609009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13609000000000, 13609009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 857 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'863487020000000_863487029999999', 'ZTE', 'Z432', 'Z432', 863487020000000, 863487029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 858 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013131000000000_013131009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13131000000000, 13131009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 859 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010504000000000_010504999999999', 'Samsung', 'E317', 'E317', 10504000000000, 10504999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 860 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013040000000000_013040009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13040000000000, 13040009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 861 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357086050000000_357086059999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 357086050000000, 357086059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 862 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351305000000000_351305999999999', 'Siemens', 'U10', 'U10', 351305000000000, 351305999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 863 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352332080000000_352334089999999', 'Samsung', 'SM-G891A', 'Galaxy S7 Edge', 352334080000000, 352334089999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 864 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354675020000000_354675029999999', 'Motorola', 'V365 att', 'V365', 354675020000000, 354675029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 865 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356863070000000_356863079999999', 'Microsoft Mobile', 'Lumia 950XL', 'Lumia 950XL', 356863070000000, 356863079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 866 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355679070000000_355679079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 355679070000000, 355679079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 867 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013129000000000_013129009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13129000000000, 13129009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 868 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355316080000000_355316089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355316080000000, 355316089999999, 'Continue', ''
);

-- INSERT QUERY NO: 869 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353153050000000_353153059999999', 'Samsung', 'SGH-i747', 'Galaxy S III', 353153050000000, 353153059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 870 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355828080000000_355828089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7', 355828080000000, 355828089999999, 'Continue', ''
);

-- INSERT QUERY NO: 871 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010422000000000_010422999999999', 'LG', 'L1400', 'L1400', 10422000000000, 10422999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 872 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351974030000000_351974039999999', 'Nokia', '6750', 'Mural', 351974030000000, 351974039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 873 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352019070000000_352019079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 352019070000000, 352019079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 874 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353327070000000_353327079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353327070000000, 353327079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 875 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355803080000000_355803089999999', 'Apple', 'iPad 9.7 A1823', 'iPad 9.7', 355803080000000, 355803089999999, 'Continue', ''
);

-- INSERT QUERY NO: 876 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013195000000000_013195009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13195000000000, 13195009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 877 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012575000000000_012575009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12575000000000, 12575009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 878 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356962060000000_356962069999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 356962060000000, 356962069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 879 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356266070000000_356266079999999', 'Samsung', 'SM-J120A', 'SM-J120A', 356266070000000, 356266079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 880 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013790000000000_013790009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13790000000000, 13790009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 881 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353254070000000_353254079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353254070000000, 353254079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 882 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353763010000000_353763019999999', 'BlackBerry', '8820', '8820', 353763010000000, 353763019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 883 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010468000000000_010468999999999', 'Sony', 'T637', 'T637', 10468000000000, 10468999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 884 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353802080000000_353802089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 353802080000000, 353802089999999, 'Continue', ''
);

-- INSERT QUERY NO: 885 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012836000000000_012836009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12836000000000, 12836009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 886 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354044030000000_354044039999999', 'Samsung', 'SGH-A887', 'Solstice', 354044030000000, 354044039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 887 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010097000000000_010097999999999', 'Samsung', 'SGH-N625', 'SGH-N625', 10097000000000, 10097999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 888 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010847000000000_010847999999999', 'LG', 'C2000', 'C2000', 10847000000000, 10847999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 889 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351625000000000_351625009999999', 'Samsung', 'SGH-V200C', 'SGH-V200C', 351625000000000, 351625009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 890 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012128000000000_012128009999999', 'Samsung', 'SGH-A137', 'SGH-A137', 12128000000000, 12128009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 891 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354256020000000_354256029999999', 'Samsung', 'SGH-A437', 'SGH-A437', 354256020000000, 354256029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 892 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012646000000000_012646009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12646000000000, 12646009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 893 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013849000000000_013849009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13849000000000, 13849009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 894 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010173000000000_010173999999999', 'Samsung', 'SGH-S307', 'SGH-S307', 10173000000000, 10173999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 895 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358299010000000_358299019999999', 'Samsung', 'SGH-A707', 'SGH-A707', 358299010000000, 358299019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 896 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357657060000000_357657069999999', 'LG', 'L33L', 'L33L', 357657060000000, 357657069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 897 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012753000000000_012753009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12753000000000, 12753009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 898 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354222000000000_354222009999999', 'BlackBerry', '7290', '7290', 354222000000000, 354222009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 899 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012987000000000_012987009999999', 'Sonim', 'XP5560-A-R4', 'XP5560-A-R4', 12987000000000, 12987009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 900 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354878060000000_354878069999999', 'Samsung', 'SM-G850A', 'Galaxy Alpha', 354878060000000, 354878069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 901 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012744000000000_012744009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12744000000000, 12744009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 902 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353978060000000_353978069999999', 'Samsung', 'SM-G800A', 'Galaxy S5 Mini', 353978060000000, 353978069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 903 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'990001730000000_990001739999999', 'Teleepoch', 'M3620', 'AT&T Cingular Flip', 990001730000000, 990001739999999, 'Continue', ''
);

-- INSERT QUERY NO: 904 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355318080000000_355318089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355318080000000, 355318089999999, 'Continue', ''
);

-- INSERT QUERY NO: 905 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355360080000000_355360089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 355360080000000, 355360089999999, 'Continue', ''
);

-- INSERT QUERY NO: 906 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356868000000000_356868009999999', 'Motorola', 'V3', 'V3', 356868000000000, 356868009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 907 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013999000000000_013999009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13999000000000, 13999009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 908 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353092050000000_353092059999999', 'Samsung', 'SGH-i747', 'Galaxy S III', 353092050000000, 353092059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 909 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353263020000000_353263029999999', 'Motorola', 'IZAR V3xx', 'MOTORAZR V3xx', 353263020000000, 353263029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 910 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350029000000000_350029999999999', 'Motorola', 'P7389i', 'P7389i', 350029000000000, 350029999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 911 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358341050000000_358341059999999', 'Nokia', '1520', 'Lumia 1520', 358341050000000, 358341059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 912 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359931040000000_359931049999999', 'Samsung', 'SGH-i667', 'Focus 2', 359931040000000, 359931049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 913 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011810000000000_011810009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11810000000000, 11810009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 914 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011750000000000_011750009999999', 'Nokia', '2610', '2610', 11750000000000, 11750009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 915 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359303030000000_359303039999999', 'PCD', 'STX-2', 'Sharp FX', 359303030000000, 359303039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 916 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012265000000000_012265009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12265000000000, 12265009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 917 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358444040000000_358444049999999', 'Samsung', 'SGH-i957', 'Galaxy Tab 8.9', 358444040000000, 358444049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 918 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353276010000000_353276019999999', 'Motorola', 'L2', 'L2', 353276010000000, 353276019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 919 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353653050000000_353653059999999', 'Nokia', '920', 'Lumia 920', 353653050000000, 353653059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 920 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011463000000000_011463999999999', 'Pantech', 'C520', 'Breeze C520', 11463000000000, 11463999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 921 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353313050000000_353313059999999', 'HTC', 'PM33100', 'First', 353313050000000, 353313059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 922 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356423070000000_356423079999999', 'Samsung', 'SM-G890A', 'Galaxy S6 Active', 356423070000000, 356423079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 923 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355309080000000_355309089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355309080000000, 355309089999999, 'Continue', ''
);

-- INSERT QUERY NO: 924 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357216070000000_357216079999999', 'Samsung', 'SM-G935A', 'Galaxy S7 Edge', 357216070000000, 357216079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 925 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012425000000000_012425009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12425000000000, 12425009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 926 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013894000000000_013894009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13894000000000, 13894009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 927 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012621000000000_012621009999999', 'LG', 'P925', 'Thrill', 12621000000000, 12621009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 928 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359215070000000_359215079999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 359215070000000, 359215079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 929 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355955060000000_355955069999999', 'Samsung', 'SM-T807A', 'Galaxy Tab S', 355955060000000, 355955069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 930 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356558080000000_356558089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 356558080000000, 356558089999999, 'Continue', ''
);

-- INSERT QUERY NO: 931 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013197000000000_013197009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13197000000000, 13197009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 932 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355743010000000_355743019999999', 'HP', 'iPAQ 510', 'iPAQ 510', 355743010000000, 355743019999999, 'Continue', ''
);

-- INSERT QUERY NO: 933 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356986060000000_356986069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 356986060000000, 356986069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 934 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353501060000000_353501069999999', 'Samsung', 'SM-G870A', 'K Active', 353501060000000, 353501069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 935 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355726070000000_355726079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 355726070000000, 355726079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 936 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358357060000000_358357069999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 358357060000000, 358357069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 937 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355969040000000_355969049999999', 'Nokia', '6350', '6350', 355969040000000, 355969049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 938 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358611060000000_358611069999999', 'Nokia', '635', 'Lumia 635', 358611060000000, 358611069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 939 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010651000000000_010651999999999', 'Motorola', 'X-PAD', 'X-PAD', 10651000000000, 10651999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 940 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354409060000000_354409069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354409060000000, 354409069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 941 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013003000000000_013003009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13003000000000, 13003009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 942 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356091060000000_356091069999999', 'Samsung', 'SM-T707A', 'Galaxy Tab S', 356091060000000, 356091069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 943 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012198000000000_012198009999999', 'LG', 'GR700', 'Vu Plus', 12198000000000, 12198009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 944 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010259000000000_010259009999999', 'Nokia', '3595', '3595', 10259000000000, 10259009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 945 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012959000000000_012959009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12959000000000, 12959009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 946 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354112070000000_354112079999999', 'Motorola', 'XT1103', 'Nexus 6', 354112070000000, 354112079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 947 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358342030000000_358342039999999', 'Motorola', 'MB511', 'FlipOut', 358342030000000, 358342039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 948 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013188000000000_013188009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13188000000000, 13188009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 949 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012939000000000_012939009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 12939000000000, 12939009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 950 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011112000000000_011112009999999', 'Motorola', 'M930 M930 MAV', 'M930 M930 MAV', 11112000000000, 11112009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 951 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355354080000000_355354089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 355354080000000, 355354089999999, 'Continue', ''
);

-- INSERT QUERY NO: 952 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013399000000000_013399009999999', 'Sonim', 'XP5560-A-R4', 'XP5560-A-R4', 13399000000000, 13399009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 953 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359497030000000_359497039999999', 'Samsung', 'SGH-A947', 'SGH-A947', 359497030000000, 359497039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 954 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013522000000000_013522009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13522000000000, 13522009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 955 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355020030000000_355020039999999', 'BlackBerry', '8310 RED', 'Curve 8310', 355020030000000, 355020039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 956 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010325000000000_010325999999999', 'Nokia', '3595', '3595', 10325000000000, 10325999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 957 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352457070000000_352457079999999', 'Samsung', 'SM-N920A', 'Galaxy Note 5', 352457070000000, 352457079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 958 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011351000000000_011351999999999', 'Palm', 'Centro', 'Centro', 11351000000000, 11351999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 959 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355356080000000_355356089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 355356080000000, 355356089999999, 'Continue', ''
);

-- INSERT QUERY NO: 960 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356920010000000_356920019999999', 'BlackBerry', 'PEARL', 'Pearl', 356920010000000, 356920019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 961 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011776000000000_011776009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11776000000000, 11776009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 962 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353833010000000_353833019999999', 'Samsung', 'SGH-C417', 'SGH-C417', 353833010000000, 353833019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 963 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355837080000000_355837089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7 Plus A1661', 355837080000000, 355837089999999, 'Continue', ''
);

-- INSERT QUERY NO: 964 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010628000000000_010628999999999', 'LG', 'C2000', 'C2000', 10628000000000, 10628999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 965 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014699000000000_014699009999999', 'Alcatel', '4060A', '4060A', 14699000000000, 14699009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 966 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354272050000000_354272059999999', 'Samsung', 'SGH-i497', 'Galaxy Tab 2', 354272050000000, 354272059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 967 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353778080000000_353778089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 353778080000000, 353778089999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 968 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'867420020000000_867420029999999', 'ZTE', 'Z958', 'ZMAX 2', 867420020000000, 867420029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 969 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'865110020000000_865110029999999', 'Huawei', 'Y536A1', 'Y536A1', 865110020000000, 865110029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 970 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013435000000000_013435009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13435000000000, 13435009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 971 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351832070000000_351832079999999', 'Microsoft Mobile', 'RM-1116', 'Lumia 950 XL', 351832070000000, 351832079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 972 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012699000000000_012699009999999', 'Pantech', 'P2030', 'Breeze III', 12699000000000, 12699009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 973 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359128070000000_359128079999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7 Plus A1661', 359128070000000, 359128079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 974 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'869069020000000_869069029999999', 'ZTE', 'Z222', 'Z222', 869069020000000, 869069029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 975 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012864000000000_012864009999999', 'Pantech', 'P9070', 'Burst', 12864000000000, 12864009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 976 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010402000000000_010402999999999', 'Siemens', 'C61', 'C61', 10402000000000, 10402999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 977 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355459010000000_355459019999999', 'Samsung', 'SGH-A707', 'SGH-A707', 355459010000000, 355459019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 978 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356566080000000_356566089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 356566080000000, 356566089999999, 'Continue', ''
);

-- INSERT QUERY NO: 979 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013160000000000_013160009999999', 'Alcatel', 'OT871A', '871A', 13160000000000, 13160009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 980 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013006000000000_013006009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13006000000000, 13006009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 981 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'980042000000000_980042009999999', 'BlackBerry', 'BOLD 9000', 'Bold 9000', 980042000000000, 980042009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 982 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013903000000000_013903009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13903000000000, 13903009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 983 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352328080000000_352328089999999', 'Samsung', 'SM-N930A', 'Galaxy Note 7', 352328080000000, 352328089999999, 'Continue', ''
);

-- INSERT QUERY NO: 984 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011206000000000_011206999999999', 'Palm', 'Treo 680', 'Treo 680', 11206000000000, 11206999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 985 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357105070000000_357105079999999', 'Samsung', 'SM-R735A', 'Gear S2 Classic', 357105070000000, 357105079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 986 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010303000000000_010303999999999', 'Siemens', 'C61', 'C61', 10303000000000, 10303999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 987 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358379010000000_358379019999999', 'Samsung', 'SGH-A827', 'SGH-A827', 358379010000000, 358379019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 988 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012577000000000_012577009999999', 'Pantech', 'P2000', 'Breeze II', 12577000000000, 12577009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 989 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010395000000000_010395999999999', 'Samsung', 'X427M', 'X427M', 10395000000000, 10395999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 990 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012995000000000_012995009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12995000000000, 12995009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 991 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355829010000000_355829019999999', 'Motorola', 'RAZR 05 att', 'RAZR 05 att', 355829010000000, 355829019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 992 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355032000000000_355032009999999', 'Nokia', '6230', '6230', 355032000000000, 355032009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 993 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013906000000000_013906009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13906000000000, 13906009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 994 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355911060000000_355911069999999', 'HP', 'MU739', 'Slate 7 Plus G2', 355911060000000, 355911069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 995 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353106000000000_353106009999999', 'Motorola', 'V400', 'V400', 353106000000000, 353106009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 996 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013058000000000_013058009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13058000000000, 13058009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 997 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012757000000000_012757009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12757000000000, 12757009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 998 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012350000000000_012350009999999', 'Nokia', '2720', '2720', 12350000000000, 12350009999999, 'Continue', ''
);

-- INSERT QUERY NO: 999 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355607000000000_355607009999999', 'Motorola', 'V180', 'V180', 355607000000000, 355607009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1000 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011393000000000_011393999999999', 'Motorola', 'C168i', 'C168i', 11393000000000, 11393999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1001 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010263000000000_010263009999999', 'Nokia', '3595', '3595', 10263000000000, 10263009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1002 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356101010000000_356101019999999', 'Motorola', 'MC7004', 'MC7004', 356101010000000, 356101019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1003 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012211000000000_012211009999999', 'LG', 'GU292', 'GU292', 12211000000000, 12211009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1004 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012547000000000_012547009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12547000000000, 12547009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1005 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359250065000000_359250065499999', 'Apple', 'iPhone 7 Plus A1784', 'IPHONE 7 PLUS A1784', 359250065000000, 359250065499999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1006 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'869641020000000_869641029999999', 'ZTE', 'Z831', 'Maven 2', 869641020000000, 869641029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1007 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357772050000000_357772059999999', 'Motorola', '7528XP', '7528XP', 357772050000000, 357772059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1008 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010685000000000_010685999999999', 'LG', 'F9200', 'F9200', 10685000000000, 10685999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1009 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353372000000000_353372999999999', 'Nokia', '6230', '6230', 353372000000000, 353372999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1010 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353216050000000_353216059999999', 'Motorola', 'XT1058', 'XT1058', 353216050000000, 353216059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1011 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354406060000000_354406069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354406060000000, 354406069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1012 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013901000000000_013901009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13901000000000, 13901009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1013 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353299070000000_353299079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353299070000000, 353299079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1014 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356642080000000_356642089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 356642080000000, 356642089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1015 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012162000000000_012162009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12162000000000, 12162009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1016 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355843020000000_355843029999999', 'Samsung', 'SGH-A867', 'Eternity', 355843020000000, 355843029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1017 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013787000000000_013787009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13787000000000, 13787009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1018 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359214070000000_359214079999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 359214070000000, 359214079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1019 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352038070000000_352038079999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 352038070000000, 352038079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1020 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013539000000000_013539009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13539000000000, 13539009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1021 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354952070000000_354952079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 354952070000000, 354952079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1022 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'868513000000000_868513009999999', 'Dell', 'Streak 7 M02M', '', 868513000000000, 868513009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1023 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013804000000000_013804009999999', 'NETGEAR', 'AC781S', 'AT&T UNITE PRO', 13804000000000, 13804009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1024 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357182050000000_357182059999999', 'Samsung', 'SGH-i437P', 'Galaxy Express', 357182050000000, 357182059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1025 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355581050000000_355581059999999', 'Samsung', 'SGH-A157', 'SGH-A157', 355581050000000, 355581059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1026 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013174000000000_013174009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13174000000000, 13174009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1027 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013676000000000_013676009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13676000000000, 13676009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1028 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013032000000000_013032009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13032000000000, 13032009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1029 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011475000000000_011475009999999', 'Pantech', 'C810', 'C810', 11475000000000, 11475009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1030 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355483040000000_355483049999999', 'Motorola', 'Pikes Peak', 'Pikes Peak', 355483040000000, 355483049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1031 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'001000145000000_001000145999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 1000145000000, 1000145999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1032 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359176070000000_359176079999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7 Plus A1661', 359176070000000, 359176079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1033 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353143020000000_353143029999999', 'HTC', 'FUZE P4605', 'Fuze NC', 353143020000000, 353143029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1034 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012657000000000_012657009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12657000000000, 12657009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1035 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'868503020000000_868503029999999', 'ZTE', 'Z968', 'ZMAX 3', 868503020000000, 868503029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1036 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012840000000000_012840009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12840000000000, 12840009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1037 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356918020000000_356918029999999', 'Motorola', 'QA1 Karma', 'Karma', 356918020000000, 356918029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1038 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014564000000000_014564009999999', 'LG', 'B470', 'B470', 14564000000000, 14564009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1039 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356569080000000_356569089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 356569080000000, 356569089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1040 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358554070000000_358554079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 358554070000000, 358554079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1041 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357159000000000_357159000020000', 'Samsung', 'ZX10', 'ZX10', 357159000000000, 357159000020000, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1042 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355503070000000_355503079999999', 'Samsung', 'SM-G935A', 'Galaxy S7 Edge', 355503070000000, 355503079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1043 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356271010000000_356271019999999', 'Nokia', '6555i', '6555i', 356271010000000, 356271019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1044 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010634000000000_010634007662508', 'Motorola', 'V173', 'V173', 10634000000000, 10634007662508, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1045 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013851000000000_013851009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13851000000000, 13851009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1046 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011918000000000_011918009999999', 'Nokia', '2660', '2660', 11918000000000, 11918009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1047 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010711000000000_010711999999999', 'Motorola', 'M900', 'M900', 10711000000000, 10711999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1048 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353779080000000_353779089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353779080000000, 353779089999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1049 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011122000000000_011122999999999', 'Nokia', '6030', '6030', 11122000000000, 11122999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1050 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013974000000000_013974009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13974000000000, 13974009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1051 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355186040000000_355186049999999', 'BlackBerry', 'Curve 8520', 'Curve 8520', 355186040000000, 355186049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1052 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012647000000000_012647009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12647000000000, 12647009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1053 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358993040000000_358993049999999', 'Lenovo', 'ThinkPad X1', 'ThinkPad X1 Carbon', 358993040000000, 358993049999999, 'Continue', ''
);

-- INSERT QUERY NO: 1054 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355807080000000_355807089999999', 'Apple', 'iPad 9.7 A1823', 'iPad 9.7', 355807080000000, 355807089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1055 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010025000000000_010025999999999', 'Motorola', 'StarTac', 'StarTac', 10025000000000, 10025999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1056 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013182000000000_013182009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13182000000000, 13182009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1057 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011212000000000_011212999999999', 'LG', 'CU575', 'Trax', 11212000000000, 11212999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1058 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010565000000000_010565999999999', 'LG', 'C1300', 'C1300', 10565000000000, 10565999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1059 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354407060000000_354407069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354407060000000, 354407069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1060 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359691040000000_359691049999999', 'HTC', 'PJ83100', 'One X', 359691040000000, 359691049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1061 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355778000000000_355778999999999', 'Samsung', 'P777', 'P777', 355778000000000, 355778999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1062 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010436000000000_010436999999999', 'Samsung', 'C207', 'C207', 10436000000000, 10436999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1063 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011120000000000_011120999999999', 'Pantech', 'C510', 'Eagle', 11120000000000, 11120999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1064 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013988000000000_013988009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13988000000000, 13988009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1065 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354518000000000_354518999999999', 'Motorola', 'V557', 'V557', 354518000000000, 354518999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1066 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352344050000000_352344059999999', 'Motorola', 'MC67NA', 'MC67NA', 352344050000000, 352344059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1067 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010477000000000_010477999999999', 'LG', 'L1200', 'L1200', 10477000000000, 10477999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1068 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'448954000000000_448954999999999', 'Motorola', 'L7089', 'L7089', 448954000000000, 448954999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1069 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355372080000000_355372089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7', 355372080000000, 355372089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1070 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352334080000000_352334089999999', 'Samsung', 'SM-G891A', 'Galaxy S7 Active', 352334080000000, 352334089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1071 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354447060000000_354447069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354447060000000, 354447069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1072 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011503000000000_011503999999999', 'Nokia', '2610', '2610', 11503000000000, 11503999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1073 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351632000000000_351632999999999', 'Siemens', 'SL55', 'SL55', 351632000000000, 351632999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1074 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011612000000000_011612009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11612000000000, 11612009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1075 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354249060000000_354249069999999', 'Nokia', '520', 'Lumia 520', 354249060000000, 354249069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1076 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351741000000000_351741019999999', 'Samsung', 'SGH-C417', 'SGH-C417', 351741000000000, 351741019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1077 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013532000000000_013532009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13532000000000, 13532009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1078 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010109000000000_010109999999999', 'Motorola', 'T193m', 'T193m', 10109000000000, 10109999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1079 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355682070000000_355682079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 355682070000000, 355682079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1080 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012912000000000_012912009999999', 'LG', 'C395', 'Xpression', 12912000000000, 12912009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1081 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355956060000000_355956069999999', 'Samsung', 'SM-G850A', 'Galaxy Alpha', 355956060000000, 355956069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1082 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354997050000000_354997059999999', 'Motorola', 'XT1045', 'XT1045', 354997050000000, 354997059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1083 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355887000000000_355887999999999', 'Motorola', 'V220', 'V220', 355887000000000, 355887999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1084 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352711010000000_352711019999999', 'Samsung', 'SGH-C417', 'SGH-C417', 352711010000000, 352711019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1085 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353294070000000_353294079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353294070000000, 353294079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1086 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359734000000000_359734009999999', 'Nokia', '6126', '6126', 359734000000000, 359734009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1087 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012545000000000_012545009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12545000000000, 12545009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1088 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356875020000000_356875029999999', 'Nokia', 'E71x', 'E71x', 356875020000000, 356875029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1089 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354385060000000_354385069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 354385060000000, 354385069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1090 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012337000000000_012337009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12337000000000, 12337009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1091 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355794050000000_355794059999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 355794050000000, 355794059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1092 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014085000000000_014085009999999', 'Amazon', 'SD4930UR Fire', 'Amazon Fire', 14085000000000, 14085009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1093 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355748070000000_355748079999999', 'Apple', 'iPhone 6S Plus A1699', 'iPhone 6s Plus A1699', 355748070000000, 355748079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1094 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359138050000000_359138059999999', 'Dell', '5130', 'Dell Venue 11 Pro 5130', 359138050000000, 359138059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1095 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013971000000000_013971009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13971000000000, 13971009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1096 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355685070000000_355685079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 355685070000000, 355685079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1097 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351520000000000_351520009999999', 'Nokia', 'N-Gage', 'N-Gage', 351520000000000, 351520009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1098 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355343080000000_355343089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7', 355343080000000, 355343089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1099 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010274000000000_010274999999999', 'Nokia', '1100', '1100', 10274000000000, 10274999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1100 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358883000000000_358883009999999', 'HP', 'iPAQ-J 6925', 'iPAQ-J 6925', 358883000000000, 358883009999999, 'Continue', ''
);

-- INSERT QUERY NO: 1101 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013069000000000_013069009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13069000000000, 13069009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1102 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355882040000000_355882049999999', 'BlackBerry', '9810', 'Torch 9810', 355882040000000, 355882049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1103 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012856000000000_012856009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12856000000000, 12856009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1104 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013670000000000_013670009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13670000000000, 13670009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1105 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358920040000000_358920049999999', 'HTC', 'PD98120', 'Inspire', 358920040000000, 358920049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1106 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010648000000000_010648999999999', 'LG', 'C1500', 'C1500', 10648000000000, 10648999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1107 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355344080000000_355344089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7', 355344080000000, 355344089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1108 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358370060000000_358370069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 358370060000000, 358370069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1109 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352189060000000_352189069999999', 'HTC', '0P9O110', 'Desire 610', 352189060000000, 352189069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1110 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013887000000000_013887009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13887000000000, 13887009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1111 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011207000000000_011207999999999', 'Palm', 'Treo 750', 'Treo 750', 11207000000000, 11207999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1112 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358618000000000_358618009999999', 'Motorola', 'L7', 'SLVR L7', 358618000000000, 358618009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1113 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357438040000000_357438049999999', 'BlackBerry', 'BOLD 9700', 'Bold 9700', 357438040000000, 357438049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1114 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011269000000000_011269999999999', 'LG', 'CU515', 'CU515', 11269000000000, 11269999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1115 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012047000000000_012047009999999', 'Nokia', '2720', '2720', 12047000000000, 12047009999999, 'Continue', ''
);

-- INSERT QUERY NO: 1116 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353823080000000_353823089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 353823080000000, 353823089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1117 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'001000144000000_001000144999999', 'Kyocera', 'Dura XE', 'Dura XE', 1000144000000, 1000144999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1118 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353338060000000_353338069999999', 'Motorola', 'XT1527', 'Moto E', 353338060000000, 353338069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1119 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353058030000000_353058039999999', 'Samsung', 'SGH-A177', 'SGH-A177', 353058030000000, 353058039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1120 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012262000000000_012262009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12262000000000, 12262009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1121 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351509000000000_351509009999999', 'Nokia', '6200', '6200', 351509000000000, 351509009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1122 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357263000000000_357263009999999', 'Motorola', 'V180', 'V180', 357263000000000, 357263009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1123 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357121040000000_357121049999999', 'HTC', 'PG09410', 'Jetstream', 357121040000000, 357121049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1124 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354531020000000_354531029999999', 'Samsung', 'SGH-i617', 'BlackJack II', 354531020000000, 354531029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1125 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353417060000000_353417069999999', 'Samsung', 'SM-G750A', 'Galaxy Mega 2', 353417060000000, 353417069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1126 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011817000000000_011817009999999', 'LG', 'GT365', 'NEON', 11817000000000, 11817009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1127 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354594000000000_354594009999999', 'BlackBerry', '7100g', '7100g', 354594000000000, 354594009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1128 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011631000000000_011631009999999', 'LG', 'CF360', 'Olivin', 11631000000000, 11631009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1129 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356260000000000_356260009999999', 'Motorola', 'V180', 'V180', 356260000000000, 356260009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1130 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013402000000000_013402009999999', 'Lenovo', 'EM7700', 'ThinkPad Tablet 2', 13402000000000, 13402009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1131 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013975000000000_013975009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13975000000000, 13975009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1132 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014486000000000_014486009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 14486000000000, 14486009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1133 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010667000000000_010667999999999', 'Sony', 'T290a', 'T290a', 10667000000000, 10667999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1134 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012336000000000_012336009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12336000000000, 12336009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1135 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355688050000000_355688059999999', 'Samsung', 'SGH-i747', 'Galaxy S III', 355688050000000, 355688059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1136 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354619000000000_354619009999999', 'Motorola', 'V180', 'V180', 354619000000000, 354619009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1137 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355834080000000_355834089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7', 355834080000000, 355834089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1138 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355080000000000_355080009999999', 'Motorola', 'V400', 'V400', 355080000000000, 355080009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1139 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353602040000000_353602049999999', 'Samsung', 'SGH-A927', 'Flight II', 353602040000000, 353602049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1140 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355838080000000_355838089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7', 355838080000000, 355838089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1141 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351808070000000_351808079999999', 'Samsung', 'SM-G920A', 'Galaxy S6', 351808070000000, 351808079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1142 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010017000000000_010017999999999', 'Motorola', 'StarTAC', 'StarTAC', 10017000000000, 10017999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1143 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'449277000000000_449277999999999', 'Motorola', 'V.60g', 'V.60g', 449277000000000, 449277999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1144 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013613000000000_013613009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13613000000000, 13613009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1145 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352127010000000_352127019999999', 'BlackBerry', 'PEARL', 'Pearl', 352127010000000, 352127019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1146 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013194000000000_013194009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13194000000000, 13194009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1147 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356252000000000_356252009999999', 'Motorola', 'V551', 'V551', 356252000000000, 356252009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1148 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011332000000000_011332999999999', 'LG', 'CU720', 'Shine', 11332000000000, 11332999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1149 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353196080000000_353196089999999', 'LG', 'LG328BG', 'B470', 353196080000000, 353196089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1150 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010060000000000_010060999999999', 'Motorola', 'T2282', 'T2282', 10060000000000, 10060999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1151 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012085000000000_012085009999999', 'LG', 'GW820', 'eXpo', 12085000000000, 12085009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1152 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'449280000000000_449280999999999', 'Motorola', 'V66', 'V66', 449280000000000, 449280999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1153 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354506000000000_354506009999999', 'Motorola', 'RAZR 06 V3', 'RAZR 06 V3', 354506000000000, 354506009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1154 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358518070000000_358518079999999', 'Samsung', 'SM-G891A', 'Galaxy S7 Active', 358518070000000, 358518079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1155 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355349080000000_355349089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 355349080000000, 355349089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1156 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355315080000000_355315089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355315080000000, 355315089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1157 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011364000000000_011364001271325', 'Apple', 'iPhone', 'iPhone', 11364000000000, 11364001271325, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1158 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351768000000000_351768999999999', 'BlackBerry', '8800', '8800', 351768000000000, 351768999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1159 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358593070000000_358593079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 358593070000000, 358593079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1160 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010002000000000_010002999999999', 'Motorola', 'FLARE', 'FLARE', 10002000000000, 10002999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1161 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353824080000000_353824089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 353824080000000, 353824089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1162 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353116050000000_353116059999999', 'Samsung', 'SGH-i687', 'SGH-i687', 353116050000000, 353116059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1163 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351841010000000_351841019999999', 'Sony', 'Z525', 'Z525', 351841010000000, 351841019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1164 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352829020000000_352829029999999', 'Samsung', 'SGH-i907', 'Epix', 352829020000000, 352829029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1165 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010022000000000_010022999999999', 'Siemens', 'G1050', 'G1050', 10022000000000, 10022999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1166 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011984000000000_011984009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 11984000000000, 11984009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1167 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013270000000000_013270009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13270000000000, 13270009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1168 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013181000000000_013181009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13181000000000, 13181009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1169 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013695000000000_013695009999999', 'LG', 'D800', 'G2', 13695000000000, 13695009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1170 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358369040000000_358369049999999', 'Samsung', 'SGH-A847', 'Rugby II', 358369040000000, 358369049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1171 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011772000000000_011772009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11772000000000, 11772009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1172 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012407000000000_012407009999999', 'Nokia', '2330', '2330', 12407000000000, 12407009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1173 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010829000000000_010830999999999', 'Sony', 'J220a', 'J220a', 10829000000000, 10830999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1174 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012177000000000_012177009999999', 'Pantech', 'P2000', 'Breeze II', 12177000000000, 12177009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1175 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352922050000000_352922059999999', 'BlackBerry', 'STL 100-3', 'Z10', 352922050000000, 352922059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1176 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350906000000000_350906999999999', 'Motorola', 'V60i', 'V60i', 350906000000000, 350906999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1177 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353262070000000_353262079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353262070000000, 353262079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1178 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013885000000000_013885009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13885000000000, 13885009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1179 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358169060000000_358169069999999', 'LG', 'V495', 'G Pad F 8.0', 358169060000000, 358169069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1180 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356571080000000_356571089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 356571080000000, 356571089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1181 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010408000000000_010408999999999', 'Sony', 'Z500a', 'Z500a', 10408000000000, 10408999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1182 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353295070000000_353295079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353295070000000, 353295079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1183 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358586040000000_358586049999999', 'Samsung', 'SGH-i677', 'Focus Flash', 358586040000000, 358586049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1184 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353538060000000_353538069999999', 'BlackBerry', 'SQW100-3', 'Passport', 353538060000000, 353538069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1185 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011990000000000_011990009999999', 'LG', 'GD710', 'Shine II', 11990000000000, 11990009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1186 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014584000000000_014584009999999', 'Alcatel', '5056O', '5056O', 14584000000000, 14584009999999, 'Continue', ''
);

-- INSERT QUERY NO: 1187 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013430000000000_013430009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13430000000000, 13430009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1188 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010291000000000_010291999999999', 'BlackBerry', '7280', '7280', 10291000000000, 10291999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1189 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356554080000000_356554089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 356554080000000, 356554089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1190 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358628000000000_358628009999999', 'Samsung', 'SGH-X507', 'SGH-X507', 358628000000000, 358628009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1191 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011975000000000_011975009999999', 'Nokia', '2320', '2320', 11975000000000, 11975009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1192 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358601070000000_358601079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 358601070000000, 358601079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1193 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010194000000000_010194999999999', 'BlackBerry', '7230', '7230', 10194000000000, 10194999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1194 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355085020000000_355085029999999', 'BlackBerry', '8310', 'Curve 8310', 355085020000000, 355085029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1195 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356613040000000_356613049999999', 'ZTE', 'Z221', 'Z221', 356613040000000, 356613049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1196 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357654010000000_357654019999999', 'Nokia', '6126', '6126', 357654010000000, 357654019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1197 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354250060000000_354250069999999', 'Nokia', '830 RM-983', 'Lumia 830', 354250060000000, 354250069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1198 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012417000000000_012417009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12417000000000, 12417009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1199 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011577000000000_011577009999999', 'LG', 'CG180', 'CG180', 11577000000000, 11577009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1200 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012759000000000_012759009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12759000000000, 12759009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1201 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013889000000000_013889009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13889000000000, 13889009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1202 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013526000000000_013526009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13526000000000, 13526009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1203 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013520000000000_013520009999999', 'LG', 'E980', 'Optimus G Pro', 13520000000000, 13520009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1204 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358846000000000_358846009999999', 'Nokia', '6102i', '6102i', 358846000000000, 358846009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1205 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'860086010000000_860086019999999', 'Huawei', 'U8652', 'Fusion', 860086010000000, 860086019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1206 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012295000000000_012295009999999', 'ZTE', 'R225', 'R225', 12295000000000, 12295009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1207 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010086000000000_010086999999999', 'Motorola', 'T193', 'T193', 10086000000000, 10086999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1208 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352268010000000_352268019999999', 'Nokia', '6102i', '6102i', 352268010000000, 352268019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1209 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358716000000000_358716009999999', 'Samsung', 'SGH-ZX20', 'SGH-ZX20', 358716000000000, 358716009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1210 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010015000000000_010015999999999', 'Motorola', 'MicroTAC Select 3000e', 'MicroTAC Select 3000e', 10015000000000, 10015999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1211 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011181003000000_011181999999999', 'LG', 'CG225 att', 'CG225', 11181003000000, 11181999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1212 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010128000000000_010128999999999', 'Nokia', '8390', '8390', 10128000000000, 10128999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1213 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355323080000000_355323089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355323080000000, 355323089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1214 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359673010000000_359673019999999', 'Samsung', 'SGH-A737', 'SGH-A737', 359673010000000, 359673019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1215 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013170000000000_013170009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13170000000000, 13170009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1216 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013107000000000_013107009999999', 'Alcatel', 'OT510A', '510A', 13107000000000, 13107009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1217 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013674000000000_013674009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13674000000000, 13674009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1218 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354390060000000_354390069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 354390060000000, 354390069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1219 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357198000000000_357198009999999', 'Sony', 'Z520a', 'Z520a', 357198000000000, 357198009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1220 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'980041000000000_980041009999999', 'BlackBerry', 'BOLD 9000', 'Bold 9000', 980041000000000, 980041009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1221 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355319080000000_355319089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355319080000000, 355319089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1222 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'861897010000000_861897019999999', 'ZTE', 'Z740', 'Radiant', 861897010000000, 861897019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1223 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354386060000000_354386069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 354386060000000, 354386069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1224 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010214000000000_010214999999999', 'Motorola', 'C350', 'C350', 10214000000000, 10214999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1225 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013672000000000_013672009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13672000000000, 13672009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1226 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013185000000000_013185009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13185000000000, 13185009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1227 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358514040000000_358514049999999', 'Samsung', 'SGH-i847', 'Rugby Smart', 358514040000000, 358514049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1228 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355840080000000_355840089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7', 355840080000000, 355840089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1229 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011233000000000_011233009999999', 'Motorola', 'HC700 F4705', 'HC700 F4705', 11233000000000, 11233009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1230 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356482050000000_356482059999999', 'HTC', 'PO58220', 'One Mini', 356482050000000, 356482059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1231 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359216070000000_359216079999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 359216070000000, 359216079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1232 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352007060000000_352007069999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 352007060000000, 352007069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1233 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012163000000000_012163009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12163000000000, 12163009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1234 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011198000000000_011198999999999', 'Motorola', 'C139', 'C139', 11198000000000, 11198999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1235 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013789000000000_013789009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13789000000000, 13789009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1236 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355654040000000_355654049999999', 'SHARP', 'ADS1', 'Sharp FX II', 355654040000000, 355654049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1237 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014300000000000_014300009999999', 'LG', 'V410', 'G Pad 7.0', 14300000000000, 14300009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1238 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012266000000000_012266009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12266000000000, 12266009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1239 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355878060000000_355878069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 355878060000000, 355878069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1240 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010469000000000_010469999999999', 'Sony', 'T237', 'T237', 10469000000000, 10469999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1241 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'868899020000000_868899029999999', 'ZTE', 'Z223', 'Z223', 868899020000000, 868899029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1242 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352319040000000_352319049999999', 'Samsung', 'SGH-A667', 'Evergreen', 352319040000000, 352319049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1243 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357447010000000_357447019999999', 'Samsung', 'SGH-A707', 'SGH-A707', 357447010000000, 357447019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1244 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358560040000000_358560049999999', 'Samsung', 'SGH-A777', 'SGH-A777', 358560040000000, 358560049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1245 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355831080000000_355831089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7', 355831080000000, 355831089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1246 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352014070000000_352014079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 352014070000000, 352014079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1247 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012424000000000_012424009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12424000000000, 12424009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1248 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359172070000000_359172079999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7 Plus A1661', 359172070000000, 359172079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1249 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354405060000000_354405069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354405060000000, 354405069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1250 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350328000000000_350328999999999', 'Sony', 'T68m', 'T68m', 350328000000000, 350328999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1251 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010152000000000_010152999999999', 'Samsung', 'SGH-V205', 'SGH-V205', 10152000000000, 10152999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1252 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357812010000000_357812019999999', 'Sony', 'Z310a', 'Z310a', 357812010000000, 357812019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1253 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011783000000000_011783009999999', 'LG', 'CU720', 'Shine', 11783000000000, 11783009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1254 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013272000000000_013272009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13272000000000, 13272009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1255 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010032000000000_010032999999999', 'Motorola', 'MicroTAC Select 3000e', 'MicroTAC Select 3000e', 10032000000000, 10032999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1256 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352331080000000_352331089999999', 'Samsung', 'SM-G935A', 'Galaxy S7 Edge', 352331080000000, 352331089999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1257 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359339010000000_359339019999999', 'Samsung', 'SGH-A437', 'SGH-A437', 359339010000000, 359339019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1258 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359828060000000_359828069999999', 'Samsung', 'SM-T817A', 'Galaxy Tab S2', 359828060000000, 359828069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1259 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013173000000000_013173009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13173000000000, 13173009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1260 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012573000000000_012573009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12573000000000, 12573009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1261 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353300070000000_353300079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353300070000000, 353300079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1262 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356425060000000_356425069999999', 'ASUS', 'ME375CL', 'Memo Pad 7', 356425060000000, 356425069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1263 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010119000000000_010119999999999', 'Nokia', '3590', '3590', 10119000000000, 10119999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1264 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013054000000000_013054009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13054000000000, 13054009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1265 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013540000000000_013540009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13540000000000, 13540009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1266 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010125000000000_010125999999999', 'Samsung', 'SGH-R225', 'SGH-R225', 10125000000000, 10125999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1267 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'862218020000000_862218029999999', 'ZTE', 'V72A', 'V72A', 862218020000000, 862218029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1268 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359210070000000_359210079999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 359210070000000, 359210079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1269 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359423030000000_359423039999999', 'Samsung', 'SGH-A847', 'Rugby II', 359423030000000, 359423039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1270 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012659000000000_012659009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12659000000000, 12659009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1271 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010202000000000_010202999999999', 'Samsung', 'SGH-R225M', 'SGH-R225M', 10202000000000, 10202999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1272 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014482000000000_014482009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 14482000000000, 14482009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1273 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358946020000000_358946029999999', 'Samsung', 'SGH-A777', 'SGH-A777', 358946020000000, 358946029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1274 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357493000000000_357493009999999', 'BlackBerry', '7290', '7290', 357493000000000, 357493009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1275 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351780030000000_351780039999999', 'Sony', 'W760a', 'W760a', 351780030000000, 351780039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1276 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353765060000000_353765069999999', 'ASUS', 'T00S', 'T00S', 353765060000000, 353765069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1277 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013902000000000_013902009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13902000000000, 13902009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1278 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353258070000000_353258079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353258070000000, 353258079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1279 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353816080000000_353816089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353816080000000, 353816089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1280 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012431000000000_012431009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12431000000000, 12431009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1281 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352717080000000_352717089999999', 'Samsung', 'SM-G935A', 'Galaxy S7 Edge', 352717080000000, 352717089999999, 'Fallout', ''
);

-- INSERT QUERY NO: 1282 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350031000000000_350031999999999', 'Motorola', 'D15', 'D15', 350031000000000, 350031999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1283 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010702000000000_010702999999999', 'Nokia', '6010', '6010', 10702000000000, 10702999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1284 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355281060000000_355281069999999', 'HTC', '0PFH100', 'Desire Eye', 355281060000000, 355281069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1285 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353513070000000_353513079999999', 'Samsung', 'SM-G928A', 'Galaxy S6 Edge Plus', 353513070000000, 353513079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1286 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013189000000000_013189009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13189000000000, 13189009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1287 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356964060000000_356964069999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 356964060000000, 356964069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1288 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357246010000000_357246019999999', 'Samsung', 'SGH-i617', 'BlackJack II', 357246010000000, 357246019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1289 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357713010000000_357713019999999', 'Motorola', 'RAZR 05 V3', 'RAZR 05 V3', 357713010000000, 357713019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1290 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355562050000000_355562059999999', 'Dell', 'XPS10J42A', 'XPS10J42A', 355562050000000, 355562059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1291 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012853000000000_012853009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12853000000000, 12853009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1292 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356716070000000_356716079999999', 'Samsung', 'SM-N920A', 'Galaxy Note 5', 356716070000000, 356716079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1293 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353414060000000_353414069999999', 'Samsung', 'SM-T337A', 'SM-T337A', 353414060000000, 353414069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1294 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012233000000000_012233009999999', 'Samsung', 'SGH-A107', 'SGH-A107', 12233000000000, 12233009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1295 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010339000000000_010339999999999', 'Nokia', 'N-Gage', 'N-Gage', 10339000000000, 10339999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1296 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012428000000000_012428009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12428000000000, 12428009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1297 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356922030000000_356922039999999', 'Nokia', '6350', '6350', 356922030000000, 356922039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1298 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356554050000000_356554059999999', 'Samsung', 'SGH-i537', 'Galaxy S4 Active', 356554050000000, 356554059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1299 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353818080000000_353818089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353818080000000, 353818089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1300 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011828000000000_011828009999999', 'LG', 'CU720', 'Shine', 11828000000000, 11828009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1301 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013187000000000_013187009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13187000000000, 13187009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1302 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354389060000000_354389069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 354389060000000, 354389069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1303 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355485000000000_355485009999999', 'Samsung', 'P207', 'P207', 355485000000000, 355485009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1304 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359410000000000_359410999999999', 'Motorola', 'V557', 'V557', 359410000000000, 359410999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1305 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010475000000000_010475999999999', 'LG', 'C1300', 'C1300', 10475000000000, 10475999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1306 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013281000000000_013281009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13281000000000, 13281009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1307 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012430000000000_012430009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12430000000000, 12430009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1308 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'449278000000000_449278999999999', 'Motorola', 'T280', 'T280', 449278000000000, 449278999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1309 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356208000000000_356208009999999', 'Nokia', '3220', '3220', 356208000000000, 356208009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1310 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013688000000000_013688009999999', 'Sonim', 'XP5560-A-R5', 'XP5560-A-R5', 13688000000000, 13688009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1311 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355384030000000_355384039999999', 'BlackBerry', '8320', 'Curve 8320', 355384030000000, 355384039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1312 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355334080000000_355334089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355334080000000, 355334089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1313 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351138000000000_351138999999999', 'Samsung', 'SGH-S108', 'SGH-S108', 351138000000000, 351138999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1314 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353751000000000_353751009999999', 'Nokia', '7610', '7610', 353751000000000, 353751009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1315 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011489000000000_011489009999999', 'LG', 'CU920 VU', 'VU', 11489000000000, 11489009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1316 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358285050100000_358285050359999', 'HP', 'HSTNH-B16C', 'Slate 7 Plus G2', 358285050100000, 358285050359999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1317 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352560020000000_352560029999999', 'Sony', 'W580i', 'W580i', 352560020000000, 352560029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1318 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013191000000000_013191009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13191000000000, 13191009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1319 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352426040000000_352426049999999', 'Samsung', 'SGH-A697', 'Sunburst', 352426040000000, 352426049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1320 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356557080000000_356557089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 356557080000000, 356557089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1321 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355772010000000_355772019999999', 'BlackBerry', '8300', 'Curve 8300', 355772010000000, 355772019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1322 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010262000000000_010262009999999', 'Nokia', '3595', '3595', 10262000000000, 10262009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1323 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011301000000000_011301009999999', 'Apple', 'iPhone', 'iPhone', 11301000000000, 11301009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1324 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013977000000000_013977009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13977000000000, 13977009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1325 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354451070000000_354451079999999', 'Samsung', 'SM-G530A', 'Grand Prime', 354451070000000, 354451079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1326 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356237020000000_356237029999999', 'Sony', 'W350A', 'W350A', 356237020000000, 356237029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1327 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012989000000000_012989009999999', 'Pantech', 'P7040P', 'Link', 12989000000000, 12989009999999, 'Continue', ''
);

-- INSERT QUERY NO: 1328 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356631040000000_356631049999999', 'Huawei', 'U2800A', 'U2800A', 356631040000000, 356631049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1329 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013039000000000_013039009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13039000000000, 13039009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1330 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352228080000000_352228089999999', 'LG', 'W280A', 'Wearable Watch LTE', 352228080000000, 352228089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1331 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359217070000000_359217079999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 359217070000000, 359217079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1332 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357365050000000_357365059999999', 'Samsung', 'SGH-i537', 'Galaxy S4 Active', 357365050000000, 357365059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1333 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353074070000000_353074079999999', 'LG', 'H900', 'V10', 353074070000000, 353074079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1334 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012748000000000_012748009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12748000000000, 12748009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1335 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357951000000000_357951999999999', 'Nokia', 'E62', 'E62', 357951000000000, 357951999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1336 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353128050000000_353128059999999', 'Samsung', 'SGH-i437', 'Galaxy Express', 353128050000000, 353128059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1337 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352295000000000_352295999999999', 'Samsung', 'SGH-A227', 'SGH-A227', 352295000000000, 352295999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1338 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359821000000000_359821009999999', 'Motorola', 'V3', 'V3', 359821000000000, 359821009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1339 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013064000000000_013064009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13064000000000, 13064009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1340 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353959030000000_353959039999999', 'Sony', 'W518a', 'W518a', 353959030000000, 353959039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1341 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355881040000000_355881049999999', 'BlackBerry', '9810', 'Torch 9810', 355881040000000, 355881049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1342 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010192000000000_010192999999999', 'Samsung', 'SGH-R225M', 'SGH-R225M', 10192000000000, 10192999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1343 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012145000000000_012145004999999', 'Palm', 'P101UNA', 'Pre Plus', 12145000000000, 12145004999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1344 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356088020000000_356088029999999', 'BlackBerry', '8310 RED', 'Curve 8310', 356088020000000, 356088029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1345 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352509000000000_352509009999999', 'Nokia', '3100', '3100', 352509000000000, 352509009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1346 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013596000000000_013596009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13596000000000, 13596009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1347 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354360060000000_354360069999999', 'BlackBerry', 'STR100-2', 'BlackBerry Leap', 354360060000000, 354360069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1348 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357699000000000_357699009999999', 'Motorola', 'V180', 'V180', 357699000000000, 357699009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1349 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014475000000000_014475009999999', 'NETGEAR', 'AC815S', 'AT&T UNITE EXPLORE', 14475000000000, 14475009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1350 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013327000000000_013327009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13327000000000, 13327009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1351 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354949050000000_354949059999999', 'HTC', 'PJ83100', 'One X', 354949050000000, 354949059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1352 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014087000000000_014087009999999', 'LG', 'D631', 'G Vista', 14087000000000, 14087009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1353 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010197000000000_010197999999999', 'Sony', 'T616', 'T616', 10197000000000, 10197999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1354 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010104000000000_010104999999999', 'Motorola', 'V70 1900', 'V70 1900', 10104000000000, 10104999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1355 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014481000000000_014481009999999', 'Sonim', 'XP7 IS', 'XP7 IS', 14481000000000, 14481009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1356 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353843080000000_353843089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 353843080000000, 353843089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1357 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355842080000000_355842089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7', 355842080000000, 355842089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1358 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356383010000000_356383019999999', 'Samsung', 'SGH-A717', 'SGH-A717', 356383010000000, 356383019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1359 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011299000000000_011299999999999', 'LG', 'CG225 att', 'CG225', 11299000000000, 11299999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1360 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354453060000000_354453069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 354453060000000, 354453069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1361 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014327000000000_014327009999999', 'ASUS', 'Z00D', 'ZenFone 2', 14327000000000, 14327009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1362 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012965000000000_012965009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12965000000000, 12965009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1363 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357778000000000_357778009999999', 'BlackBerry', '7290', '7290', 357778000000000, 357778009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1364 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353325070000000_353325079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353325070000000, 353325079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1365 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013896000000000_013896009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13896000000000, 13896009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1366 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012149000000000_012149009999999', 'LG', 'CU920 VU', 'VU', 12149000000000, 12149009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1367 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010546000000000_010546999999999', 'Samsung', 'X427M', 'X427M', 10546000000000, 10546999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1368 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013233000000000_013233009999999', 'Pantech', 'P8010', 'Flex', 13233000000000, 13233009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1369 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012546000000000_012546009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12546000000000, 12546009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1370 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359238060000000_359238069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359238060000000, 359238069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1371 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355830080000000_355830089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7', 355830080000000, 355830089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1372 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358625030000000_358625039999999', 'Samsung', 'SGH-A237', 'SGH-A237', 358625030000000, 358625039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1373 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359324060000000_359324069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 359324060000000, 359324069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1374 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010383000000000_010383999999999', 'Motorola', 'M900', 'M900', 10383000000000, 10383999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1375 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010012000000000_010012999999999', 'Motorola', '6000', '6000', 10012000000000, 10012999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1376 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013035000000000_013035009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13035000000000, 13035009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1377 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010091000000000_010091999999999', 'Motorola', 'T194 T193', 'T194 T193', 10091000000000, 10091999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1378 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351091050000000_351091059999999', 'Samsung', 'SGH-i577', 'Galaxy Exhilarate', 351091050000000, 351091059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1379 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012156000000000_012156009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12156000000000, 12156009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1380 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355342080000000_355342089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7', 355342080000000, 355342089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1381 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012071000000000_012071009999999', 'LG', 'GR500', 'Xenon', 12071000000000, 12071009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1382 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013979000000000_013979009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13979000000000, 13979009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1383 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352130070000000_352130079999999', 'Samsung', 'SM-G890A', 'Galaxy S6 Active', 352130070000000, 352130079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1384 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350640000000000_350640999999999', 'Motorola', 'V60g', 'V60g', 350640000000000, 350640999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1385 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012030000000000_012030009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12030000000000, 12030009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1386 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013426000000000_013426009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13426000000000, 13426009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1387 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356406060000000_356406069999999', 'Dell', '7350', 'Latitude 7350', 356406060000000, 356406069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1388 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012029000000000_012029009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12029000000000, 12029009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1389 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358192000000000_358192009999999', 'Samsung', 'X497', 'X497', 358192000000000, 358192009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1390 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354473070000000_354473079999999', 'Samsung', 'SM-G928A', 'Galaxy S6 Edge Plus', 354473070000000, 354473079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1391 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358789010000000_358789019999999', 'Motorola', 'VA76r Tundra', 'Tundra', 358789010000000, 358789019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1392 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357366050000000_357366059999999', 'Samsung', 'SM-T217A', 'Galaxy Tab 3', 357366050000000, 357366059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1393 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010320000000000_010320999999999', 'Nokia', '1100', '1100', 10320000000000, 10320999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1394 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012843000000000_012843009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12843000000000, 12843009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1395 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350894000000000_350894999999999', 'Nokia', '7210', '7210', 350894000000000, 350894999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1396 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012534000000000_012534009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12534000000000, 12534009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1397 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012986000000000_012986009999999', 'Sonim', 'XP5560-A-R4', 'XP5560-A-R4', 12986000000000, 12986009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1398 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011509000000000_011509999999999', 'Nokia', '2610', '2610', 11509000000000, 11509999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1399 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012540000000000_012540009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12540000000000, 12540009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1400 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358696030000000_358696039999999', 'Samsung', 'SGH-A877', 'Impression', 358696030000000, 358696039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1401 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013665000000000_013665009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13665000000000, 13665009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1402 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358560070000000_358560079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 358560070000000, 358560079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1403 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014251000000000_014251009999999', 'Sonim', 'XP5700', 'XP5', 14251000000000, 14251009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1404 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350654000000000_350654999999999', 'Motorola', 'A830-Siemens U10', 'A830-Siemens U10', 350654000000000, 350654999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1405 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357294040000000_357294049999999', 'Huawei', 'U8652', 'Fusion', 357294040000000, 357294049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1406 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013437000000000_013437009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13437000000000, 13437009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1407 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358949040000000_358949049999999', 'Samsung', 'SGH-i757', 'Galaxy S II Skyrocket', 358949040000000, 358949049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1408 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352041070000000_352041079999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 352041070000000, 352041079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1409 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353989070000000_353989079999999', 'LG', 'H790', 'Google Nexus 5X', 353989070000000, 353989079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1410 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'869346010000000_869346019999999', 'Lenovo', 'A2107A', 'IdeaTab A2107', 869346010000000, 869346019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1411 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359180070000000_359180079999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7 Plus A1661', 359180070000000, 359180079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1412 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013852000000000_013852009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13852000000000, 13852009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1413 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013899000000000_013899009999999', 'LG', 'D950', 'G Flex', 13899000000000, 13899009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1414 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011713000000000_011713009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11713000000000, 11713009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1415 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013061000000000_013061009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13061000000000, 13061009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1416 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356283050000000_356283059999999', 'Samsung', 'SGH-i187', 'ATIV Neo', 356283050000000, 356283059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1417 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356334060000000_356334069999999', 'HP', 'MU739', 'Slate 7 Plus G2', 356334060000000, 356334069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1418 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013202000000000_013202009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13202000000000, 13202009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1419 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355824080000000_355824089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7', 355824080000000, 355824089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1420 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356244050000000_356244999999999', 'Nokia', '3120', '3120', 356244050000000, 356244999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1421 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355681070000000_355681079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 355681070000000, 355681079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1422 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010236000000000_010236999999999', 'Nokia', '6340i', '6340i', 10236000000000, 10236999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1423 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014063000000000_014063009999999', 'Microsoft', '1573a', 'Surface 2', 14063000000000, 14063009999999, 'Continue', ''
);

-- INSERT QUERY NO: 1424 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014290000000000_014290009999999', 'Sonim', 'XP7', 'XP7', 14290000000000, 14290009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1425 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010047000000000_010047999999999', 'Motorola', 'M3682', 'M3682', 10047000000000, 10047999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1426 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350644000000000_350644999999999', 'Motorola', 'V60i', 'V60i', 350644000000000, 350644999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1427 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011808000000000_011808009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11808000000000, 11808009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1428 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358512030000000_358512039999999', 'HTC', 'A6366', 'Aria', 358512030000000, 358512039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1429 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'449318000000000_449318999999999', 'Motorola', 'Daxian GH-300 Soutec PT2000', 'Daxian GH-300 Soutec PT2000', 449318000000000, 449318999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1430 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013433000000000_013433009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13433000000000, 13433009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1431 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012498000000000_012498009999999', 'LG', 'C900', 'Quantum', 12498000000000, 12498009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1432 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013973000000000_013973009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13973000000000, 13973009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1433 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355330080000000_355330089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355330080000000, 355330089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1434 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359219070000000_359219079999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 359219070000000, 359219079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1435 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353819080000000_353819089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353819080000000, 353819089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1436 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'869142020000000_869142029999999', 'AT&T', 'MF923', 'Velocity', 869142020000000, 869142029999999, 'Continue', ''
);

-- INSERT QUERY NO: 1437 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011974000000000_011974009999999', 'Nokia', '2320', '2320', 11974000000000, 11974009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1438 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013124000000000_013124009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13124000000000, 13124009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1439 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013846000000000_013846009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13846000000000, 13846009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1440 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357396000000000_357396009999999', 'Motorola', 'V551', 'V551', 357396000000000, 357396009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1441 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353876070000000_353876079999999', 'Samsung', 'SM-N920A', 'Galaxy Note 5', 353876070000000, 353876079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1442 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010131000000000_010131999999999', 'Siemens', 'CT56', 'CT56', 10131000000000, 10131999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1443 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353428050000000_353428059999999', 'HTC', 'PM36100', 'One VX', 353428050000000, 353428059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1444 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010203000000000_010203999999999', 'Motorola', 'C350', 'C350', 10203000000000, 10203999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1445 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355768010000000_355768019999999', 'BlackBerry', 'Pearl att', 'Pearl', 355768010000000, 355768019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1446 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353989020000000_353989029999999', 'Motorola', 'Z9', 'Z9', 353989020000000, 353989029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1447 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353311080000000_353311089999999', 'Motorla', 'XT1789-04', 'Moto Z', 353311080000000, 353311089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1448 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012367001000000_012367009999999', 'Pantech', 'P7040P', 'Link', 12367001000000, 12367009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1449 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353984020000000_353984029999999', 'Motorola', 'IZAR V3xx', 'MOTORAZR V3xx', 353984020000000, 353984029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1450 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355683070000000_355683079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 355683070000000, 355683079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1451 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358285050000000_358285050099999', 'HP', 'HSTNH-B16C', 'Slate 10 HD', 358285050000000, 358285050099999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1452 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013256000000000_013256009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 13256000000000, 13256009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1453 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358427030000000_358427039999999', 'BlackBerry', 'Curve 8520', 'Curve 8520', 358427030000000, 358427039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1454 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351741020000000_351741029999999', 'Samsung', 'SGH-A747', 'SGH-A747', 351741020000000, 351741029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1455 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358373060000000_358373069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 358373060000000, 358373069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1456 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013423000000000_013423009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13423000000000, 13423009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1457 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'863132030000000_863132039999999', 'ZTE', 'Z983', '863132030000000', 863132030000000, 863132039999999, 'Fallout', ''
);

-- INSERT QUERY NO: 1458 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359886000000000_359886009999999', 'BlackBerry', '7130c', '7130c', 359886000000000, 359886009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1459 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351512030000000_351512039999999', 'Motorola', 'V365 no cam', 'V365', 351512030000000, 351512039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1460 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010112000000000_010112999999999', 'Samsung', 'SGH-R225M', 'SGH-R225M', 10112000000000, 10112999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1461 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358731020000000_358731029999999', 'Samsung', 'SGH-A877', 'Impression', 358731020000000, 358731029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1462 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013206000000000_013206009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13206000000000, 13206009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1463 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011847000000000_011847009999999', 'LG', 'CU920 VU', 'VU', 11847000000000, 11847009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1464 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357673060000000_357673069999999', 'HTC', '801e', 'Volantis Nexus 9', 357673060000000, 357673069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1465 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010297000000000_010297999999999', 'Siemens', 'A56i', 'A56i', 10297000000000, 10297999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1466 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013900000000000_013900009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13900000000000, 13900009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1467 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013132000000000_013132009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13132000000000, 13132009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1468 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013110000000000_013110009999999', 'Pantech', 'P2020', 'Ease', 13110000000000, 13110009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1469 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357335040000000_357335049999999', 'Samsung', 'SGH-A967', 'SGH-A967', 357335040000000, 357335049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1470 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354903000000000_354903009999999', 'Motorola', 'V180', 'V180', 354903000000000, 354903009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1471 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351461000000000_351461999999999', 'Nokia', '6200', '6200', 351461000000000, 351461999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1472 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010165000000000_010165999999999', 'Nokia', '3595', '3595', 10165000000000, 10165999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1473 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010175000000000_010175999999999', 'Nokia', '6800', '6800', 10175000000000, 10175999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1474 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358292030000000_358292039999999', 'Nokia', '6790', 'Surge', 358292030000000, 358292039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1475 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353093050000000_353093059999999', 'Samsung', 'SGH-i747', 'Galaxy S III', 353093050000000, 353093059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1476 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353030000000000_353030999999999', 'Siemens', 'SX66', 'SX66', 353030000000000, 353030999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1477 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352329080000000_352329089999999', 'Samsung', 'SM-G935A', 'Galaxy S7 Edge', 352329080000000, 352329089999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1478 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355687070000000_355687079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 355687070000000, 355687079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1479 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011630000000000_011630009999999', 'LG', 'CT810', 'CT810 Incite', 11630000000000, 11630009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1480 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010136000000000_010136999999999', 'Nokia', '6590i', '6590i', 10136000000000, 10136999999999, 'Continue', ''
);

-- INSERT QUERY NO: 1481 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359413000000000_359413009999999', 'Motorola', 'KRZR K1', 'KRZR K1', 359413000000000, 359413009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1482 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359307060000000_359307069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359307060000000, 359307069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1483 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013978000000000_013978009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13978000000000, 13978009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1484 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011897000000000_011897009999999', 'Samsung', 'SGH-A167', 'SGH-A167', 11897000000000, 11897009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1485 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359162070000000_359162079999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 359162070000000, 359162079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1486 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356619050000000_356619059999999', 'ASUS', 'K009', 'K009', 356619050000000, 356619059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1487 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355357080000000_355357089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 355357080000000, 355357089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1488 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011809000000000_011809009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11809000000000, 11809009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1489 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356965060000000_356965069999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 356965060000000, 356965069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1490 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358055040000000_358055049999999', 'Samsung', 'SGH-i777', 'Galaxy S II', 358055040000000, 358055049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1491 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357238030000000_357238039999999', 'BlackBerry', 'CURVE 8900', 'Curve 8900', 357238030000000, 357238039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1492 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010460000000000_010460999999999', 'Samsung', 'X427M', 'X427M', 10460000000000, 10460999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1493 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352735010000000_352735019999999', 'Nokia', '6102i', '6102i', 352735010000000, 352735019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1494 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'449263000000000_449263999999999', 'Motorola', 'P7389', 'P7389', 449263000000000, 449263999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1495 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358850020000000_358850029999999', 'HTC', 'ST7377', 'Tilt 2', 358850020000000, 358850029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1496 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356961060000000_356961069999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 356961060000000, 356961069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1497 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013897000000000_013897009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13897000000000, 13897009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1498 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356562080000000_356562089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 356562080000000, 356562089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1499 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010276000000000_010276999999999', 'Sony', 'T637', 'T637', 10276000000000, 10276999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1500 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355256020000000_355256029999999', 'BlackBerry', 'BOLD 9000', 'Bold 9000', 355256020000000, 355256029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1501 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358553070000000_358553079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 358553070000000, 358553079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1502 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'864607020000000_864607029999999', 'ZTE', 'Z830', 'Comel', 864607020000000, 864607029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1503 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353047060000000_353047069999999', 'Nokia', '635', 'Lumia 635', 353047060000000, 353047069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1504 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355347080000000_355347089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 355347080000000, 355347089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1505 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350637000000000_350637999999999', 'Motorola', 'V101', 'V101', 350637000000000, 350637999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1506 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013053000000000_013053009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13053000000000, 13053009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1507 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014071000000000_014071009999999', 'LG', 'D725', 'G3 Vigor', 14071000000000, 14071009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1508 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353844080000000_353844089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 353844080000000, 353844089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1509 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354997000000000_354997009999999', 'Motorola', 'V220', 'V220', 354997000000000, 354997009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1510 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353648040000000_353648049999999', 'Motorola', 'MB860', 'Atrix 4G', 353648040000000, 353648049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1511 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012420000000000_012420009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12420000000000, 12420009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1512 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354073000000000_354073009999999', 'Motorola', 'V220', 'V220', 354073000000000, 354073009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1513 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011934000000000_011934009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11934000000000, 11934009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1514 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'990004297000000_990004299999999', 'HTC', '801n', 'One 801n', 990004297000000, 990004299999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1515 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013524000000000_013524009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13524000000000, 13524009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1516 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351807070000000_351807079999999', 'Samsung', 'SM-G920A', 'Galaxy S6', 351807070000000, 351807079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1517 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010385000000000_010385999999999', 'Siemens', 'C61', 'C61', 10385000000000, 10385999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1518 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014975000000000_014975009999999', 'Netgear', 'MR1100', 'MR1100', 14975000000000, 14975009999999, 'Continue', ''
);

-- INSERT QUERY NO: 1519 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352069000000000_352069009999999', 'Motorola', 'C350g - Euro Model', 'C350g - Euro Model', 352069000000000, 352069009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1520 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355792070000000_355792079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 355792070000000, 355792079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1521 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358001050000000_358001059999999', 'Samsung', 'SM-C105A', 'Galaxy S4 Zoom', 358001050000000, 358001059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1522 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013837000000000_013837009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13837000000000, 13837009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1523 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012968000000000_012968009999999', 'Samsung', 'SGH-A107', 'SGH-A107', 12968000000000, 12968009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1524 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354021040000000_354021049999999', 'Samsung', 'SGH-i987', 'Galaxy Tab', 354021040000000, 354021049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1525 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011335000000000_011335999999999', 'Palm', 'Treo 750', 'Treo 750', 11335000000000, 11335999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1526 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357440020000000_357440029999999', 'Samsung', 'SGH-A657', 'SGH-A657', 357440020000000, 357440029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1527 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359440050000000_359440059999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 359440050000000, 359440059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1528 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356565080000000_356565089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 356565080000000, 356565089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1529 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354798000000000_354798009999999', 'Motorola', 'V3', 'V3', 354798000000000, 354798009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1530 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351609010000000_351609019999999', 'Sony', 'Z520a', 'Z520a', 351609010000000, 351609019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1531 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354018040000000_354018049999999', 'Samsung', 'SGH-A847', 'Rugby II', 354018040000000, 354018049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1532 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354393060000000_354393069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 354393060000000, 354393069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1533 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359320050000000_359320059999999', 'Motorola', 'XT1103', 'Nexus 6', 359320050000000, 359320059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1534 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352021070000000_352021079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 352021070000000, 352021079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1535 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013666000000000_013666009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13666000000000, 13666009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1536 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013257000000000_013257009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 13257000000000, 13257009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1537 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012650000000000_012650009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12650000000000, 12650009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1538 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359296060000000_359296069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359296060000000, 359296069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1539 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356257000000000_356257009999999', 'Motorola', 'V180', 'V180', 356257000000000, 356257009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1540 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352350010000000_352350019999999', 'Sony', 'W810i', 'W810i', 352350010000000, 352350019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1541 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353800050000000_353800059999999', 'Samsung', 'SGH-i317', 'Galaxy Note II', 353800050000000, 353800059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1542 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359168070000000_359168079999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 359168070000000, 359168079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1543 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354454060000000_354454069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 354454060000000, 354454069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1544 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013533000000000_013533009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13533000000000, 13533009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1545 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352797040000000_352797049999999', 'Motorola', 'MB300', 'BackFlip', 352797040000000, 352797049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1546 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354640010000000_354640019999999', 'Sony', 'Z310a', 'Z310a', 354640010000000, 354640019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1547 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351626050000000_351626059999999', 'Motorola', 'MB511', 'FlipOut', 351626050000000, 351626059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1548 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355784070000000_355784079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 355784070000000, 355784079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1549 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359207070000000_359207079999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 359207070000000, 359207079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1550 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359161070000000_359161079999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 359161070000000, 359161079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1551 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358633070000000_358633079999999', 'Apple', 'iPhone SE A1662', 'iPhone SE', 358633070000000, 358633079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1552 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013536000000000_013536009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13536000000000, 13536009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1553 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012172000000000_012172009999999', 'Samsung', 'SGH-A167', 'SGH-A167', 12172000000000, 12172009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1554 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012261000000000_012261009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12261000000000, 12261009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1555 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359100040000000_359100049999999', 'Samsung', 'SGH-i717', 'Galaxy Note', 359100040000000, 359100049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1556 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359306060000000_359306069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359306060000000, 359306069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1557 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353813080000000_353813089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353813080000000, 353813089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1558 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013985000000000_013985009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13985000000000, 13985009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1559 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013263000000000_013263009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13263000000000, 13263009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1560 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013427000000000_013427009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13427000000000, 13427009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1561 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353071060000000_353071069999999', 'Nokia', '520', 'Lumia 520', 353071060000000, 353071069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1562 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353103010000000_353103019999999', 'Samsung', 'SGH-A707', 'SGH-A707', 353103010000000, 353103019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1563 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012752000000000_012752009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12752000000000, 12752009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1564 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356658000000000_356658999999999', 'Nokia', '6682', '6682', 356658000000000, 356658999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1565 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353786050000000_353786059999999', 'ASUS', 'TF600TL', 'Vivo Tab RT', 353786050000000, 353786059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1566 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010089302394230_010089302894239', 'Nokia', '6340i', '6340i', 10089302394230, 10089302894239, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1567 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353826080000000_353826089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 353826080000000, 353826089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1568 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013287000000000_013287009999999', 'LG', 'E970', 'Optimus G', 13287000000000, 13287009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1569 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'860755030000000_860755039999999', 'ZTE', 'K88', 'K88', 860755030000000, 860755039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1570 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010217000000000_010217999999999', 'Motorola', 'T720', 'T720', 10217000000000, 10217999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1571 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011191000000000_011191999999999', 'Nokia', '2610', '2610', 11191000000000, 11191999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1572 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351626000000000_351626009999999', 'Samsung', 'SGH-V200C', 'SGH-V200C', 351626000000000, 351626009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1573 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356553040000000_356553049999999', 'BlackBerry', '9800', 'Torch', 356553040000000, 356553049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1574 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010144000000000_010144999999999', 'Nokia', '6340i', '6340i', 10144000000000, 10144999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1575 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351505030000000_351505039999999', 'Motorola', 'RAZR 06 V3', 'RAZR 06 V3', 351505030000000, 351505039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1576 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350030000000000_350030999999999', 'Motorola', 'Intermec 700', 'Intermec 700', 350030000000000, 350030999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1577 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012028000000000_012028009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12028000000000, 12028009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1578 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352302000000000_352302009999999', 'Motorola', 'C350g - Euro Model', 'C350g - Euro Model', 352302000000000, 352302009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1579 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'863496010000000_863496019999999', 'Huawei', 'U8665', 'Fusion 2', 863496010000000, 863496019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1580 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355308080000000_355308089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355308080000000, 355308089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1581 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010073000000000_010073999999999', 'Motorola', 'V.100', 'V.100', 10073000000000, 10073999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1582 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'449176000000000_449176999999999', 'Motorola', 'P7389', 'P7389', 449176000000000, 449176999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1583 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010226000000000_010226999999999', 'BlackBerry', '6280', '6280', 10226000000000, 10226999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1584 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013203000000000_013203009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13203000000000, 13203009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1585 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353110030000000_353110039999999', 'Sony', 'C905A', 'C905A', 353110030000000, 353110039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1586 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353509040000000_353509049999999', 'Samsung', 'SGH-A877', 'Impression', 353509040000000, 353509049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1587 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359606010000000_359606019999999', 'Motorola', 'IZAR V3xx', 'MOTORAZR V3xx', 359606010000000, 359606019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1588 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012945000000000_012945009999999', 'Pantech', 'P6020', 'Swift', 12945000000000, 12945009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1589 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353820080000000_353820089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353820080000000, 353820089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1590 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357592020000000_357592029999999', 'Samsung', 'SGH-A837', 'Rugby', 357592020000000, 357592029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1591 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012252000000000_012252009999999', 'Pantech', 'P2020', 'Ease', 12252000000000, 12252009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1592 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012754000000000_012754009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12754000000000, 12754009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1593 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357073080000000_357073089999999', 'Samsung', 'SM-J120A', 'Samsung Galaxy Express 3', 357073080000000, 357073089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1594 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359318050000000_359318059999999', 'Motorola', 'XT1097', 'Motorola X', 359318050000000, 359318059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1595 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357457000000000_357457009999999', 'Samsung', 'D357', 'D357', 357457000000000, 357457009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1596 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351862040000000_351862049999999', 'Samsung', 'SGH-A687', 'Strive', 351862040000000, 351862049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1597 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359302060000000_359302069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359302060000000, 359302069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1598 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356239050000000_356239059999999', 'ASUS', 'ME302KL', 'Memo Pad FHD 10', 356239050000000, 356239059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1599 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354438010000000_354438019999999', 'Motorola', 'MC3574', 'MC3574', 354438010000000, 354438019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1600 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355375080000000_355375089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7', 355375080000000, 355375089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1601 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012268000000000_012268009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12268000000000, 12268009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1602 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354446060000000_354446069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354446060000000, 354446069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1603 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012617000000000_012617009999999', 'Pantech', 'P7040', 'Link', 12617000000000, 12617009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1604 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358345050000000_358345059999999', 'Nokia', '2520', '2520', 358345050000000, 358345059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1605 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013013000000000_013013009999999', 'Samsung', 'SGH-A107', 'SGH-A107', 13013000000000, 13013009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1606 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013537000000000_013537009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13537000000000, 13537009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1607 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355435070000000_355435079999999', 'Apple', 'iPhone SE A1662', 'iPhone SE', 355435070000000, 355435079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1608 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350766000000000_350766999999999', 'Siemens', 'S46', 'S46', 350766000000000, 350766999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1609 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013130000000000_013130009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13130000000000, 13130009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1610 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013595000000000_013595009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13595000000000, 13595009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1611 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358718040000000_358718049999999', 'BlackBerry', 'P150-32LT2', 'P150-32LT2', 358718040000000, 358718049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1612 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013905000000000_013905009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13905000000000, 13905009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1613 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359174070000000_359174079999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7 Plus A1661', 359174070000000, 359174079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1614 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011397000000000_011397999999999', 'Samsung', 'SGH-A117', 'SGH-A117', 11397000000000, 11397999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1615 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353817080000000_353817089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353817080000000, 353817089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1616 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013428000000000_013428009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13428000000000, 13428009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1617 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355431050000000_355431059999999', 'Samsung', 'SGH-i747', 'Galaxy S III', 355431050000000, 355431059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1618 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352335016000000_352335999999999', 'Sony', 'W300i', 'W300i', 352335016000000, 352335999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1619 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357090060000000_357090069999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 357090060000000, 357090069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1620 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352017070000000_352017079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 352017070000000, 352017079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1621 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011614000000000_011614009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11614000000000, 11614009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1622 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355330050000000_355330059999999', 'HTC', 'PJ83100', 'One X', 355330050000000, 355330059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1623 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014485000000000_014485009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 14485000000000, 14485009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1624 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358158010000000_358158019999999', 'Samsung', 'SGH-A517', 'SGH-A517', 358158010000000, 358158019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1625 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013969000000000_013969009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13969000000000, 13969009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1626 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355326080000000_355326089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355326080000000, 355326089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1627 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013976000000000_013976009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13976000000000, 13976009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1628 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359318060000000_359318069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 359318060000000, 359318069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1629 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'863580010000000_863580019999999', 'Lenovo', 'A2107A', 'IdeaTab A2107', 863580010000000, 863580019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1630 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011916000000000_011916009999999', 'Pantech', 'C530', 'Slate', 11916000000000, 11916009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1631 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013883000000000_013883009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13883000000000, 13883009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1632 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010121000000000_010121999999999', 'Motorola', 'C331g', 'C331g', 10121000000000, 10121999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1633 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356045000000000_356045009999999', 'Motorola', 'V551', 'V551', 356045000000000, 356045009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1634 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354691060000000_354691069999999', 'Samsung', 'SM-G900A', 'Galaxy S5', 354691060000000, 354691069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1635 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012762000000000_012762009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12762000000000, 12762009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1636 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350003000000000_350003999999999', 'Nokia', '8890', '8890', 350003000000000, 350003999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1637 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350077000000000_350077999999999', 'Siemens', 'S40', 'S40', 350077000000000, 350077999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1638 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353793080000000_353793089999999', 'Apple', 'iPhone SE A1662', 'iPhone SE A1662', 353793080000000, 353793089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1639 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359409000000000_359409999999999', 'Motorola', 'V557', 'V557', 359409000000000, 359409999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1640 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013280000000000_013280009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13280000000000, 13280009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1641 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357942060000000_357942069999999', 'Samsung', 'SM-G925A', 'Galaxy S6 Edge', 357942060000000, 357942069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1642 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356560080000000_356560089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 356560080000000, 356560089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1643 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014328006000000_014328009999999', 'ASUS', 'ME375CL', 'Memo Pad 7', 14328006000000, 14328009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1644 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355373080000000_355373089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7', 355373080000000, 355373089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1645 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013282000000000_013282009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13282000000000, 13282009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1646 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354601070000000_354601079999999', 'Samsung', 'SM-R730A', 'Gear S2', 354601070000000, 354601079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1647 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355562010000000_355562019999999', 'Motorola', 'IZAR att', 'IZAR att', 355562010000000, 355562019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1648 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355997050000000_355997059999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 355997050000000, 355997059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1649 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358507000000000_358507009999999', 'Palm', 'Treo 650', 'Treo 650', 358507000000000, 358507009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1650 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352332080000000_352332089999999', 'Samsung', 'SM-G891A', 'Galaxy S7 Edge', 352332080000000, 352332089999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1651 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355333080000000_355333089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355333080000000, 355333089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1652 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010201000000000_010201999999999', 'Siemens', 'SL56', 'SL56', 10201000000000, 10201999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1653 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011982000000000_011982009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 11982000000000, 11982009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1654 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013881000000000_013881009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13881000000000, 13881009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1655 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010564000000000_010564999999999', 'LG', 'C1300i', 'C1300i', 10564000000000, 10564999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1656 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351863040000000_351863049999999', 'Samsung', 'SGH-i897', 'Captivate', 351863040000000, 351863049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1657 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011932000000000_011932009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11932000000000, 11932009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1658 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351633000000000_351633009999999', 'Siemens', 'SL55', 'SL55', 351633000000000, 351633009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1659 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013175000000000_013175009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13175000000000, 13175009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1660 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359324000000000_359324009999999', 'Samsung', 'SGH-A517', 'SGH-A517', 359324000000000, 359324009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1661 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355724070000000_355724079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 355724070000000, 355724079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1662 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352054000000000_352054009999999', 'Motorola', 'C350g - Euro Model', 'C350g - Euro Model', 352054000000000, 352054009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1663 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355723070000000_355723079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 355723070000000, 355723079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1664 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010127000000000_010127999999999', 'Siemens', 'A56', 'A56', 10127000000000, 10127999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1665 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010498000000000_010498999999999', 'Nokia', '1100', '1100', 10498000000000, 10498999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1666 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010188000000000_010188999999999', 'Motorola', 'C330 EOTD', 'C330 EOTD', 10188000000000, 10188999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1667 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354331030000000_354331039999999', 'Samsung', 'SGH-A177', 'SGH-A177', 354331030000000, 354331039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1668 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010256000000000_010256009999999', 'Sony', 'GC82', 'GC82', 10256000000000, 10256009999999, 'Continue', ''
);

-- INSERT QUERY NO: 1669 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012263000000000_012263009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12263000000000, 12263009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1670 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010283000000000_010283009999999', 'Nokia', '3595', '3595', 10283000000000, 10283009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1671 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352926030000000_352926039999999', 'Garmin', 'G60', 'G60', 352926030000000, 352926039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1672 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014490000000000_014490009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 14490000000000, 14490009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1673 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011225000000000_011225999999999', 'LG', 'CU405', 'CU405', 11225000000000, 11225999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1674 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355722070000000_355722079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 355722070000000, 355722079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1675 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013264000000000 _013264009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13264000000000, 13264009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1676 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012339000000000_012339009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12339000000000, 12339009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1677 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012760000000000_012760009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12760000000000, 12760009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1678 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353479000000000_353479999999999', 'Samsung', 'SGH-C417', 'SGH-C417', 353479000000000, 353479999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1679 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010146000000000_010146999999999', 'Nokia', '3100', '3100', 10146000000000, 10146999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1680 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354493040000000_354493049999999', 'Samsung', 'SGH-A817', 'Solstice II', 354493040000000, 354493049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1681 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010196000000000_010196999999999', 'Samsung', 'SGH-S300M', 'SGH-S300M', 10196000000000, 10196999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1682 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350652000000000_350652999999999', 'Motorola', 'A388', 'A388', 350652000000000, 350652999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1683 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'861384030000000_861384039999999', 'Huawei', 'H1611', 'H1611', 861384030000000, 861384039999999, 'Continue', ''
);

-- INSERT QUERY NO: 1684 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353348070000000_353348079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353348070000000, 353348079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1685 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354891060000000_354891069999999', 'Samsung', 'SM-G900A', 'Galaxy S5', 354891060000000, 354891069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1686 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351633070000000_351633079999999', 'LG', 'V410', 'G Pad 7.0', 351633070000000, 351633079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1687 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012213000000000_012213009999999', 'Dell', 'Venue', 'Dell Venue', 12213000000000, 12213009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1688 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013835000000000_013835009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13835000000000, 13835009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1689 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013041000000000_013041009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13041000000000, 13041009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1690 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353256070000000_353256079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353256070000000, 353256079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1691 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013209000000000_013209009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13209000000000, 13209009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1692 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352314040000000_352314049999999', 'Motorola', 'MC959B', 'MC959B', 352314040000000, 352314049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1693 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013853000000000_013853009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13853000000000, 13853009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1694 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352904060000000_352904069999999', 'Samsung', 'SM-B780A', 'Rugby 4', 352904060000000, 352904069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1695 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013047000000000_013047009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13047000000000, 13047009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1696 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357376020000000_357376029999999', 'Samsung', 'SGH-A237', 'SGH-A237', 357376020000000, 357376029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1697 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012164000000000_012164009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12164000000000, 12164009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1698 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357112040000000_357112049999999', 'Samsung', 'SGH-i927', 'Captivate Glide', 357112040000000, 357112049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1699 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013591000000000_013591009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13591000000000, 13591009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1700 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013994000000000_013994009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13994000000000, 13994009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1701 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013333000000000_013333009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13333000000000, 13333009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1702 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351818050000000_351818059999999', 'Samsung', 'SGH-i717', 'Galaxy Note', 351818050000000, 351818059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1703 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358177040000000_358177049999999', 'BlackBerry', '9300', 'Curve', 358177040000000, 358177049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1704 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355312080000000_355312089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355312080000000, 355312089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1705 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356884040000000_356884049999999', 'Samsung', 'SGH-A687', 'Strive', 356884040000000, 356884049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1706 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353302070000000_353302079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353302070000000, 353302079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1707 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352249060000000_352249069999999', 'HTC', 'PN07120', 'ONE', 352249060000000, 352249069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1708 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358356060000000_358356069999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 358356060000000, 358356069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1709 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'866011020000000_866011029999999', 'ZTE', 'Z222', 'Z222', 866011020000000, 866011029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1710 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014391000000000_014391009999999', 'Kyocera', 'E6790', 'DuraForce XD', 14391000000000, 14391009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1711 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'001000138000000_001000138999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 1000138000000, 1000138999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1712 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014487000000000_014487009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 14487000000000, 14487009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1713 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355570000000000_355570999999999', 'Motorola', 'Z9', 'Z9', 355570000000000, 355570999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1714 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351714080300000_351714089999999', 'Samsung', 'SM-G891A', 'Galaxy S7 Active', 351714080300000, 351714089999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1715 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351102000000000_351102999999999', 'Nokia', '3650', '3650', 351102000000000, 351102999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1716 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352487050000000_352487059999999', 'Samsung', 'SGH-i667', 'Focus 2', 352487050000000, 352487059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1717 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354153040000000_354153049999999', 'Samsung', 'XE700T1A', 'XE700T1A', 354153040000000, 354153049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1718 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355434070000000_355434079999999', 'Apple', 'iPhone SE A1662', 'iPhone SE', 355434070000000, 355434079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1719 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357272000000000_357272009999999', 'Samsung', 'X497', 'X497', 357272000000000, 357272009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1720 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012264000000000_012264009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12264000000000, 12264009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1721 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010302000000000_010302999999999', 'Siemens', 'A56i', 'A56i', 10302000000000, 10302999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1722 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011197000000000_011197999999999', 'Pantech', 'C150', 'C150', 11197000000000, 11197999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1723 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010180000000000_010180999999999', 'Nokia', '3590', '3590', 10180000000000, 10180999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1724 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012031000000000_012031009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12031000000000, 12031009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1725 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356101000000000_356101009999999', 'Motorola', 'MC7004', 'MC7004', 356101000000000, 356101009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1726 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012567000000000_012567009999999', 'Pantech', 'P6010', 'Pursuit II', 12567000000000, 12567009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1727 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012196000000000_012196009999999', 'LG', 'GS390', 'Prime', 12196000000000, 12196009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1728 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354427000000000_354427009999999', 'Palm', 'Treo 650', 'Treo 650', 354427000000000, 354427009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1729 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013749000000000_013749009999999', 'Pantech', 'P2030', 'Breeze III', 13749000000000, 13749009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1730 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356552040000000_356552049999999', 'BlackBerry', '9800', 'Torch', 356552040000000, 356552049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1731 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011896000000000_011896009999999', 'LG', 'CT815', 'CT815 Incite', 11896000000000, 11896009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1732 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011712000000000_011712009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11712000000000, 11712009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1733 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013662000000000_013662009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13662000000000, 13662009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1734 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359026020000000_359026029999999', 'HTC', 'ST6356', 'PURE', 359026020000000, 359026029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1735 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012604000000000_012604009999999', 'HP', 'P160UNA', 'Veer 4G', 12604000000000, 12604009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1736 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355798070000000_355798079999999', 'Apple', 'iPhone SE A1662', 'iPhone SE', 355798070000000, 355798079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1737 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359432030000000_359432039999999', 'BlackBerry', '8110 Pearl', 'Pearl', 359432030000000, 359432039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1738 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013836000000000_013836009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13836000000000, 13836009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1739 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353808080000000_353808089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353808080000000, 353808089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1740 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355789070000000_355789079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 355789070000000, 355789079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1741 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358442020000000_358442029999999', 'Samsung', 'SGH-A767', 'Propel', 358442020000000, 358442029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1742 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356419070000000_356419079999999', 'Samsung', 'SM-J120AZ', 'SM-J120AZ', 356419070000000, 356419079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1743 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359232060000000_359232069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359232060000000, 359232069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1744 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014483000000000_014483009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 14483000000000, 14483009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1745 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353155000200000_353155009999999', 'Motorola', 'MC9002', 'MC9002', 353155000200000, 353155009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1746 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012938000000000_012938009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 12938000000000, 12938009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1747 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'449242000000000_449242999999999', 'Motorola', 'P7689-T250', 'P7689-T250', 449242000000000, 449242999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1748 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357413000000000_357413009999999', 'HP', 'iPAQ 6515', 'iPAQ 6515', 357413000000000, 357413009999999, 'Continue', ''
);

-- INSERT QUERY NO: 1749 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355986080000000_355986089999999', 'Samsung', 'SM-G955U', 'Samsung Galaxy S8', 355986080000000, 355986089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1750 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011309000000000_011309999999999', 'Motorola', 'C168i', 'C168i', 11309000000000, 11309999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1751 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012423000000000_012423009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12423000000000, 12423009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1752 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011236000000000_011236009999999', 'Pantech', 'C-120', 'C120', 11236000000000, 11236009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1753 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013073000000000_013073009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13073000000000, 13073009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1754 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'866599020000000_866599029999999', 'ZTE', 'Z955L', 'Z955L', 866599020000000, 866599029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1755 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359614020000000_359614029999999', 'BlackBerry', 'BOLD 9000', 'Bold 9000', 359614020000000, 359614029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1756 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013259000000000_013259009999999', 'Sony', 'LT30at', 'Experia TL', 13259000000000, 13259009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1757 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013668000000000_013668009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13668000000000, 13668009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1758 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355376080000000_355376089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7', 355376080000000, 355376089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1759 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355804080000000_355804089999999', 'Apple', 'iPad 9.7 A1823', 'iPad 9.7', 355804080000000, 355804089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1760 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010834000000000_010834999999999', 'LG', 'C1500', 'C1500', 10834000000000, 10834999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1761 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358733020000000_358733029999999', 'Motorola', 'MC9596', 'MC9596', 358733020000000, 358733029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1762 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352018070000000_352018079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 352018070000000, 352018079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1763 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359152070000000_359152079999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 359152070000000, 359152079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1764 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353845080000000_353845089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 353845080000000, 353845089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1765 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013030000000000_013030009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13030000000000, 13030009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1766 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013993000000000_013993009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13993000000000, 13993009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1767 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010322000000000_010322999999999', 'Nokia', '3595', '3595', 10322000000000, 10322999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1768 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358408030000000_358408039999999', 'Huawei', 'U8665', 'Fusion 2', 358408030000000, 358408039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1769 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010046000000000_010046999999999', 'Motorola', 'V3682', 'V3682', 10046000000000, 10046999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1770 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354843050000000_354843059999999', 'Samsung', 'SGH-i467', 'Galaxy Note 8.0', 354843050000000, 354843059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1771 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355071000000000_355071009999999', 'Motorola', 'V3i', 'V3i', 355071000000000, 355071009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1772 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355604000000000_355604009999999', 'Motorola', 'V220', 'V220', 355604000000000, 355604009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1773 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'868661020000000_868661029999999', 'ZTE', 'Z962BL', 'PDA Android LTE', 868661020000000, 868661029999999, 'Continue', ''
);

-- INSERT QUERY NO: 1774 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359163070000000_359163079999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 359163070000000, 359163079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1775 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354474070000000_354474079999999', 'Samsung', 'SM-G928A', 'Galaxy S6 Edge Plus', 354474070000000, 354474079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1776 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355317080000000_355317089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355317080000000, 355317089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1777 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353324070000000_353324079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353324070000000, 353324079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1778 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357417070000000_357417079999999', 'Samsung', 'SM-J320A', 'SM-J320A', 357417070000000, 357417079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1779 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013278000000000_013278009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13278000000000, 13278009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1780 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011245000000000_011245000010493', 'Apple', 'iPhone', 'iPhone', 11245000000000, 11245000010493, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1781 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353152050000000_353152059999999', 'Samsung', 'SGH-i747', 'Galaxy S III', 353152050000000, 353152059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1782 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354392060000000_354392069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 354392060000000, 354392069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1783 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355359080000000_355359089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus', 355359080000000, 355359089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1784 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357335060000000_357335069999999', 'Motorola', 'TC55AH-xJ', 'TC55AH-xJ', 357335060000000, 357335069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1785 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012849000000000_012849009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12849000000000, 12849009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1786 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011679000000000_011679009999999', 'LG', 'CU720', 'Shine', 11679000000000, 11679009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1787 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359344050000000_359344059999999', 'ASUS', 'T00D', 'Asus PadFone X', 359344050000000, 359344059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1788 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354610070000000_354610079999999', 'Samsung', 'SM-T677A', 'Galaxy View', 354610070000000, 354610079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1789 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012269000000000_012269009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12269000000000, 12269009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1790 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352683000000000_352683009999999', 'Motorola', 'V400', 'V400', 352683000000000, 352683009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1791 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353155000000000_353155000199999', 'Motorola', 'MC9062', 'MC9062', 353155000000000, 353155000199999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1792 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351530010000000_351530019999999', 'Motorola', 'RAZR 05 V3', 'RAZR 05 V3', 351530010000000, 351530019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1793 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013172000000000_013172009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13172000000000, 13172009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1794 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011709000000000_011709009999999', 'Motorola', 'C168i', 'C168i', 11709000000000, 11709009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1795 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357190040000000_357190049999999', 'Acer', 'A501-10S16u', 'Iconia Tab', 357190040000000, 357190049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1796 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358372060000000_358372069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 358372060000000, 358372069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1797 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012958000000000_012958009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12958000000000, 12958009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1798 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352553060000000_352553069999999', 'Samsung', 'SM-T537A', 'Galaxy Tab 4', 352553060000000, 352553069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1799 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352307050000000_352307059999999', 'Samsung', 'SGH-A157', 'SGH-A157', 352307050000000, 352307059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1800 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010156000000000_010156999999999', 'Siemens', 'S56', 'S56', 10156000000000, 10156999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1801 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357494060000000_357494069999999', 'LG', 'H443', 'Escape 2', 357494060000000, 357494069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1802 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359762060000000_359762069999999', 'Microsoft Mobile', '640XL AT&T', 'Lumia 640XL AT&T', 359762060000000, 359762069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1803 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012761000000000_012761009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12761000000000, 12761009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1804 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010089300194230_010089301294229', 'Nokia', '6340i', '6340i', 10089300194230, 10089301294229, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1805 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354391060000000_354391069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 354391060000000, 354391069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1806 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013990000000000_013990009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13990000000000, 13990009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1807 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'980067000000000_980067009999999', 'Motorola', 'MC659B', 'MC659B', 980067000000000, 980067009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1808 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353919060000000_353919069999999', 'Samsung', 'SM-G900A', 'Galaxy S5', 353919060000000, 353919069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1809 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'001000148000000_001000148999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7 Plus A1661', 1000148000000, 1000148999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1810 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010189000000000_010189999999999', 'Motorola', 'C330 EOTD', 'C330 EOTD', 10189000000000, 10189999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1811 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010038000000000_010038999999999', 'Motorola', 'G520', 'G520', 10038000000000, 10038999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1812 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355321080000000_355321089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355321080000000, 355321089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1813 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357485060000000_357485069999999', 'LG', 'L21G', 'L21G', 357485060000000, 357485069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1814 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354411060000000_354411069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354411060000000, 354411069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1815 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357712080000000_357712089999999', 'LG', 'L81AL', 'L81AL', 357712080000000, 357712089999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1816 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355836080000000_355836089999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7', 355836080000000, 355836089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1817 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359206070000000_359206079999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 359206070000000, 359206079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1818 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357814040000000_357814049999999', 'HTC', 'PD98120', 'Inspire', 357814040000000, 357814049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1819 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355833080000000_355833089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7', 355833080000000, 355833089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1820 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010235000000000_010235009999999', 'Nokia', '6340i', '6340i', 10235000000000, 10235009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1821 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358600070000000_358600079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 358600070000000, 358600079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1822 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013890000000000_013890009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13890000000000, 13890009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1823 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012941000000000_012941009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 12941000000000, 12941009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1824 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013424000000000_013424009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13424000000000, 13424009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1825 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356259000000000_356259009999999', 'Motorola', 'V551', 'V551', 356259000000000, 356259009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1826 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012194000000000_012194009999999', 'Samsung', 'SGH-A107', 'SGH-A107', 12194000000000, 12194009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1827 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011632000000000_011632009999999', 'LG', 'CF750', 'CF750', 11632000000000, 11632009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1828 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355719070000000_355719079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 355719070000000, 355719079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1829 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012542000000000_012542009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12542000000000, 12542009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1830 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355467020000000_355467029999999', 'Samsung', 'SGH-A777', 'SGH-A777', 355467020000000, 355467029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1831 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010208000000000_010208999999999', 'Sony', 'T226', 'T226', 10208000000000, 10208999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1832 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353822080000000_353822089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 353822080000000, 353822089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1833 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351624000000000_351624009999999', 'Samsung', 'SGH-V200', 'SGH-V200', 351624000000000, 351624009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1834 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358184000000000_358184009999999', 'HP', 'iPAQ 6510', 'iPAQ 6510', 358184000000000, 358184009999999, 'Continue', ''
);

-- INSERT QUERY NO: 1835 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355790070000000_355790079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 355790070000000, 355790079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1836 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010488000000000_010488999999999', 'Sony', 'Z500a', 'Z500a', 10488000000000, 10488999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1837 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356453040000000_356453049999999', 'Motorola', 'MB886', 'ATRIX HD', 356453040000000, 356453049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1838 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011221000000000_011221999999999', 'Samsung', 'SGH-A117', 'SGH-A117', 11221000000000, 11221999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1839 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012148000000000_012148009999999', 'LG', 'GT365', 'NEON', 12148000000000, 12148009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1840 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359356060000000_359356069999999', 'Samsung', 'SM-G890A', 'Galaxy S6 Active', 359356060000000, 359356069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1841 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011271000000000_011271999999999', 'Sony', 'W580i', 'W580i', 11271000000000, 11271999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1842 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011249000000000_011249999999999', 'Samsung', 'SGH-A117', 'SGH-A117', 11249000000000, 11249999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1843 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359721050000000_359721059999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 359721050000000, 359721059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1844 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353706050000000_353706059999999', 'HTC', 'PJ83100', 'One X', 353706050000000, 353706059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1845 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356851000000000_356851009999999', 'Motorola', 'V540', 'V540', 356851000000000, 356851009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1846 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013660000000000_013660009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13660000000000, 13660009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1847 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013043000000000_013043009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13043000000000, 13043009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1848 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356989060000000_356989069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 356989060000000, 356989069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1849 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353602010000000_353602019999999', 'Motorola', 'V3', 'V3', 353602010000000, 353602019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1850 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013200000000000_013200009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13200000000000, 13200009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1851 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010118000000000_010118999999999', 'Nokia', '3590', '3590', 10118000000000, 10118999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1852 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355345080000000_355345089999999', 'Apple', 'iPhone 7 Plus A1784', 'IPHONE 7 PLUS A1784', 355345080000000, 355345089999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1853 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355788070000000_355788079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 355788070000000, 355788079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1854 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355301080000000_355301089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 355301080000000, 355301089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1855 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356377050000000_356377059999999', 'HTC', 'PN07120', 'ONE', 356377050000000, 356377059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1856 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358002000000000_358002009999999', 'Motorola', 'V3', 'V3', 358002000000000, 358002009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1857 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010366000000000_010366999999999', 'Samsung', 'E317', 'E317', 10366000000000, 10366999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1858 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012649000000000_012649009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12649000000000, 12649009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1859 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012182000000000_012182009999999', 'Pantech', 'P9020', 'Pursuit', 12182000000000, 12182009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1860 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013895000000000_013895009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13895000000000, 13895009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1861 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353411060000000_353411069999999', 'Samsung', 'SM-G900A', 'Galaxy S5', 353411060000000, 353411069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1862 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353825080000000_353825089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 353825080000000, 353825089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1863 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013442000000000_013442009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13442000000000, 13442009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1864 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359218070000000_359218079999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 359218070000000, 359218079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1865 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010495000000000_010495999999999', 'Nokia', '6010', '6010', 10495000000000, 10495999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1866 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352518080000000_352518089999999', 'Samsung', 'SM-R765A', 'Wearable Watch LTE', 352518080000000, 352518089999999, 'Fallout', ''
);

-- INSERT QUERY NO: 1867 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'868567020000000_868567029999999', 'ZTE', 'Z432', 'Z432', 868567020000000, 868567029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1868 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012155000000000_012155009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12155000000000, 12155009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1869 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358579050000000_358579059999999', 'Samsung', 'SM-N900A', 'Galaxy Note 3', 358579050000000, 358579059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1870 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354449060000000_354449069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354449060000000, 354449069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1871 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354957070000000_354957079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 354957070000000, 354957079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1872 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354651030000000_354651039999999', 'Samsung', 'SGH-A237', 'SGH-A237', 354651030000000, 354651039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1873 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358474050000000_358474059999999', 'BlackBerry', 'SQC100-2', 'Classic', 358474050000000, 358474059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1874 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013439000000000_013439009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13439000000000, 13439009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1875 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013908000000000_013908009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13908000000000, 13908009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1876 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356361010000000_356361019999999', 'Samsung', 'SGH-A437', 'SGH-A437', 356361010000000, 356361019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1877 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358389000000000_358389009999999', 'Nokia', '6102i', '6102i', 358389000000000, 358389009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1878 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011592000000000_011592009999999', 'Pantech', 'C820', 'Pantech Matrix Pro', 11592000000000, 11592009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1879 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353338070000000_353338079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353338070000000, 353338079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1880 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013525000000000_013525009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13525000000000, 13525009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1881 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354837010000000_354837019999999', 'Nokia', '6085', '6085', 354837010000000, 354837019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1882 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353810080000000_353810089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353810080000000, 353810089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1883 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355443060000000_355443069999999', 'Samsung', 'SM-R750A', 'Gear S', 355443060000000, 355443069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1884 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010940000000000_010940999999999', 'Motorola', 'M900BP', 'M900BP', 10940000000000, 10940999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1885 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352441040000000_352441049999999', 'HTC', 'F5151', 'Freestyle', 352441040000000, 352441049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1886 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355829080000000_355829089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7', 355829080000000, 355829089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1887 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013834000000000_013834009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13834000000000, 13834009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1888 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011941000000000_011941009999999', 'Nokia', '2600', '2600', 11941000000000, 11941009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1889 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013008000000000_013008009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13008000000000, 13008009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1890 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354589040000000_354589049999999', 'Samsung', 'SGH-A667', 'Evergreen', 354589040000000, 354589049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1891 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356565050000000_356565059999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 356565050000000, 356565059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1892 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359305060000000_359305069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359305060000000, 359305069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1893 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013434000000000_013434009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13434000000000, 13434009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1894 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353811080000000_353811089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353811080000000, 353811089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1895 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010640000000000_010640099999999', 'Motorola', 'M900BP', 'M900BP', 10640000000000, 10640099999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1896 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010186000600000_010186999999999', 'Motorola', 'EPAD', 'EPAD', 10186000600000, 10186999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1897 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013882000000000_013882009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13882000000000, 13882009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1898 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355502070000000_355502079999999', 'Samsung', 'SM-G930A', 'Galaxy S7', 355502070000000, 355502079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1899 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351537060000000_351537069999999', 'Samsung', 'SGH-i747', 'Galaxy S III', 351537060000000, 351537069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1900 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353490040000000_353490049999999', 'BlackBerry', '9800', 'Torch', 353490040000000, 353490049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1901 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357084050000000_357084059999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 357084050000000, 357084059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1902 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012421000000000_012421009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12421000000000, 12421009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1903 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011741000000000_011741009999999', 'Nokia', '2680', '2680', 11741000000000, 11741009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1904 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355992010000000_355992019999999', 'Samsung', 'SGH-A737', 'SGH-A737', 355992010000000, 355992019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1905 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011667000000000_011667009999999', 'Nokia', '2600', '2600', 11667000000000, 11667009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1906 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354209070000000_354209079999999', 'Samsung', 'SM-R750A', 'Gear S', 354209070000000, 354209079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1907 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012847000000000_012847009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12847000000000, 12847009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1908 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355378000000000_355378009999999', 'Nokia', '9300', '9300', 355378000000000, 355378009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1909 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010473000000000_010473999999999', 'Siemens', 'S66', 'S66', 10473000000000, 10473999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1910 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356555080000000_356555089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 356555080000000, 356555089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1911 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359178070000000_359178079999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7 Plus A1661', 359178070000000, 359178079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1912 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355072060000000_355072069999999', 'Samsung', 'SM-N915A', 'Galaxy Note Edge', 355072060000000, 355072069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1913 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012599000000000_012599009999999', 'Samsung', 'SGH-A107', 'SGH-A107', 12599000000000, 12599009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1914 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357756080000000_357756089999999', 'Samsung', 'SM-G955U', 'Samsung Galaxy S8 Plus', 357756080000000, 357756089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1915 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359886010000000_359886019999999', 'Sony', 'W580i', 'W580i', 359886010000000, 359886019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1916 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355327080000000_355327089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355327080000000, 355327089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1917 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358557070000000_358557079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 358557070000000, 358557079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1918 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010801000000000_010801999999999', 'LG', 'CG300', 'CG300', 10801000000000, 10801999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1919 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013967000000000_013967009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13967000000000, 13967009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1920 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012568000000000_012568009999999', 'LG', 'P505', 'P505', 12568000000000, 12568009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1921 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355329080000000_355329089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355329080000000, 355329089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1922 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358305010000000_358305019999999', 'Motorola', 'Q9', 'MOTO Q', 358305010000000, 358305019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1923 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013970000000000_013970009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13970000000000, 13970009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1924 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355791070000000_355791079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 355791070000000, 355791079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1925 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355352080000000_355352089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 355352080000000, 355352089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1926 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359181010000000_359181019999999', 'BlackBerry', '8120 Pearl', 'Pearl 8120', 359181010000000, 359181019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1927 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359160050000000_359160059999999', 'Samsung', 'SGH-i527', 'Galaxy Mega', 359160050000000, 359160059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1928 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013198000000000_013198009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13198000000000, 13198009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1929 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'860369020000000_860369029999999', 'ZTE', 'Z998', 'Z998', 860369020000000, 860369029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1930 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013838000000000_013838009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13838000000000, 13838009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1931 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013845000000000_013845009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13845000000000, 13845009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1932 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354094020000000_354094029999999', 'Samsung', 'SGH-A737', 'SGH-A737', 354094020000000, 354094029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1933 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011626000000000_011626009999999', 'LG', 'CP150', 'CP150', 11626000000000, 11626009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1934 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355341080000000_355341089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355341080000000, 355341089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1935 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355006050000000_355006059999999', 'Motorola', 'XT1058', 'XT1058', 355006050000000, 355006059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1936 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013987000000000_013987009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13987000000000, 13987009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1937 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011935000000000_011935009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11935000000000, 11935009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1938 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353783000000000_353783999999999', 'Nokia', '3120', '3120', 353783000000000, 353783999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1939 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359823010000000_359823019999999', 'Nokia', '6555i', '6555i', 359823010000000, 359823019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1940 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359176000000000_359176009999999', 'Motorola', 'V190', 'V190', 359176000000000, 359176009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1941 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012786000000000_012786009999999', 'LG', 'P930', 'Nitro HD', 12786000000000, 12786009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1942 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352020070000000_352020079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 352020070000000, 352020079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1943 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011500000000000_011500999999999', 'Samsung', 'SGH-A137', 'SGH-A137', 11500000000000, 11500999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1944 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352013050000000_352013059999999', 'Samsung', 'SGH-i717', 'Galaxy Note', 352013050000000, 352013059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1945 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359078030000000_359078039999999', 'ZTE', 'F160', 'F160', 359078030000000, 359078039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1946 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012993000000000_012993009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12993000000000, 12993009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1947 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010124000000000_010124999999999', 'Sony', 'T62U', 'T62U', 10124000000000, 10124999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1948 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010089301294230_010089302394229', 'Nokia', '6340i', '6340i', 10089301294230, 10089302394229, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1949 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353897050000000_353897059999999', 'HTC', 'PM23300', 'PM23300', 353897050000000, 353897059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1950 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352132070000000_352132079999999', 'Samsung', 'SM-G900A', 'Galaxy S5', 352132070000000, 352132079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1951 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352794010000000_352794019999999', 'Samsung', 'SGH-i607', 'BlackJack', 352794010000000, 352794019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1952 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359818000000000_359818999999999', 'Motorola', 'L2', 'L2', 359818000000000, 359818999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1953 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359420030000000_359420039999999', 'Sony', 'x10a', 'Xperia X10', 359420030000000, 359420039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1954 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355610020000000_355610029999999', 'Samsung', 'SGH-A767', 'Propel', 355610020000000, 355610029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1955 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352013070000000_352013079999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 352013070000000, 352013079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1956 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010457000000000_010457999999999', 'LG', 'C1300', 'C1300', 10457000000000, 10457999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1957 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355458010000000_355458019999999', 'Samsung', 'SGH-A707', 'SGH-A707', 355458010000000, 355458019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1958 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356250070000000_356250079999999', 'Samsung', 'SM-G930AZ', 'Samsung GS7', 356250070000000, 356250079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1959 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010282000000000_010282999999999', 'Nokia', '6800', '6800', 10282000000000, 10282999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1960 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011944000000000_011944009999999', 'LG', 'GR500', 'Xenon', 11944000000000, 11944009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1961 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014499000000000_014499009999999', 'Alcatel', 'A464BG', 'One Touch', 14499000000000, 14499009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1962 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353488050000000_353488059999999', 'Samsung', 'SGH-i497', 'Galaxy Tab 2', 353488050000000, 353488059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1963 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'990000870000000_990000879999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 990000870000000, 990000879999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1964 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011182000000000_011182999999999', 'LG', 'CU500', 'CU500', 11182000000000, 11182999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1965 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011951000000000_011951009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 11951000000000, 11951009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1966 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012022000000000_012022009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 12022000000000, 12022009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1967 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358582050000000_358582059999999', 'Samsung', 'SGH-i257', 'SGH-i257', 358582050000000, 358582059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1968 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011595000000000_011595009999999', 'Pantech', 'C740', 'Matrix', 11595000000000, 11595009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1969 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351765000000000_351765999999999', 'Motorola', 'V60g', 'V60g', 351765000000000, 351765999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1970 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010652000600000_010652000799999', 'Motorola', 'HC700', 'HC700', 10652000600000, 10652000799999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1971 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356991060000000_356991069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 356991060000000, 356991069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1972 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350650000000000_350650999999999', 'Motorola', 'V66m', 'V66m', 350650000000000, 350650999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1973 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353807080000000_353807089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353807080000000, 353807089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1974 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357366000000000_357366009999999', 'Samsung', 'D307', 'D307', 357366000000000, 357366009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1975 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'990000880000000_990000889999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 990000880000000, 990000889999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1976 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354455060000000_354455069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 354455060000000, 354455069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1977 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012764000000000_012764009999999', 'Pantech', 'P9060', 'Pocket', 12764000000000, 12764009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1978 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358561070000000_358561079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 358561070000000, 358561079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1979 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012543000000000_012543009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12543000000000, 12543009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1980 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013196000000000_013196009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13196000000000, 13196009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1981 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357572050000000_357572059999999', 'Samsung', 'SM-N900A', 'Galaxy Note 3', 357572050000000, 357572059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1982 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010340000000000_010340999999999', 'Samsung', 'X427', 'X427', 10340000000000, 10340999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1983 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355320080000000_355320089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355320080000000, 355320089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1984 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356503060000000_356503069999999', 'Samsung', 'SGH-i747', 'Galaxy S III', 356503060000000, 356503069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1985 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353118080000000_353118089999999', 'Samsung', 'SM-J120A', 'Galaxy Express 3', 353118080000000, 353118089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1986 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013046000000000_013046009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13046000000000, 13046009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1987 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356261000000000_356261009999999', 'Motorola', 'V220', 'V220', 356261000000000, 356261009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1988 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010902000000000_010902999999999', 'LG', 'CG225', 'CG225', 10902000000000, 10902999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1989 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358040020000000_358040029999999', 'Sony', 'W350A', 'W350A', 358040020000000, 358040029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1990 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352520000000000_352520009999999', 'Nokia', '3200', '3200', 352520000000000, 352520009999999, 'Continue', ''
);

-- INSERT QUERY NO: 1991 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010016000000000_010016999999999', 'Motorola', 'MicroTAC Select 6000e', 'MicroTAC Select 6000e', 10016000000000, 10016999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1992 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013126000000000_013126009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13126000000000, 13126009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1993 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351955080000000_351955089999999', 'Samsung', 'SM-N930A', 'Galaxy Note 7', 351955080000000, 351955089999999, 'Continue', ''
);

-- INSERT QUERY NO: 1994 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354989000000000_354989009999999', 'Motorola', 'MPX220', 'MPX220', 354989000000000, 354989009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1995 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013966000000000_013966009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13966000000000, 13966009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1996 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013067000000000_013067009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13067000000000, 13067009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1997 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011983000000000_011983009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 11983000000000, 11983009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1998 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359624040000000_359624049999999', 'Samsung', 'SGH-i577', 'Galaxy Exhilarate', 359624040000000, 359624049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 1999 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'001080001752000_001080001755899', 'Sonim', 'XP7', 'XP7', 1080001752000, 1080001755899, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2000 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013034000000000_013034009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13034000000000, 13034009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2001 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013127000000000_013127009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13127000000000, 13127009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2002 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351961020000000_351961029999999', 'BlackBerry', '8110 Pearl', 'Pearl', 351961020000000, 351961029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2003 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354831010000000_354831019999999', 'Nokia', '6085', '6085', 354831010000000, 354831019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2004 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013128000000000_013128009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13128000000000, 13128009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2005 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351845030000000_351845039999999', 'BlackBerry', 'BOLD 9000', 'Bold 9000', 351845030000000, 351845039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2006 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012837000000000_012837009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12837000000000, 12837009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2007 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010295000000000_010295999999999', 'Samsung', 'P107', 'P107', 10295000000000, 10295999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2008 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011365000000000_011365009999999', 'Apple', 'iPhone', 'iPhone', 11365000000000, 11365009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2009 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010333000000000_010333999999999', 'Sony', 'T226', 'T226', 10333000000000, 10333999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2010 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012651000000000_012651009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12651000000000, 12651009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2011 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013616000000000_013616009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13616000000000, 13616009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2012 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013178000000000_013178009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13178000000000, 13178009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2013 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012653000000000_012653009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12653000000000, 12653009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2014 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353323070000000_353323079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 353323070000000, 353323079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2015 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'867980020000000_867980029999999', 'Huawei', 'H1511 Nin-A13', 'Google Nexus 6P', 867980020000000, 867980029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2016 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358599070000000_358599079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 358599070000000, 358599079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2017 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356378040000000_356378049999999', 'Motorola', 'MB865', 'ATRIX 2', 356378040000000, 356378049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2018 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012538000000000_012538009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12538000000000, 12538009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2019 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011232000000000_011232999999999', 'Motorola', 'HC700', 'HC700', 11232000000000, 11232999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2020 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352065060000000_352065069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 352065060000000, 352065069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2021 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355877060000000_355877069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 355877060000000, 355877069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2022 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357905060000000_357905069999999', 'LG', 'H810', 'G4', 357905060000000, 357905069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2023 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359229060000000_359229069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359229060000000, 359229069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2024 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357723080000000_357723089999999', 'Samsung', 'SM-G955U', 'Samsung Galaxy S8', 357723080000000, 357723089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2025 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013998000000000_013998009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13998000000000, 13998009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2026 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358793010000000_358793019999999', 'Motorola', 'IZAR V3xx', 'MOTORAZR V3xx', 358793010000000, 358793019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2027 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'001080001630000_001080001679999', 'Sonim', 'XP5700', 'XP5', 1080001630000, 1080001679999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2028 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013441000000000_013441009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13441000000000, 13441009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2029 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'862097020000000_862097029999999', 'ZTE', 'Z700A', 'AT&T Home Base (Z700A)', 862097020000000, 862097029999999, 'Continue', ''
);

-- INSERT QUERY NO: 2030 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353142020000000_353142029999999', 'HTC', 'FUZE P4600', 'Fuze', 353142020000000, 353142029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2031 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355432040000000_355432049999999', 'HTC', 'T9295', 'HD7S', 355432040000000, 355432049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2032 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354829010000000_354829019999999', 'Nokia', '6102i', '6102i', 354829010000000, 354829019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2033 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012157000000000_012157009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12157000000000, 12157009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2034 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353319050000000_353319059999999', 'Samsung', 'SGH-A997', 'Rugby III', 353319050000000, 353319059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2035 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358542070000000_358542079999999', 'Apple', 'iPhone SE A1662', 'iPhone SE', 358542070000000, 358542079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2036 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011264000000000_011264999999999', 'Motorola', 'C139 att', 'C139 att', 11264000000000, 11264999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2037 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013968000000000_013968009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13968000000000, 13968009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2038 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351846070000000_351846079999999', 'Microsoft Mobile', '950', 'Lumia 950', 351846070000000, 351846079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2039 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359423000000000_359423009999999', 'Motorola', 'V3', 'V3', 359423000000000, 359423009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2040 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350325000000000_350325999999999', 'Sony', 'T68m', 'T68m', 350325000000000, 350325999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2041 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354951070000000_354951079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 354951070000000, 354951079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2042 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011300000000000_011300009999999', 'Apple', 'iPhone', 'iPhone', 11300000000000, 11300009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2043 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353333060000000_353333069999999', 'Motorola', 'XT1527', 'Moto E', 353333060000000, 353333069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2044 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355815040000000_355815049999999', 'Samsung', 'SGH-i997', 'Infuse 4G', 355815040000000, 355815049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2045 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012839000000000_012839009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12839000000000, 12839009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2046 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011114000000000_011114999999999', 'Nokia', '6030', '6030', 11114000000000, 11114999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2047 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355285060000000_355285069999999', 'HTC', '0P6B180', 'One M8', 355285060000000, 355285069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2048 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359092000000000_359092009999999', 'Samsung', 'SGH-D407', 'SGH-D407', 359092000000000, 359092009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2049 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359154070000000_359154079999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 359154070000000, 359154079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2050 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011954000000000_011954009999999', 'Dell', 'M01M', 'Dell Streak', 11954000000000, 11954009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2051 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013060000000000_013060009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13060000000000, 13060009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2052 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350648000000000_350648999999999', 'Motorola', 'T280', 'T280', 350648000000000, 350648999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2053 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356441070000000_356441079999999', 'LG', 'H820', 'G5', 356441070000000, 356441079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2054 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359820000000000_359820999999999', 'Motorola', 'V3', 'V3', 359820000000000, 359820999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2055 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012602000000000_012602009999999', 'Dell', 'Venue Pro', 'Dell Venue Pro', 12602000000000, 12602009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2056 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355806080000000_355806089999999', 'Apple', 'iPad 9.7 A1823', 'iPad 9.7', 355806080000000, 355806089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2057 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010185000000000_010185999999999', 'Nokia', '3595', '3595', 10185000000000, 10185999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2058 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010717000000000_010717999999999', 'Motorola', 'G200', 'G200', 10717000000000, 10717999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2059 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010182000000000_010182999999999', 'Nokia', '3590', '3590', 10182000000000, 10182999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2060 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355367050000000_355367059999999', 'Samsung', 'SGH-i577', 'Galaxy Exhilarate', 355367050000000, 355367059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2061 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013664000000000_013664009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13664000000000, 13664009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2062 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013610000000000_013610009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13610000000000, 13610009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2063 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356205060000000_356205069999999', 'Samsung', 'SM-N915A', 'Galaxy Note Edge', 356205060000000, 356205069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2064 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359099050000000_359099059999999', 'Samsung', 'SGH-i257', 'SGH-i257', 359099050000000, 359099059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2065 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'990000890000000_990000899999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 990000890000000, 990000899999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2066 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350649000000000_350649999999999', 'Motorola', '388c', '388c', 350649000000000, 350649999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2067 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359173070000000_359173079999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7 Plus A1661', 359173070000000, 359173079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2068 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012652000000000_012652009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12652000000000, 12652009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2069 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012419000000000_012419009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12419000000000, 12419009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2070 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011434000000000_011434002908272', 'Apple', 'iPhone', 'iPhone', 11434000000000, 11434002908272, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2071 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354321050000000_354321059999999', 'Samsung', 'SGH-i437', 'Galaxy Express', 354321050000000, 354321059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2072 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013639000000000_013639009999999', 'Alcatel', '7030L', '7030L', 13639000000000, 13639009999999, 'Continue', ''
);

-- INSERT QUERY NO: 2073 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355331080000000_355331089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355331080000000, 355331089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2074 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013184000000000_013184009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13184000000000, 13184009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2075 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353491040000000_353491049999999', 'BlackBerry', '9800', 'Torch', 353491040000000, 353491049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2076 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012270000000000_012270009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12270000000000, 12270009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2077 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355680070000000_355680079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 355680070000000, 355680079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2078 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012123000000000_012123009999999', 'LG', 'CF360', 'Olivin', 12123000000000, 12123009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2079 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359202070000000_359202079999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 359202070000000, 359202079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2080 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013618000000000_013618009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13618000000000, 13618009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2081 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359785050000000_359785059999999', 'Samsung', 'SGH-A157', 'SGH-A157', 359785050000000, 359785059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2082 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358285053600000_358285059999999', 'HP', 'HSTNH-B16C', 'Slate 10 HD', 358285053600000, 358285059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2083 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013679000000000_013679009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13679000000000, 13679009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2084 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353803080000000_353803089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 353803080000000, 353803089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2085 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358429030000000_358429039999999', 'BlackBerry', 'BOLD 9000', 'Bold 9000', 358429030000000, 358429039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2086 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013036000000000_013036009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13036000000000, 13036009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2087 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359844030000000_359844039999999', 'Samsung', 'SGH-A937', 'SGH-A937', 359844030000000, 359844039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2088 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010481000000000_010481999999999', 'Samsung', 'E317', 'E317', 10481000000000, 10481999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2089 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352436020050000_352436029999999', 'Samsung', 'SGH-A837', 'Rugby', 352436020050000, 352436029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2090 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'449271000000000_449271999999999', 'Motorola', 'V100', 'V100', 449271000000000, 449271999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2091 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013541000000000_013541009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13541000000000, 13541009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2092 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354672010000000_354672019999999', 'BlackBerry', '8800', '8800', 354672010000000, 354672019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2093 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351623000000000_351623009999999', 'Samsung', 'SGH-V200', 'SGH-V200', 351623000000000, 351623009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2094 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013654000000000_013654009999999', 'Sonim', 'XP5560-A-R0', 'XP5560-A-R0', 13654000000000, 13654009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2095 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358559070000000_358559079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 358559070000000, 358559079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2096 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354445060000000_354445069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 354445060000000, 354445069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2097 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012994000000000_012994009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12994000000000, 12994009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2098 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013329000000000_013329009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13329000000000, 13329009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2099 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012620000000000_012620009999999', 'LG', 'GS390', 'Prime', 12620000000000, 12620009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2100 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013671000000000_013671009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13671000000000, 13671009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2101 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358937010000000_358937059999999', 'Sony', 'Z750a', 'Z750a', 358937010000000, 358937059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2102 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359250066500000_359250066999999', 'Apple', 'iPhone 7 Plus A1661', 'IPHONE 7 PLUS A1661', 359250066500000, 359250066999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2103 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353277010000000_353277019999999', 'Motorola', 'L6', 'L6', 353277010000000, 353277019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2104 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012154000000000_012154009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12154000000000, 12154009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2105 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352961020000000_352961029999999', 'Samsung', 'SGH-i617', 'BlackJack II', 352961020000000, 352961029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2106 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359213070000000_359213079999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 359213070000000, 359213079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2107 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012996000000000_012996009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12996000000000, 12996009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2108 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013070000000000_013070009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13070000000000, 13070009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2109 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355805080000000_355805089999999', 'Apple', 'iPad 9.7 A1823', 'iPad 9.7', 355805080000000, 355805089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2110 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010227000000000_010227999999999', 'BlackBerry', '7280', '7280', 10227000000000, 10227999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2111 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351846030000000_351846039999999', 'BlackBerry', 'BOLD 9000', 'Bold 9000', 351846030000000, 351846039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2112 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353005010000000_353005019999999', 'Motorola', 'V365', 'V365', 353005010000000, 353005019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2113 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013995000000000_013995009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13995000000000, 13995009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2114 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013005000000000_013005009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13005000000000, 13005009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2115 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353800020000000_353800029999999', 'Samsung', 'SGH-A637', 'SGH-A637', 353800020000000, 353800029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2116 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'449267000000000_449267999999999', 'Motorola', 'V100', 'V100', 449267000000000, 449267999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2117 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013265000000000 _013265009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13265000000000, 13265009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2118 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011560000000000_011560009999999', 'Pantech', 'C610', 'C610', 11560000000000, 11560009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2119 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359171070000000_359171079999999', 'Apple', 'iPhone 7 Plus A1661', 'iPhone 7 Plus A1661', 359171070000000, 359171079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2120 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351410000000000_351410999999999', 'Samsung', 'SGH-S200', 'SGH-S200', 351410000000000, 351410999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2121 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013531000000000_013531009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13531000000000, 13531009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2122 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359237028000000_359237029999999', 'Sony', 'W760a', 'W760a', 359237028000000, 359237029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2123 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359236060000000_359236069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359236060000000, 359236069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2124 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010749000000000_010749999999999', 'Sony', 'Z300a', 'Z300a', 10749000000000, 10749999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2125 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014169000000000_014169009999999', 'LG', 'V410GO', 'G Pad 7.0', 14169000000000, 14169009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2126 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014400000000000_014400009999999', 'Kyocera', 'C6745', 'Hydro Air', 14400000000000, 14400009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2127 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010158000000000_010158999999999', 'Sony', 'T306', 'T306', 10158000000000, 10158999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2128 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355697050000000_355697059999999', 'Samsung', 'SGH-A157', 'SGH-A157', 355697050000000, 355697059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2129 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012852000000000_012852009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12852000000000, 12852009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2130 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351575010000000_351575019999999', 'Samsung', 'SGH-D407', 'SGH-D407', 351575010000000, 351575019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2131 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355197030000000_355197039999999', 'Samsung', 'SGH-A767', 'Propel', 355197030000000, 355197039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2132 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013980000000000_013980009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13980000000000, 13980009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2133 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358558070000000_358558079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 358558070000000, 358558079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2134 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013888000000000_013888009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13888000000000, 13888009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2135 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013273000000000_013273009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13273000000000, 13273009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2136 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357997040000000_357997049999999', 'Samsung', 'SGH-i937', 'Focus S', 357997040000000, 357997049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2137 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355769010000000_355769019999999', 'BlackBerry', '8800c att', '8800c', 355769010000000, 355769019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2138 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353985020000000_353985029999999', 'Motorola', 'V9', 'MOTORAZR2 V9', 353985020000000, 353985029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2139 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351630000000000_351630999999999', 'Siemens', 'SL55', 'SL55', 351630000000000, 351630999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2140 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354846050000000_354846059999999', 'Samsung', 'SGH-i317', 'Galaxy Note II', 354846050000000, 354846059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2141 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359198000000000_359198999999999', 'Motorola', 'V3', 'V3', 359198000000000, 359198999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2142 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013269000000000_013269009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13269000000000, 13269009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2143 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353259070000000_353259079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353259070000000, 353259079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2144 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010483000000000_010483999999999', 'LG', 'A7110', 'A7110', 10483000000000, 10483999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2145 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011116000000000_011116009999999', 'Pantech', 'C740', 'Matrix', 11116000000000, 11116009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2146 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013255000000000_013255009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 13255000000000, 13255009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2147 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357404050000000_357404059999999', 'Motorola', 'TC55AH', 'TC55AH', 357404050000000, 357404059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2148 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013072000000000_013072009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13072000000000, 13072009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2149 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013991000000000_013991009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13991000000000, 13991009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2150 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356923070000000_356923079999999', 'Samsung', 'SM-G928A', 'Galaxy S6 Edge Plus', 356923070000000, 356923079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2151 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355346080000000_355346089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus', 355346080000000, 355346089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2152 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357704010000000_357704019999999', 'Motorola', 'EM330', 'Moto EM330', 357704010000000, 357704019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2153 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355871020000000_355871029999999', 'Samsung', 'SGH-i627', 'Propel Pro', 355871020000000, 355871029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2154 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014376000000000_014376001999999', 'Microsoft', '1657', 'Surface 3', 14376000000000, 14376001999999, 'Continue', ''
);

-- INSERT QUERY NO: 2155 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358263010000000_358263019999999', 'BlackBerry', '8310', 'Curve 8310', 358263010000000, 358263019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2156 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353371030000000_353371039999999', 'Samsung', 'SGH-A767', 'Propel', 353371030000000, 353371039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2157 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010447000000000_010447999999999', 'Nokia', '1100', '1100', 10447000000000, 10447999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2158 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358261000000000_358261009999999', 'Motorola', 'L7', 'SLVR L7', 358261000000000, 358261009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2159 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359373000000000_359373009999999', 'Nokia', '6102i', '6102i', 359373000000000, 359373009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2160 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012962000000000_012962009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12962000000000, 12962009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2161 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357743060000000_357743069999999', 'Samsung', 'SM-G920A', 'Galaxy S6', 357743060000000, 357743069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2162 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358249040000000_358249049999999', 'HTC', 'PI86100', 'PI86100', 358249040000000, 358249049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2163 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'869578020000000_869578029999999', 'ZTE', 'Z812', 'Maven Blue', 869578020000000, 869578029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2164 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356422070000000_356422079999999', 'Samsung', 'SM-G890A', 'Galaxy S6 Active', 356422070000000, 356422079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2165 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352042070000000_352042079999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 352042070000000, 352042079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2166 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013254000000000_013254009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 13254000000000, 13254009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2167 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013438000000000_013438009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13438000000000, 13438009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2168 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357360030000000_357360039999999', 'BlackBerry', 'BOLD 9700', 'Bold 9700', 357360030000000, 357360039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2169 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353221030000000_353221039999999', 'Nokia', '6790', 'Surge', 353221030000000, 353221039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2170 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012749000000000_012749009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12749000000000, 12749009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2171 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012516000000000_012516009999999', 'Samsung', 'SGH-A107', 'SGH-A107', 12516000000000, 12516009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2172 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013891000000000_013891009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13891000000000, 13891009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2173 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355340080000000_355340089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355340080000000, 355340089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2174 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354650030000000_354650039999999', 'Motorola', 'EM330', 'Moto EM330', 354650030000000, 354650039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2175 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359300060000000_359300069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359300060000000, 359300069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2176 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013176000000000_013176009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13176000000000, 13176009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2177 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013589000000000_013589009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13589000000000, 13589009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2178 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010089000000000_010089299999999', 'Nokia', '6340i', '6340i', 10089000000000, 10089299999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2179 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011811000000000_011811009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11811000000000, 11811009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2180 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013001000000000_013001009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13001000000000, 13001009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2181 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357889000000000_357889999999999', 'BlackBerry', '8700c', '8700c', 357889000000000, 357889999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2182 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358851020000000_358851029999999', 'HTC', 'ST7378NC', 'Tilt 2', 358851020000000, 358851029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2183 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354611000000000_354611009999999', 'Audiovox', 'SMT5600', 'SMT5600', 354611000000000, 354611009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2184 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'990000860000000_990000869999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 990000860000000, 990000869999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2185 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353680050000000_353680059999999', 'Nokia', '920', 'Lumia 920', 353680050000000, 353680059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2186 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013847000000000_013847009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13847000000000, 13847009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2187 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010167000000000_010167999999999', 'Motorola', 'C331g', 'C331g', 10167000000000, 10167999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2188 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357100000000000_357100999999999', 'Nokia', '6102i', '6102i', 357100000000000, 357100999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2189 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010336000000000_010336999999999', 'Nokia', '6010', '6010', 10336000000000, 10336999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2190 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010520000000000_010520999999999', 'Nokia', '1100', '1100', 10520000000000, 10520999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2191 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011948000000000_011948009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 11948000000000, 11948009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2192 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358921000000000_358921009999999', 'Motorola', 'V3', 'V3', 358921000000000, 358921009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2193 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355071010000000_355071019999999', 'Motorola', 'MQ4', 'MQ4', 355071010000000, 355071019999999, 'Continue', ''
);

-- INSERT QUERY NO: 2194 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356882050000000_356882059999999', 'Samsung', 'SGH-A217', 'SGH-A217', 356882050000000, 356882059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2195 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013425000000000_013425009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13425000000000, 13425009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2196 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010221000000000_010221999999999', 'Nokia', '6340i', '6340i', 10221000000000, 10221999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2197 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012185000000000_012185009999999', 'Nokia', '2320', '2320', 12185000000000, 12185009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2198 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353806080000000_353806089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 353806080000000, 353806089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2199 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359209070000000_359209079999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 359209070000000, 359209079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2200 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011775000000000_011775009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11775000000000, 11775009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2201 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357182040000000_357182049999999', 'Sony', 'SGPT211US', 'Tablet P', 357182040000000, 357182049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2202 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013279000000000_013279009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13279000000000, 13279009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2203 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355684070000000_355684079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 355684070000000, 355684079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2204 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014671000000000_014671009999999', 'TCL Communication', '4060O', '4060O', 14671000000000, 14671009999999, 'Continue', ''
);

-- INSERT QUERY NO: 2205 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356714070000000_356714079999999', 'Samsung', 'SM-N920A', 'Galaxy Note 5', 356714070000000, 356714079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2206 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354896020000000_354896029999999', 'Motorola', 'KRZR K1', 'KRZR K1', 354896020000000, 354896029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2207 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355350080000000_355350089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7', 355350080000000, 355350089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2208 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359204070000000_359204079999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7 A1778', 359204070000000, 359204079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2209 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011145000000000_011145999999999', 'LG', 'CU500v', 'CU500v', 11145000000000, 11145999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2210 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014328000000000_014328000000299', 'ASUS', 'ME375CL', 'Memo Pad 7', 14328000000000, 14328000000299, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2211 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359590070000000_359590079999999', 'Samsung', 'SM-N930A', 'Galaxy Note 7', 359590070000000, 359590079999999, 'Continue', ''
);

-- INSERT QUERY NO: 2212 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'865651020000000_865651029999999', 'ZTE', 'Z222', 'Z222', 865651020000000, 865651029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2213 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359273030000000_359273039999999', 'Samsung', 'SGH-A597', 'Eternity II', 359273030000000, 359273039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2214 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359153070000000_359153079999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 359153070000000, 359153079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2215 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357332010000000_357332019999999', 'Motorola', 'V365 att', 'V365', 357332010000000, 357332019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2216 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011270000000000_011270999999999', 'LG', 'CG180', 'CG180', 11270000000000, 11270999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2217 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353872070000000_353872079999999', 'Blackberry', 'RJE181LW', 'STH100-1', 353872070000000, 353872079999999, 'Continue', ''
);

-- INSERT QUERY NO: 2218 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010113000000000_010113999999999', 'Motorola', 'T191', 'T191', 10113000000000, 10113999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2219 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013663000000000_013663009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13663000000000, 13663009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2220 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011743000000000_011743009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11743000000000, 11743009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2221 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011174002085600_011174999999999', 'Nokia', '2610', '2610', 11174002085600, 11174999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2222 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357928040000000_357928049999999', 'BlackBerry', '9860', 'Torch 9860', 357928040000000, 357928049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2223 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013880000000000_013880009999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 13880000000000, 13880009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2224 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010204000000000_010204999999999', 'BlackBerry', '7210', '7210', 10204000000000, 10204999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2225 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358588030000000_358588039999999', 'Samsung', 'SGH-A897', 'Mythic', 358588030000000, 358588039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2226 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352706000000000_352706009999999', 'Motorola', 'V60Gi', 'V60Gi', 352706000000000, 352706009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2227 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358595030000000_358595039999999', 'Samsung', 'SGH-A797', 'Flight', 358595030000000, 358595039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2228 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352982040000000_352982049999999', 'Samsung', 'SGH-i917', 'Focus', 352982040000000, 352982049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2229 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011219000000000_011219999999999', 'Motorola', 'C168i', 'C168i', 11219000000000, 11219999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2230 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353791000000000_353791009999999', 'Nokia', '3100', '3100', 353791000000000, 353791009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2231 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013598000000000_013598009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13598000000000, 13598009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2232 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351590040000000_351590049999999', 'ZTE', 'R225', 'R225', 351590040000000, 351590049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2233 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353260070000000_353260079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353260070000000, 353260079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2234 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355081040000000_355081049999999', 'ASUS', 'TF300TL', 'TF300TL', 355081040000000, 355081049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2235 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010111000000000_010111999999999', 'Siemens', 'M46', 'M46', 10111000000000, 10111999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2236 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358837070000000_358837079999999', 'LG', 'LG328BG', 'B470', 358837070000000, 358837079999999, 'Continue', ''
);

-- INSERT QUERY NO: 2237 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353257070000000_353257079999999', 'Apple', 'iPhone 6S Model A1633', 'iPhone 6S', 353257070000000, 353257079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2238 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354998000000000_354998009999999', 'Motorola', 'V180', 'V180', 354998000000000, 354998009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2239 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013594000000000_013594009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13594000000000, 13594009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2240 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014065000000000_014065009999999', 'LG', 'D850', 'D850', 14065000000000, 14065009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2241 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012795000000000_012795009999999', 'Samsung', 'SGH-A107', 'SGH-A107', 12795000000000, 12795009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2242 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010335000000000_010335999999999', 'Nokia', '6010', '6010', 10335000000000, 10335999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2243 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014000000000000_014000009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 14000000000000, 14000009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2244 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354674020000000_354674029999999', 'Motorola', 'Q9h', 'Q9h', 354674020000000, 354674029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2245 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013655000000000_013655009999999', 'Sonim', 'Ex-Handy 08', 'Ex-Handy 08', 13655000000000, 13655009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2246 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010186000400000_010186000599999', 'Motorola', 'MU500 blackbox', 'MU500 blackbox', 10186000400000, 10186000599999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2247 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358347040000000_358347049999999', 'Samsung', 'SGH-i997', 'Infuse 4G', 358347040000000, 358347049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2248 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356561080000000_356561089999999', 'Apple', 'iPhone 7 A1778', 'iPhone 7', 356561080000000, 356561089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2249 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013063000000000_013063009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13063000000000, 13063009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2250 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011754000000000_011754009999999', 'Nokia', '2610', '2610', 11754000000000, 11754009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2251 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358347000000000_358347009999999', 'Motorola', 'MC9094', 'MC9094', 358347000000000, 358347009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2252 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011714000000000_011714009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11714000000000, 11714009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2253 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013996000000000_013996009999999', 'Apple', 'iPhone 5C Model A1532', 'iPhone  5C', 13996000000000, 13996009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2254 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356442020000000_356442029999999', 'Motorola', 'Z9 OrNand', 'Z9 OrNand', 356442020000000, 356442029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2255 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352714080000000_352714089999999', 'Samsung', 'SM-G930A', 'Galaxy S7', 352714080000000, 352714089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2256 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357227060000000_357227069999999', 'HTC', '0PJA110', 'One M9', 357227060000000, 357227069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2257 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358602000000000_358602009999999', 'Motorola', 'V235', 'V235', 358602000000000, 358602009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2258 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012286000000000_012286009999999', 'Dell', 'V02S', 'Dell Venue Pro V02S', 12286000000000, 12286009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2259 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355433070000000_355433079999999', 'Apple', 'iPhone SE A1662', 'iPhone SE', 355433070000000, 355433079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2260 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012515000000000_012515009999999', 'Pantech', 'P7000', 'Impact', 12515000000000, 12515009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2261 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353777000000000_353777999999999', 'Samsung', 'SGH-A707', 'SGH-A707', 353777000000000, 353777999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2262 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011330000000000_011330009999999', 'Audiovox', 'SMT5700', 'SMT5700', 11330000000000, 11330009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2263 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011654000000000_011654009999999', 'Apple', 'iPhone', 'iPhone', 11654000000000, 11654009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2264 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355727070000000_355727079999999', 'Apple', 'iPhone 6S Plus A1634', 'iPhone 6S Plus', 355727070000000, 355727079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2265 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011546000000000_011546009999999', 'Apple', 'iPhone', 'iPhone', 11546000000000, 11546009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2266 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359366020000000_359366029999999', 'Samsung', 'SGH-A257', 'Magnet', 359366020000000, 359366029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2267 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351810070000000_351810079999999', 'Samsung', 'SM-G920A', 'Galaxy S6', 351810070000000, 351810079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2268 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010896000000000_010896999999999', 'Pantech', 'C-120', 'C120', 10896000000000, 10896999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2269 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011751009999000_011751009999010', 'Test', 'test1234', 'dev test', 11751009999000, 11751009999010, 'Continue', ''
);

-- INSERT QUERY NO: 2270 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358377030000000_358377039999999', 'HP', 'Glisten', 'Glisten', 358377030000000, 358377039999999, 'Continue', ''
);

-- INSERT QUERY NO: 2271 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014328000000300_014328005999999', 'ASUS', 'ME375CL', 'Memo Pad 7', 14328000000300, 14328005999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2272 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012796000000000_012796009999999', 'Pantech', 'P7050', 'P7050', 12796000000000, 12796009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2273 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356693030000000_356693039999999', 'Motorola', 'MB300', 'BackFlip', 356693030000000, 356693039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2274 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355282030000000_355282039999999', 'Motorola', 'MC75A6', 'MC75A6', 355282030000000, 355282039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2275 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'863806010000000_863806019999999', 'ZTE', 'Z221', 'Z221', 863806010000000, 863806019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2276 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354982050000000_354982059999999', 'Motorola', 'XT1058', 'XT1058', 354982050000000, 354982059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2277 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011924000000000_011924009999999', 'Samsung', 'SGH-A137', 'SGH-A137', 11924000000000, 11924009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2278 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359163050000000_359163059999999', 'Samsung', 'SM-T217A', 'Galaxy Tab 3', 359163050000000, 359163059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2279 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352012050000000_352012059999999', 'Samsung', 'SGH-i717', 'Galaxy Note', 352012050000000, 352012059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2280 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010797000000000_010797999999999', 'Pantech', 'C-300', 'C300', 10797000000000, 10797999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2281 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359811040000000_359811049999999', 'HTC', 'PD98120', 'Inspire', 359811040000000, 359811049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2282 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011813000000000_011813009999999', 'Apple', 'iPhone 3G', 'iPhone 3G', 11813000000000, 11813009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2283 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357153080000000_357153089999999', 'Samsung', 'SM-J327A', 'Samsung SM-J327A', 357153080000000, 357153089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2284 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011097000000000_011097999999999', 'LG', 'CG300', 'CG300', 11097000000000, 11097999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2285 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350327000000000_350327999999999', 'Sony', 'T68m', 'T68m', 350327000000000, 350327999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2286 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352288010000000_352288019999999', 'Nokia', 'N75', 'N75', 352288010000000, 352288019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2287 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013335000000000_013335009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13335000000000, 13335009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2288 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352001070000000_352001079999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 352001070000000, 352001079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2289 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013266000000000_013266009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 13266000000000, 13266009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2290 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'350450000000000_350450999999999', 'Siemens', 'MC45', 'MC45', 350450000000000, 350450999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2291 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355368050000000_355368059999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 355368050000000, 355368059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2292 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010374000000000_010374999999999', 'Sony', 'T226', 'T226', 10374000000000, 10374999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2293 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012848000000000_012848009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12848000000000, 12848009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2294 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010319000000000_010319999999999', 'Nokia', '1100', '1100', 10319000000000, 10319999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2295 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013037000000000_013037009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13037000000000, 13037009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2296 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010540000000000_010540999999999', 'LG', 'F9100', 'F9100', 10540000000000, 10540999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2297 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353388040000000_353388049999999', 'Nokia', 'C3', 'C3', 353388040000000, 353388049999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2298 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359303060000000_359303069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 359303060000000, 359303069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2299 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012747000000000_012747009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12747000000000, 12747009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2300 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352009060000000_352009069999999', 'Apple', 'iPhone 5S Model A1533', 'iPhone 5S', 352009060000000, 352009069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2301 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356263050000000_356263059999999', 'Samsung', 'SGH-i527', 'Galaxy Mega', 356263050000000, 356263059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2302 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012992000000000_012992009999999', 'Apple', 'iPhone 3GS', 'iPhone 3GS', 12992000000000, 12992009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2303 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'359165070000000_359165079999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 359165070000000, 359165079999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2304 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012429000000000_012429009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12429000000000, 12429009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2305 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014072000000000_014072009999999', 'Kyocera', 'E6560', 'Duo Force', 14072000000000, 14072009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2306 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012705000000000_012705009999999', 'HP', 'HSTNH-I30C', 'HSTNH-I30C', 12705000000000, 12705009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2307 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355325080000000_355325089999999', 'Apple', 'iPhone 7 A1660', 'iPhone 7 A1660', 355325080000000, 355325089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2308 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356144060000000_356144069999999', 'Samsung', 'SM-R750', 'Gear S', 356144060000000, 356144069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2309 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013529000000000_013529009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13529000000000, 13529009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2310 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'011793000000000_011793009999999', 'LG', 'GR500', 'Xenon', 11793000000000, 11793009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2311 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353149050000000_353149059999999', 'Samsung', 'SGH-i687', 'SGH-i687', 353149050000000, 353149059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2312 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'352001010000000_352001019999999', 'Samsung', 'SGH-D807', 'SGH-D807', 352001010000000, 352001019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2313 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354400050000000_354400059999999', 'ASUS', 'ME370TG', 'ME370TG', 354400050000000, 354400059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2314 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354388060000000_354388069999999', 'Apple', 'iPhone 6 Plus A1522', 'iPhone 6 Plus', 354388060000000, 354388069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2315 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357375080000000_357375089999999', 'LG', 'W280', 'Watch Sport', 357375080000000, 357375089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2316 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354999000000000_354999009999999', 'Motorola', 'V400', 'V400', 354999000000000, 354999009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2317 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'358369060000000_358369069999999', 'Apple', 'iPhone 6 A1549', 'iPhone 6', 358369060000000, 358369069999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2318 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351939050000000_351939059999999', 'Nokia', '900', 'Lumia 900', 351939050000000, 351939059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2319 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013193000000000_013193009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13193000000000, 13193009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2320 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354512000000000_354512019999999', 'Motorola', 'RAZR 05 V3', 'RAZR 05 V3', 354512000000000, 354512019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2321 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013527000000000_013527009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13527000000000, 13527009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2322 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357085050000000_357085059999999', 'Samsung', 'SGH-i337', 'Galaxy S4', 357085050000000, 357085059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2323 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012746000000000_012746009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12746000000000, 12746009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2324 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'354879010000000_354879019999999', 'BlackBerry', 'PEARL', 'Pearl', 354879010000000, 354879019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2325 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355430050000000_355430059999999', 'Samsung', 'SGH-i747', 'Galaxy S III', 355430050000000, 355430059999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2326 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010120000000000_010120999999999', 'Motorola', 'T193m (ROM8)', 'T193m (ROM8)', 10120000000000, 10120999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2327 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353814080000000_353814089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 353814080000000, 353814089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2328 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013330000000000_013330009999999', 'Apple', 'iPhone 5 Model A1428', 'iPhone 5', 13330000000000, 13330009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2329 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'356244000000000_356244039999999', 'Nokia', '3120', '3120', 356244000000000, 356244039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2330 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010260000000000_010260009999999', 'Nokia', '3595', '3595', 10260000000000, 10260009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2331 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'013205000000000_013205009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 13205000000000, 13205009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2332 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355302080000000_355302089999999', 'Apple', 'iPiPhone 7 Plus A1784', 'iPhone 7 Plus A1784', 355302080000000, 355302089999999, 'Continue', ''
);

-- INSERT QUERY NO: 2333 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'012544000000000_012544009999999', 'Apple', 'iPhone 4 Model A1332', 'iPhone 4', 12544000000000, 12544009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2334 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'353623010000000_353623019999999', 'Motorola', 'V3r', 'V3r', 353623010000000, 353623019999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2335 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010337000000000_010337999999999', 'Nokia', '6010', '6010', 10337000000000, 10337999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2336 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'866551020000000_866551029999999', 'ZTE', 'Z818L', 'Z818L', 866551020000000, 866551029999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2337 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'351507030000000_351507039999999', 'Motorola', 'V9x OrNand', 'MOTORAZR2 V9', 351507030000000, 351507039999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2338 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'010310000000000_010310999999999', 'Motorola', 'T720', 'T720', 10310000000000, 10310999999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2339 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'357446000000000_357446009999999', 'Sony', 'W600i', 'W600i', 357446000000000, 357446009999999, 'Continue', 'NOT DEFINED'
);

-- INSERT QUERY NO: 2340 
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'014488000000000_014488009999999', 'Apple', 'iPhone 4S Model A1387', 'iPhone 4S', 14488000000000, 14488009999999, 'Continue', 'NOT DEFINED'
);

 INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355353080000000_355353089999999', 'Apple', 'iPhone 7 Plus A1784', 'iPhone 7 Plus', 355353080000000, 355353089999999, 'Continue', ''
);
INSERT INTO oce_ru_make_model(id, make, model, friendlyModelName, startRange, endRange, falloutAction, deviceMessage)
VALUES
(
'355864070000000_355864079999999', 'LG', 'L81AL', 'L81AL', 355864070000000, 355864079999999, 'Continue', 'NOT DEFINED'
);
commit;
/
