The TestHumanTask workflow contains a BusinessRuleTask that uses a DMN table (dish.dmn). 
The BusinessRuleTask expects a String variable called "season" -- this is fed into the DMN table.
When you start the TestHumanTask process via the Camunda Tasklist web application, you need to add a add a variable: 
    Name = season
    Type = String
    Value = Winter   --> this is a single value and can be Winter, Spring, Summer, or Fall - these match the values in the dish.dmn file.
    