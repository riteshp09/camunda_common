create table GOPHONE_SKU(
skuid varchar2(15) not null,
make varchar2(50),
model varchar2(100),
displayname varchar2(500),
active varchar2(1),
PRIMARY KEY (skuid)
);