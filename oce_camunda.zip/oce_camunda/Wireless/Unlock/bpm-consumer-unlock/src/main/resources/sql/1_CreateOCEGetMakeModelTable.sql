CREATE TABLE oce_ru_make_model(
id VARCHAR2(40) NOT NULL,
make VARCHAR2(64),
model VARCHAR2(64),
friendlyModelName VARCHAR2(64),
startRange NUMBER(20),
endRange NUMBER(20),
falloutAction VARCHAR2(64),
deviceMessage VARCHAR2(64),
PRIMARY KEY (id)
);
