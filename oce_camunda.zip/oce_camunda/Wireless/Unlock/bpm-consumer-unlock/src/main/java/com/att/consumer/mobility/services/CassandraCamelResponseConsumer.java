package com.att.consumer.mobility.services;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.ajsc.camel.custom.AbstractCamelConsumer;

public class CassandraCamelResponseConsumer extends AbstractCamelConsumer {
	
	@Override
	public void execute(Exchange e) {
		System.out.println("BRMS Response handler started..");
		Message msg = e.getIn();
		String inMessageStr = null;
		Map<String, Object> responseWrapper  = new LinkedHashMap<>();
		boolean isFaultResponse;
		
		try {
			inMessageStr = readExchangeMessage(e);
			
			String responseCode =  String.valueOf(msg.getHeaders().get("CamelHttpResponseCode"));
			String camelException = String.valueOf(e.getProperties().get("CamelExceptionCaught"));
			
			/*System.out.println(responseCode + "==" + camelException);
			System.out.println(e.getProperties());
			System.out.println(msg.getHeaders());*/
			if( e.getProperties()!=null && e.getProperties().get(CommonConstants.INTERFACE_NAME)!=null 
					&& e.getProperties().get(CommonConstants.INTERFACE_NAME).toString().equalsIgnoreCase("brms")){
				responseWrapper.put(CommonConstants.INTERFACE_NAME, (String) e.getProperties().get(CommonConstants.INTERFACE_NAME));
				if(!CommonConstants.isNull(camelException)){
					e.setProperty(CommonConstants.IS_FAULT_RESPONSE, true);
					if(!CommonConstants.isNull(responseCode)){
						responseWrapper.put(CommonConstants.ERROR_CODE, responseCode);
					}else{
						responseWrapper.put(CommonConstants.ERROR_CODE, "404");
					}
					responseWrapper.put("payload", camelException);
				} else {
					e.setProperty(CommonConstants.IS_FAULT_RESPONSE, false);
					responseWrapper.put(CommonConstants.ERROR_CODE, "0");
					responseWrapper.put("payload", inMessageStr);
				}
				responseWrapper.put(CommonConstants.IS_FAULT_RESPONSE, (Boolean) e.getProperties().get(CommonConstants.IS_FAULT_RESPONSE));
			}else{
				responseWrapper.put(CommonConstants.INTERFACE_NAME, (String) e.getProperties().get(CommonConstants.INTERFACE_NAME));
				
				if((!CommonConstants.isNull(responseCode) && !"200".equals(responseCode)) 
						|| !CommonConstants.isNull(camelException)) {
					e.setProperty(CommonConstants.IS_FAULT_RESPONSE, true);
					
					if(!CommonConstants.isNull(responseCode) && !"200".equals(responseCode)) {
						responseWrapper.put(CommonConstants.ERROR_CODE, responseCode);
					} else {
						responseWrapper.put(CommonConstants.ERROR_CODE, "404");
						responseWrapper.put("payload", camelException);
					}
					
				} else {
					e.setProperty(CommonConstants.IS_FAULT_RESPONSE, false);
					responseWrapper.put(CommonConstants.ERROR_CODE, "0");
					responseWrapper.put("payload", inMessageStr);
				}
				
				responseWrapper.put(CommonConstants.IS_FAULT_RESPONSE, (Boolean) e.getProperties().get(CommonConstants.IS_FAULT_RESPONSE));
			}
			
		} catch (IOException e1) {
			e1.printStackTrace();
		
		}catch (Exception e1) {
			e1.printStackTrace();
		
		}
		
		msg.setBody(responseWrapper);
		e.setOut(msg);

	}

}
