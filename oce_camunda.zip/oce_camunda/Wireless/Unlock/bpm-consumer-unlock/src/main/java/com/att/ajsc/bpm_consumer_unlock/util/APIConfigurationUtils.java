package com.att.ajsc.bpm_consumer_unlock.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.xml.bind.JAXBException;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.Expression;
import org.camunda.bpm.engine.impl.el.ExpressionManager;
import org.camunda.bpm.engine.impl.pvm.runtime.ExecutionImpl;

import com.att.oce.bpm.common.FileUtility;
import com.att.oce.bpm.common.JAXBUtil;
import com.att.oce.oce.namespaces.bpel.apiconfiguration.APIConfiguration;
import com.att.oce.oce.namespaces.bpel.apiconfiguration.APIConfigurations;
import com.att.oce.oce.namespaces.bpel.apiconfiguration.FaultAction;
import com.att.oce.oce.namespaces.config.retry_config.ConditionType;
import com.att.oce.oce.namespaces.config.retry_config.FaultNameType;
import com.att.oce.oce.namespaces.config.retry_config.RetryConfigType;
import com.att.oce.oce.namespaces.config.retry_config.RetryPolicies;
import com.att.oce.oce.namespaces.config.retry_config.RetryPolicy;

public class APIConfigurationUtils {
	private APIConfigurations configs = null;
	private RetryPolicies retryPolicies = null;
	private RetryPolicy defaultRetryPolicy = null;
	private static APIConfigurationUtils instance = null;

	private static Logger logger = Logger.getLogger(APIConfigurationUtils.class.getName());
	
	public static ExpressionManager EXPRESSION_MANAGER = new ExpressionManager();
	
	private APIConfigurationUtils() {
		
	}


	public static APIConfigurationUtils getInstance() {
		if(instance == null)
			instance = new APIConfigurationUtils();
		return instance;
	}

	public RetryPolicies getRetryPolicies() {
		if(retryPolicies == null) {
			try {
				String xml = FileUtility.getInstance().getFileContent("retry-config.xml");
				retryPolicies = JAXBUtil.unmarshalObj(xml, RetryPolicies.class);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (JAXBException e) {
				e.printStackTrace();
			}
		}
		return retryPolicies;
	}

	public RetryPolicy getDefaultRetryPolicy() {
		if(defaultRetryPolicy == null) {
			List<RetryPolicy> policies = getRetryPolicies().getRetryPolicies();
			for (RetryPolicy retryPolicy : policies) {
				if(retryPolicy.getId().equals(CommonConstants.DEFAULT)) {
					defaultRetryPolicy = retryPolicy;
					break;
				}
			}
		}

		return defaultRetryPolicy;
	}

	public RetryPolicy getRetryPolicy(String id) {
		if(CommonConstants.DEFAULT.equals(id)) 
			return getDefaultRetryPolicy();
		else {
			List<RetryPolicy> policies = getRetryPolicies().getRetryPolicies();
			for (RetryPolicy retryPolicy : policies) {
				if(retryPolicy.getId().equals(id))
					return retryPolicy;
			}
		}
		return null;
	}

	public RetryConfigType getMatchingRetryConfig(/*DelegateExecution execution, */String exceptionClass,
			String errorCode, String interfaceName) {

		RetryConfigType config = null;
		boolean found = false;

		List<FaultNameType> faultNames = getDefaultRetryPolicy().getConditions().getFaultNames();
		for (FaultNameType faultNameType : faultNames) {
			if(exceptionClass != null && !"".equals(exceptionClass) && exceptionClass.equals(faultNameType.getName())) {
				List<ConditionType> faultConditions = faultNameType.getConditions();
				config = iterateOverFaultNames(faultConditions, errorCode, interfaceName);
				if(config != null)
					found = true;
			} else {
				List<ConditionType> faultConditions = faultNameType.getConditions();
				config = iterateOverFaultNames(faultConditions, errorCode, interfaceName);
				if(config != null) found = true;
			}
			if(found) break;
		}

		return config;
	}
	
	protected RetryConfigType iterateOverFaultNames(List<ConditionType> faultConditions, String errorCode, String interfaceName) {
		RetryConfigType config = null;
		ExecutionImpl execution = new ExecutionImpl();
		execution.setVariable(CommonConstants.ERROR_CODE, errorCode);
		execution.setVariable(CommonConstants.INTERFACE_NAME, interfaceName);
		
		for (ConditionType conditionType : faultConditions) {
			String test = conditionType.getTest();
			logger.info("Condition Expression :: " + test);
			Expression expression = EXPRESSION_MANAGER.createExpression(test);
			String result = expression.getValue(execution).toString();
			logger.info("Condition Expression Result :: " + result);
			if(Boolean.valueOf(result)) {
				String configName = conditionType.getRetryConfig().getRef();
				config = getRetryConfig(configName);
				logger.info("Matching Retry Config found  :: " + config.getId());
				break;
			}
		}
		return config;
	}

	public String formatRetryConfigString(int retryCount, int retryInterval) {
		String retryConfig = "R3/PT10S";
		retryConfig = "R#/PT?S";
		retryConfig = retryConfig.replace("#", String.valueOf(retryCount));
		retryConfig = retryConfig.replace("?", String.valueOf(retryInterval));
		return retryConfig;
	}

	public RetryConfigType getRetryConfig(String name) {
		List<RetryConfigType> retryConfigs = getDefaultRetryPolicy().getRetryConfigs().getRetryConfigs();
		for (RetryConfigType retryConfigType : retryConfigs) {
			if(retryConfigType.getId().equals(name))
				return retryConfigType;
		}
		return null;
	}

	public  APIConfigurations getAPIConfigurations() {
		if(configs == null) {
			try {
				String xml = FileUtility.getInstance().getFileContent("api-configuration-cru.xml");
				configs = JAXBUtil.unmarshalObj(xml, APIConfigurations.class);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (JAXBException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} 
		}

		return configs;
	}

	public APIConfiguration getApiConfiguration(String configName) {
		APIConfigurations apiconfigs = getAPIConfigurations();
		List<APIConfiguration> configs = apiconfigs.getAPIConfigurations();

		for (APIConfiguration apiConfiguration : configs) {
			if(configName.equals(apiConfiguration.getAPIName()))
				return apiConfiguration;
		}
		return null;
	}

	public FaultAction getDefaultFaultAction(String configName) {
		//{ANY}

		List<FaultAction> faultActions = getApiConfiguration(configName).getFaultActions();
		for (FaultAction faultAction : faultActions) {
			if(faultAction.getCSIErrorCode().equals("{ANY}")) {
				return faultAction;
			}
		}
		return null;
	}

	public FaultAction getFaultAction(String configName, String errorCode) {
		FaultAction retFaultAction = null;

		List<FaultAction> faultActions = getApiConfiguration(configName).getFaultActions();
		for (FaultAction faultAction : faultActions) {
			if(faultAction.getCSIErrorCode().equals(errorCode)) {
				retFaultAction = faultAction;
				break;
			}
		}

		if(retFaultAction == null) {
			retFaultAction = getDefaultFaultAction(configName);
		}

		return retFaultAction;
	}
	
	public String getPathForwardAfterFallout(String interfaceName, String errorCode) {
		String[] data = getLosgStatusSubStatus(interfaceName, errorCode);
		if(data.length == 3 && data[2] != null && !"".equals(data[2].trim()))
			return data[2];
		else
			return "REVIEW";
	}
	
	public String[] getLosgStatusSubStatus(String interfaceName, String errcode) {
		String status[] = null;
		
//		String errcode = exception.getResponse().getCode();
		
		FaultAction faultAction = getFaultAction(interfaceName, errcode);
		if(faultAction!= null) {
			status = new String[3];
			status[0] = faultAction.getStatus().getStatus().value();
			status[1] = faultAction.getStatus().getSubStatus();
			status[2] = faultAction.getStatus().getPathForward();
		}
		
		return status;
		
	}

	public static void main(String[] a) {
//		RetryConfigType retryConfig =  APIConfigurationUtils.getInstance().getAPIConfigurations();
		DelegateExecution execution = new ExecutionImpl();
		execution.setVariable(CommonConstants.ERROR_CODE, "400");
		execution.setVariable(CommonConstants.INTERFACE_NAME, "AddNote");
		APIConfigurationUtils.getInstance().getMatchingRetryConfig(null, "400", "AddNote");
	}

}
