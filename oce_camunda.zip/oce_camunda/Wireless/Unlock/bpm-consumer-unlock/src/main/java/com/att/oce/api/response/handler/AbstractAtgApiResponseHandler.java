package com.att.oce.api.response.handler;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.oce.bpm.common.VelocityHelper;

public abstract class AbstractAtgApiResponseHandler implements UnlockApiResponseHandler {
	
	private String response;
	private LinkedHashMap<String, Object> exception;
	private DelegateExecution execution;
	private LinkedHashMap<String, Object> responseWrapper;

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		this.execution = execution;
		responseWrapper =  (LinkedHashMap<String, Object>) execution.getVariable("response");
		boolean isFault = (boolean) responseWrapper.get(CommonConstants.IS_FAULT_RESPONSE);
		if(isFault) {
			try{
				String payload = (String) responseWrapper.get("payload");
				exception = (LinkedHashMap<String, Object>) VelocityHelper.jsonToMap(payload);
			}catch(ClassCastException c){
				exception=(LinkedHashMap<String, Object>) responseWrapper.get("payload");
			}
			
			getExecution().setVariable((String) responseWrapper.get(CommonConstants.INTERFACE_NAME) + "_FaultResponse", exception);
			handleFaultResponse();
		} else {
			response = (String) responseWrapper.get("payload");
			handleSuccessResponse();
		}
		postExecute();
	}

	@Override
	public DelegateExecution getExecution() {
		return this.execution;
	}

	@Override
	public String getResponse() {
		return this.response;
	}

	@Override
	public LinkedHashMap<String, Object> getException() {
		return this.exception;
	}

	@Override
	public abstract void handleSuccessResponse() throws Exception;

	@Override
	public void handleFaultResponse() throws Exception {
		LinkedHashMap<String,Object> errors=null;
		Map<?,?> error = null;
		if(getException().get("Errors")!=null){
			 errors = (LinkedHashMap<String,Object>) getException().get("Errors");
			 error =  (Map<?, ?>) ((ArrayList) errors.get("Error")).get(0);
		}
		
		String errorCode =  error.get("ErrorCode")!=null?(String) error.get("ErrorCode"):"404";
		String errorDesc =  error.get("ErrorDescription")!=null?(String) error.get("ErrorDescription"):"Request Failed";
		
		if(CommonConstants.CONNECTION_ERR_CODE.equals(errorCode) || CommonConstants.SYSTEM_ERROR.equals(errorDesc))
			throw new Exception("ATG Fault Response Received : ErrorCode(" + errorCode + ") and ErrorDescription(" + errorDesc + ").\n"
					+ "Please retry after some time.");		
	}
	
	@Override
	public void preExecute() throws Exception {
	}

	@Override
	public void postExecute() throws Exception {
		getExecution().removeVariable("response");
	}

}
