package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.joda.time.DateTime;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.bpm.common.JAXBUtil;
import com.csi.v112.container.inquireDeviceUnlockEligibilityResponse.InquireDeviceUnlockEligibilityResponseInfo;

public class OldestNetworkActivity implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {

		Map<String,String> unlockContext = (Map<String, String>) execution.getVariable("unlockContext");

		boolean isOldestActivityPast6M = false;

		boolean isGoPhone =  (CommonConstants.isNull(unlockContext.get(CommonConstants.PREPAIED_INDICATOR))) ? false : true ;

		if(!CommonConstants.isNull(execution.getVariable("getIddResponse"))) {
			String iddResponseXML = execution.getVariable("getIddResponse").toString();

			Document xmlDocument = JAXBUtil.getXMLDocument(iddResponseXML); 

			NodeList nwActivityList = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireDeviceDetailsResponse.xsd", 
					"NetworkActivity");

			Element[] sortedNWActivity = UnlockUtils.sortNodes(nwActivityList, "activityDate","http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd" ,true, Date.class);

			String activityDateStr = JAXBUtil.getElementValue(sortedNWActivity[0], 
					"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
					"activityDate");

			if(!CommonConstants.isEmpty(activityDateStr)) {
				long activityDate = CommonConstants.usDateFormat.parse(activityDateStr).getTime();

				long past_date_6m = new DateTime(new Date()).minusMonths(6).toDate().getTime();

				isOldestActivityPast6M =  (activityDate < past_date_6m); 
			}
		}

//		execution.setVariable("isCallGoPhoneIAP", (isOldestActivityPast6M && isGoPhone));
		
		if(isGoPhone) {
			execution.setVariableLocal("callISH", false);
			if(isOldestActivityPast6M) {
				execution.setVariableLocal("callIAP", true);
			} else {
				execution.setVariableLocal("callIAP", false);
				Map<String,Object> order = (Map<String, Object>) execution.getVariable(CommonConstants.ORDER);
				order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_DENIED,
						CommonConstants.LOSG_SUB_STATUS_GOPHONE_COMMITMENT_6_MONTHS));
				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_GOPHONE_6MONTHS_UNKN);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				execution.setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
				execution.setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
				execution.setVariable("unlockContext", unlockContext);
				execution.setVariable(CommonConstants.ORDER, order);
			}
		} else {
			execution.setVariableLocal("callISH", true);
			execution.setVariableLocal("callIAP", false);
		}
	}

}
