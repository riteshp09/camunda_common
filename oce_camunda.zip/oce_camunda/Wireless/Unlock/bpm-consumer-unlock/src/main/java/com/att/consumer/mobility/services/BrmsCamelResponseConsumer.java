package com.att.consumer.mobility.services;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;

import com.att.ajsc.camel.custom.AbstractCamelConsumer;

public class BrmsCamelResponseConsumer extends AbstractCamelConsumer {

	@Override
	public void execute(Exchange e) {
		System.out.println("BRMS Response handler started..");
		Message msg = e.getIn();
		String inMessageStr = null;
		Map<String, Object> responseWrapper  = new LinkedHashMap<>();
		boolean isFaultResponse;
		
		try {
			inMessageStr = readExchangeMessage(e);
			
			String responseCode =  String.valueOf(msg.getHeaders().get("CamelHttpResponseCode"));
			String camelException = String.valueOf(e.getProperties().get("CamelExceptionCaught") );
			
			System.out.println(e.getProperties());
			System.out.println(msg.getHeaders());
			
		} catch (IOException e1) {
			e1.printStackTrace();
		}

	}

}
