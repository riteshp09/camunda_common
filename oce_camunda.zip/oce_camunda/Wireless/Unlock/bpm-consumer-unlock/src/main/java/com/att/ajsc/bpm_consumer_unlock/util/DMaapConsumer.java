package com.att.ajsc.bpm_consumer_unlock.util;


import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Properties;

import com.att.nsa.mr.client.MRClientFactory;
import com.att.nsa.mr.client.MRConsumer;

public class DMaapConsumer
{

	static FileWriter routeWriter= null;
	static Properties props=null;	
	static FileReader routeReader=null;
	private static String preferredRouteFileName = "preferredRoute.txt";
	private static String consumerProperties = "\\etc\\appprops\\consumer.properties";
	
	public   String  consume()
	{
//		long count = 0;
//		long nextReport = 5;
//
//		final long startMs = System.currentTimeMillis ();
		String messageFromTopic = "";		
		try
		{
			String routeFilePath = preferredRouteFileName;
			String consumerFilePath = System.getProperty("AJSC_CONF_HOME") + consumerProperties;
			
			File fo= new File(routeFilePath);
			if(!fo.exists()){
					routeWriter=new FileWriter(new File (routeFilePath));
			}	
			routeReader= new FileReader(new File (routeFilePath));
			props= new Properties();
			final MRConsumer cc = MRClientFactory.createConsumer( consumerFilePath);
			boolean messageRead = true;
			while ( messageRead )
			{
				for ( String msg : cc.fetch () )
				{
					//System.out.println ( "" + (++count) + ": " + msg );
					System.out.println(msg);
					messageFromTopic = msg;
					messageRead = false;
				}
			}
		}
		catch ( Exception x )
		{
			System.err.println ( x.getClass().getName () + ": " + x.getMessage () );
		}
		return messageFromTopic;
	}
}
