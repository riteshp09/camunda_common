package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.util.HashMap;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;

public class UpdateAssignOrderStatus implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		
		Map<String,String> unlockContext = (Map<String, String>) execution.getVariable("unlockContext");
		Map<String,Object> order = (Map<String, Object>) execution.getVariable(CommonConstants.ORDER);
		
		String eligibilityStatus = unlockContext.get("eligibilityStatus");
		String customerType = unlockContext.get("CustomerType");
		String make = unlockContext.get("Make");
		if(unlockContext.get("LOSGSTATUS")!=null && unlockContext.get("LOSGSTATUS").toString().equalsIgnoreCase(CommonConstants.LOSG_STATUS_IN_QUEUE)){
			execution.setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.FALLOUT_INFO_CATCH_ALL));
			execution.setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
			
		}
		if(unlockContext.get("LOSGSTATUS")!=null && unlockContext.get("LOSGSTATUS").toString().equalsIgnoreCase(CommonConstants.LOSG_STATUS_SYS_PROCESSING))
		{
		if(!CommonConstants.isEmpty(eligibilityStatus) 
				&& CommonConstants.LOSG_SUB_STATUS_DATA_NOT_FOUND.equals(eligibilityStatus)){
			
			if(CommonConstants.MAKE_TYPE_APPLE.equalsIgnoreCase(make)) {
				order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_APPROVED,CommonConstants.LOSG_SUB_STATUS_COMPLETED));
				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_APPROVED);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
				
				execution.setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
				execution.setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
			} else {
				order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idd")));
				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.NO_UNLOCK_CODE_FALLOUT_REASON);
				execution.setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.NO_UNLOCK_CODE_FALLOUT_REASON));
				execution.setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
				
			}
			
			
		} else {
			
			order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_APPROVED,CommonConstants.LOSG_SUB_STATUS_COMPLETED));
			unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_APPROVED);
			if(unlockContext.get("Make")!=null)
			UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
			
			execution.setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
			execution.setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());

		}
	}
	}

}
