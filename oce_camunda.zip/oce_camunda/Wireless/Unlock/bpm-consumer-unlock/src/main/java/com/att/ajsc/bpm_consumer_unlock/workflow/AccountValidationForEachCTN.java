package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.dom.DOMSource;

import org.camunda.bpm.engine.variable.Variables;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.api.response.handler.AbstractCsiApiResponseHandler;
import com.att.oce.bpm.common.JAXBUtil;
import com.csi.v112.container.inquireAccountProfileResponse.InquireAccountProfileResponseInfo;
import com.csi.v112.container.inquireSubscriberProfileResponse.InquireSubscriberProfileResponseInfo;

public class AccountValidationForEachCTN extends AbstractCsiApiResponseHandler{
	static final Logger logger = Logger.getLogger(AccountValidationForEachCTN.class.getName());
	@Override
	public void handleFaultResponse() throws Exception {
		Map<?,?> response = (Map<?, ?>) getException().get("response");

		Map<?,?> svcProviderEntity = (Map<?, ?>) ((ArrayList)getException().get("serviceProviderEntity")).get(0);
		Map<?,?> svcProviderRawErr = (Map<?, ?>) svcProviderEntity.get("serviceProviderRawError");
		String faultcode =  (String) svcProviderEntity.get("faultCode"); 

		//Arrays.asList(skippingErrorCodes).contains(faultcode)
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		String desc = (String) svcProviderRawErr.get("description");
		if(!Arrays.asList(UnlockUtils.skippingErrorCodes).contains(faultcode) || 
				("200".equals(faultcode) && unlockContext.get("CustomerType")!=null 
				&& unlockContext.get("CustomerType").toString().equalsIgnoreCase("NonATT")
				&& unlockContext.get(CommonConstants.PREPAIED_INDICATOR)==null)){
			order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idd")));
			unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
			if(unlockContext.get("Make")!=null)
			UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_CATCH_ALL);
			if(unlockContext.get("CustomerType")!=null  && unlockContext.get("CustomerType").toString().equalsIgnoreCase("Current")){
				if(getExecution().getVariableLocal(CommonConstants.ERRORS)!=null && ((Map<String,Object>)getExecution().getVariableLocal(CommonConstants.ERRORS)).size()==0){
					getExecution().removeVariableLocal(CommonConstants.ERRORS);
				}
				if(getExecution().getVariableLocal(CommonConstants.ORDERTASKS)!=null && ((Map<String,Object>)getExecution().getVariableLocal(CommonConstants.ORDERTASKS)).size()==0){
					getExecution().removeVariableLocal(CommonConstants.ORDERTASKS);
				}
			getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.FALLOUT_INFO_CATCH_ALL));
			getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
			}
			getExecution().setVariableLocal("isloopbreak", "true");
			
			if(unlockContext.get("CustomerType").toString().equalsIgnoreCase("NonATT") && unlockContext.get(CommonConstants.PREPAIED_INDICATOR)==null){
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +(String)getExecution().getVariable("BAN") , CommonConstants.VALUE_SKIPPED);
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_OTHET_ACTIVE_ACCOUNT +(String)getExecution().getVariable("BAN") , CommonConstants.VALUE_SKIPPED);
				
			}else{
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_OTHET_ACTIVE_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
			}
			
			
			logger.info("CSIException : "+desc);
		}
		else{
		if(unlockContext.get("CustomerType")!=null  && unlockContext.get("CustomerType").toString().equalsIgnoreCase("Current")){
			if(Arrays.asList(UnlockUtils.skippingErrorCodes).contains(faultcode)){
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_OTHET_ACTIVE_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_SYS_PROCESSING);
				if(getExecution().getVariableLocal(CommonConstants.ERRORS)==null || ((Map<String,Object>)getExecution().getVariableLocal(CommonConstants.ERRORS)).size()==0){
					getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
				}
				if(getExecution().getVariableLocal(CommonConstants.ORDERTASKS)==null || ((Map<String,Object>)getExecution().getVariableLocal(CommonConstants.ORDERTASKS)).size()==0){
					getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
				}
				/*getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
				getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());*/
				
			}
		}else{
			if(Arrays.asList(UnlockUtils.skippingErrorCodes).contains(faultcode) && unlockContext.get(CommonConstants.PREPAIED_INDICATOR)!=null){
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_OTHET_ACTIVE_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_PRESENT_PAST_DUE_ON_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
				
			}
			if(!"200".equals(faultcode) && unlockContext.get(CommonConstants.PREPAIED_INDICATOR)==null){
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +(String)getExecution().getVariable("BAN") , CommonConstants.VALUE_SKIPPED);
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_OTHET_ACTIVE_ACCOUNT +(String)getExecution().getVariable("BAN") , CommonConstants.VALUE_SKIPPED);
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_PRESENT_PAST_DUE_ON_ACCOUNT +(String)getExecution().getVariable("BAN") , CommonConstants.VALUE_SKIPPED);
			
			}
			
			unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_SYS_PROCESSING);
			
		}
		
		getExecution().setVariableLocal("isloopbreak", "false");
		}
	}
	@Override
	public void handleSuccessResponse() throws Exception {
		// TODO Auto-generated method stub
		String response = getResponse();
		
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		if(unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("NonATT") 
				&& unlockContext.get(CommonConstants.PREPAIED_INDICATOR)==null ){
			getExecution().setVariableLocal("IAPResponse"+"_"+(String)getExecution().getVariable("BAN"), new StringBuffer(response));
		}else{
			getExecution().setVariableLocal("IAPResponse"+"_"+(String)getExecution().getVariable("loopCTN"), new StringBuffer(response));
		}
		 
		boolean isFraudSubscriber=false;
		String accountType ="", subType="";
		if(response!=null && !response.equals("")){
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = null;
			try {
				builder = factory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
				logger.info("Error creating xmlDoc from soap response in AccountValidationForEachCTN "+e.getMessage());  
			}
			Document xmlDocument = builder.parse(new ByteArrayInputStream(response.getBytes()));
			
			accountType = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
					"accountType").item(0).getTextContent(); 
			subType = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
					"accountSubType").item(0).getTextContent();

			if( unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("Current")){
				if(null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberProfileResponse.xsd", 
						"Subscriber")){
					NodeList subscriberList = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberProfileResponse.xsd", 
							"Subscriber");

					Node iapReqNode = JAXBUtil.getDocumentElement(xmlDocument, "http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd", "InquireAccountProfileResponse");
					InquireAccountProfileResponseInfo iapRespponseInfo = JAXBUtil.unmarshalObj(new DOMSource(iapReqNode), InquireAccountProfileResponseInfo.class);
					List<InquireSubscriberProfileResponseInfo> subs= iapRespponseInfo.getAccount().getSubscriber();
					for(InquireSubscriberProfileResponseInfo info:subs) {
						isFraudSubscriber = IsSubscriberFraud(info);
						if(isFraudSubscriber) break;
					}
					
					if(isFraudSubscriber){
						getExecution().setVariableLocal("isloopbreak", "true");
						order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_FRAUD_SUBSCRIBER));
						unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_FRAUD_SUBSCRIBER);
						if(unlockContext.get("Make")!=null)
						UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
						
						UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_YES);
					//	logger.info("Fraud subscriber for CTN "+(String)getExecution().getVariable("loopCTN"));
					}else{
						UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_NO);
						if(xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
								"accountType")!=null && null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
										"accountType").item(0) && 
								xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
										"accountSubType")!=null && null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
												"accountSubType").item(0)){
							/*accountType = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
										"accountType").item(0).getTextContent(); */
							subType = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
									"accountSubType").item(0).getTextContent();
							if(!accountType.equals("")&& accountType.equalsIgnoreCase("B") && !subType.equals("") && subType.equalsIgnoreCase("U")){
								getExecution().setVariableLocal("isloopbreak", "true");
								order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_COU_DEVICE));
								unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
								UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
								UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
								UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_COU_DEVICE);
								if(unlockContext.get("Make")!=null)
								UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
								
							}
						}
					}


				}
				
				
				if(getExecution().getVariableLocal(CommonConstants.ERRORS)==null || ((Map<String,Object>)getExecution().getVariableLocal(CommonConstants.ERRORS)).size()==0){
					getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
				}
				if(getExecution().getVariableLocal(CommonConstants.ORDERTASKS)==null || ((Map<String,Object>)getExecution().getVariableLocal(CommonConstants.ORDERTASKS)).size()==0){
					getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
				}
				
				
				
			}
			//Write code here for gophone and non att both
			if(unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("NonATT") ){
				getExecution().setVariableLocal("isloopbreak", "false");
				//				if(!UnlockUtils.isGoPhone(accountType, subType, unlockContext.get(CommonConstants.PREPAIED_INDICATOR))) {
				Node iapReqNode = JAXBUtil.getDocumentElement(xmlDocument, "http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd", "InquireAccountProfileResponse");

				InquireAccountProfileResponseInfo iapRespponseInfo = JAXBUtil.unmarshalObj(new DOMSource(iapReqNode), InquireAccountProfileResponseInfo.class);
				String pastDue  = String.valueOf(iapRespponseInfo.getAccount().getAccountBilling().getBalance().getTotalAmountPastDue());
				String accountSubtype=iapRespponseInfo.getAccount().getAccountType().getAccountSubType();
				String requestIMEI=UnlockUtils.getReqestedIMEI(order);
				List<InquireSubscriberProfileResponseInfo> subs= iapRespponseInfo.getAccount().getSubscriber();
				String accountSubscriberStatus = null;
				boolean isAnySubscriberFraud = false;
				boolean isAccountCancelledForPastDue = false;
				String loopBAN =  (String)getExecution().getVariable("BAN");
				for(InquireSubscriberProfileResponseInfo info:subs)
				{
					if(info.getSubscriber() != null &&
							info.getSubscriber().getDeviceInformation() != null &&
							info.getSubscriber().getDeviceInformation().getDevice() != null &&
							info.getSubscriber().getDeviceInformation().getDevice().get(0) != null &&
							!CommonConstants.isNull(info.getSubscriber().getDeviceInformation().getDevice().get(0).getIMEI())) {
						String responseIMEI=info.getSubscriber().getDeviceInformation().getDevice().get(0).getIMEI();

						if(requestIMEI.equals(responseIMEI))
						{
							accountSubscriberStatus = info.getSubscriber().getSubscriberStatus().getSubscriberStatus().value();
						}
						isAnySubscriberFraud = IsSubscriberFraud(info);
						if(isAnySubscriberFraud) break;
					}
				}

				isAccountCancelledForPastDue = (!isAnySubscriberFraud && !CommonConstants.isEmpty(accountSubscriberStatus) 
						&& CommonConstants.IAP_RESPONSE_ACCOUNT_STATUS_CANCELLED.equals(accountSubscriberStatus)
						&& Double.valueOf(pastDue) > CommonConstants.PAST_DUE);
				getExecution().setVariable("isAccountCancelledForPastDue", isAccountCancelledForPastDue);
				//					getExecution().setVariable("isAccountCancelledForPastDue", isAccountCancelledForPastDue);

				//account type check.
				boolean accoutTypeCheck = (CommonConstants.ACCOUNT_TYPE_B.equals(accountType) && CommonConstants.ACCOUNT_SUBTYPE_U.equals(subType));
				
				if(isAnySubscriberFraud) {
					getExecution().setVariableLocal("isloopbreak", "true");
					
					order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_FRAUD_SUBSCRIBER));
					unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_FRAUD_SUBSCRIBER);
					if(unlockContext.get("Make")!=null)
					UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					
				//	logger.info("Fraud subscriber for CTN "+(String)getExecution().getVariable("loopCTN"));
					
				} 
				if(isAccountCancelledForPastDue){
					getExecution().setVariableLocal("isloopbreak", "true");
					
					order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_PAST_DUE));
					unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANEEL_REASON_PAST_DUE);
					if(unlockContext.get("Make")!=null)
					UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					
				} 
				if(accoutTypeCheck) {
					getExecution().setVariableLocal("isloopbreak", "true");
					
					
					order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_COU_DEVICE));
					unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_COU_DEVICE);
					if(unlockContext.get("Make")!=null)
					UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					
				}	
				if(isAnySubscriberFraud){
					if(unlockContext.get(CommonConstants.PREPAIED_INDICATOR)!=null){
						UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_YES);
					}else{
						UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +loopBAN , CommonConstants.VALUE_YES);
					}
					
				}else{
					if(unlockContext.get(CommonConstants.PREPAIED_INDICATOR)!=null){
						UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_NO);
					}else{
						UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +loopBAN , CommonConstants.VALUE_NO);
					}
					
					if(isAccountCancelledForPastDue){
						if(unlockContext.get(CommonConstants.PREPAIED_INDICATOR)!=null){
							UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_PRESENT_PAST_DUE_ON_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_YES);
						}else{
							UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_PRESENT_PAST_DUE_ON_ACCOUNT +loopBAN , CommonConstants.VALUE_YES);
						}
						
					}else{
						if(unlockContext.get(CommonConstants.PREPAIED_INDICATOR)!=null){
							UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_PRESENT_PAST_DUE_ON_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_NO);
						}else{
							UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_PRESENT_PAST_DUE_ON_ACCOUNT +loopBAN , CommonConstants.VALUE_NO);
						}
						
					}
				}
				//getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
				//getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
			}
		}else{
			order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idd")));
			unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
			if(unlockContext.get("Make")!=null)
			UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_CATCH_ALL);
			if( unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("Current") ){
				if(getExecution().getVariable(CommonConstants.ERRORS)!=null && ((Map<String,Object>)getExecution().getVariable(CommonConstants.ERRORS)).size()==0){
					getExecution().removeVariable(CommonConstants.ERRORS);
				}
				if(getExecution().getVariable(CommonConstants.ORDERTASKS)!=null && ((Map<String,Object>)getExecution().getVariable(CommonConstants.ORDERTASKS)).size()==0){
					getExecution().removeVariable(CommonConstants.ORDERTASKS);
				}
			getExecution().setVariable(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.FALLOUT_INFO_CATCH_ALL));
			getExecution().setVariable(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
			}
			getExecution().setVariableLocal("isloopbreak", "true");
			if(unlockContext.get(CommonConstants.PREPAIED_INDICATOR)!=null && unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("NonATT") ){
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_OTHET_ACTIVE_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
				
			}
			if(unlockContext.get(CommonConstants.PREPAIED_INDICATOR)==null && unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("NonATT") ){
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +(String)getExecution().getVariable("BAN") , CommonConstants.VALUE_SKIPPED);
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_OTHET_ACTIVE_ACCOUNT +(String)getExecution().getVariable("BAN") , CommonConstants.VALUE_SKIPPED);
				
			}
			if( unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("Current") ){
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
				UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_OTHET_ACTIVE_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
			}
			
		}
		
		getExecution().setVariable(CommonConstants.ORDER, Variables.objectValue(order).
				serializationDataFormat(Variables.SerializationDataFormats.JSON).create());
	}

	public Boolean IsSubscriberFraud(InquireSubscriberProfileResponseInfo info)
	{
		Boolean flag=false;
		if((info.getSubscriber().getSubscriberStatus().getSubscriberStatus().equals(CommonConstants.IAP_RESPONSE_ACCOUNT_STATUS_CANCELLED)) 
				|| info.getSubscriber().getSubscriberStatus().getSubscriberStatus().equals(CommonConstants.IAP_RESPONSE_ACCOUNT_STATUS_SUSPENDED)) {

			if(Arrays.asList(UnlockUtils.statusReasonCodesForFraud).contains(info.getSubscriber().getSubscriberStatus().getStatusReasonCode())) {
				flag=true;
			}

		}
		return flag; 

	}
}