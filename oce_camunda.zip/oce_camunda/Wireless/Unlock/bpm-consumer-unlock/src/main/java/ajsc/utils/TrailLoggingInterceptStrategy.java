package ajsc.utils;

import javax.servlet.http.HttpServletRequest;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.restlet.RestletConstants;
import org.apache.camel.model.ProcessorDefinition;
import org.apache.camel.model.ProcessorDefinitionHelper;
import org.apache.camel.model.RouteDefinition;
import org.apache.camel.processor.DelegateAsyncProcessor;
import org.apache.camel.spi.InterceptStrategy;
import org.apache.commons.collections.CollectionUtils;
import org.restlet.engine.adapter.HttpRequest;
import org.restlet.ext.servlet.internal.ServletCall;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ajsc.csi.logging.PerformanceTrackingBean;

public class TrailLoggingInterceptStrategy implements InterceptStrategy {

	private final static Logger logger = LoggerFactory.getLogger(TrailLoggingInterceptStrategy.class);

	public static final String PROCESSED = "Processed";
	public static final String INPROCESS = "In-Process";
	PerformanceTrackingBean perfTrackerBean = null;

	@Override
	public Processor wrapProcessorInInterceptors(final CamelContext context, final ProcessorDefinition<?> definition,
					final Processor target, final Processor nextTarget) throws Exception {

		return new DelegateAsyncProcessor(new Processor() {

			@Override
			public void process(Exchange exchange) {

				try {
					HttpServletRequest request = null;
					PerformanceTrackingBean perfTrackerBean = null;
					RouteDefinition route = ProcessorDefinitionHelper.getRoute(definition);
					
					if (exchange.getIn().getHeader(Exchange.HTTP_SERVLET_REQUEST, HttpServletRequest.class) != null
							|| exchange.getIn().getHeader(RestletConstants.RESTLET_REQUEST, HttpRequest.class) != null) {
						perfTrackerBean = AjscUtil.getTrackingBean(exchange);
					} else {
						perfTrackerBean = new PerformanceTrackingBean();
						exchange.getOut().setHeader(AjscUtil.PERFORMANCE_TRACKER_BEAN, perfTrackerBean);
					}
					
					if(perfTrackerBean != null){

						if (CollectionUtils.isEmpty(perfTrackerBean.getTrailLog())) {
							MessageHistory initialHeader = new MessageHistory(exchange.getFromEndpoint().getEndpointUri(),route.getId(), 0);
							initialHeader.doneProcessing();
							perfTrackerBean.getTrailLog().add(initialHeader);
						}
	
						int level = perfTrackerBean.getLevel();
						String lastProcessedRoute = perfTrackerBean.getLastProcessedRoute().get(exchange.getExchangeId());
	
						if (lastProcessedRoute == null || !lastProcessedRoute.equals(route.getId())) {
							perfTrackerBean.getLastProcessedRoute().put(exchange.getExchangeId(), route.getId());
							level = level + 1;
							perfTrackerBean.setLevel(level);
						}
	
						MessageHistory myHistory = new MessageHistory(definition.getLabel(), route.getId(), level);
						perfTrackerBean.getTrailLog().add(myHistory);
						target.process(exchange);
						myHistory.doneProcessing();
					}else{
						target.process(exchange);
					}

				} catch (Exception e) {
					System.out.println("Ritesh :: Error");
					e.printStackTrace();
					if (perfTrackerBean != null) {
						for (MessageHistory hist : perfTrackerBean.getTrailLog()) {
							logger.info(hist.getLabel() + "Status: " + (hist.isDone() ? PROCESSED : INPROCESS));
						}
					} else {
						logger.error("Performance Tracking Bean is null");
					}
				}

			}

		}) {

		};

	}

	
}

