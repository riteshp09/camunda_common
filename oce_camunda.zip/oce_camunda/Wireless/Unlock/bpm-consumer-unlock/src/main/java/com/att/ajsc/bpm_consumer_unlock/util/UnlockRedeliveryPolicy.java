package com.att.ajsc.bpm_consumer_unlock.util;

import java.math.BigInteger;
import java.util.List;
import java.util.logging.Logger;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.camel.processor.RedeliveryPolicy;

import com.att.oce.oce.namespaces.config.retry_config.RetryConfigType;

public class UnlockRedeliveryPolicy extends RedeliveryPolicy {
	
	private final static Logger logger = Logger.getLogger(UnlockRedeliveryPolicy.class.getName());

	private static final long serialVersionUID = 1L;
	private String interfaceName;
	private String errorCode;

	protected String prepareDelayPattern(RetryConfigType retryConfig) {
		StringBuffer pattern=null; //5:1000;10:5000:20:20000
		List<BigInteger> intervals = retryConfig.getRetryIntervals();
		for(int i=0;i<intervals.size();i++) {
			int interval = intervals.get(i).intValue();
			interval *=1000;
			if(pattern == null) pattern = new StringBuffer("").append(i).append(":").append(interval).append(";");
			else pattern.append(i).append(":").append(interval).append(";");
		}
		if(pattern.toString().endsWith(";")) {
			pattern.replace(pattern.lastIndexOf(";"), pattern.length(), "");
		}
		return (pattern!=null) ? pattern.toString() : "";
	}

	@Override
	public boolean shouldRedeliver(Exchange exchange, int redeliveryCounter, Predicate retryWhile) {
		logger.info("UnlockRedeliveryPolicy::shouldRedeliver() invoked.");
		
		interfaceName = (String) exchange.getProperties().get(CommonConstants.INTERFACE_NAME);
		errorCode = (String) exchange.getProperties().get(CommonConstants.ERROR_CODE);
		
		logger.info("UnlockRedeliveryPolicy::shouldRedeliver() InterfaceName = " + interfaceName + " ErrorCode = " + errorCode);
		
		RetryConfigType retryConfig = APIConfigurationUtils.getInstance()
				.getMatchingRetryConfig(null ,(errorCode != null && !"".equals(errorCode.trim())) ? errorCode : "200"
					, (interfaceName != null && !"".equals(interfaceName.trim()) ? interfaceName : "AddNote"));
		if(retryConfig != null) { 
			if(retryConfig.getRetry() != null && 
				"yes".equalsIgnoreCase(retryConfig.getRetry())) {
				logger.info("UnlockRedeliveryPolicy::shouldRedeliver():: setMaximumRedeliveries = " + retryConfig.getRetryCount().intValue());
				super.setMaximumRedeliveries(retryConfig.getRetryCount().intValue());
				return "yes".equalsIgnoreCase(retryConfig.getRetry()) && super.shouldRedeliver(exchange, redeliveryCounter, retryWhile);
			} else
				return false;
		} else 
			return super.shouldRedeliver(exchange, redeliveryCounter, retryWhile);
	}

	@Override
	public long calculateRedeliveryDelay(long previousDelay, int redeliveryCounter) {
		logger.info("UnlockRedeliveryPolicy::shouldRedeliver():: " + "errorcode = " + errorCode + " interfacename= " + interfaceName);
		System.out.println();

		long redeliveryDelayResult;
		RetryConfigType retryConfig = APIConfigurationUtils.getInstance()
				.getMatchingRetryConfig(null ,errorCode, interfaceName);
		logger.info("RetryConfig = " + retryConfig);
		if(retryConfig!= null && "yes".equalsIgnoreCase(retryConfig.getRetry())) {
			logger.info("Retry Config :: " + retryConfig.getRetry());
			logger.info("Retry Config :: " + retryConfig.getRetryIntervals());
			super.setMaximumRedeliveries(retryConfig.getRetryCount().intValue());
			if(redeliveryCounter <= retryConfig.getRetryCount().intValue())
				redeliveryDelayResult = retryConfig.getRetryIntervals().get(redeliveryCounter-1).longValue();
			else
				redeliveryDelayResult = retryConfig.getRetryIntervals().get(0).longValue();
		} else
			return super.calculateRedeliveryDelay(previousDelay, redeliveryCounter);
		
		redeliveryDelayResult *= 1000;
		logger.info("Set redeliveryDelayResult = " + redeliveryDelayResult +"ms");
		return redeliveryDelayResult;
	}

}
