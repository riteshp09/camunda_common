package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.camunda.bpm.engine.variable.Variables;
import org.json.JSONObject;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.api.response.handler.AbstractAtgApiResponseHandler;

public class CreateOrderResponseValidator extends AbstractAtgApiResponseHandler /*implements JavaDelegate*/ {

	static final Logger logger = Logger.getLogger(CreateOrderResponseValidator.class.getName());

	@Override
	public void handleSuccessResponse() throws Exception {
		String response = getResponse(); /*getExecution().getVariable("createOrderResponse").toString();*/
		getExecution().setVariable("createOrderResponse", new StringBuffer(response));

		if(response!=null ){
			Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);

			
			JSONObject jsonObject = new JSONObject(response);

			//Set OCEOrderNumber in order
			String OCEordernumber =  (String) jsonObject.get("OrderNumber");

			order.put("OCEOrderNumber", OCEordernumber);
		
			//Check for Fraud, Bulk or Denied 
			getExecution().setVariableLocal("isFraudCheckRequired", UnlockUtils.isFraudCheckRequired(order));
			getExecution().setVariableLocal("isBulkAutomationRequired", UnlockUtils.isBulkAutomationRequired(order));
			getExecution().setVariableLocal("isNoAutomation", UnlockUtils.isNoAutomation(order));

			getExecution().setVariableLocal(CommonConstants.ORDER, Variables.objectValue(order).
					serializationDataFormat(Variables.SerializationDataFormats.JSON).create());
		}
		getExecution().setVariableLocal("isDuplicateOrder", Boolean.valueOf(false));
	}

	@Override
	public void handleFaultResponse() throws Exception {
		super.handleFaultResponse();
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		String orderType = (String) order.get("OrderType");
	
		LinkedHashMap<String,Object> errors = null;
		Map<?,?> error =null;
		if(getException().get("Errors")!=null){
			 errors = (LinkedHashMap<String,Object>) getException().get("Errors");
			 error =  (Map<?, ?>) ((ArrayList) errors.get("Error")).get(0);
		}
		
		String errorDesc = error.get("ErrorDescription")!=null?(String) error.get("ErrorDescription"):"Request Failed";
		
		if("Duplicate Order".equals(errorDesc) && "CREATE".equalsIgnoreCase(orderType)) {
			String oceOrderNo = (String) getException().get("OrderNumber");
			order.put("OCEOrderNumber", oceOrderNo);
			getExecution().setVariableLocal("isDuplicateOrder", Boolean.valueOf(true));
		} else {
			String oceOrderNo = (String) getException().get("OrderNumber");
			order.put("OCEOrderNumber", oceOrderNo);
			logger.info("Order :"+order);
			getExecution().setVariableLocal("isDuplicateOrder", Boolean.valueOf(false));
		}
		
		
		//Check for Fraud, Bulk or Denied 
		getExecution().setVariableLocal("isFraudCheckRequired", UnlockUtils.isFraudCheckRequired(order));
		getExecution().setVariableLocal("isBulkAutomationRequired", UnlockUtils.isBulkAutomationRequired(order));
		getExecution().setVariableLocal("isNoAutomation", UnlockUtils.isNoAutomation(order));

	}
}
