package com.att.ajsc.bpm_consumer_unlock;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.camunda.bpm.engine.impl.history.event.HistoricActivityInstanceEventEntity;

public class AttCamundaService {
	
	
	private static HttpServletRequest httpRequest;
	

	public static HttpServletRequest getHttpRequest() {
		return httpRequest;
	}

	public static void setHttpRequest(HttpServletRequest httpRequest) {
		AttCamundaService.httpRequest = httpRequest;
	}
    
}