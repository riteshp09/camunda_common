package com.att.ajsc.camel.custom.typeconverters;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Converter;
import org.apache.camel.TypeConversionException;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.bpm.common.VelocityHelper;

public class InquireOrderResponseConvertor{

	@Converter
	public LinkedHashMap<String, Object> convertTo(String value) throws TypeConversionException {
		System.out.println("InquireOrderResponseConvertor::convertTo():: " + value);
		
		LinkedHashMap<String, Object> inquireOrderResponseMap = (LinkedHashMap<String, Object>) VelocityHelper.jsonToMap(value);
		
		String total = ((Map<?,?>)  inquireOrderResponseMap.get("MetaInformation")).get("Total").toString();
		
		
		boolean isDupliateOrder = (total != null && !"".equals(total.trim()) && Integer.parseInt(total) > 0);
		inquireOrderResponseMap.put("isDuplicateOrder", isDupliateOrder);
		inquireOrderResponseMap.put("isStatus_Denied_Approved_InQueue",false);
		if(isDupliateOrder) {
			List<?> orderDetails = (List<?>) inquireOrderResponseMap.get("OrderDetails");
			Map<?,?> order =  (Map<?, ?>) ((Map<?,?>)orderDetails.get(0)).get("Order");
			Map<String,String> losgStatus = UnlockUtils.getLOSGStatusSubStatus(order);
			
			String status = losgStatus.get("Status");
			
			inquireOrderResponseMap.put("isStatus_Denied_Approved_InQueue", (CommonConstants.LOSG_STATUS_DENIED.equals(status) 
						|| CommonConstants.LOSG_STATUS_APPROVED.equals(status)
						|| CommonConstants.LOSG_STATUS_IN_QUEUE.equals(status)));
			
		}
		
		
		return inquireOrderResponseMap;
	}
}
