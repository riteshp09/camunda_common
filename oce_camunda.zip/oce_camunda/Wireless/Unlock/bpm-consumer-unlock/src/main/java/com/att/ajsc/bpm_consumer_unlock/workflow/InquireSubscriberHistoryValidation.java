package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.transform.dom.DOMSource;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.oce.api.response.handler.AbstractCsiApiResponseHandler;
import com.att.oce.bpm.common.JAXBUtil;
import com.csi.v112.container.inquireAccountProfileRequest.InquireAccountProfileRequestInfo;
import com.csi.v112.container.inquireAccountProfileRequest.InquireAccountProfileRequestInfo.AccountOrSubscriptionIDSelector;
import com.csi.v112.container.inquireSubscriberHistoryResponse.InquireSubscriberHistoryResponseInfo;
import com.csi.v112.container.inquireSubscriberHistoryResponse.InquireSubscriberHistoryResponseInfo.HistoryProfiles.BillingAccountHistory;
import com.csi.v112.types.cingularDataModel.AccountSelectorInfo;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
public class InquireSubscriberHistoryValidation extends AbstractCsiApiResponseHandler {

	@Override
	public void handleSuccessResponse() throws Exception {
		// TODO Auto-generated method stub
		String response = getResponse();
		getExecution().setVariable("getISHResponse_"+(String)getExecution().getVariable("loopCTN"), new StringBuffer(response));
//		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
//		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
//		Map<String, Object>  groups =  (Map<String, Object>)order.get("Groups");
		
		Document xmlDoc = JAXBUtil.getXMLDocument(response);
		Node ishNode = JAXBUtil.getDocumentElement(xmlDoc, 
				"http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberHistoryResponse.xsd", 
				"InquireSubscriberHistoryResponse");
		InquireSubscriberHistoryResponseInfo ishResponse = JAXBUtil.unmarshalObj(new DOMSource(ishNode)
				, InquireSubscriberHistoryResponseInfo.class);
		
		List<String> banList = new ArrayList<>();
		
		List<BillingAccountHistory> baList = ishResponse.getHistoryProfiles().getBillingAccountHistory();
		for (BillingAccountHistory billingAccountHistory : baList) {
			banList.add(billingAccountHistory.getBillingAccountNumber());
		}
		getExecution().setVariable("banList", banList);
		getExecution().setVariableLocal("skipExceptionFlag", false);
	
	}

	@Override
	public void handleFaultResponse() throws Exception {
		// TODO Auto-generated method stub
		Map<?,?> svcProviderEntity = (Map<?, ?>) ((ArrayList)getException().get("serviceProviderEntity")).get(0);
		Map<?,?> svcProviderRawErr = (Map<?, ?>) svcProviderEntity.get("serviceProviderRawError");
		String faultcode =  (String) svcProviderEntity.get("faultCode");
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		String svcProviderRawErrorCode = (String) svcProviderRawErr.get("code");
		getExecution().setVariableLocal("skipExceptionFlag", true);
		if(!CommonConstants.isNull(faultcode) && !"30001794006".equals(faultcode)) { 	
			
			UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
			UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_PRESENT_PAST_DUE_ON_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
			getExecution().setVariableLocal("isloopbreak", "false");
			unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_SYS_PROCESSING);
		
		} else{	
			super.handleFaultResponse();
			UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_LINKED_TO_FRAUDULRNT_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
			UnlockUtils.createAutomationSummary(order, CommonConstants.PREVIOUS_SUBSCRIBER_TYPE , CommonConstants.CODE_PRESENT_PAST_DUE_ON_ACCOUNT +(String)getExecution().getVariable("loopCTN") , CommonConstants.VALUE_SKIPPED);
			getExecution().setVariableLocal("isloopbreak", "true");
			/*order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idd")));
			unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);*/
			if(unlockContext.get("Make")!=null)
			UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_CATCH_ALL);
		
		}
		
	}

}
