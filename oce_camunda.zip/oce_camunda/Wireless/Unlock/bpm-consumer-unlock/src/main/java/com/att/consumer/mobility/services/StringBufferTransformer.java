package com.att.consumer.mobility.services;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.converter.stream.InputStreamCache;

public class StringBufferTransformer {

	
	public void transform(Exchange e){
		System.out.println("Inside StringBufferTransformer");
		Message msg = e.getIn();
		StringBuffer inMessageStr = null;
		
		try {
			if (msg.getBody() instanceof String) {
				inMessageStr = new StringBuffer().append(msg.getBody());
			} else {
				InputStreamCache msgCache = (InputStreamCache) msg.getBody();
				byte[] content = new byte[msgCache.available()];
				msgCache.read(content);
				inMessageStr = new StringBuffer().append(content);
			}
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		
		msg.setBody(inMessageStr);
		e.setOut(msg);
	}
}
