package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.camunda.bpm.engine.variable.Variables;
import org.w3c.dom.Document;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.api.response.handler.AbstractCsiApiResponseHandler;


public class DeviceAlreadyUnlockValidator extends AbstractCsiApiResponseHandler /*implements JavaDelegate*/ {

	static final Logger logger = Logger.getLogger(DeviceAlreadyUnlockValidator.class.getName());
	
	
	
	@Override
	public void handleFaultResponse() throws Exception {
		/*int idsCallCount = 1;
		if(getExecution().getVariable("idsCallCount") != null && !"".equals(getExecution().getVariable("idsCallCount"))) {
			idsCallCount = (Integer) getExecution().getVariable("idsCallCount");
		} else {
			 getExecution().setVariable("idsCallCount", idsCallCount);
		}
		if(idsCallCount == 2) {
			super.handleFaultResponse();
		}*/
	}



	@Override
	public void handleSuccessResponse() throws Exception {
		// TODO Auto-generated method stub
		String response =  getResponse(); //(String) execution.getVariable("idsResponse");
		getExecution().setVariable("idsResponse", new StringBuffer(response));
		//UnlockUtils unlockUtils = new UnlockUtils();
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		if(response!=null && !response.equals("")){
			
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = null;
			try {
			    builder = factory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
			    logger.info("Error creating xmlDoc from soap response in DeviceAlreadyUnlockValidator "+e.getMessage());  
			}
			Document xmlDocument = builder.parse(new ByteArrayInputStream(response.getBytes()));
			//XPath xPath =  XPathFactory.newInstance().newXPath();
			String statusDescription ="";
			String statusDescriptionlowercase = "";
			if(xmlDocument.getElementsByTagName("statusDescription")!=null && xmlDocument.getElementsByTagName("statusDescription").item(0)!=null){
				statusDescription = xmlDocument.getElementsByTagName("statusDescription").item(0).getTextContent();
				 statusDescriptionlowercase = xmlDocument.getElementsByTagName("statusDescription").item(0).getTextContent();
				 statusDescriptionlowercase=statusDescriptionlowercase.toLowerCase();
			}
			 

	      
	        String message = "";
	        if(xmlDocument.getElementsByTagName("message")!=null && xmlDocument.getElementsByTagName("message").item(0)!=null){
			 message = xmlDocument.getElementsByTagName("message").item(0).getTextContent();		
	        }
	       
	        if((statusDescription!=null && !statusDescription.equals("") && statusDescription.equalsIgnoreCase(CommonConstants.DEVICE_UNLOCKED)) 
	        		|| (statusDescriptionlowercase!=null && !statusDescriptionlowercase.equals("") && statusDescriptionlowercase.contains("unlocked"))
	        		|| (message!=null && !message.equals("") && message.equalsIgnoreCase(CommonConstants.AL_PENDING_UNLOCK))){
	        	
	        	 order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_APPROVED,CommonConstants.LOSG_SUBSTATUS_TORCH_APPLE_COMPLETED));
	        		/*UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
					 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
					 if(unlockContext.get("Make")!=null)
					 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));*/
	    		   unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_APPROVED);
	    		   UnlockUtils.createAutomationSummary(order, CommonConstants.ELIGIBILITY_CHECK_TYPE , CommonConstants.UNLOCK_STATUS_CODE , CommonConstants.VALUE_UNLOCK);
	    		   unlockContext.put("isDeviceAlreadyUnlock", CommonConstants.VALUE_TRUE);
	    		   logger.info("IDS response message :"+message);
	    		   logger.info("IDS response statusDescription :"+statusDescription);
	        }
		}
		getExecution().setVariableLocal(CommonConstants.ORDER, Variables.objectValue(order).
				serializationDataFormat(Variables.SerializationDataFormats.JSON).create());
	}


}
