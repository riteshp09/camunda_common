package com.att.ajsc.bpm_consumer_unlock.util;

import java.text.SimpleDateFormat;
import java.util.HashMap;

import javax.xml.namespace.QName;



public class CommonConstants {
	
	public static final String ORDER = "order";
	public static final String CSI_ENV_PROPERTIES = "csi_env.properties";
	public static final String WEB_SERVICE_PROPERTIES = "webServiceConfig.properties";
	public static final String ATG_TASK_Q_PROPERTIES = "AtgTaskQueueConstant.properties";
	
	public static final String INTERFACE_NAME = "interfaceName"	;
	public static final String ORDER_EQUIPMENT = "OrderEquipment";
	public static final String CONTENT_TYPE_XML = "text/xml";
	public static final String CAMUNDA_APPLICATION_NAME = "CAMUNDA";
	
	public static final String LOSG_STATUS = "LoSGStatus";
	public static final String LOSG_SUB_STATUS = "LoSGSubStatus";
	public static final String CSI_FAULT_CODE = "CSI_FAULT";
	
	public static final String LOSG_STATUS_SUBMITTED = "SUBMITTED";
	public static final String LOSG_STATUS_SYS_PROCESSING = "SYS_PROCESSING";
	public static final String LOSG_STATUS_PENDING = "PENDING";
	public static final String LOSG_SUB_STATUS_OE_PASS = "ORDER_EQUIPMENT_PASS";  
	public static final String LOSG_SUB_STATUS_OE_MANUAL = "ORDER_EQUIPMENT_MANUAL";
	public static final String LOSG_SS_EMAIL_CONFIRMED = "EMAIL_CONFIRMED";
	public static final String LOSG_SS_EMAIL_CONFIRMATION = "EMAIL_CONFIRMATION";
	
	public static final String YODA_ID = "YODA_ID";
	public static final String OE_SUCCESS = "isYodaIdExist";
	
	public static final String CUST_ORDER_NUM = "CustomerOrderNumber";
	public static final String REQUEST_ID = "RequestId";
	public static final String ORDER_ACTION="orderAction"; 
	public static final String IS_UNLOCK="isUnlockOrder";
	public static final String LOSGTYPE_UNLOCK="UNLOCK";
	public static final String PRODUCT_CATEGORY_WIRELESS ="WIRELESS";
	public static final String CHANNEL_UNLOCK="UNLOCK";
	public static final String losgStatus = "losgstatus";
	public static final String ORDERSTATUS_RECEIVED = "RECEIVED";
	public static final String ORDERACTION_CREATE = "CREATE";
	public static final String ORDERACTION_UPDATE = "UPDATE";
	public static final String ENTERPRISE_CRU = "CRU";
	public static final String ACCSUBCAT_EXISTING = "EXISTING";
	public static final String ACCSUBCAT_ANONYMOUS = "ANONYMOUS";
	public static final String PaymentArrangement = "PaymentArrangement";
	public static final String EnterpriseType = "EnterpriseType";
	public static final String PAYMENTARRANGEMENT_POSTPAID = "POSTPAID";
	public static final String ENTERPRISE_NON_CUSTOMER = "CON";
	
	public static final String ATGUpdateOrderUpdated="OrderUpdatedinATG";
	public static final String CURRENT_CUSTOMER_TYPE ="EXISTING";
	
	//constants related to fraud validation
	public static final String LOSG_STATUS_FRAUD_PASS = "FRAUD_VALIDATION_PASSED";
	public static final String MAKE_TYPE_APPLE = "APPLE";
	public static final String MAKE_TYPE_NOKIA = "NOKIA";
	public static final String MAKE_TYPE_NON_APPLE = "NON_APPLE";
	public static final String LOSG_SUBSTATUS_APPLE_VERIFIED = "APPLE_VERIFIED";
	public static final String LOSG_SUBSTATUS_NOKIA_VERIFIED = "NOKIA_VERIFIED";
	public static final String LOSG_SUBSTATUS_NON_APPLE_VERIFIED = "NON_APPLE_VERIFIED";
	public static final String LOSG_SUBSTATUS_UNVERIFIED = "UNABLE_TO_VERIFY";
	public static final String SECTION_ELIGIBILITY_CHECK = "Eligibility Check";
	public static final String CODE_FRAUD_CHECK = "Fraud_Check";
	public static final String VALUE_PASSED = "Passed";
	public static final String VALUE_FAILED = "Failed";
	public static final String VALUE_SKIPPED="Skipped";
	public static final String VALUE_TRUE = "true";
	public static final String VALUE_FALSE = "false";
	public static final String FRAUD_VALIDATION_FAILED_BRMS = "Fraud Validation Failed";
	public static final String AUTOMATION_FLAG = "AUTOMATION_FLAG";
	public static final String CANCELED_BY_AUTOMATION = "CANCELED_BY_AUTOMATION";
	public static final String CANCELED_REASON = "CANCELED_REASON";
	public static final String FALLOUT_INFO = "FALLOUT_INFO";
	public static final String PHONE_TYPE = "PHONE_TYPE";
	public static final String ACC_TYPE_I="I";
	public static final String ACC_TYPE_S="S";
	public static final String SUB_TYPE_G="G";
	public static final String SUB_TYPE_H="H";
	public static final String SUB_TYPE_R="R";
	public static final String ACC_TYPE="accType";
	public static final String SUB_TYPE="subType";
	public static boolean isEmpty(String value) {
		return !(value != null && !"".equals(value) && !"null".equalsIgnoreCase(value));
	}
	
	public static boolean isNull(Object object) {
		if(object instanceof String)
			return isEmpty((String)object);
		return (object == null);
	}
	
	//public static final SimpleDateFormat US_DATE_FORMAT = new SimpleDateFormat("mm/dd/yyyy");
	public static final String _RESPONSE = "_Response";
	public static final String _REQUEST = "_Request";
	public static final String ORDER_EQUIPMENT_REQUEST = ORDER_EQUIPMENT + _REQUEST;
	public static final String JSON_CONTENT_TYPE = "application/json";
	
	public static HashMap<String, String> CREDITCARD_TYPE_MAP = new HashMap<String, String>();
	public static HashMap<String, String> ACCOUNT_TYPE_MAP = new HashMap<String, String>();
	
	public static final QName ATG_QNAME = 
			new QName("http://www.att.com/ooce/core", "ProcessOrderRequest");
	
	public static final QName CSI_FAULT_QNAME = 
			new QName("http://csi.cingular.com/CSI/Namespaces/Types/Public/SoapFaultDetails.xsd", "CSIApplicationException");
	
	public static final QName ATG_CREATE_TASK_RESPONSE_QNAME = 
			new QName("http://www.att.com/ooce/core", "Response");
	public static final QName ATG_INQUIRE_RESPONSE_QNAME = 
			new QName("http://www.att.com/ooce/core", "OrderResponse");
	
	public static final QName ATG_INQ_QNAME = 
			new QName( "String");
	public static final String PROCESS_ORDER_REQUEST = "ProcessOrderRequest";
	public static final String DEFAULT = "default";
	public static final String COUNTRY_US = "US";
	public static final String BULK_UNLOCK_JOB_NAME = "BULK_UNLOCK_JOB_NAME";
	
	//LOSG status sub status
	public static final String LOSG_STATUS_DENIED = "DENIED";
	public static final String LOSG_STATUS_IN_QUEUE = "IN_QUEUE";
	public static final String LOSG_STATUS_APPROVED = "APPROVED";
	//public static final String LOSG_SUB_STATUS_NOT_ATT_IMEI = "NOT_ATT_IMEI";
	public static final String LOSG_SUB_STATUS_FRAUD_SUBSCRIBER = "FRAUD_SUBSCRIBER";
	
	public static final String OCE_ORDER_NO = "OCEOrderNumber";
	public static final String LOSG_SUBSTATUS_GOPHONE_VERIFIED = "GOPHONE_VERIFIED";
	public static final String LOSG_SUBSTATUS_GOPHONE_UNVERIFIED = "GOPHONE_UNVERIFIED";
	public static final String LOSG_SUBSTATUS_APPLE_UNVERIFIED = "APPLE_UNVERIFIED";
	public static final String LOSG_SUBSTATUS_NOKIA_UNVERIFIED = "NOKIA_UNVERIFIED";
	public static final String LOSG_SUBSTATUS_NON_APPLE_UNVERIFIED = "NON_APPLE_UNVERIFIED";
	public static final String LOSG_SUBSTATUS_REQUIRES_CRU_SUBMITTER_VALIDATION="REQUIRES_CRU_SUBMITTER_VALIDATION";
	public static final String LOSG_SUBSTATUS_TORCH_APPLE_COMPLETED="TORCH_APPLE_COMPLETED";
	public static final String LOSG_SUBSTATUS_NON_ATT_IMEI="NON_ATT_IMEI";
	public static final String LOSG_SUBSTATUS_COMPLETED="COMPLETED";
	
	public static final String DEVICE_UNLOCKED = "DEVICE_UNLOCKED";
	public static final String AL_PENDING_UNLOCK = "AL_PENDING_UNLOCK";
	public static final String SUCCESS="SUCCESS";
	public static final String FAILURE="Failure";
	public static final String LOSG_SUBSTATUS_TORCH_APPLE_FAILED = "TORCH_APPLE_FAILED";
	public static final String AL_BAD_REQUEST = "AL_BAD_REQUEST";
	public static final String LOSG_SUB_STATUS_GO_PHONE_REQUIRED = "GO_PHONE_REQUIRED";
	public static final String LOSG_SUB_STATUS_CRU_FLOW_REQUIRED = "CRU_FLOW_REQUIRED";
	public static final String LOSG_SUB_STATUS_CONSUMER_IRU = "CONSUMER_IRU";
	public static final String LOSG_SUB_STATUS_UNVERIFIED = "UNVERIFIED";
	public static final String LOSG_SUB_STATUS_DATA_NOT_FOUND = "DATA_NOT_FOUND";
	public static final String LOSG_SUB_STATUS_GOPHONE_COMMITMENT_6_MONTHS = "GOPHONE_COMMITMENT_6_MONTHS";
	public static final String LOSG_SUB_STATUS_UNABLE_TO_VERIFY = "UNABLE_TO_VERIFY";
	public static final String LOSG_SUB_STATUS_PAST_DUE = "PAST_DUE";
	public static final String LOSG_SUB_STATUS_ACCOUNT_ACTIVE_60_DAYS = "ACCOUNT_ACTIVE_60_DAYS";
	public static final String LOSG_SUB_STATUS_APPLE_COMPLETED="APPLE_COMPLETED";
	public static final String NO_UNLOCK_CODE_FALLOUT_REASON = "Eligible, Unlock Code needs manually pulled";
	public static final String CRU_FALLOUT_REASON = "CRU Account";
		public static final String ERRORS = "Errors";
	public static final String ORDERTASKS = "OrderTasks";
	
	public static final String IS_REVIEW = "isReview";
	public static final String IS_FAULT_RESPONSE = "isFaultResponse";
	public static final String ERROR_CODE = "errorCode";
	public static final String ELIGIBLE = "ELIGIBLE";
	public static final String INELIGIBLE = "INELIGIBLE";
	public static final String UNLOCK_CODE = "UnlockCode";
	public static final String ELIGIBILITY_UNKNOWN = "UNKNOWN";
	public static final String PREPAIED_INDICATOR = "prepaidIndicator";
	public static final String LOSG_SUB_STATUS_LOST_STOLEN = "LOST_STOLEN";
	public static final String LOSG_SUB_STATUS_IN_BRE_PERIOD = "IN_BRE_PERIOD";
	public static final String LOSG_SUB_STATUS_MILITARY_VERIFICATION = "MILITARY_VERIFICATION";
	public static final String LOSG_SUB_STATUS_SUBSIDY_SERVICE_COMMITMENT_NOT_MET = "SUBSIDY_SERVICE_COMMITMENT_NOT_MET";
	public static final String LOSG_SUB_STATUS_ATT_NEXT_SERVICE_COMMITMENT_NOT_MET = "ATT_NEXT_SERVICE_COMMITMENT_NOT_MET";
	public static final String LOSG_SUB_STATUS_COMPLETED = "COMPLETED";
	public static final String FALLOUT_INFO_B4_IDUE = "Order failed at CSI exception prior to VID";
	public static final String FALLOUT_INFO_AFTER_IDUE = "Order failed at OCE exception post VID";
	public static final String ADDNOTE_TEXT = "noteText";
	public static final String INELIGIBLE_REASON_CODE_1_FALLOUT_INFO = "No Unlock Code";
	public static final String CANCEL_REASON_LOST_STOLEN = "IMEI reported lost or stolen";
	public static final String CANCEL_REASON_IN_BRE_PERIOD = "BRE period is not yet passed";
	public static final String CANCEL_REASON_SUBSIDY_SERVICE_COMMITMENT_NOT_MET = "Service Commitment not met";
	public static final String CANCEL_REASON_ATT_NEXT_SERVICE_COMMITMENT_NOT_MET = "ATT Next remaining payments due";
	public static final String FALLOUT_INFO_CRU_IN_BRE_PERIOD = "Ineligible for BRE - CRU Manual Validation needed";
	public static final String FALLOUT_INFO_MILITARY_VERIFICATION = "Customer notified to send a copy of deployment orders";
	public static final String FALLOUT_INFO_CRU_SUBSIDY_COMMITMENT = "Ineligible for Service Commitment - CRU Manual Validation needed";
	public static final String FALLOUT_INFO_CRU_ATT_NEXT_COMMITMENT = "Ineligible for ATT Next Service Commitment- CRU Manual Validation needed";
	public static final String CANCEL_REASON_MAKE_MISMATCH = "Order submitted through BOTS";
	public static final String CANCEL_REASON_NON_ATT_IMEI = "NON-ATT Device";
	public static final String CANCEL_REASON_GOPHONE_6MONTHS_UNKN = "Device Eligibility is Unknown with Go Phone Account Active more than 6 Months";
	public static final String FALLOUT_INFO_TORCH_APPLE_FAILED = "Error while submitting unlock request to TORCH";
	public static final String CODE_ANY_NW_ACTIVITY_PRESENT_ON_DEVICE = "Any N/W Activity Present on device?";
	public static final String VALUE_NO = "No";
	public static final String CANCELLED_REASON_PASSCODE_MISMATCH = "Passcode did not match in TLG";
	public static final String CANCELLED_REASON_LAST4BAN_MISMATCH = "Last 4 of BAN did not match in TLG";
	public static final String CANCELLED_REASON_LAST4SSN_MISMATCH = "Last 4 of SSN did not match in TLG";
	public static final String CANCELLED_REASON_LASTNAME_MISMATCH = "Lastname did not match in TLG";
	public static final String CANCELLED_REASON_MARKET_MISMATCH = "Billing market not found in TLG";
	public static final String CANCELLED_REASON_ACCOUNTSUBTYPE_MISMATCH = "Account SubType did not match in TLG";
	public static final String CANCELLED_REASON_ACCOUNT_ACTIVE_60_DAYS = "Account not active for 60 days";
	public static final String CANCELLED_REASON_BAN_NOT_FOUND = "BAN not found in TLG";
	public static final String CANCELLED_REASON_PAST_DUE = "Past due amount on account";
	public static final String CANCELLED_REASON_ACCOUNT_NOT_FOUND = "InValid ATT Account";
	public static final String DUPLICATE_ORDER_RESPONSE = "Duplicate Order";
	public static final String CONNECTION_ERR_CODE = "404";
	public static final String SYSTEM_ERROR = "System Error";
	public static final String URN_MAPPING_PROPS = "urn-mappings.properties";
	public static final String OCE_USER_NAME_PROPERTY = "commonCsiServicesUsername";
	public static final String OCE_PASSWORD_PROPERTY = "commonCsiServicesPassword";
	public static final String OCE_CSI_VERSION_PROPERTY = "CSIVersion";
	public static final String OCE_CSI_TTL_PROPERTY = "ttl";
	public static final String FALLOUT_INFO_NO_NW_ACT="No Network Activity Present on Device";
	public static final String CANCEL_REASON_GOPHONE_6MONTHS_COMMITMENT="Device has not been active for at least 6 months";
	public static final String FALLOUT_INFO_NO_NW_ACT_DATA_NOT_FOUND = "No Unlock code and Network Activity Found";
	public static final String VALUE_YES = "Yes";
	public static final String ANY_NW_ACTIVITY_PRESENT = "ANY_NW_ACTIVITY_PRESENT";
	public static final String FALLOUT_INFO_IMEI_ACTIVE_OTHER = "IMEI ACTIVE Other check failed";
	public static final String LOSG_SUB_STATUS_IMEI_ACTIVE_OTHER = "IMEI_ACTIVE_OTHER";
	public static final String CANCEL_REASON_IMEI_ACTIVE_OTHER = "IMEI Active Other";
	public static final String FALLOUT_INFO_CATCH_ALL = "Order failed at CSI exception prior to VID";
	public static final String LOSG_SUB_STATUS_COU_DEVICE = "COU_DEVICE";
	public static final String CANCEL_REASON_COU_DEVICE = "COU Device";
	public static final String CANCEL_REASON_FRAUD_SUBSCRIBER = "Fraud activity on the subscriber noted";
	public static final String CANEEL_REASON_PAST_DUE = "Past due amount on account";
	
	public static final String IAP_RESPONSE_ACCOUNT_STATUS_CANCELLED="C";
	public static final String IAP_RESPONSE_ACCOUNT_STATUS_SUSPENDED="S";
	public static final String IAP_RESPONSE_SUBSCRIBER_STATUS_ACTIVE="A";
	public static final double PAST_DUE=0.0;
	public static final String ACCOUNT_TYPE_B="B";
	public static final String ACCOUNT_TYPE_G="G";
	public static final String ACCOUNT_SUBTYPE_U="U";
	public static final String LOSG_SUB_STATUS_ISP_REQUIRED = "ISP_REQUIRED";
	public static final String ACC_AUTH_TYPE = "Account Authentication";
	public static final String BAN_CODE = "BAN";
	public static final String ACC_VALIDATION_TYPE = "Account Validation";
	public static final String PASTDUE_CODE = "Past Dues";
	public static final String ACC_CREATE_60 = "Account Created more than 60 days ago?";
	public static final String PASSCODE_CODE = "Passcode";
	public static final String CODE_LASTNAME_AND_LAST4OFSSN = "Last Name,Last 4 of SSN";
	public static final String CODE_LAST4OFSIM_NUMBER_AND_LAST4OFBAN = "Last 4 of BAN";
	public static final String ELIGIBILITY_CHECK_TYPE = "Eligibility Check";
	public static final String ELIGIBILITY_CHECK_CODE = "Device Eligibility";
	public static final String VALUE_DATA_NOT_FOUND = "DATA NOT FOUND";
	public static final String FALLOUT_INFO_FRAUD_VAL_FAILED = "Farud Validation Failed";
	public static final String UNLOCK_STATUS_CODE = "Unlocked Status";
	public static final String VALUE_UNLOCK = "UNLOCK";
	public static final String DEVICE_VALIDATION_TYPE = "Device Validation";
	public static final String PREVIOUS_SUBSCRIBER_TYPE = "Previous Subscriber";
	public static final String CODE_LINKED_TO_FRAUDULRNT_ACCOUNT = "Linked to Fraudulent Account-";
	public static final String CODE_LINKED_TO_OTHET_ACTIVE_ACCOUNT = "Linked to other Active Account-";
	public static final String CODE_PRESENT_PAST_DUE_ON_ACCOUNT = "Present Past Due on Account-";
	
	public static SimpleDateFormat usDateFormat = new SimpleDateFormat("yyyy-MM-dd'Z'"); //2014-01-16Z
	
	public static final int DiffContractStartFirstUseDate = 14;
	public static final String COMMITMENT_REASONCODE = "EMR";
	public static final int ConvertToMonth = 30;
	public static final int TermDiff = 3;
	public static final String CODE_BRE_PERIOD = "BRE Period";
	public static final String VALUE_UNKNOWN = "UNKNOWN";
	public static final String FALLOUT_INFO_BRE_UNKNW = "Device is in BRE period with Unknown Eligibility";
	public static final String SUBSCRIBER_VALIDATION_TYPE = "Subscriber Validation";
	public static final String CODE_SERVICE_COMMITMENT_MET = "Service Commitment met?";
	public static final String CODE_DEVICE_LINKED_TO_ACCOUNT ="Device Linked to Account?";
	public static final String FALLOUT_INFO_GOPHONE_6MONTHS_UNKN = "Device Eligibility is Unknown with Go Phone Account Active more than 6 Months";
	public static final String CODE_DEVICE_LINKED_DLC = "Device Linked in DLC?";
	public static final String CANCEL_REASON_DATA_NOT_FOUND = "Data Not Found";
	public static final String CODE_NETWORK_ACTIVITY = "N/W Activity is more than 6 month old";
	public static final String CODE_GOPHONE_ACTIVE = "GoPhone account more than 6 month Active";
	public static final String FALLOUT_INFO_FIRST_USE_DATE = "First use date is less than contract term - 3 months";
	public static final String FALLOUT_INFO_SUBSCRIBER_INACTIVE = "Subscriber is not active";
	public static final String APPLICATION_NAME_ORDERTASK="CAMUNDA_UNLOCK";
	public static final String LOSG_SUB_STATUS_BULK="BULK_UNLOCK_ORDER";
	public static final String ROBOTICS_PROCESS_AUTOMATION="ROBOTICS_PROCESS_AUTOMATION";
	
	public static final String FALLOUT_INFO_FRAUD_SERVICE_UNAVAILABLE = "Fraud Service Unavailable";
	public static final String IS_ROBOTICS_AUTOMATION="IS_ROBOTICS_AUTOMATION";
	
	public static final String CANCEL_REASON_POSTPAID_NOT_ACTIVATED="Postpaid Device but not Activated";
	public static final String SKU_CODE = "sku";
	public static final String PURCHASE_DATE_CODE = "Purchase Date";
	public static final String LOSG_STATUS_CANCELLED = "CANCELLED";
	
}

