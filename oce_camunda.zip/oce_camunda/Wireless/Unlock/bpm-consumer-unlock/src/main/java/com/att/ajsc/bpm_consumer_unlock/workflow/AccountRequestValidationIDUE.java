package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;

import org.joda.time.DateTime;
import org.w3c.dom.Document;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.api.response.handler.AbstractCsiApiResponseHandler;
import com.att.oce.bpm.common.JAXBUtil;

public class AccountRequestValidationIDUE extends AbstractCsiApiResponseHandler {
	static final Logger logger = Logger.getLogger(AccountRequestValidation.class.getName());
	
	
	@Override
	public void handleFaultResponse() throws Exception {
		super.handleFaultResponse();
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
		 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
		 if(unlockContext.get("Make")!=null)
			 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_AFTER_IDUE);
	}
	
	@Override
	public void handleSuccessResponse() throws Exception {
		// TODO Auto-generated method stub
		Map<String, Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String, Object> unlockContext = (Map<String, Object>) getExecution().getVariable("unlockContext");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd");
		DocumentBuilder builder = null;
		String xml=getResponse();
		getExecution().setVariable("iapresponse_in_idue", new StringBuffer(xml));
		Document xmlDocument = JAXBUtil.getXMLDocument(xml);


		String createdDate = JAXBUtil.getDocumentElementValue(xmlDocument,
				"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", "effectiveDate"); 
		//xmlDocument.getElementsByTagNameNS(, "effectiveDate").item(0).getTextContent();

		

		long createdDateLong = format.parse(createdDate).getTime();

		String accountType =  JAXBUtil.getDocumentElementValue(xmlDocument,
				"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", "accountType");
		
		String accountSubType = JAXBUtil.getDocumentElementValue(xmlDocument,
				"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", "accountSubType");
		//(xmlDocument.getElementsByTagName("cng:accountSubType").item(0).getTextContent()!=null ? xmlDocument.getElementsByTagName("cng:accountSubType").item(0).getTextContent():"");

		String status =  JAXBUtil.getDocumentElementValue(xmlDocument,
				"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", "status");
		
	
		String deviceType =  (String) unlockContext.get(CommonConstants.PREPAIED_INDICATOR);

		Date date = new Date();
	
		Date daysAgo = new DateTime(date).minusMonths(6).toDate();
		

		long sysdatelong=daysAgo.getTime();
		
		if(accountType!=null && !accountType.equals("") && accountSubType!=null && !accountSubType.equals("")){
			if(UnlockUtils.isGoPhone(accountType, accountSubType, deviceType) && unlockContext.get(CommonConstants.PREPAIED_INDICATOR)==null){
				unlockContext.put(CommonConstants.PREPAIED_INDICATOR, "true");
			}
		}
		
		boolean isGoPhone6month=(createdDateLong>sysdatelong) && (UnlockUtils.isGoPhone(accountType, accountSubType, deviceType)) && !status.equals(null) && !status.equals("X");

		getExecution().setVariable("isGoPhone6month", isGoPhone6month);
		if(isGoPhone6month )
		{
			order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_DENIED,
					CommonConstants.LOSG_SUB_STATUS_GOPHONE_COMMITMENT_6_MONTHS));
			unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_GOPHONE_6MONTHS_UNKN);
			if(unlockContext.get("Make")!=null)
			 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			 getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
				getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
				logger.info("GoPhone 6 month commitment not met");
		}

	}
}
