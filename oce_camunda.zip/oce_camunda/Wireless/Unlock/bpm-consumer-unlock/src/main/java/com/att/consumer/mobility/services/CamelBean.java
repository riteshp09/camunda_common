package com.att.consumer.mobility.services;

import org.apache.camel.Exchange;

public interface CamelBean {
	
	public void execute(Exchange e);
}
