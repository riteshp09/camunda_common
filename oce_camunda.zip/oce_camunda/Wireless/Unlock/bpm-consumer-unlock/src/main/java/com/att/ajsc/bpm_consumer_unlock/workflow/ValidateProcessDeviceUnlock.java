package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.camunda.bpm.engine.variable.Variables;
import org.w3c.dom.Document;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.api.response.handler.AbstractCsiApiResponseHandler;

public class ValidateProcessDeviceUnlock extends AbstractCsiApiResponseHandler /*implements JavaDelegate*/ {

	
	static final Logger logger = Logger.getLogger(ValidateProcessDeviceUnlock.class.getName());
	
	@Override
	public void handleSuccessResponse() throws Exception {
		// TODO Auto-generated method stub
		String response = getResponse(); 
		getExecution().setVariable("pduresponse", new StringBuffer(response));
		//UnlockUtils unlockUtils = new UnlockUtils();
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable("order");
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		
		if(response!=null && !response.equals("")){
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = null;
			try {
			    builder = factory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
			    logger.info("Error creating xmlDoc from soap response in ValidateProcessDeviceUnlock "+e.getMessage());  
			}
			Document xmlDocument = builder.parse(new ByteArrayInputStream(response.getBytes()));
			//XPath xPath =  XPathFactory.newInstance().newXPath();
			String status ="";
			if(xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/ProcessDeviceUnlockResponse.xsd", 
					"status")!=null && null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/ProcessDeviceUnlockResponse.xsd", 
							"status").item(0) ){
				status = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/ProcessDeviceUnlockResponse.xsd", 
						"status").item(0).getTextContent(); 
			}
			 
					//xmlDocument.getElementsByTagName("status").item(0).getTextContent();
			if(status!=null && !status.equals("") && status.equalsIgnoreCase(CommonConstants.SUCCESS)){
				unlockContext.put("isIDSRequired", CommonConstants.VALUE_TRUE);
			}
			else if(status!=null && !status.equals("") && status.equalsIgnoreCase(CommonConstants.FAILURE) 
					&& unlockContext.get(CommonConstants.ANY_NW_ACTIVITY_PRESENT)!=null 
					&& unlockContext.get(CommonConstants.ANY_NW_ACTIVITY_PRESENT).toString().equalsIgnoreCase(CommonConstants.VALUE_NO)){
				order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUBSTATUS_NON_ATT_IMEI));
				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_NON_ATT_IMEI);
				 if(unlockContext.get("Make")!=null)
				 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				unlockContext.put("isIDSRequired", CommonConstants.VALUE_FALSE);
				 logger.info("PDU response status=failure No N/w activity");
			}
			else{
				if(unlockContext.get("isBulkUnlockOrder")!=null && unlockContext.get("isBulkUnlockOrder").toString().equalsIgnoreCase("true")){
	        		order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,CommonConstants.LOSG_SUB_STATUS_BULK));
	        	}else{
	        		order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,CommonConstants.LOSG_SUBSTATUS_TORCH_APPLE_FAILED));
	        	}
				
				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
				unlockContext.put("isIDSRequired", CommonConstants.VALUE_FALSE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
				 if(unlockContext.get("Make")!=null)
				 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_TORCH_APPLE_FAILED);

				 getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(CommonConstants.LOSG_SUBSTATUS_TORCH_APPLE_FAILED,CommonConstants.FALLOUT_INFO_TORCH_APPLE_FAILED));
				 getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));

			}
		}
		getExecution().setVariableLocal(CommonConstants.ORDER, Variables.objectValue(order).
				serializationDataFormat(Variables.SerializationDataFormats.JSON).create());
	}

}
