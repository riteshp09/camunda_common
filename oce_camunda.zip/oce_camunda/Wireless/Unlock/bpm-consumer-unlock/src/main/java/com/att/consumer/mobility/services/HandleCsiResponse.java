package com.att.consumer.mobility.services;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.transform.dom.DOMSource;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.camunda.bpm.engine.variable.Variables;
import org.camunda.bpm.engine.variable.value.ObjectValue;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.camel.custom.AbstractCamelConsumer;
import com.att.oce.bpm.common.JAXBUtil;
import com.att.oce.bpm.common.VelocityHelper;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.ResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.errorresponse.CSIApplicationException;
import com.cingular.csi.csi.namespaces.types._public.errorresponse.ServiceProviderEntityInfo;
import com.cingular.csi.csi.namespaces.types._public.errorresponse.ServiceProviderEntityInfo.ServiceProviderRawError;
import com.google.gson.Gson;

public class HandleCsiResponse extends AbstractCamelConsumer {
	
	public void execute(Exchange e){
		
		System.out.println("Inside Handler CSI Response for API : " + e.getProperties().get("interfaceName"));
		Message msg = e.getIn();
		String inMessageStr = null;
		String outMessageStr = null;
		Map<String, Object> responseWrapper  = new LinkedHashMap<>();
		boolean isFaultResponse;
		
		try {
			inMessageStr = readExchangeMessage(e);

	        Document d = JAXBUtil.getXMLDocument(inMessageStr); //db.parse(new ByteArrayInputStream(inMessageStr.getBytes()));
	        Node csiApplicationExceptionNode = JAXBUtil.getDocumentElement(d, 
	        		"http://csi.cingular.com/CSI/Namespaces/Types/Public/SoapFaultDetails.xsd"
	        		, "CSIApplicationException");
	        
			if(csiApplicationExceptionNode != null) {
				CSIApplicationException exception = JAXBUtil.unmarshalObj(new DOMSource(csiApplicationExceptionNode), CSIApplicationException.class);
				
				isFaultResponse = true;
				
				outMessageStr = JAXBUtil.toXML(exception); //csiExceptionElm.textContent();
				
				System.out.println("CSI Application Exception Msg : " + outMessageStr);
				
				String errorCode = exception.getResponse().getCode();
				
				e.getProperties().put(CommonConstants.ERROR_CODE, errorCode);
				System.out.println("CSI Application Exception errorCode : " + errorCode);
				
				/*ObjectValue value = Variables.objectValue(exception).
				serializationDataFormat(Variables.SerializationDataFormats.JSON).create();*/
				Gson gson = new Gson();
				String exceptionStr = gson.toJson(exception);
				
				responseWrapper.put("payload", VelocityHelper.jsonToMap(exceptionStr));
			} else {
				isFaultResponse = false;
				outMessageStr = inMessageStr;
			}
			
			e.setProperty(CommonConstants.IS_FAULT_RESPONSE, isFaultResponse);
			responseWrapper.put(CommonConstants.INTERFACE_NAME, (String) e.getProperties().get(CommonConstants.INTERFACE_NAME));
			responseWrapper.put(CommonConstants.IS_FAULT_RESPONSE, (Boolean) e.getProperties().get(CommonConstants.IS_FAULT_RESPONSE));
			if(isFaultResponse) {
				responseWrapper.put(CommonConstants.ERROR_CODE, (String) e.getProperties().get(CommonConstants.ERROR_CODE));
			} else {
				responseWrapper.put(CommonConstants.ERROR_CODE, "0");
				responseWrapper.put("payload", outMessageStr);
			}
			
			System.out.println("Response Msg : " + responseWrapper);
			
		} catch (Exception e2) {
			e2.printStackTrace();
			e.getProperties().put(CommonConstants.ERROR_CODE, "500");
			e.setProperty(CommonConstants.IS_FAULT_RESPONSE, true);
			CSIApplicationException exception = new CSIApplicationException();
			
			ResponseInfo response = new ResponseInfo();
			response.setCode("500");
			response.setDescription("System Error");
			exception.setResponse(response);
			
			ServiceProviderEntityInfo spe = new ServiceProviderEntityInfo();
			ServiceProviderRawError rawErr = new ServiceProviderRawError();
			rawErr.setCode("500");
			rawErr.setDescription("System Error");
			spe.setServiceProviderRawError(rawErr);
			exception.getServiceProviderEntity().add(spe);
			
			Gson gson = new Gson();
			String exceptionStr = gson.toJson(exception);
			
			responseWrapper.put("payload", VelocityHelper.jsonToMap(exceptionStr));
			responseWrapper.put(CommonConstants.IS_FAULT_RESPONSE, (Boolean) e.getProperties().get(CommonConstants.IS_FAULT_RESPONSE));
			responseWrapper.put(CommonConstants.ERROR_CODE, (String) e.getProperties().get(CommonConstants.ERROR_CODE));
		}
		
		msg.setBody(responseWrapper);
		e.setOut(msg);
	}

}
