package com.att.ajsc.bpm_consumer_unlock.workflow;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

import com.att.ajsc.bpm_consumer_unlock.util.DMaapPublisher;

import java.util.logging.Logger;

/**
 * Log message.
 * Invoked by the log-message-wf example Camunda workflow/bpmn. 
 * 
 * @author cb3786
 *
 */
public class PublishMessageDelegate implements JavaDelegate {
	// currently uses the java.util.logging.Logger like the Camunda engine
	private final Logger LOGGER = Logger.getLogger(PublishMessageDelegate.class.getName());

	/**
	 * Perform activity.  Log message from running process and set a variable in the running process.
	 * 
	 * @param execution
	 */
	public void execute(DelegateExecution execution) throws Exception {
		String messageToQueue = (String)execution.getVariable("TopicMessage");
	
		DMaapPublisher publisher = new DMaapPublisher();
		if(messageToQueue != null )
		{
			publisher.publishMessage(messageToQueue);
		}
		else
		{
			publisher.publishMessage("TestTopic");
		}
		LOGGER.info("Invoked from processDefinitionId=" + execution.getProcessDefinitionId() +  ", processInstanceId=" + execution.getProcessInstanceId() +  ", activityInstanceId=" + execution.getActivityInstanceId() + ": logMessageText=" + messageToQueue);

		execution.setVariable("isMessageLogComplete", true);
	}
}
