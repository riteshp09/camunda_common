package com.att.oce.unlock.service.auditLog;

import java.net.InetAddress;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.UUID;
import java.util.logging.Logger;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.http.common.HttpMessage;

import sun.misc.BASE64Decoder;

import com.att.oce.dblog.util.AuditLog;
import com.att.oce.dblog.util.AuditLogUtil;
import com.att.oce.dblog.util.OCEManager;

/**
 * 
 * This class is responsible for Auditing of all request and response
 * 
 */
public class AuditLogProcessor implements Processor {

	static final Logger logger = Logger.getLogger(AuditLogProcessor.class.getName());
	String brokerURL;
	String mqUsername;
	String mqPassword;
	String queueName;
	String dbURL;
	String encCodeKey;

	public String getEncCodeKey() {
		return encCodeKey;
	}

	public void setEncCodeKey(String encCodeKey) {
		this.encCodeKey = encCodeKey;
	}

	String dbUsername;

	public String getDbUsername() {
		return dbUsername;
	}

	public void setDbUsername(String dbUsername) {
		this.dbUsername = dbUsername;
	}

	public String getDbPassword() {
		return this.decryptText(dbPassword);
	}

	private String decryptText(String str) {
		String retVal = null;

		try {
			// decode the keys
			BASE64Decoder decoder = new BASE64Decoder();

			byte[] keyBytes = decoder.decodeBuffer(this.getEncCodeKey());

			// construct the keyspec using AES algorithm
			SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");

			// decrypt using cipher AES alg
			Cipher aesCipher = Cipher.getInstance("AES");
			aesCipher.init(Cipher.DECRYPT_MODE, keySpec);

			byte[] decrypted = aesCipher.doFinal(decoder.decodeBuffer(str));

			// store the decrypted value
			retVal = new String(decrypted);
		} catch (Exception e) {
			logger.info("Exception Occurred while decrypting auditlog ");
		}

		return retVal;
	}

	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}

	String dbPassword;

	public String getBrokerURL() {
		return brokerURL;
	}

	public void setBrokerURL(String brokerURL) {
		this.brokerURL = brokerURL;
	}

	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public String getDbURL() {
		return dbURL;
	}

	public void setDbURL(String dbURL) {
		this.dbURL = dbURL;
	}

	public String getMqUsername() {
		return mqUsername;
	}

	public void setMqUsername(String mqUsername) {
		this.mqUsername = mqUsername;
	}

	public String getMqPassword() {
		return this.decryptText(mqPassword);
	}

	public void setMqPassword(String mqPassword) {
		this.mqPassword = mqPassword;
	}

	@Override
	public void process(Exchange exchange) throws Exception {

		/*
		 * Object ReqRespFlag = null; String body =
		 * exchange.getIn().getBody(String.class);
		 */
		AuditLog auditLog = new AuditLog();
		
		 
		
		    if(exchange.getProperty("operationName")!=null)
		    auditLog.setOperationName(exchange.getProperty("operationName").toString());
		    if(exchange.getProperty("serviceName")!=null)
			auditLog.setServiceName(exchange.getProperty("serviceName").toString());
		    Calendar insertedDate = Calendar.getInstance();
		    insertedDate.setTime(new Date());
			auditLog.setInsertedDate(insertedDate);
			auditLog.setLayer("CAMUNDA");
			auditLog.setInsertedBy("CAMUNDA");
			
			if (exchange.getProperty("RequestId") != null){
				auditLog.setRequestID(exchange.getProperty("RequestId").toString());
				
				}
			if (exchange.getIn().getHeader("RequestId") != null){
				auditLog.setRequestID(exchange.getIn().getHeader("RequestId").toString());
				
				}
			if (exchange.getProperty("ConversationId") != null){
				auditLog.setConversationID(exchange.getProperty("ConversationId").toString());
				
				}
			if(exchange.getProperty("customerOrderNumber")!=null)
				auditLog.setCustomerOrderNumber(exchange.getProperty("customerOrderNumber").toString());
			if (exchange.getProperty("interfaceName") != null)
				auditLog.setInterfaceName(exchange.getProperty("interfaceName").toString());
			
		if(exchange.getIn().getHeader("type")!=null && exchange.getIn().getHeader("type").toString().equalsIgnoreCase("request")){
		
			if(exchange.getIn()!=null && exchange.getIn().getBody()!=null)
			auditLog.setRequest(exchange.getIn().getBody().toString());
			Calendar requestTime = Calendar.getInstance();
			requestTime.setTime(new Date());
			auditLog.setRequestTime(requestTime);
			exchange.setProperty("correlationID", UUID.randomUUID().toString());
			if(exchange.getProperty("correlationID")!=null)
			auditLog.setCorrelationID(exchange.getProperty("correlationID").toString());
		}
		
		if(exchange.getIn().getHeader("type")!=null && exchange.getIn().getHeader("type").toString().equalsIgnoreCase("response")){
			
			if(exchange.getIn()!=null && exchange.getIn().getBody()!=null)
			auditLog.setResponse(exchange.getIn().getBody().toString());
			Calendar responseTime = Calendar.getInstance();
			responseTime.setTime(new Date());
			auditLog.setResponseTime(responseTime);
			if(exchange.getProperty("correlationID")!=null)
			auditLog.setCorrelationID(exchange.getProperty("correlationID").toString());
		}
		
		InetAddress ip =  InetAddress.getLocalHost(); 
		auditLog.setServerName(ip.getHostName());
		auditLog.setLogType(1);
		auditLog.setIsExternal(0);
		

		// System.out.println("Preparing mq factory");
		org.apache.activemq.pool.PooledConnectionFactory mQPooledConnectionFactory = null;
		org.apache.commons.dbcp2.BasicDataSource ods = null;
		Properties mqProp = new Properties();

		brokerURL = brokerURL;// + TaskConstants.qSuffix;

		mqProp.setProperty("brokerURL", brokerURL);

		mqProp.setProperty("user", mqUsername);

		mqProp.setProperty("password", this.getMqPassword());

		mQPooledConnectionFactory = OCEManager.getMQInstance(mqProp);

		Properties dbProp = new Properties();
		dbProp.setProperty("dbURL", dbURL);
		dbProp.setProperty("username", dbUsername);

		dbProp.setProperty("password", this.getDbPassword());

	/*	dbProp.setProperty("minIdleConn", "5");
		dbProp.setProperty("maxIdleConn", "10");
		dbProp.setProperty("dbInitialSize", "50");
		dbProp.setProperty("dbMaxTotal", "100");
		dbProp.setProperty("dbMaxOpenPreparedStatements", "180");*/

		ods = OCEManager.getConnectionPoolInstance(dbProp);

		AuditLogUtil auditLogUtil = new AuditLogUtil();

		// String retStatus = null;
		try {

			auditLogUtil.publishLog(auditLog, mQPooledConnectionFactory, ods,
					queueName);
		} catch (Exception e) {
			logger.info("Exception while initializing AuditLogger :"
					+ e.getMessage());
		} catch (Throwable t) {
			logger.info("Exception while initializing AuditLogger :"
					+ t.getMessage());
		}

	}

}
