package com.att.consumer.mobility.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.ProcessEngineConfiguration;
import org.camunda.bpm.engine.ProcessEngines;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;

public class GetMakeModelFromCamundaDB implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet result = null;
		
		try {
			
			Map<String, Object> unlockContext = (Map<String, Object>) execution.getVariable("unlockContext");
			
			ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
			ProcessEngineConfiguration processEngineConfiguration = processEngine.getProcessEngineConfiguration();
			DataSource dataSource = processEngineConfiguration.getDataSource();
			long imei = Long.valueOf((String) unlockContext.get("requestedIMEI"));
			connection = dataSource.getConnection();
			stmt = connection
					.prepareStatement("select * from oce_ru_make_model where startRange <= ? and endRange >= ?");
			stmt.setLong(1, imei);
			stmt.setLong(2, imei);
			result = stmt.executeQuery();
			result.next();
			//result.first();
			/*String make = result.getString("make");
			String model = result.getString("model");*/
			
			/**
			 * {
"id": "013598000000000_013598009999999",
"make": "Apple",
"model": "IPHONE 4S A1387",
"friendlyModelName": "iPhone 4S",
"startRange": 13598000000000,
"endRange": 13598009999999,
"falloutAction": "Continue",
"deviceMessage": "NOT DEFINED"
}
			 */
			
			String payload = "{"
					+ "\"id\": \""+ result.getString("id") + "\","
					+ "\"make\": \"" + result.getString("make") + "\","
					+ "\"model\": \"" + result.getString("model") + "\","
					+ "\"friendlyModelName\": \"" + result.getString("friendlyModelName") + "\","
					+ "\"startRange\": " + result.getLong("startRange") + ","
					+ "\"endRange\": " +  result.getLong("endRange") + ","
					+ "\"falloutAction\": \"" + result.getString("falloutAction") + "\","
					+ "\"deviceMessage\": \"" + result.getString("deviceMessage") + "\"" 
					+ "}";
			
			Map<String, Object> responseWrapper = new HashMap<>();
			responseWrapper.put(CommonConstants.IS_FAULT_RESPONSE, false);
			responseWrapper.put("payload", payload);
			
			execution.setVariable("getMakeModelResponse", responseWrapper);
			
		} catch (Exception e) {
			Map<String, Object> responseWrapper = new HashMap<>();
			responseWrapper.put(CommonConstants.IS_FAULT_RESPONSE, true);
			execution.setVariable("getMakeModelResponse", responseWrapper);
		} finally {
			if(result != null && !result.isClosed())
				result.close();
			if(stmt != null && !stmt.isClosed())
				stmt.close();
			if(connection != null && !connection.isClosed())
				connection.close();
		}
	}

}
