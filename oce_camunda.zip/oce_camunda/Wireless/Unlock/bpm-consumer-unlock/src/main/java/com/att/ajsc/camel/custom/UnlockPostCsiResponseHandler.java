package com.att.ajsc.camel.custom;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

import com.att.ajsc.bpm_consumer_unlock.util.APIConfigurationUtils;
import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.bpm.common.JAXBUtil;
import com.att.oce.bpm.common.VelocityHelper;

public class UnlockPostCsiResponseHandler implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		Map<String, Object> response = (Map<String, Object>) execution.getVariable("response");
		
		String interfaceName = (String) response.get(CommonConstants.INTERFACE_NAME);
		boolean isFaultResponse = (boolean) response.get("isFaultResponse");
		
		String errorCode = (String) response.get(CommonConstants.ERROR_CODE);
		
		execution.setVariable(CommonConstants.IS_FAULT_RESPONSE , isFaultResponse);
		execution.setVariable(CommonConstants.IS_REVIEW, false);
		
		Map<String,Object> order = (Map<String, Object>) execution.getVariable(CommonConstants.ORDER);
		
		if(isFaultResponse ) {
			
			LinkedHashMap<String, Object> exception =  (LinkedHashMap<String, Object>) response.get("payload");
			
			Map<?,?> svcProviderEntity = (Map<?, ?>) ((ArrayList)exception.get("serviceProviderEntity")).get(0);
			Map<?,?> svcProviderRawErr = (Map<?, ?>) svcProviderEntity.get("serviceProviderRawError");
			
			String desc = (String) svcProviderRawErr.get("description");
			
			if(interfaceName!=null && !interfaceName.equals("") && !interfaceName.equalsIgnoreCase("AddNote")){
				execution.setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(errorCode,desc));
			}
			
			String pathFarward = APIConfigurationUtils.getInstance().getPathForwardAfterFallout(interfaceName, errorCode);
			execution.setVariable(CommonConstants.IS_REVIEW, !"NEXT".equals(pathFarward));
			execution.setVariable(interfaceName + CommonConstants._RESPONSE, new StringBuffer(VelocityHelper.toJsonString(exception) /*JAXBUtil.toXML(exception)*/));
		} else {
			execution.setVariable(interfaceName + CommonConstants._RESPONSE, new StringBuffer((String) response.get("payload")));
		}
		execution.removeVariable("response");
		
		System.out.println(execution.getVariable(CommonConstants.IS_FAULT_RESPONSE) + "|" + 
				execution.getVariable(CommonConstants.IS_REVIEW));
	}
	

}