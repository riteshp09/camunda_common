package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.api.response.handler.AbstractCsiApiResponseHandler;

public class LatestCTNAccountValidation extends AbstractCsiApiResponseHandler{

	static final Logger logger = Logger.getLogger(LatestCTNAccountValidation.class.getName());

	@Override
	public void handleFaultResponse() throws Exception {
		Map<?,?> response = (Map<?, ?>) getException().get("response");
			
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		//getExecution().setVariableLocal("isIAPForLatestCTNRequired", false);
		
			order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idd")));
			unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
			if(unlockContext.get("Make")!=null)
			UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_IMEI_ACTIVE_OTHER);
			getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.FALLOUT_INFO_IMEI_ACTIVE_OTHER));
			getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
		logger.info("CSI Exception in IAP call for latest CTN ");
			
		
	}
	@Override
	public void handleSuccessResponse() throws Exception {
		// TODO Auto-generated method stub
		
		String response = getResponse();
		getExecution().setVariableLocal("getLatestCTNIAPResponse", new StringBuffer(response));
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		Map<String, Object>  accounts =  (Map<String, Object>)order.get("Accounts");
		Map<String, Object>  account =   (Map<String, Object>) ( (List<Object>)accounts.get("Account")).get(0);
		String RequestedBAN="";
		if(account.get("BillingAccountNumber")!=null){
			 RequestedBAN =  account.get("BillingAccountNumber").toString();
		}
		
		if(response!=null && !response.equals("")){
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = null;
			try {
			    builder = factory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
			    logger.info("Error creating xmlDoc from soap response in LatestCTNDeviceDetailsValidation "+e.getMessage());  
			}
			Document xmlDocument = builder.parse(new ByteArrayInputStream(response.getBytes()));
			if(null!=xmlDocument.getElementsByTagName("billingAccountNumber")){
				String responseBAN =xmlDocument.getElementsByTagName("billingAccountNumber").item(0).getTextContent().toString();
				if(!RequestedBAN.equals("") && !responseBAN.equals("") && responseBAN.equalsIgnoreCase(RequestedBAN)){
					if(unlockContext.get("eligibilityStatus")!=null && !unlockContext.get("eligibilityStatus").toString().equalsIgnoreCase(CommonConstants.ELIGIBLE)){
						order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idd")));
						unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
						if(unlockContext.get("Make")!=null)
						UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_IMEI_ACTIVE_OTHER);
						getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.FALLOUT_INFO_IMEI_ACTIVE_OTHER));
						getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
						logger.info("BAN matches for active other imei IAP call and not eligible ");
					}
				}else{
					order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_IMEI_ACTIVE_OTHER));
					unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
		   			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
					 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_IMEI_ACTIVE_OTHER);
					if(unlockContext.get("Make")!=null)
					 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					 getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
						getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
						logger.info("BAN mismatches for active other imei IAP call ");
				}
			}
		}
		
	}
	
}
