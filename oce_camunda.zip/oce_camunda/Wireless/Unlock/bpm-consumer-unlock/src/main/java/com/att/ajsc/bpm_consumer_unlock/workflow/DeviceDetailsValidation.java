package com.att.ajsc.bpm_consumer_unlock.workflow;


import java.io.ByteArrayInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.sql.DataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.ProcessEngineConfiguration;
import org.camunda.bpm.engine.ProcessEngines;
import org.camunda.bpm.engine.variable.Variables;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.api.response.handler.AbstractCsiApiResponseHandler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

public class DeviceDetailsValidation extends AbstractCsiApiResponseHandler
{
	static final Logger logger = Logger.getLogger(DeviceDetailsValidation.class.getName());
	
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	@Override
	public void handleFaultResponse() throws Exception {
		super.handleFaultResponse();
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		unlockContext.put((String) CommonConstants.ANY_NW_ACTIVITY_PRESENT, CommonConstants.VALUE_NO);
		UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
		 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
		 if(unlockContext.get("Make")!=null)
			 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_AFTER_IDUE);
		getExecution().setVariableLocal("isAnyOtherCTN", false);
		getExecution().setVariableLocal("isLatestCTNRequested", false);
		getExecution().setVariable("getIddResponse", getException());
		logger.info("CSI Exception for IDD ");
	}



	@Override
	public void handleSuccessResponse() throws Exception {
		// TODO Auto-generated method stub
		String response = getResponse();
		getExecution().setVariable("getIddResponse", new StringBuffer(response));
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		Map<String, Object>  groups =  (Map<String, Object>)order.get("Groups");
		//List<Object> grouplist = (List<Object>)groups.get("Group");
		Map<String, Object>  accounts =  (Map<String, Object>)order.get("Accounts");
		Map<String, Object>  account =   (Map<String, Object>) ( (List<Object>)accounts.get("Account")).get(0);
		String enterpriseType="";
		if(account.get("EnterpriseType")!=null)
		 enterpriseType = account.get("EnterpriseType").toString();
		Map<String, Object>  group =   (Map<String, Object>) ( (List<Object>)groups.get("Group")).get(0);
		  List<String> sortedCTNs=new ArrayList();
		boolean isAnyOtherCTN=false,isLatestCTNRequested=false;
		if(response!=null && !response.equals("")){
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = null;
			try {
			    builder = factory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
			    logger.info("Error creating xmlDoc from soap response in DeviceAlreadyUnlockValidator "+e.getMessage());  
			}
			Document xmlDocument = builder.parse(new ByteArrayInputStream(response.getBytes()));
			boolean isNWActivityPresent = false;
			if(xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireDeviceDetailsResponse.xsd", 
					"NetworkActivity")!=null && null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireDeviceDetailsResponse.xsd", 
							"NetworkActivity").item(0)){
				isNWActivityPresent=true;
			}
			String purchaseDateStr ="";
			Date purchaseDate = null;
			int diffInDays =0;
			if (xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
					"purchaseDate")!=null && null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
							"purchaseDate").item(0)) {
				
				purchaseDateStr = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
						"purchaseDate").item(0).getTextContent();
				purchaseDate = format.parse(purchaseDateStr);
				Date currentDate = new Date();
				currentDate = format.parse(format.format(currentDate));
				
				if (purchaseDate!=null) {
					diffInDays = (int) ((currentDate.getTime() - purchaseDate.getTime()) / (1000 * 60 * 60 * 24));
					 
				}
				if(purchaseDateStr!=null && !purchaseDateStr.equals("")){
				
					 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PURCHASE_DATE_CODE, purchaseDateStr);
				}
			}
			String skuVal = "";
			if(xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","sku")!=null &&
					xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","sku").item(0)!=null){
				 skuVal = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","sku").item(0).getTextContent();
				if(skuVal==null || skuVal.equals("")){
					if(xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","cng:sku")!=null &&
							xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","cng:sku").item(0)!=null){
						skuVal = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","cng:sku").item(0).getTextContent();
					}
				}
				
				if(skuVal!=null && !skuVal.equals("")){
					
					 UnlockUtils.createAutomationSummary(order, null, CommonConstants.SKU_CODE, skuVal);
				}
			}
			
			if(unlockContext.get(CommonConstants.PREPAIED_INDICATOR)==null){
				if(skuVal!=null && !skuVal.equals("")){
					
					Connection con =null;
					ResultSet result =null;
					PreparedStatement stmt = null;
					try{
					ProcessEngine processEngine = ProcessEngines.getDefaultProcessEngine();
					ProcessEngineConfiguration processEngineConfiguration = processEngine.getProcessEngineConfiguration();
					DataSource dataSource = processEngineConfiguration.getDataSource();
					 con =   dataSource.getConnection();
					 stmt = con.prepareStatement("Select * from GOPHONE_SKU Where SKUID= ?");
					stmt.setString(1, skuVal);
					 result = stmt.executeQuery();
					 result.next();
					String active =result.getString("ACTIVE");
					if(active!=null && !active.equals("") && active.equalsIgnoreCase("Y") ){
						unlockContext.put(CommonConstants.PREPAIED_INDICATOR, "true");
					}
					 
					}catch (Exception e) {
						
					} finally {
						if(result != null && !result.isClosed())
							result.close();
						if(stmt != null && !stmt.isClosed())
							stmt.close();
						if(con != null && !con.isClosed())
							con.close();
					}
				}
				
				
			}
			String blacklistIndicatorVal = "";
			if(xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","blacklistIndicator")!=null && 
					null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","blacklistIndicator").item(0) ){
			//	logger.info("here");
				blacklistIndicatorVal = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","blacklistIndicator").item(0).getTextContent(); 
			}
			if(blacklistIndicatorVal!=null && !blacklistIndicatorVal.equals("") && blacklistIndicatorVal.equalsIgnoreCase("B")){
				 order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_LOST_STOLEN));
					unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
		   			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
    				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
    				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_LOST_STOLEN);
    				if(unlockContext.get("Make")!=null)
    				 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
    				 unlockContext.put((String) CommonConstants.ANY_NW_ACTIVITY_PRESENT, CommonConstants.VALUE_NO);
    				 
    				 getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
						getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
						logger.info("Device found lost/stolen ");
			}
			else {
				if(!isNWActivityPresent){
					unlockContext.put((String) CommonConstants.ANY_NW_ACTIVITY_PRESENT, CommonConstants.VALUE_NO);
					 UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_ANY_NW_ACTIVITY_PRESENT_ON_DEVICE , 
							 CommonConstants.VALUE_NO);
					//unlockContext.put(CommonConstants.CODE_ANY_NW_ACTIVITY_PRESENT_ON_DEVICE,CommonConstants.VALUE_YES);
					if(unlockContext.get("eligibilityStatus")!=null && unlockContext.get("eligibilityStatus").toString()
							.equalsIgnoreCase(CommonConstants.LOSG_SUB_STATUS_DATA_NOT_FOUND)){
						if(unlockContext.get(CommonConstants.PREPAIED_INDICATOR)!=null){
							
								if(unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("Current")){
									if(enterpriseType!=null && !enterpriseType.equals("") && enterpriseType.equalsIgnoreCase(CommonConstants.ENTERPRISE_CRU)){
										order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idd")));
										unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
										if(unlockContext.get("Make")!=null)
										UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
										UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
										UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
										UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_NO_NW_ACT_DATA_NOT_FOUND);
										
										getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.FALLOUT_INFO_NO_NW_ACT_DATA_NOT_FOUND));
										getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
									
									}else{
										if(UnlockUtils.getPaymentArrangement(order)!=null && !UnlockUtils.getPaymentArrangement(order).equalsIgnoreCase("POSTPAID")){
											order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_GOPHONE_COMMITMENT_6_MONTHS));
											unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
								   			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
						    				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
						    				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_GOPHONE_6MONTHS_COMMITMENT);
						    				if(unlockContext.get("Make")!=null)
						    				UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
						    				
						    				 getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
												getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
										}else{
											order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idd")));
											unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
											if(unlockContext.get("Make")!=null)
											UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
											UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
											UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
											UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_NO_NW_ACT_DATA_NOT_FOUND);
											
											getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.FALLOUT_INFO_NO_NW_ACT_DATA_NOT_FOUND));
											getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
										
										}
									}
									
								}else{
									order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_GOPHONE_COMMITMENT_6_MONTHS));
									unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
						   			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
				    				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
				    				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_GOPHONE_6MONTHS_COMMITMENT);
				    				if(unlockContext.get("Make")!=null)
				    				UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				    				
				    				 getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
										getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
								}
							 
									
						}else if(unlockContext.get("Make")!=null && unlockContext.get("Make").toString().equalsIgnoreCase(CommonConstants.MAKE_TYPE_APPLE)){
						
							if(unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("NonATT")){
								order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_APPROVED,CommonConstants.LOSG_SUBSTATUS_TORCH_APPLE_COMPLETED));
								unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_APPROVED);
								getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
								getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());					
							
								
							}else{
								//unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_SYS_PROCESSING);
								order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idd")));
								unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
								if(unlockContext.get("Make")!=null)
								UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
								UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
								UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
								UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_NO_NW_ACT_DATA_NOT_FOUND);
								
								getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.FALLOUT_INFO_NO_NW_ACT_DATA_NOT_FOUND));
								getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
							
							}
						
							if (diffInDays < 60){
								UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_POSTPAID_NOT_ACTIVATED);
							}
						}else{
							order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idd")));
							unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
							if(unlockContext.get("Make")!=null)
							UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
							UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
							UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
							UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_NO_NW_ACT_DATA_NOT_FOUND);
							
							getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.FALLOUT_INFO_NO_NW_ACT_DATA_NOT_FOUND));
							getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
							if (diffInDays < 60){
								UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_POSTPAID_NOT_ACTIVATED);
							}
						}
						
					}else{
						if(unlockContext.get(CommonConstants.PREPAIED_INDICATOR)!=null){
							
							if(unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("Current")){
								if(enterpriseType!=null && !enterpriseType.equals("") && enterpriseType.equalsIgnoreCase(CommonConstants.ENTERPRISE_CRU)){
									order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idd")));
									unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
									if(unlockContext.get("Make")!=null)
									UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
									UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
									UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
									UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_NO_NW_ACT_DATA_NOT_FOUND);
									
									getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.FALLOUT_INFO_NO_NW_ACT_DATA_NOT_FOUND));
									getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
								
								}else{
									if(UnlockUtils.getPaymentArrangement(order)!=null && !UnlockUtils.getPaymentArrangement(order).equalsIgnoreCase("POSTPAID")){
										order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_GOPHONE_COMMITMENT_6_MONTHS));
										unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
							   			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
					    				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
					    				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_GOPHONE_6MONTHS_COMMITMENT);
					    				if(unlockContext.get("Make")!=null)
					    				UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					    				
					    				 getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
											getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
									}else{
										order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idd")));
										unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
										if(unlockContext.get("Make")!=null)
										UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
										UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
										UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
										UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_NO_NW_ACT_DATA_NOT_FOUND);
										
										getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.FALLOUT_INFO_NO_NW_ACT_DATA_NOT_FOUND));
										getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
									
									}
								}
								
							}else{
								order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_GOPHONE_COMMITMENT_6_MONTHS));
								unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
					   			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
			    				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
			    				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_GOPHONE_6MONTHS_COMMITMENT);
			    				if(unlockContext.get("Make")!=null)
			    				UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			    				
			    				 getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
									getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
							}
						 
								
					}else if(unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("NonATT") && 
								unlockContext.get("eligibilityStatus")!=null && unlockContext.get("eligibilityStatus").toString().equalsIgnoreCase(CommonConstants.ELIGIBLE)){
							order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_APPROVED,CommonConstants.LOSG_SUB_STATUS_COMPLETED));
							unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_APPROVED);
							if(unlockContext.get("Make")!=null)
							UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
							UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
							UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
							getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
							getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
							
						}else{
							
							order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idd")));
							unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
							if(unlockContext.get("Make")!=null)
							UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
							UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
							UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
							UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_NO_NW_ACT);

							getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.FALLOUT_INFO_NO_NW_ACT));
							getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
							
							if (diffInDays < 60 && unlockContext.get("eligibilityStatus")!=null && unlockContext.get("eligibilityStatus").toString().equalsIgnoreCase(CommonConstants.ELIGIBILITY_UNKNOWN)){
								UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_POSTPAID_NOT_ACTIVATED);
							}
						}
						
					}
					logger.info("no N/W activity found ");
				}
				else{
					//nw activity present code 
					unlockContext.put((String) CommonConstants.ANY_NW_ACTIVITY_PRESENT, CommonConstants.VALUE_YES);
					 UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_ANY_NW_ACTIVITY_PRESENT_ON_DEVICE , CommonConstants.VALUE_YES);
					NodeList nwActivityList = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireDeviceDetailsResponse.xsd", 
							"NetworkActivity");
					if(nwActivityList.getLength()>0 && unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("NonATT")){
						isAnyOtherCTN=true;
					}
					if(nwActivityList.getLength()>0 && unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("Current"))
					{
						String requestCTN =UnlockUtils.getRequestCTN(group);
						for (int i = 0; i < nwActivityList.getLength(); i++) {
							 Node nwactivity = nwActivityList.item(i); 
							 if (nwactivity.getNodeType() == Node.ELEMENT_NODE)
						     {
						        Element information = (Element) nwactivity;
						     
						        String responseCTN = information.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","subscriberNumber").item(0).getTextContent();
						      
						        if(!responseCTN.equals(requestCTN)){
						        	isAnyOtherCTN=true;
						        }
						     }
							 
							 
						 }
					}
					if(!isAnyOtherCTN && unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("NonATT")){
						order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_APPROVED,CommonConstants.LOSG_SUB_STATUS_COMPLETED));
						unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_APPROVED);
					
					}else{
						 Element[] sortedNWActivity = UnlockUtils.sortNodes(nwActivityList, "activityDate","http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd" ,false, Date.class);
					       // List<String> sortedCTNs=new ArrayList();
					        for(Element n: sortedNWActivity)
					        {
					        	sortedCTNs.add(n.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","subscriberNumber").item(0).getTextContent().toString());
					            //System.out.println(n.getElementsByTagName("cng:subscriberNumber").item(0).getTextContent()+" : "+n.getElementsByTagName("cng:activityDate").item(0).getTextContent());
					        
					        }
					        if(unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").toString().equalsIgnoreCase("Current")){
					        	String requestCTN =UnlockUtils.getRequestCTN(group);
					        	if(requestCTN.equals(sortedCTNs.get(0).toString()))
					        	{	isLatestCTNRequested=true;
					        	sortedCTNs.remove(0);
					        	}
					        	else{
					        		sortedCTNs.remove(requestCTN);
					        	}
					        }
						
					}
					//this needs to be move to if block once idd process completed
					getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
					getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());

					
				}
			}
			getExecution().setVariableLocal("sortedCTNs", sortedCTNs);
		}
		
		getExecution().setVariableLocal("isAnyOtherCTN", isAnyOtherCTN);
		getExecution().setVariableLocal("isLatestCTNRequested", isLatestCTNRequested);		
		getExecution().setVariableLocal(CommonConstants.ORDER, Variables.objectValue(order).
		serializationDataFormat(Variables.SerializationDataFormats.JSON).create());
	}

}
