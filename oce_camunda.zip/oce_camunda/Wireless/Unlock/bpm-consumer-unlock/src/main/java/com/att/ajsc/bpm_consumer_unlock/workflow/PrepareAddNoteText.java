package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.util.Map;
import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.bpm.common.VelocityHelper;

public class PrepareAddNoteText implements JavaDelegate {
	
	static final Logger logger = Logger.getLogger(PrepareAddNoteText.class.getName());

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		
		Map<String,Object> order = (Map<String, Object>) execution.getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) execution.getVariable("unlockContext");
		
//		Map<String,Object> params = new HashedMap();
		String unlockCode = UnlockUtils.getUnlockCode(order);
		//logger.info("############ Unlock Code : " + unlockCode);
		unlockContext.put(CommonConstants.UNLOCK_CODE, unlockCode);
		
		String status = UnlockUtils.getLOSGStatusSubStatus(order).get("Status");
		String subStatus = UnlockUtils.getLOSGStatusSubStatus(order).get("SubStatus");
		String noteText = UnlockUtils.prepareAddNoteText(status,subStatus);
		if(status!=null && subStatus!=null && status.equalsIgnoreCase(CommonConstants.LOSG_STATUS_APPROVED) && subStatus.equalsIgnoreCase(CommonConstants.LOSG_SUB_STATUS_COMPLETED)){
			noteText = noteText.concat(unlockCode);
		}else{
			noteText = VelocityHelper.renderDynamicTemplate(unlockContext, noteText);
		}
		
		
		
		unlockContext.put(CommonConstants.ADDNOTE_TEXT, noteText);
		
	//	logger.info("############ Note Text : " + noteText);

	}

}
