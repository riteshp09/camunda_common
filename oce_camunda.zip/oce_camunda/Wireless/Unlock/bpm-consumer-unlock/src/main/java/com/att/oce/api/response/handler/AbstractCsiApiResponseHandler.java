package com.att.oce.api.response.handler;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.bpm.common.VelocityHelper;
import com.cingular.csi.csi.namespaces.types._public.cingulardatamodel.ResponseInfo;
import com.cingular.csi.csi.namespaces.types._public.errorresponse.CSIApplicationException;
import com.cingular.csi.csi.namespaces.types._public.errorresponse.ServiceProviderEntityInfo;
import com.cingular.csi.csi.namespaces.types._public.errorresponse.ServiceProviderEntityInfo.ServiceProviderRawError;
import com.google.gson.Gson;

public abstract class AbstractCsiApiResponseHandler implements UnlockApiResponseHandler {

	@Override
	public void preExecute() throws Exception {
		// TODO Auto-generated method stub
	}

	@Override
	public void postExecute() throws Exception {
		//cleaning up response variable
		getExecution().removeVariable("response");
	}

	private String response;
	private LinkedHashMap<String, Object> exception;
	private DelegateExecution execution;
	private LinkedHashMap<String, Object> responseWrapper;

	@Override
	public String getResponse() {
		return response;
	}

	@Override
	public LinkedHashMap<String, Object> getException() {
		return exception;
	}

	@Override
	public DelegateExecution getExecution() {
		return execution;
	}

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		this.execution = execution;
		try {
			responseWrapper = (LinkedHashMap<String, Object>) execution.getVariable("response");
		} catch (Exception e) {
			CSIApplicationException exception = new CSIApplicationException();
			
			ResponseInfo response = new ResponseInfo();
			response.setCode("500");
			response.setDescription("System Error");
			exception.setResponse(response);
			
			ServiceProviderEntityInfo spe = new ServiceProviderEntityInfo();
			ServiceProviderRawError rawErr = new ServiceProviderRawError();
			rawErr.setCode("500");
			rawErr.setDescription("System Error");
			spe.setServiceProviderRawError(rawErr);
			exception.getServiceProviderEntity().add(spe);
			
			Gson gson = new Gson();
			String exceptionStr = gson.toJson(exception);
			
			responseWrapper  = new LinkedHashMap<>();
			responseWrapper.put("payload", VelocityHelper.jsonToMap(exceptionStr));
			responseWrapper.put(CommonConstants.IS_FAULT_RESPONSE, true);
			responseWrapper.put(CommonConstants.ERROR_CODE, "500");
		}
		boolean isFault = (boolean) responseWrapper.get(CommonConstants.IS_FAULT_RESPONSE);
		if (isFault) {
			exception = (LinkedHashMap<String, Object>) responseWrapper.get("payload");
			getExecution().setVariable(
					(String) responseWrapper.get(CommonConstants.INTERFACE_NAME) + "_FaultResponse", exception);
			handleFaultResponse();
		} else {
			response = (String) responseWrapper.get("payload");
			handleSuccessResponse();
		} 
		postExecute();
	}

	@Override
	public abstract void handleSuccessResponse() throws Exception;

	@Override
	public void handleFaultResponse() throws Exception {
		Map<?,?> response = (Map<?, ?>) getException().get("response");
		String errorCode = (String) response.get("code");

//		Map<?,?> svcProviderEntity = (Map<?, ?>) ((ArrayList)getException().get("serviceProviderEntity")).get(0);
//		Map<?,?> svcProviderRawErr = (Map<?, ?>) svcProviderEntity.get("serviceProviderRawError");

//		String svcProviderRawErrorCode = (String) svcProviderRawErr.get("code");
//		String desc = (String) svcProviderRawErr.get("description");
		boolean beforeIDUE = (boolean) getExecution().getVariable("beforeIDUE");

		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,(String) responseWrapper.get(CommonConstants.INTERFACE_NAME))));
		unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
		getExecution().setVariable("unlockContext", unlockContext);
		getExecution().setVariable(CommonConstants.ERRORS, UnlockUtils.getErrors(errorCode,
				(beforeIDUE) ? CommonConstants.FALLOUT_INFO_B4_IDUE : CommonConstants.FALLOUT_INFO_AFTER_IDUE));
		getExecution().setVariable(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
		
	}

}
