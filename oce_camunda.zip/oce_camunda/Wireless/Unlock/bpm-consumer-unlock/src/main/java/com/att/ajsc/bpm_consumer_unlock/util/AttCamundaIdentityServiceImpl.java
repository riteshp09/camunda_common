package com.att.ajsc.bpm_consumer_unlock.util;
/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import static org.camunda.bpm.engine.authorization.Authorization.AUTH_TYPE_GRANT;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.ServiceLoader;

import javax.servlet.ServletException;

import org.camunda.bpm.engine.AuthorizationService;
import org.camunda.bpm.engine.IdentityService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.authorization.Authorization;
import org.camunda.bpm.engine.authorization.AuthorizationQuery;
import org.camunda.bpm.engine.authorization.Permissions;
import org.camunda.bpm.engine.identity.Group;
import org.camunda.bpm.engine.identity.GroupQuery;
import org.camunda.bpm.engine.identity.Picture;
import org.camunda.bpm.engine.identity.User;
import org.camunda.bpm.engine.identity.UserQuery;
import org.camunda.bpm.engine.impl.ServiceImpl;
import org.camunda.bpm.engine.impl.cmd.CreateGroupCmd;
import org.camunda.bpm.engine.impl.cmd.CreateGroupQueryCmd;
import org.camunda.bpm.engine.impl.cmd.CreateMembershipCmd;
import org.camunda.bpm.engine.impl.cmd.CreateUserCmd;
import org.camunda.bpm.engine.impl.cmd.CreateUserQueryCmd;
import org.camunda.bpm.engine.impl.cmd.DeleteGroupCmd;
import org.camunda.bpm.engine.impl.cmd.DeleteMembershipCmd;
import org.camunda.bpm.engine.impl.cmd.DeleteUserCmd;
import org.camunda.bpm.engine.impl.cmd.DeleteUserInfoCmd;
import org.camunda.bpm.engine.impl.cmd.DeleteUserPictureCmd;
import org.camunda.bpm.engine.impl.cmd.GetUserAccountCmd;
import org.camunda.bpm.engine.impl.cmd.GetUserInfoCmd;
import org.camunda.bpm.engine.impl.cmd.GetUserInfoKeysCmd;
import org.camunda.bpm.engine.impl.cmd.GetUserPictureCmd;
import org.camunda.bpm.engine.impl.cmd.IsIdentityServiceReadOnlyCmd;
import org.camunda.bpm.engine.impl.cmd.SaveGroupCmd;
import org.camunda.bpm.engine.impl.cmd.SaveUserCmd;
import org.camunda.bpm.engine.impl.cmd.SetUserInfoCmd;
import org.camunda.bpm.engine.impl.cmd.SetUserPictureCmd;
import org.camunda.bpm.engine.impl.identity.Account;
import org.camunda.bpm.engine.impl.identity.Authentication;
import org.camunda.bpm.engine.impl.persistence.entity.GroupEntity;
import org.camunda.bpm.engine.impl.persistence.entity.IdentityInfoEntity;
import org.camunda.bpm.engine.rest.spi.ProcessEngineProvider;
import org.camunda.bpm.engine.impl.cmd.CheckPassword;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ajsc.filemonitor.AJSCPropertiesMap;
import com.att.cadi.Access;
import com.att.cadi.aaf.v2_0.AAFAuthn;
import com.att.cadi.aaf.v2_0.AAFCon;
import com.att.cadi.aaf.v2_0.AAFLurPerm;
import com.att.cadi.config.Config;
import com.att.cadi.lur.aaf.AAFPermission;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * 
 */
public class AttCamundaIdentityServiceImpl extends ServiceImpl implements
		IdentityService {

	/** thread local holding the current authentication */
	/** thread local holding the current authentication */
	private static final Logger logger = LoggerFactory.getLogger(AttCamundaIdentityServiceImpl.class);
	private static final String AJSC_PROPS_FILE = "AAFUserRoles.properties";
	private static final String AAFENABLEDPROP = "AAFENABLEDPROP";
	private static final String CADIPROPSPATH = "\\etc\\cadi.properties";
	private static final String  nameEndPointProp = "nameEndpointUrl";
	private ThreadLocal<Authentication> currentAuthentication = new ThreadLocal<Authentication>();
	private Map<String, List<String>> ajscResourcePermissionMap = null;
	
	private String processEngineName ;
	private Access myAccess = null;
	
	private AAFCon con = null;
	// AAFLur has pool of DME clients as needed, and Caches Client lookups
	private AAFLurPerm aafLur = null;
	// As we require both Authn and Authz,we will  construct the following:
	private AAFAuthn aafAuthn = null;
	
	private boolean isAafCamundaRolesEmpty = false;;

	public boolean isReadOnly() {
		return commandExecutor.execute(new IsIdentityServiceReadOnlyCmd());
	}

	public Group newGroup(String groupId) {
		return commandExecutor.execute(new CreateGroupCmd(groupId));
	}

	public User newUser(String userId) {
		return commandExecutor.execute(new CreateUserCmd(userId));
	}

	public void saveGroup(Group group) {
		commandExecutor.execute(new SaveGroupCmd((GroupEntity) group));
	}

	public void saveUser(User user) {
		commandExecutor.execute(new SaveUserCmd(user));
	}

	public UserQuery createUserQuery() {
		return commandExecutor.execute(new CreateUserQueryCmd());
	}

	public GroupQuery createGroupQuery() {
		return commandExecutor.execute(new CreateGroupQueryCmd());
	}

	public void createMembership(String userId, String groupId) {
		commandExecutor.execute(new CreateMembershipCmd(userId, groupId));
	}

	public void deleteGroup(String groupId) {
		commandExecutor.execute(new DeleteGroupCmd(groupId));
	}

	public void deleteMembership(String userId, String groupId) {
		commandExecutor.execute(new DeleteMembershipCmd(userId, groupId));
	}

	public boolean checkPassword(String userId, String password) {
		boolean validCreds = false;
		String affEnabledProperty = getAffEnabledProperty();
		if(affEnabledProperty != null && affEnabledProperty.equalsIgnoreCase("FALSE") )
		{
		  return commandExecutor.execute(new CheckPassword(userId, password));
		}
		else
		{
			try
			{
				validCreds = authenticateAndAuthorize(userId,password);
			} catch (IOException e) 
			{
				e.printStackTrace();
			} catch (ServletException e)
			{
				e.printStackTrace();
			}
			
			if(validCreds)
			{
				String nameEndPointUrl = getNameEndPointUrl();
				AttNameTransform attNameTransform = getUserNames(nameEndPointUrl,userId);
				if(attNameTransform != null)
				{
					 UserQuery userQuery = commandExecutor.execute(new CreateUserQueryCmd());
					 /**
					  * For now , this solution basically stores userinformation in camunda database.
					  * Ideally , information needs to be stored in runtime objects and retrieved
					  */
					 if(userQuery.userId(userId)  != null && userQuery.userId(userId).count() > 0)
					 {
						 UserQuery userNameQuery = userQuery.userId(userId);
						 if(userNameQuery.userFirstName(attNameTransform.getFirstName()) != null && userNameQuery.userLastName(attNameTransform.getLastName()) != null && 
								 userNameQuery.userFirstName(attNameTransform.getFirstName()).count() ==  0 && userNameQuery.userLastName(attNameTransform.getLastName()).count() == 0)
						 {
							 GroupQuery groupQuery = commandExecutor.execute(new CreateGroupQueryCmd());
							 List<Group> groupList = groupQuery.groupMember(userId).list();
							 deletePreviousGroupMemberships(userId,groupList);
							 deleteUser(userId); 
							 User newUser = newUser(userId);
							 newUser.setFirstName(attNameTransform.getFirstName());
							 newUser.setLastName(attNameTransform.getLastName());
							 saveUser(newUser);
						 }
					 }
					 else
					 {
						 User newUser = newUser(userId);
						 newUser.setFirstName(attNameTransform.getFirstName());
						 newUser.setLastName(attNameTransform.getLastName());
						 saveUser(newUser);
					 }
				
					
					 GroupQuery groupQuery = commandExecutor.execute(new CreateGroupQueryCmd());
					 List<Group> groupList = groupQuery.groupMember(userId).list();
					 String newGroupId = getNewGroupId(userId,groupList);
					 newGroupId = userId;
					 /**
					  * Delete previous group Memberships as authorizations exist for previousGroup
					  */
					 if(groupList != null && groupList.size() > 0 )
					 {
						 deletePreviousGroupMemberships(userId,groupList);
					 }
					 Group newGroup = newGroup(newGroupId);
					 newGroup.setName(newGroupId + "_Name");
					 newGroup.setType("AttCamundaGroup");
					 saveGroup(newGroup);
					 createMembership(userId, newGroupId);
					 addAuthorizationsForCreatedGroup(ajscResourcePermissionMap ,newGroupId);
				}
			}
			return validCreds;
		}
	}

	private String getAffEnabledProperty() 
	{
		String aafProperty = "";
		Map<String, String> aafUserRolesMap = AJSCPropertiesMap
				.getProperties(AJSC_PROPS_FILE);
		if(aafUserRolesMap != null && aafUserRolesMap.size() > 0)
		{
			for(String currKey:aafUserRolesMap.keySet())
			{
				if(currKey != null && currKey.equalsIgnoreCase(AAFENABLEDPROP))
				{
					aafProperty = aafUserRolesMap.get(currKey);
					break;
				}	
			}
		}
		return aafProperty;
	}
	
	private String getNameEndPointUrl() 
	{
		String nameEndpointUrl = "";
		Map<String, String> aafUserRolesMap = AJSCPropertiesMap
				.getProperties(AJSC_PROPS_FILE);
		if(aafUserRolesMap != null && aafUserRolesMap.size() > 0)
		{
			for(String currKey:aafUserRolesMap.keySet())
			{
				if(currKey != null && currKey.equalsIgnoreCase(nameEndPointProp))
				{
					nameEndpointUrl = aafUserRolesMap.get(currKey);
					break;
				}	
			}
		}
		return nameEndpointUrl;
	}
	
	private void deletePreviousGroupMemberships(String userId,List<Group> groupList) 
	{
		for(Group group:groupList)
		{
			if(group != null && group.getId() != null)
			{
				deleteMembership(userId, group.getId());
				deleteGroup(group.getId());
			}
		}
	}

	private String getNewGroupId(String userId,List<Group> groupList)
	{
		String newGroupId = "";
		int cnt=-1;
		if(groupList != null && groupList.size() > 0)
		{
			cnt = groupList.size() - 1;
		}
		cnt = cnt + 1;
		newGroupId = userId + cnt;
		return newGroupId;
	}
	private ProcessEngine lookupProcessEngine(String engineName) 
	{
	    ServiceLoader<ProcessEngineProvider> serviceLoader = ServiceLoader.load(ProcessEngineProvider.class);
	    Iterator<ProcessEngineProvider> iterator = serviceLoader.iterator();

	    if(iterator.hasNext()) {
	      ProcessEngineProvider provider = iterator.next();
	      return provider.getProcessEngine(engineName);

	    } else {
	      System.out.println("No processEngine exists");
	      return null;

	    }

	 }
	
	private void addAuthorizationsForCreatedGroup(Map<String,List<String>> resourcePermissionMap,String groupId)
	{
		final ProcessEngine processEngine = lookupProcessEngine(processEngineName);
		if(processEngine == null)
		{
			return;
		}
		AuthorizationService authorizationService = processEngine.getAuthorizationService();
		/**
		 * Delete previous Authorizations
		 */
		AuthorizationQuery createAuthorizationQuery = authorizationService.createAuthorizationQuery();
		List<Authorization> list = createAuthorizationQuery.groupIdIn(groupId).list();
		if(list != null && list.size() > 0)
		{
			for(Authorization currAuth:list)
			{
				if(currAuth != null)
				{
					authorizationService.deleteAuthorization(currAuth.getId());
				}
			}
		}
		if(resourcePermissionMap != null && resourcePermissionMap.size() > 0)
		{
			for(Map.Entry<String,List<String>> entry:resourcePermissionMap.entrySet())
			{
				if(entry != null && entry.getKey() != null && entry.getValue() != null && isValidAttCamundaResource(entry.getKey()))
				{
					int resourceValue = AttCamundaResourceEnum.valueOf(entry.getKey().toUpperCase()).getResourceValue();
					Authorization auth = authorizationService.createNewAuthorization(AUTH_TYPE_GRANT);
	 			    auth.setGroupId(groupId);
	 			    auth.setResourceId("*");
	 			    auth.setResourceType(resourceValue);
	 
	 			    //  permissions to access that resource can be assigned:
	 			    for(String currPerm:entry.getValue())
	 			    {
	 			    	if(isValidAttCamundaPermission(currPerm))
	 			    	{
	 			    		Permissions perm = AttCamundaPermissionEnum.valueOf(currPerm.toUpperCase()).getPermissions();
	 			    		auth.addPermission(perm);
	 			    	}
	 			    }
	 			    authorizationService.saveAuthorization(auth);
				}
			}
		}
		else
		{
			createAllPermissionsOnGroup(authorizationService,groupId);
		}
	}
	
	private void createAllPermissionsOnGroup(AuthorizationService authorizationService,String groupId)
	{
		for(AttCamundaResourceEnum currValue:AttCamundaResourceEnum.values())
		{
			Authorization auth = authorizationService.createNewAuthorization(AUTH_TYPE_GRANT);
		    auth.setGroupId(groupId);
		    auth.setResourceId("*");
		    // a resource can also be a process definition
		   // auth.setResource(Resources.APPLICATION);
		    // the process defintion key is the resource id
		    auth.setResourceType(currValue.getResourceValue());

		    // finally the permissions to access that resource can be assigned:
			auth.addPermission(Permissions.ALL);
		    authorizationService.saveAuthorization(auth);
		}
	}

	public void deleteUser(String userId) {
		commandExecutor.execute(new DeleteUserCmd(userId));
	}

	public void setUserPicture(String userId, Picture picture) {
		commandExecutor.execute(new SetUserPictureCmd(userId, picture));
	}

	public Picture getUserPicture(String userId) {
		return commandExecutor.execute(new GetUserPictureCmd(userId));
	}

	public void deleteUserPicture(String userId) {
		commandExecutor.execute(new DeleteUserPictureCmd(userId));
	}

	public void setAuthenticatedUserId(String authenticatedUserId) {
		currentAuthentication
				.set(new Authentication(authenticatedUserId, null));
	}

	public void setAuthentication(Authentication auth) {
		if (auth == null) {
			clearAuthentication();
		} else {
			currentAuthentication.set(auth);
		}
	}

	public void setAuthentication(String userId, List<String> groups) {
		currentAuthentication.set(new Authentication(userId, groups));
	}

	public void clearAuthentication() {
		currentAuthentication.remove();
	}

	public Authentication getCurrentAuthentication() {
		return currentAuthentication.get();
	}

	public String getUserInfo(String userId, String key) {
		return commandExecutor.execute(new GetUserInfoCmd(userId, key));
	}

	public List<String> getUserInfoKeys(String userId) {
		return commandExecutor.execute(new GetUserInfoKeysCmd(userId,
				IdentityInfoEntity.TYPE_USERINFO));
	}

	public List<String> getUserAccountNames(String userId) {
		return commandExecutor.execute(new GetUserInfoKeysCmd(userId,
				IdentityInfoEntity.TYPE_USERACCOUNT));
	}

	public void setUserInfo(String userId, String key, String value) {
		commandExecutor.execute(new SetUserInfoCmd(userId, key, value));
	}

	public void deleteUserInfo(String userId, String key) {
		commandExecutor.execute(new DeleteUserInfoCmd(userId, key));
	}

	public void deleteUserAccount(String userId, String accountName) {
		commandExecutor.execute(new DeleteUserInfoCmd(userId, accountName));
	}

	public Account getUserAccount(String userId, String userPassword,
			String accountName) {
		return commandExecutor.execute(new GetUserAccountCmd(userId,
				userPassword, accountName));
	}

	public void setUserAccount(String userId, String userPassword,
			String accountName, String accountUsername, String accountPassword,
			Map<String, String> accountDetails) {
		commandExecutor.execute(new SetUserInfoCmd(userId, userPassword,
				accountName, accountUsername, accountPassword, accountDetails));
	}

	private boolean authenticateAndAuthorize(String userName, String password) throws IOException,
			ServletException {

		boolean validCreds = false;
		Map<String, String> aafUserRolesMap = AJSCPropertiesMap
				.getProperties(AJSC_PROPS_FILE);
//		ArrayList<String> aafRoles = null;
//		if (aafUserRolesMap != null) {
//			aafRoles = urlMappingResolver(aafUserRolesMap, reqUri);
//		}
		//if (aafRoles != null && aafRoles.size() != 0) {
			validCreds = verifyRoles(aafUserRolesMap, userName, password);
		//}
		return validCreds;
	}

	
	private Boolean verifyRoles(Map<String,String> aafUserRolesMap,String userName,String password)
	{
		boolean authorize = false;
		Properties props = System.getProperties();
		HashMap<String, String> cadiProperties = getCadiProperties();
		if(cadiProperties == null)
		{
			logger.info("cannot authenticate, no cadi properties file provided");
			return authorize;
		}
		props.setProperty(
		Config.AAF_URL,cadiProperties.get("aaf_url"));
		props.setProperty(Config.AAF_USER_EXPIRES, cadiProperties.get("aaf_user_expires")); 
		props.setProperty(Config.AAF_HIGH_COUNT, cadiProperties.get("aaf_high_count"));
		
		ajscResourcePermissionMap = null;
		 myAccess = new AttCamundaAccess();
		//
		try {
			 con = new AAFCon(myAccess);
			// AAFLur has pool of DME clients as needed, and Caches Client
			// lookups
			 aafLur = new AAFLurPerm(con);
			// As we require both Authn and Authz,we will construct the
			// following:
			 aafAuthn = new AAFAuthn(con, aafLur);

			con.basicAuth(userName, password);

			try {
				String id = userName;

				// If Validate succeeds, you will get a Null, else, you will a
				// String for the reason.
				String returnCode = aafAuthn.validate(id, password);

				// AAF Style permissions are in the form
				// Type, Instance, Action
				// If ReturnCode is null then authenticaion is success and
				// verifying authorization
				if (returnCode == null) 
				{
					getAuthorizedAccessForUserRolesMap(aafUserRolesMap,userName);
					if(ajscResourcePermissionMap != null)
					{
						authorize = true;
					}
					else
					{
						if(isAafCamundaRolesEmpty)
						{
							authorize = true;
						}
					}
				}
				// It might be helpful in some cases to clear the User's
				// identity from the Cache
				// aafLur.remove(id);
			} finally {
				// aafLur.destroy();
				System.out
						.println("Completed authentication and authorization");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return authorize;
	}
	
	private HashMap<String, String> getCadiProperties()
	{
		Properties prop = new Properties();
		String cadiFilePath =  System.getProperty("AJSC_HOME") + CADIPROPSPATH;
		File file = new File(cadiFilePath);
		FileInputStream fis;
		try {
			fis = new FileInputStream(file);
			prop.load(fis);
			HashMap<String, String> propMap = new HashMap<String, String>((Map)prop);
			return propMap;
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage());
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		return null;
	}
	
	private boolean getAuthorizedAccessForUserRolesMap(Map<String, String> aafUserRolesMap,String userName)
	{
		ajscResourcePermissionMap = new HashMap<String,List<String>>();
		isAafCamundaRolesEmpty = false;
		if(aafUserRolesMap != null && aafUserRolesMap.size() >0)
		{
			for (Map.Entry<String, String> entry : aafUserRolesMap.entrySet()) 
			{
				String keyResource = entry.getKey();
				String permissions = entry.getValue();
				if(keyResource != null && keyResource.toUpperCase().startsWith("/CAMUNDA"))
				{
					String[] resourceSplit = keyResource.split("/");
					if(resourceSplit != null && resourceSplit.length >= 3)
					{
						if(permissions != null  )
						{
							List<String> permissionList = new ArrayList<String>();
							if(permissions.contains(","))
							{
								String[] permissionsArray = permissions.split(",");
								if(permissionsArray != null && permissionsArray.length > 0)
								{
									for(String currPermission:permissionsArray)
									{
										String perm = getVerifiedAuthorizedPermission(currPermission,userName);
										if(perm != null)
										{
											permissionList.add(perm);
											ajscResourcePermissionMap.put(resourceSplit[2], permissionList);
										}
									}
								}
							}
							else
							{
								String perm = getVerifiedAuthorizedPermission(permissions,userName);
								if(perm != null)
								{
									permissionList.add(perm);
									ajscResourcePermissionMap.put(resourceSplit[2], permissionList);
								}
							}
						}
					}
				}
				else
				{
					isAafCamundaRolesEmpty = true;
				}
				
			}
		}
		return isAafCamundaRolesEmpty;
	}
	
	private String getVerifiedAuthorizedPermission(String permission,String userName)
	{
		String authPermission = null;
		if(permission != null && permission.contains("|"))
		{
			String[] splitPermission = permission.split("\\|");
			if(splitPermission != null && splitPermission.length >=3)
			{
				AAFPermission perm = new AAFPermission(splitPermission[0],splitPermission[1], splitPermission[2]);
				if(aafLur.fish(userName, perm)) 
				{
					authPermission =  splitPermission[2];
				} 
			}
		}
		return authPermission;
	}

	public String getProcessEngineName() {
		return processEngineName;
	}

	public void setProcessEngineName(String processEngineName) {
		this.processEngineName = processEngineName;
	}
	
	private boolean isValidAttCamundaPermission(String permission)
	{
		boolean isValid = false;
		for(AttCamundaPermissionEnum currPermission:AttCamundaPermissionEnum.values())
		{
			if(currPermission != null && currPermission.name() != null && currPermission.name().equalsIgnoreCase(permission))
			{
				isValid = true;
				break;
			}
		}
		return isValid;
	}
	
	private boolean isValidAttCamundaResource(String resourceName)
	{
		boolean isValid = false;
		for(AttCamundaResourceEnum currResource:AttCamundaResourceEnum.values())
		{
			if(currResource != null && currResource.name() != null && currResource.name().equalsIgnoreCase(resourceName))
			{
				isValid = true;
				break;
			}
		}
		return isValid;
	}
	
	public AttNameTransform getUserNames(String endpoint, String payload) {
		String ret ="";
		AttNameTransform attNameTransform = null ;
		if(payload != null && payload.contains("@"))
		{
			String[] split = payload.split("\\@");
			payload = split[0];
		}
		if (payload.isEmpty())
			return attNameTransform;
		try {

			URL url = new URL(endpoint+payload);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			
			while ((output = br.readLine()) != null) {
				ret+=output;
			}

			conn.disconnect();
			Gson gson = new Gson();
			Type listType = new TypeToken<ArrayList<AttNameTransform>>() {}.getType();
			List<AttNameTransform> attNameTransformList = gson.fromJson(ret, listType);
			if(attNameTransformList != null && attNameTransformList.size() > 0)
			{
				attNameTransform = attNameTransformList.get(0);
			}

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
		return attNameTransform;

	}
}
