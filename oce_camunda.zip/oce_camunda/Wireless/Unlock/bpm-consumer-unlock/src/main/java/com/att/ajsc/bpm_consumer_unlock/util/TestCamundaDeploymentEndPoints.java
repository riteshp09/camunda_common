package com.att.ajsc.bpm_consumer_unlock.util;
import java.io.FileNotFoundException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Properties;

import com.att.aft.dme2.api.DME2Client;
import com.att.aft.dme2.api.DME2Exception;
import com.att.aft.dme2.api.DME2Manager;


public class TestCamundaDeploymentEndPoints{
	
	public  static void main(String[] args)
	{
		String serviceName = "com.att.ajsc.VerifyCamunda091-v1/services/deployment";
		String version= "0.0.1-SNAPSHOT";
		String envContext = "TEST";
		String routeOffer = "DEFAULT";
		
	    //String clientUri = "http://DME2RESOLVE/service="+ serviceName + "/version=" + version + "/envContext=" + envContext + "/routeOffer=" + routeOffer;
		String clientUri = "http://VerifyCamunda091-v1.ajsc.att.com/services/deployment?version=0.0.1-SNAPSHOT&envContext=TEST&routeOffer=DEFAULT";
		String methodName = "GET";
		String payload = "";
		
		DME2Manager mgr= null;
		DME2Client client = null;
		try 
		{
			Properties props = new Properties();
			System.setProperty("AFT_DME2_HTTP_EXCHANGE_TRACE_ON","false");
			System.setProperty("AFT_LATITUDE","20");
			System.setProperty("AFT_LONGITUDE","30");
			System.setProperty("AFT_ENVIRONMENT", "AFTUAT");
			System.setProperty("AFT_DME2_CONN_IDLE_TIMEOUTMS","3000");
			System.setProperty("DME2.DEBUG", "false");
			mgr = new DME2Manager("JettyClient", props);
			client = new DME2Client(mgr,new URI(clientUri),30000);
			client.setSubContext("deployment");
            client.addHeader("authCode","YXMyNzFrOm5ldzJ5b3Uh");
            client.addHeader("Content-Type", "application/json");
            client.setMethod(methodName);
            client.setPayload(payload);
            client.setAllowAllHttpReturnCodes(true);
            String response = null;
			response = client.sendAndWait(300000);
			System.out.println("Response after hitting the grm services");
			System.out.println("Successful Response:" + response);
			// Object rsp;
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (DME2Exception e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				mgr.stop();
			} catch (DME2Exception e1) 
			{
				e1.printStackTrace();
			}
			
		}
	}

}

