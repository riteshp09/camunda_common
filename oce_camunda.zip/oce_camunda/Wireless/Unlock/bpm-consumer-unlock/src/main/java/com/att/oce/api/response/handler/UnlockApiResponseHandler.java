package com.att.oce.api.response.handler;

import java.util.LinkedHashMap;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public interface UnlockApiResponseHandler extends JavaDelegate {
	
	public DelegateExecution getExecution();
	public String getResponse();
	public LinkedHashMap<String, Object> getException();
	public void handleSuccessResponse() throws Exception;
	public void handleFaultResponse() throws Exception;
	public void preExecute() throws Exception;
	public void postExecute() throws Exception;

}
