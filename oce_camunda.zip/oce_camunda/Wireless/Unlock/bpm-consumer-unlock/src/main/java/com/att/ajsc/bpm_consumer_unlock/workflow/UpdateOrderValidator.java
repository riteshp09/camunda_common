package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.bpm.common.VelocityHelper;
import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.variable.Variables;
import org.json.JSONObject;

public class UpdateOrderValidator implements JavaDelegate {

	static final Logger logger = Logger.getLogger(UpdateOrderValidator.class.getName());
	@SuppressWarnings("unchecked")
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
			//	String PDUResponse = execution.getVariable("pduResponse").toString();
				Map<String,String> unlockContext = (Map<String, String>) execution.getVariable("unlockContext");
				Map<String,Object> order = (Map<String, Object>) execution.getVariable("order");
				Map<String, Object>  accounts =  (Map<String, Object>)order.get("Accounts");
				Map<String, Object>  account =   (Map<String, Object>) ( (List<Object>)accounts.get("Account")).get(0);
				String enterpriseType = account.get("EnterpriseType").toString();
				
				unlockContext.put("ENTERPRISE_TYPE", enterpriseType);
				
				if(enterpriseType.equalsIgnoreCase(CommonConstants.ENTERPRISE_CRU)){
					order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_IN_QUEUE, CommonConstants.LOSG_SUBSTATUS_REQUIRES_CRU_SUBMITTER_VALIDATION));
					unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
					unlockContext.put("isPDURequired", CommonConstants.VALUE_FALSE);
					if(unlockContext.get("Make")!=null)
					UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.CRU_FALLOUT_REASON);
					execution.setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(CommonConstants.LOSG_SUBSTATUS_REQUIRES_CRU_SUBMITTER_VALIDATION,CommonConstants.CRU_FALLOUT_REASON));
					execution.setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
				}
				
				else if(unlockContext.get("Make").toString().equalsIgnoreCase(CommonConstants.MAKE_TYPE_APPLE)){
					if(unlockContext.get("isDeviceAlreadyUnlock")!=null && ((String)unlockContext.get("isDeviceAlreadyUnlock")).equals(CommonConstants.VALUE_TRUE)){
						unlockContext.put("isPDURequired", CommonConstants.VALUE_FALSE);
						if(unlockContext.get("Make")!=null)
						UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
					}else{
						unlockContext.put("isPDURequired", CommonConstants.VALUE_TRUE);
					}
					
				}
				else{
					//Make sure that idue respons handler should set this value in unlockContext
					if(unlockContext.get(CommonConstants.UNLOCK_CODE)!=null && !unlockContext.get(CommonConstants.UNLOCK_CODE).toString().equals("0") && !unlockContext.get(CommonConstants.UNLOCK_CODE).toString().equals("")){
						unlockContext.put("isPDURequired", CommonConstants.VALUE_FALSE);
						order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_APPROVED, CommonConstants.LOSG_SUBSTATUS_COMPLETED));
						unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_APPROVED);
						if(unlockContext.get("Make")!=null)
						UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
						String noteText = "unlock approved; customer has been emailed unlock instructions with Unlock Code : "+unlockContext.get(CommonConstants.UNLOCK_CODE).toString(); // +unlockContext.get(CommonConstants.UNLOCK_CODE).toString();
						//noteText = VelocityHelper.renderDynamicTemplate(unlockContext, noteText);
						unlockContext.put(CommonConstants.ADDNOTE_TEXT, noteText);
						
						
					}else{
						order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_IN_QUEUE, UnlockUtils.getSubStatusForFallout(unlockContext,"updateOrder")));
						unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
						unlockContext.put("isPDURequired", CommonConstants.VALUE_FALSE);
						if(unlockContext.get("Make")!=null)
						UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.NO_UNLOCK_CODE_FALLOUT_REASON);
						execution.setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"updateOrder"),CommonConstants.NO_UNLOCK_CODE_FALLOUT_REASON));
						execution.setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
					}
					
				}
				
			/*	if(PDUResponse!=null && !PDUResponse.equals("")){
					logger.info("PDUResponse :"+PDUResponse);
					JSONObject jsonObject = new JSONObject(PDUResponse);
					String responeStatus  = jsonObject.getString("status");
					//check this condition
					if(responeStatus == "Failure" && Code == "Any N/W Activity Present on device?" && Value == "No"){
						order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_DENIED, "NON_ATT_IMEI"));
						unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
					}
					else{
						order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_IN_QUEUE, "TORCH_APPLE_FAILED"));
						unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
					}
					
				}*/
					
				execution.setVariableLocal(CommonConstants.ORDER, Variables.objectValue(order).
						serializationDataFormat(Variables.SerializationDataFormats.JSON).create());
			}

}
