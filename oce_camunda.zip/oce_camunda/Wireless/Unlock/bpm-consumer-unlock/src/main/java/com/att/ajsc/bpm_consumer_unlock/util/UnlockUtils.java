package com.att.ajsc.bpm_consumer_unlock.util;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Constructor;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;










//import com.att.aft.dme2.internal.jettison.json.JSONObject;
import com.att.ajsc.beans.PropertiesMapBean;
import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
//import com.att.oce.bpm.common.JSONObject;
import com.att.oce.bpm.common.VelocityHelper;
import com.att.oce.v10.internal.order.model.Order;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationModule;

public class UnlockUtils {

	static final Logger logger = Logger.getLogger(UnlockUtils.class.getName());
	public static final String[] NokiaModelList = new String[] {"1100","2320","2330","2600","2610","2630","2660","2680","2720","3120","3220","3590","3595","3650","6010","6030","6061","6085","6126","6200","6230","6350","6650","6682","6750","6790","7210","8390","8890","9300","6102i","6102I","6340i","6340I","6555i","6555I","6590i","6590I","6800","6820","C3","c3","E61","e61","E62","e62","E71X","e71X","E71x","e71x","n75","N75","n80","N80","N-Gage","N-GAGE","n-gage","N-gage","n-Gage","n-GAGE"};
	public static final String[] skippingErrorCodes = new String[]{"SubNtExist_10150","30000109001","300800109001","30000012001","30001794006"};
	public static final String[] statusReasonCodesForFraud = new String[]{"AFRD","ASF","BCF","BFR1","BFR2","BFRD","BPFR","CF","CFWR","CNPF","CNVF","DFF","FPFC","FPFS","FR","FRD","FRDH","FRDI","FRDR","FV","PFR","PFR","PPF","SF","SFDH","SFDI","SFDR","SFI","SFW","SFWR"};

	/**
	 * 
	 * @param order
	 * @return customer type for unlock
	 */
	public static String getCustomerType(Map<String,Object> order){
		String customerType="";
		List<Object>  accountArray = (List<Object>) ( (Map<?,?>)order.get("Accounts")).get("Account");
		customerType = ((Map<?,?>)accountArray.get(0)).get("AccountSubCategory").toString();
		if(!customerType.equals("") && customerType.equalsIgnoreCase(CommonConstants.CURRENT_CUSTOMER_TYPE)){
			customerType="Current";
		}else
		{
			customerType ="NonATT";
		}
		//logger.info("customerType :"+customerType);
		return customerType;
	}

	/**
	 * @author 
	 * @param order
	 * @return Imei from order payload
	 */

	public static String getReqestedIMEI(Map<String, Object> order) {
		// TODO Auto-generated method stub
		String requestedIMIE="";
		List<Object>  lineitemarray = (List<Object>) ( (Map<?,?>)order.get("LineItems")).get("LineItem");
		requestedIMIE = ( (Map<?,?>)( (Map <?,?>)((Map<?,?>)lineitemarray.get(0)).get("HardGood")).get("WirelessHardGoodChars")).get("Imei").toString();
	//	logger.info("requestedIMIE : "+requestedIMIE);

		return requestedIMIE;
	}

	/**
	 * 
	 * @param order
	 * @return true if BULK Unlock Order
	 */
	public static boolean  isBulkUnlockOrder(Map<String, Object> order) {
		// TODO Auto-generated method stub
		boolean isBulk=false;
		if(((Map<?,?>)((Map<?,?>)order.get("OrderSource")).get("AdditionalDetails"))!=null){
			List<Object>  additionaldetailarray = (List<Object>) ((Map<?,?>)((Map<?,?>)order.get("OrderSource")).get("AdditionalDetails")).get("AdditionalDetail");
			if(additionaldetailarray!=null && !additionaldetailarray.isEmpty()){
				for(int i=0;i<additionaldetailarray.size();i++){
					String code =((Map<?,?>)additionaldetailarray.get(i)).get("Code").toString();
					if(code.equalsIgnoreCase(CommonConstants.BULK_UNLOCK_JOB_NAME)){
						isBulk=true;
					}
				}
			}
		}

		return isBulk;
	}

	/**
	 * This function set losg status substatus in order
	 * @param order
	 * @param losgStatus
	 * @param losgSubStatus
	 * @return Groups with updated updated LOSG Status, Sub status
	 * @throws NullPointerException
	 */
	public static Map<?, ?> setLOSGStatusSubStatus(Map<String, Object> order, String losgStatus, String losgSubStatus) throws NullPointerException {

		Map<String, Object>  groups =  (Map<String, Object>)order.get("Groups");
		//logger.info("Start :Set LOSG status Substatus :"+losgStatus+"/"+losgSubStatus);
		List<Object> grouplist =(List<Object>)groups.get("Group");
		Map<String, Object>  group =   (Map<String, Object>) ( (List<Object>)groups.get("Group")).get(0);
		Map<String, Object>  groupCharacteristics =  (Map<String, Object>)group.get("GroupCharacteristics");
		//GroupCharacteristics,LoSGCharacteristics,LoSGStatus,Status,SubStatus
		Map<String, Object>  loSGCharacteristics =  (Map<String, Object>)groupCharacteristics.get("LoSGCharacteristics");
		Map<String, Object> loSGStatus = (Map<String, Object>)loSGCharacteristics.get("LoSGStatus");
		loSGStatus.put("Status", losgStatus);
		loSGStatus.put("SubStatus", losgSubStatus);
		loSGCharacteristics.put("LoSGStatus", loSGStatus);
		groupCharacteristics.put("LoSGCharacteristics", loSGCharacteristics);
		group.put("GroupCharacteristics", groupCharacteristics);
		grouplist.set(0, group);
		groups.put("Group", grouplist);
		//logger.info("Completed :Set LOSG status Substatus :"+losgStatus+"/"+losgSubStatus);
		return groups;
	}

	public static Map<String, String> getLOSGStatusSubStatus(Map<?, ?> order) throws NullPointerException {

		Map<String, Object>  groups =  (Map<String, Object>)order.get("Groups");
		List<Object> grouplist =(List<Object>)groups.get("Group");
		Map<String, Object>  group =   (Map<String, Object>) ( (List<Object>)groups.get("Group")).get(0);
		Map<String, Object>  groupCharacteristics =  (Map<String, Object>)group.get("GroupCharacteristics");
		Map<String, Object>  loSGCharacteristics =  (Map<String, Object>)groupCharacteristics.get("LoSGCharacteristics");
		Map<String, Object>  loSGStatus =  (Map<String, Object>)loSGCharacteristics.get("LoSGStatus");
		
		Map<String, String> loSGStatusMap = new HashMap<>();
		loSGStatusMap.put("Status", (String)loSGStatus.get("Status"));
		loSGStatusMap.put("SubStatus", (String)loSGStatus.get("SubStatus"));

		return loSGStatusMap;
	}

	@SuppressWarnings("unchecked")
	public static Map<?, ?> setInitialLoSGStatus(Map<String,Object> order, String losgStatus, String losgSubStatus) throws NullPointerException {

		Map<String, Object>  groups =  (Map<String, Object>)order.get("Groups");
		List<Object> grouplist =(List<Object>)groups.get("Group");
		Map<String, Object>  group =   (Map<String, Object>) ( (List<Object>)groups.get("Group")).get(0);
		Map<String, Object>  groupCharacteristics =  (Map<String, Object>)group.get("GroupCharacteristics");
		Map<String, Object>  loSGCharacteristics =  (Map<String, Object>)groupCharacteristics.get("LoSGCharacteristics");

		Map<String, Object> loSGStatus = new HashMap<String, Object>();

		loSGStatus.put("Status", losgStatus);
		loSGStatus.put("SubStatus", losgSubStatus);
		loSGCharacteristics.put("LoSGStatus", loSGStatus);
		groupCharacteristics.put("LoSGCharacteristics", loSGCharacteristics);
		group.put("GroupCharacteristics", groupCharacteristics);
		grouplist.set(0, group);
		groups.put("Group", grouplist);

		//logger.info("Completed :Set LOSG status Substatus :"+losgStatus+"/"+losgSubStatus);

		return groups;

	}

	/**
	 * 
	 * @param order 
	 * @return initial LoSGStatus for unlock
	 */
	@SuppressWarnings("unchecked")
	public static Map<?, ?> setIntializations(Map<String,Object> order, String status)
	{
		String OrderType = order.get("OrderType").toString();

		Map<String, Object>  accounts =  (Map<String, Object>)order.get("Accounts");
		List<Object> accountlist = (List<Object>)accounts.get("Account");
		Map<String, Object>  account =   (Map<String, Object>) ( (List<Object>)accounts.get("Account")).get(0);
		String enterpriseType ="";
		if(account.get("EnterpriseType")!=null)
			enterpriseType = account.get("EnterpriseType").toString();

		Map<String, Object>  groups =  (Map<String, Object>)order.get("Groups");
		Map<String, Object>  group =   (Map<String, Object>) ( (List<Object>)groups.get("Group")).get(0);
		Map<String,Object> losgchars = (Map<String, Object>) ((Map<String, Object>) group.get("GroupCharacteristics")).get("LoSGCharacteristics");

		if(order.get("OrderStatus") == null)
		{
			Map<String, Object> OrderStatus = new HashMap<String, Object>();
			OrderStatus.put("Status", status);
			order.put("OrderStatus", OrderStatus);
		}

		if(OrderType.equalsIgnoreCase(CommonConstants.ORDERACTION_CREATE) && losgchars.get("LoSGStatus")==null)
		{		
			if(enterpriseType.equalsIgnoreCase(CommonConstants.ENTERPRISE_CRU))
			{
				order.put("Groups", setInitialLoSGStatus(order, CommonConstants.LOSG_STATUS_SYS_PROCESSING, CommonConstants.LOSG_SS_EMAIL_CONFIRMED));
			}
			else
			{
				order.put("Groups", setInitialLoSGStatus(order, CommonConstants.LOSG_STATUS_PENDING, CommonConstants.LOSG_SS_EMAIL_CONFIRMATION));
			}
		}
		else if(OrderType.equalsIgnoreCase(CommonConstants.ORDERACTION_UPDATE) && losgchars.get("LoSGStatus")==null)
		{
			order.put("Groups", setInitialLoSGStatus(order, CommonConstants.LOSG_STATUS_SYS_PROCESSING, CommonConstants.LOSG_SS_EMAIL_CONFIRMED));
		}

		if(getCustomerType(order).equalsIgnoreCase("NonATT"))
		{
			account.put("EnterpriseType", CommonConstants.ENTERPRISE_NON_CUSTOMER);
			account.put("PaymentArrangement", CommonConstants.PAYMENTARRANGEMENT_POSTPAID);
			accountlist.set(0, account);		
			accounts.put("Account", accountlist);
			order.put("Accounts", accounts);
		}

		return order;

	}



	/**
	 * 
	 * @param order
	 * @param responeMake
	 * @param responeModel
	 * @return lineitems with updated make and model 
	 * @throws NullPointerException
	 */
	public static Map<?, ?> setMakeModel(Map<String, Object> order, String responeMake,String responeModel) throws NullPointerException {
		// TODO Auto-generated method stub HardGood
	//	logger.info("Start :Set Make and Model :"+responeMake+" & "+responeModel);

		Map<String,Object> lineItems=   (Map<String, Object>)order.get("LineItems");
		List<Object> liteitemlist = (List<Object>)lineItems.get("LineItem");
		Map<String, Object>  lineItem =   (Map<String, Object>) ( (List<Object>)lineItems.get("LineItem")).get(0);
		Map<String, Object>  hardGood =  (Map<String, Object>)lineItem.get("HardGood");
		hardGood.put("Make",responeMake);
		hardGood.put("Model",responeModel);
		lineItem.put("HardGood", hardGood);
		liteitemlist.set(0, lineItem);
		lineItems.put("LineItem", liteitemlist);
		//logger.info("Completed :Set Make and Model :"+responeMake+" & "+responeModel);
		return lineItems;
	}

	/**
	 * 
	 * @param unlockInstructionMap
	 * @param order
	 * @return set unlock instruction in order 
	 */
	public static void setUnlockInstructions(Map<?,?> unlockInstructionMap, Map<String,Object> order) {
		Map<String, Object>  lineitems =  (Map<String, Object>)order.get("LineItems");
		List<Object> lineitemlist =(List<Object>)lineitems.get("LineItem");
		Map<String, Object>  lineitem =   (Map<String, Object>) ( (List<Object>)lineitems.get("LineItem")).get(0);
		Map<String, Object> additionalDetails = ((Map<String, Object>)lineitem.get("AdditionalDetails"));

		if(null!=additionalDetails){
			List<Object> additionalDetaillist =(List<Object>)additionalDetails.get("AdditionalDetail");
			/*Map<String, Object> additionalDetail = new HashMap<String, Object>();
			additionalDetail.put("Code", "UnlockInstruction");
			additionalDetail.put("Value", UnlockInstruction);*/
			additionalDetaillist.add(unlockInstructionMap);
			additionalDetails.put("AdditionalDetail", additionalDetaillist);
			lineitem.put("AdditionalDetails", additionalDetails);
			lineitemlist.set(0, lineitem);
			lineitems.put("LineItem", lineitemlist);
			order.put("LineItems", lineitems);
		}else
		{
			additionalDetails = new HashMap<String, Object>();
			List<Object> additionalDetaillist = new ArrayList<Object>();
			/*Map<String, Object> additionalDetail = new HashMap<String, Object>();
			additionalDetail.put("Code", "UnlockInstruction");
			additionalDetail.put("Value", UnlockInstruction);*/
			additionalDetaillist.add(unlockInstructionMap);
			additionalDetails.put("AdditionalDetail", additionalDetaillist);
			lineitem.put("AdditionalDetails", additionalDetails);
			lineitemlist.set(0, lineitem);
			lineitems.put("LineItem", lineitemlist);
			order.put("LineItems", lineitems);

		}
	}

	public static Map<String, Object> setOceOrderNumber(String oceOrderNumber, Map<String, Object> order) {
		order.put("OCEOrderNumber", oceOrderNumber);
		return order;
	}

	/**
	 * 
	 * @param order
	 * @return true if email confirmed and not bulk order
	 * @throws NullPointerException
	 */
	@SuppressWarnings("unchecked")
	public static boolean isFraudCheckRequired(Map<String, Object> order) throws NullPointerException
	{
		boolean isFraudCheck = false;

		Map<String, Object> groups = (Map<String, Object>)order.get("Groups");
		Map<String, Object> group = (Map<String, Object>) ( (List<Object>)groups.get("Group")).get(0);
		String status = (String) ((Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) group.get("GroupCharacteristics")).get("LoSGCharacteristics")).get("LoSGStatus")).get("Status").toString();

		if(order.get("OCEOrderNumber") != null && !status.equalsIgnoreCase(CommonConstants.LOSG_STATUS_PENDING) && !status.equalsIgnoreCase( CommonConstants.LOSG_STATUS_DENIED) && !(isBulkUnlockOrder(order)))
		{
			isFraudCheck=true;
		}

		return isFraudCheck;

	}

	/**
	 * 
	 * @param order
	 * @return true if its bulk order 
	 * @throws NullPointerException
	 */
	@SuppressWarnings("unchecked")
	public static boolean isBulkAutomationRequired(Map<String, Object> order) throws NullPointerException 
	{
		boolean isBulkOrder = false;

		Map<String, Object>  groups =  (Map<String, Object>)order.get("Groups");
		Map<String, Object>  group =   (Map<String, Object>) ( (List<Object>)groups.get("Group")).get(0);
		String status = (String) ((Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) group.get("GroupCharacteristics")).get("LoSGCharacteristics")).get("LoSGStatus")).get("Status").toString();

		if(order.get("OCEOrderNumber") != null && !status.equalsIgnoreCase( CommonConstants.LOSG_STATUS_DENIED) &&  (isBulkUnlockOrder(order)))
		{
			isBulkOrder=true;
		}

		return isBulkOrder;

	}

	/**
	 * 
	 * @param order
	 * @return
	 * @throws NullPointerException
	 */
	@SuppressWarnings("unchecked")
	public static boolean isNoAutomation(Map<String, Object> order) throws NullPointerException 
	{
		boolean isStatusDenied = false;

		Map<String, Object>  groups =  (Map<String, Object>)order.get("Groups");
		Map<String, Object>  group =   (Map<String, Object>) ( (List<Object>)groups.get("Group")).get(0);
		String status = (String) ((Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) group.get("GroupCharacteristics")).get("LoSGCharacteristics")).get("LoSGStatus")).get("Status").toString();

		if(status.equalsIgnoreCase(CommonConstants.LOSG_STATUS_DENIED) || status.equalsIgnoreCase(CommonConstants.LOSG_STATUS_PENDING)  )
		{
			isStatusDenied=true;
		}

		return isStatusDenied;
	}

	public static String getSearchString(String channel, String application, String custOrderNo, String requestId, int duration) {

		// TODO Auto-generated method stub
		String searchString="";
		SimpleDateFormat dateFormat = new SimpleDateFormat ("dd-MMM-yyyy");
		Date toDate = new Date( );
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, duration * -1);
		Date fromDate = cal.getTime();
		String toDateVal= dateFormat.format(toDate);
		String fromDateVal= dateFormat.format(fromDate);
		searchString = "{\"fromDate\":\""+fromDateVal+"\",\"toDate\":\""+toDateVal+
				"\",\"channel\":\""+channel+
				"\",\"applicationName\":\""+application+
				"\",\"customerOrderNumber\":\""+custOrderNo+
				"\",\"requestId\":\""+requestId+"\"}";

		return searchString;
	}

	/**
	 * "Order Number {0}; Submitted: {1}; IMEI: {2}; CTN: {3};"
	 * @param status
	 * @param subStatus
	 * @param params
	 * @return
	 */
	public static String prepareAddNoteText(String status, String subStatus/*, String[] params*/) {
		StringBuffer addNoteText = new StringBuffer("");
		//		addNoteText.append(PropertiesMapBean.getProperty("unlock-messages.properties", "BASE_NOTE_TEXT"));
		//		addNoteText.append(" ")

		addNoteText.append(PropertiesMapBean.getProperty("unlock-messages.properties", status + "_" + subStatus));

		//		MessageFormat format = new MessageFormat(addNoteText.toString());
		return addNoteText.toString();
	}

	public static String prepareAddNoteText(String status, String subStatus, Map<String,Object> addNoteContext) 
	{
		StringBuffer addNoteText = new StringBuffer("");
		if(addNoteContext!=null && !CommonConstants.isNull(addNoteContext.get(CommonConstants.ADDNOTE_TEXT)))
		{
			addNoteText.append(addNoteContext.get(CommonConstants.ADDNOTE_TEXT));
		}
		else
		{
			addNoteText.append(PropertiesMapBean.getProperty("unlock-messages.properties", status + "_" + subStatus));
		}

		/*String addNoteText_str= VelocityHelper.renderDynamicTemplate(addNoteContext, addNoteText.toString());
		return addNoteText_str;*/
		return addNoteText.toString();
	}


	/**
	 * 
	 * @param order, type, code, value
	 * @return
	 * @throws NullPointerException
	 */
	@SuppressWarnings("unchecked")
	public static Map<?, ?> createAutomationSummary(Map<String, Object> order, String type, String code, String value) throws NullPointerException 
	{
		Map<String, Object>  lineitems =  (Map<String, Object>)order.get("LineItems");
		List<Object> lineitemlist =(List<Object>)lineitems.get("LineItem");
		Map<String, Object>  lineitem =   (Map<String, Object>) ( (List<Object>)lineitems.get("LineItem")).get(0);
		Map<String, Object> additionalDetails = ((Map<String, Object>)lineitem.get("AdditionalDetails"));
		if(null!=additionalDetails){
			List<Object> additionalDetaillist =(List<Object>)additionalDetails.get("AdditionalDetail");
			Map<String, Object> additionalDetail = new HashMap<String, Object>();
			if(type != null){
				additionalDetail.put("Type", type);
				additionalDetail.put("ParentType", "Automation Summary");
			}
			additionalDetail.put("Code", code);
			additionalDetail.put("Value", value);
			additionalDetaillist.add(additionalDetail);
			additionalDetails.put("AdditionalDetail", additionalDetaillist);
			lineitem.put("AdditionalDetails", additionalDetails);
			lineitemlist.set(0, lineitem);
			lineitems.put("LineItem", lineitemlist);
			order.put("LineItems", lineitems);
		}
		else{
			additionalDetails = new HashMap<String, Object>();
			List<Object> additionalDetaillist = new ArrayList<Object>();
			Map<String, Object> additionalDetail = new HashMap<String, Object>();
			if(type != null){
				additionalDetail.put("Type", type);
				additionalDetail.put("ParentType", "Automation Summary");
			}
			additionalDetail.put("Code", code);
			additionalDetail.put("Value", value);
			additionalDetaillist.add(additionalDetail);
			additionalDetails.put("AdditionalDetail", additionalDetaillist);
			lineitem.put("AdditionalDetails", additionalDetails);
			lineitemlist.set(0, lineitem);
			lineitems.put("LineItem", lineitemlist);
			order.put("LineItems", lineitems);

		}
		return order;
	}

	/**
	 * 
	 * @param order, code, value
	 * @return
	 * @throws NullPointerException
	 */
	@SuppressWarnings("unchecked")
	public static Map<?, ?> updatedditionalDetailsForGroup(Map<String, Object> order, String code, String value) throws NullPointerException 
	{
		Map<String, Object>  groups =  (Map<String, Object>)order.get("Groups");
		List<Object> grouplist =(List<Object>)groups.get("Group");
		Map<String, Object>  group =   (Map<String, Object>) ( (List<Object>)groups.get("Group")).get(0);
		Map<String, Object> additionalDetails = ((Map<String, Object>)group.get("AdditionalDetails"));
		if(null!=additionalDetails){
			List<Object> additionalDetaillist =(List<Object>)additionalDetails.get("AdditionalDetail");
			Map<String, Object> additionalDetail = new HashMap<String, Object>();
			additionalDetail.put("Code", code);
			additionalDetail.put("Value", value);
			additionalDetaillist.add(additionalDetail);
			additionalDetails.put("AdditionalDetail", additionalDetaillist);
			group.put("AdditionalDetails", additionalDetails);
			grouplist.set(0, group);
			groups.put("Group", grouplist);
			order.put("Groups", groups);
		}
		else{
			additionalDetails = new HashMap<String, Object>();
			List<Object> additionalDetaillist = new ArrayList<Object>();
			Map<String, Object> additionalDetail = new HashMap<String, Object>();
			additionalDetail.put("Code", code);
			additionalDetail.put("Value", value);
			additionalDetaillist.add(additionalDetail);
			additionalDetails.put("AdditionalDetail", additionalDetaillist);
			group.put("AdditionalDetails", additionalDetails);
			grouplist.set(0, group);
			groups.put("Group", grouplist);
			order.put("Groups", groups);
		}
		return order;
	}

	/**
	 * 
	 * @param order
	 * @return phone type which used for report summary
	 * @throws NullPointerException
	 */
	@SuppressWarnings("unchecked")
	public static String getPhoneType(String make) throws NullPointerException 
	{
		String phoneType = "";


		if(make.equalsIgnoreCase(CommonConstants.MAKE_TYPE_APPLE)){
			phoneType = CommonConstants.MAKE_TYPE_APPLE;
		}
		else if(make.equalsIgnoreCase(CommonConstants.MAKE_TYPE_NOKIA)){
			phoneType = CommonConstants.MAKE_TYPE_NOKIA;
		}
		else{
			phoneType = CommonConstants.MAKE_TYPE_NON_APPLE;
		}
		return phoneType;
	}


	/**
	 * 
	 * @param order
	 * @param unlockContext: context for unlock
	 * @param componentName : This is name of component from which function called rms, idue,idd,iap
	 * @return
	 * @throws NullPointerException
	 */
	@SuppressWarnings("unchecked")
	public static String getSubStatusForFallout(Map<String,String> unlockContext,String componentName) throws NullPointerException 
	{


		String SubStatus = "";
		if(unlockContext.get("isBulkUnlockOrder")!=null && unlockContext.get("isBulkUnlockOrder").toString().equalsIgnoreCase("true")){
			SubStatus=CommonConstants.LOSG_SUB_STATUS_BULK;
		}else{
			if(unlockContext.get("CustomerType")!=null && unlockContext.get("CustomerType").equalsIgnoreCase("NonATT")){
				if(componentName!=null && componentName.equalsIgnoreCase("brms"))
				{
					SubStatus= getVerifiedDeviceSubStatus(unlockContext.get("Make"),unlockContext.get("Model"));
				}
				else{	
					if (unlockContext.get(CommonConstants.PREPAIED_INDICATOR)!=null ){
						SubStatus= CommonConstants.LOSG_SUBSTATUS_GOPHONE_VERIFIED;
					}


					else{
						SubStatus= getVerifiedDeviceSubStatus(unlockContext.get("Make"),unlockContext.get("Model"));
					}

				}
			}else
			{
				if(componentName!=null && componentName.equalsIgnoreCase("brms"))
				{
					SubStatus= getUnverifiedDeviceSubStatus(unlockContext.get("Make"),unlockContext.get("Model"));
				}
				else if(componentName!=null && componentName.equalsIgnoreCase("idue"))
				{
					if (unlockContext.get(CommonConstants.PREPAIED_INDICATOR)!=null){
						SubStatus= CommonConstants.LOSG_SUBSTATUS_GOPHONE_UNVERIFIED;
					}

					else{
						SubStatus= getUnverifiedDeviceSubStatus(unlockContext.get("Make"),unlockContext.get("Model"));
					}


				}
				else if(componentName!=null && componentName.equalsIgnoreCase("idd"))
				{
					if (unlockContext.get(CommonConstants.PREPAIED_INDICATOR)!=null)
					{
						SubStatus= CommonConstants.LOSG_SUBSTATUS_GOPHONE_VERIFIED;
					}

					else{
						SubStatus= getVerifiedDeviceSubStatus(unlockContext.get("Make"),unlockContext.get("Model"));
					}


				} else if(componentName!=null && ("pdu".equalsIgnoreCase(componentName) || "ids".equalsIgnoreCase(componentName))) {
					SubStatus = CommonConstants.LOSG_SUBSTATUS_TORCH_APPLE_FAILED;
				}
				else{
					if((unlockContext.get(CommonConstants.PREPAIED_INDICATOR)!=null )
							|| (unlockContext.get(CommonConstants.ACC_TYPE)!=null &&  unlockContext.get(CommonConstants.ACC_TYPE).equalsIgnoreCase(CommonConstants.ACC_TYPE_I) && unlockContext.get(CommonConstants.SUB_TYPE)!=null && (unlockContext.get(CommonConstants.SUB_TYPE).equalsIgnoreCase(CommonConstants.SUB_TYPE_G) || unlockContext.get(CommonConstants.SUB_TYPE).equalsIgnoreCase(CommonConstants.SUB_TYPE_H) )) 
							||(unlockContext.get(CommonConstants.ACC_TYPE)!=null &&  unlockContext.get(CommonConstants.ACC_TYPE).equalsIgnoreCase(CommonConstants.ACC_TYPE_S) && unlockContext.get(CommonConstants.SUB_TYPE)!=null && unlockContext.get(CommonConstants.SUB_TYPE).equalsIgnoreCase(CommonConstants.SUB_TYPE_R)))
					{
						SubStatus= CommonConstants.LOSG_SUBSTATUS_GOPHONE_VERIFIED;
					}
					else{
						SubStatus= getVerifiedDeviceSubStatus(unlockContext.get("Make"),unlockContext.get("Model"));
					}

				}
			}
		}
		
		//logger.info("Sub status for fallout: "+SubStatus);
		return SubStatus;
	}

	/**
	 * 
	 * @param make
	 * @param model
	 * @return unverified sub status based on make and model values 
	 */
	public static String getUnverifiedDeviceSubStatus(String make , String model){
		if (make.equalsIgnoreCase(CommonConstants.MAKE_TYPE_APPLE)){
			return CommonConstants.LOSG_SUBSTATUS_APPLE_UNVERIFIED;
		}
		else if (make.equalsIgnoreCase(CommonConstants.MAKE_TYPE_NOKIA) && Arrays.asList(NokiaModelList).contains(model)){
			return CommonConstants.LOSG_SUBSTATUS_NOKIA_UNVERIFIED;
		}
		else
		{
			return CommonConstants.LOSG_SUBSTATUS_NON_APPLE_UNVERIFIED;
		}
	}

	/**
	 * 
	 * @param make
	 * @param model
	 * @return verified sub status based on make and model values 
	 */
	public static String getVerifiedDeviceSubStatus(String make , String model){
		if (make.equalsIgnoreCase(CommonConstants.MAKE_TYPE_APPLE)){
			return CommonConstants.LOSG_SUBSTATUS_APPLE_VERIFIED;
		}
		else if (make.equalsIgnoreCase(CommonConstants.MAKE_TYPE_NOKIA) && Arrays.asList(NokiaModelList).contains(model)){
			return CommonConstants.LOSG_SUBSTATUS_NOKIA_VERIFIED;
		}
		else
		{
			return CommonConstants.LOSG_SUBSTATUS_NON_APPLE_VERIFIED;
		}
	}
	/**
	 * 
	 * @param messageStr
	 * @return json formated order payload
	 * @throws JAXBException 
	 * @throws JsonProcessingException 
	 */
	public static String xmlToJson(String messageStr) throws JAXBException, JsonProcessingException
	{

		int from = messageStr.indexOf("<Order>", 0);
		int to = messageStr.indexOf("</Order>", 0);
		String orderXml = messageStr.substring(from, to+8);
		orderXml = orderXml.replace("<Order>", "<Order xmlns=\"http://oce.att.com/OCE/Namespaces/Types/Private/OCEDataModel.xsd\">");
		Order order = VelocityHelper.unmarshlXmlToObject(orderXml);
		String json = VelocityHelper.marshalToJson(order);
		if(json.contains("{http://oce.att.com/OCE/Namespaces/Types/Private/OCEDataModel.xsd}GroupRef")){
			int grouprefstart=json.indexOf("\"GroupRef\"", 0);
			int grouprefend=json.indexOf("typeSubstituted", 0);
			String groupref=json.substring(grouprefstart, grouprefend+23);
			System.out.println(groupref);
			if(groupref.contains("\"value\"")){
				int grprefstrart=groupref.indexOf("value",0);
				String grouprefval=groupref.substring(grprefstrart+8,grprefstrart+16);
				System.out.println(grouprefval);
				json=json.replace(groupref, "\"GroupRef\":[\""+grouprefval+"\"]");
			}

		}

		return json;
	}



	/**
	 * 
	 * @param errorCode
	 * @param errorDesc
	 * @return errors 
	 */
	public static Map<?,?> getErrors(
			String errorCode,
			String errorDesc) {
		// TODO Auto-generated method stub
		Map<String,Object> errors= new HashMap<String, Object>();
		List<Object> errorlist = new ArrayList<Object>();
		Map<String, Object> error = new HashMap<String, Object>();
		error.put("ErrorCode", errorCode);
		error.put("ErrorDescription", errorDesc);
		errorlist.add(error);
		errors.put("Error", errorlist);
		return errors;
	}

	/**
	 * 
	 * @param order
	 * @param applicationName
	 * @return
	 */
	public static Map<?,?> getOrderTasks(Map<String, Object> order, String applicationName) {
		// TODO Auto-generated method stub
		Map<String,Object> orderTasks= new HashMap<String, Object>();
		List<Object> orderTasklist = new ArrayList<Object>();
		Map<String, Object> orderTask = new HashMap<String, Object>();
		orderTask.put("OrderNumber", order.get("OCEOrderNumber"));
		if( order.get("OCEOrderNumber").toString().equals("")){
			orderTask.put("CustomerOrderNumber", order.get("CustomerOrderNumber"));
		}
		orderTask.put("ApplicationName", applicationName);
		orderTasklist.add(orderTask);
		orderTasks.put("OrderTask", orderTasklist);
		return orderTasks;
	}

	public static String getDecryptedPasscodeParams(
			Map<String, Object> order) {
		// TODO Auto-generated method stub
		String unmaskingParam = "";
		Map<String, Object>  accounts =  (Map<String, Object>)order.get("Accounts");
		List<Object> accountlist = (List<Object>)accounts.get("Account");
		Map<String, Object>  account =   (Map<String, Object>) ( (List<Object>)accounts.get("Account")).get(0);
		String enterpriseType ="";
		if(account.get("PassCode")!=null)
			unmaskingParam = "fields={\"Account\":[\"Passcode\"]}&accountFilter=MOBILITY_ACCOUNT";
		return unmaskingParam;
	}
	/**
	 * 
	 * @param account
	 * @return true if Active Military ='Y'
	 */
	public static boolean isActiveMilitary(Map<String, Object> account) {
		// TODO Auto-generated method stub
		boolean isActiveMilitary=false;
		Map<String, Object> additionalDetails = ((Map<String, Object>)account.get("AdditionalDetails"));
		if(null!=additionalDetails){
			List<Map<String, Object>> additionalDetaillist =(List<Map<String, Object>>)additionalDetails.get("AdditionalDetail");
			for (Map<String, Object> additionalDetail : additionalDetaillist) {

				if(additionalDetail.get("Code").toString().equalsIgnoreCase("ActiveMilitary") && additionalDetail.get("Value").toString().equalsIgnoreCase("Y")) {
					isActiveMilitary = true;
					break;
				}
			}
		}
		return isActiveMilitary;
	}
	
	public static boolean isGoPhone(String accountType, String accountSubType, String deviceType) {

		if( (deviceType!=null && !deviceType.isEmpty()) ||  (accountType.equalsIgnoreCase("I") && 
				(accountSubType.equalsIgnoreCase("G") || accountSubType.equalsIgnoreCase("H"))) || (accountType.equalsIgnoreCase("S") && accountSubType.equalsIgnoreCase("R")))
		{ 
			return true;
		}
		else
			return false;
	}
	
	/**
	 * 
	 * @param group
	 * @return mobile number for current customer only
	 */
	@SuppressWarnings("unchecked")
	public static String getRequestCTN(Map<String, Object> group){
		String requestCTN="";
		//order.Groups.Group[0].GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.MobileNumber
		
		requestCTN=(String) ((Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) group.get("GroupCharacteristics")).get("LoSGCharacteristics")).get("WirelessLOSChars")).get("MobileNumber").toString();
		return requestCTN;
		
		
	}
	
/**
 * 
 * @param nl
 * @param attributeName
 * @param asc
 * @param B
 * @return
 */
	 public static Element[] sortNodes(NodeList nl, final String tagName, final String namespace, final boolean asc,  final Class<? extends Comparable> B)
	    {        
	        class NodeComparator<T> implements Comparator<T>
	        {
	            @Override
	            public int compare(T a, T b)
	            {
	                int ret;
	                Comparable bda = null, bdb = null;
	                try{
	                    Constructor bc = B.getDeclaredConstructor(String.class);
	                  
	                    Element information1 = (Element) a;
	                    Element information2 = (Element) b;
	                    if(namespace!=null){
	                    	 bda = information1.getElementsByTagNameNS(namespace, tagName).item(0).getTextContent();
		 	                 bdb = information2.getElementsByTagNameNS(namespace,tagName).item(0).getTextContent();
	                    }else{
	                    	 bda = information1.getElementsByTagName(tagName).item(0).getTextContent();
	 	                    bdb = information2.getElementsByTagName(tagName).item(0).getTextContent();
	                    }
	                    
	                   
	        	       
	                }
	                catch(Exception e)
	                {
	                   return 0;  // yes, ugly, i know :)
	                }
	                ret = bda.compareTo(bdb);
	                return asc ? ret : -ret; 
	            }
	        }

	        List<Element> x = new ArrayList<>();
	        for(int i = 0; i < nl.getLength(); i++)
	        {
	        	
	             x.add((Element) nl.item(i));
	        }
	        Element[] ret = new Element[x.size()];
	        ret = x.toArray(ret);
	        
	        Arrays.sort(ret, new NodeComparator<Element>());
	        return ret;
	    } 
	 
	 
	 public static String getUnlockCode(Map<String, Object> order) {
		 // TODO Auto-generated method stub
		 String unlockCode="";
		 List<Object>  lineitemarray = (List<Object>) ( (Map<?,?>)order.get("LineItems")).get("LineItem");
		 Map<String, Object> lineItem = (Map<String, Object>) lineitemarray.get(0);

		 List<Object> additionalDetaails = (List<Object>) ((Map<?,?>)lineItem.get("AdditionalDetails")).get("AdditionalDetail");

		 for(int i=0;i<additionalDetaails.size();i++){
			 String code =((Map<?,?>)additionalDetaails.get(i)).get("Code").toString();
			 if(code.equalsIgnoreCase(CommonConstants.UNLOCK_CODE)){
				 unlockCode = ((Map<?,?>)additionalDetaails.get(i)).get("Value").toString();
				 break;
			 }
		 }

		 return unlockCode;
	 }

	    public static String getAdditionalDetailValue(Map<String, Object> order, String code) {
	        try {
	            Map<String, Object> groups = (Map<String, Object>) order.get("Groups");
	            List<Object> grouplist = (List<Object>) groups.get("Group");
	            Map<String, Object> group = (Map<String, Object>) ((List<Object>) groups.get("Group")).get(0);
	            Map<String, Object> additionalDetails = ((Map<String, Object>) group.get("AdditionalDetails"));
	            if (additionalDetails != null) {
	                List<Object> additionalDetaillist = (List<Object>) additionalDetails.get("AdditionalDetail");
	                for (Object detail : additionalDetaillist) {
	                    Map<String, Object> additionalDetail = (Map<String, Object>) detail;
	                    if (code.equals(additionalDetail.get("Code")))
	                        return (String) additionalDetail.get("Value");
	                }
	            } 
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return null;
	    }

	    
	    /**
		 * 
		 * @param order
		 * @return Payment Arrangement for unlock
		 */
		public static String getPaymentArrangement(Map<String,Object> order){
			List<Object>  accountArray = (List<Object>) ( (Map<?,?>)order.get("Accounts")).get("Account");
			if( ((Map<?,?>)accountArray.get(0)).get("PaymentArrangement")!=null )
			{
				return ((Map<?,?>)accountArray.get(0)).get("PaymentArrangement").toString();
			}else{
				return null;
			}
			
		}

}
