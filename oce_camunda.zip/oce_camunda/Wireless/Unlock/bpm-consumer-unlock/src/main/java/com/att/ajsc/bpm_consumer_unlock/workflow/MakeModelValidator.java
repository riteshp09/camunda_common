package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.util.Map;
import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.variable.Variables;
import org.json.JSONObject;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;

public class MakeModelValidator implements JavaDelegate {

	static final Logger logger = Logger.getLogger(MakeModelValidator.class.getName());
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		Map<String,Object> order = (Map<String, Object>) execution.getVariable(CommonConstants.ORDER);
		Map<String,Object> unlockContext = (Map<String, Object>) execution.getVariable("unlockContext");
		//		String response = (String) execution.getVariable("getMakeModelResponse");
		try{
		Map<String, Object> responseWrapper  = (Map<String, Object>) execution.getVariable("getMakeModelResponse");
		boolean isFault =false;
		if(responseWrapper!=null && responseWrapper.get(CommonConstants.IS_FAULT_RESPONSE)!=null){
			 isFault = (boolean) responseWrapper.get(CommonConstants.IS_FAULT_RESPONSE);
		}
		else{
			isFault=true;
		}

		if(isFault) {
			order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUBSTATUS_NON_ATT_IMEI));
			unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_NON_ATT_IMEI);
			if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			
			
			execution.setVariableLocal("getMakeModelResponse","204");
			logger.info("Make and model Mismatch due to blank response");
		} else {
			String response = (String) responseWrapper.get("payload");
			//UnlockUtils unlockUtils = new UnlockUtils();

			if(!CommonConstants.isNull(response)
					/*response!=null && !response.equals("") && !response.isEmpty() && response!="" && !response.equals("\"\"")*/){

				

				JSONObject jsonObject = new JSONObject(response);
				String responeMake  = jsonObject.getString("make").trim();
				
				String responeModel  = jsonObject.getString("model");
				
				String isbulkOrder =  (String) unlockContext.get("isBulkUnlockOrder");

				if(isbulkOrder.equalsIgnoreCase("true")){
					//set make model in order
					order.put("LineItems", UnlockUtils.setMakeModel(order,responeMake,responeModel));
					String paramString = "model=" + responeModel + "&make=" + responeMake;
					unlockContext.put("paramString", paramString);
					unlockContext.put("Make", responeMake);
					unlockContext.put("Model", responeModel);
					logger.info("set make model in bulk Order");

				}else{
					//compare make model with request

					String requestMake = unlockContext.get("Make").toString();
					String requestModel = unlockContext.get("Model").toString();
					if(!(requestMake.equals(responeMake) && requestModel.equals(responeModel))){
						order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_FRAUD_SUBSCRIBER));
						unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_MAKE_MISMATCH);
						if(unlockContext.get("Make")!=null)
						UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
						logger.info("Make and model Mismatch");
						//prepare addNoteContext
						/** 
						 * noteText = Device Unlock request is denied. This request was not submitted by a valid user. Please reference myCSP for a complete list of eligibility requirements.
						 */
						String noteText = "Device Unlock request is denied. This request was not submitted by a valid user. Please reference myCSP for a complete list of eligibility requirements.";
						unlockContext.put("noteText", noteText);
						//logger.info("AddNote Text Prepared : " + noteText);
					}
				}
			}else
			{
				execution.setVariableLocal("getMakeModelResponse","204");
				order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUBSTATUS_NON_ATT_IMEI));
				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_NON_ATT_IMEI);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				logger.info("Make and model Mismatch due to blank response");
			}


			execution.setVariableLocal(CommonConstants.ORDER, Variables.objectValue(order).
					serializationDataFormat(Variables.SerializationDataFormats.JSON).create());
		}
	}catch(NullPointerException e){
		execution.setVariableLocal("getMakeModelResponse","204");
		order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUBSTATUS_NON_ATT_IMEI));
		unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
		UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
		UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
		UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_NON_ATT_IMEI);
		if(unlockContext.get("Make")!=null)
		UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
		logger.info("Make and model Mismatch due to blank response");
	}
	}
}
