package com.att.ajsc.camel.custom.typeconverters;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.converter.stream.InputStreamCache;

import com.att.oce.bpm.common.VelocityHelper;


public class GetOrderResponseTransformer {
	
	static final Logger logger = Logger.getLogger(GetOrderResponseTransformer.class.getName());
	
	public void transform(Exchange e){
		
		Message msg = e.getIn();
		InputStreamCache msgCache = (InputStreamCache) msg.getBody();
		byte[] content = new byte[msgCache.available()];
		
		try {
			msgCache.read(content);
			String requestStr =  new String(content);
			logger.info("GetOrderResponseTransformer:: OrderResponse " + requestStr);
			Map<String,Object> orderResponse = VelocityHelper.jsonToMap(requestStr);
			List<?> orderDetails = (List<?>) orderResponse.get("OrderDetails");
			Map<String,Object> order =  (Map<String, Object>) ((Map<String,Object>)orderDetails.get(0)).get("Order");
			logger.info("GetOrderResponseTransformer::Order:: " + order);
			msg.setBody(order);
			e.setOut(msg);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

}
