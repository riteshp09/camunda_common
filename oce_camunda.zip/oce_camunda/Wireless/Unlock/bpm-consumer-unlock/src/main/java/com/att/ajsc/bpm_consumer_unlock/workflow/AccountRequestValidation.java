package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;

import org.camunda.bpm.engine.variable.Variables;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.api.response.handler.AbstractCsiApiResponseHandler;
import com.att.oce.bpm.common.JAXBUtil;
import com.att.oce.bpm.common.VelocityHelper;



public class AccountRequestValidation extends AbstractCsiApiResponseHandler{
	
	static final Logger logger = Logger.getLogger(AccountRequestValidation.class.getName());
	String setBlank = "", noteText ="";
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	
	
	@Override
	public void handleFaultResponse() throws Exception {
		super.handleFaultResponse();
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
		 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
		 if(unlockContext.get("Make")!=null)
			 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_AFTER_IDUE);
	}

	  
	@SuppressWarnings("unchecked")
	public void handleSuccessResponse() throws Exception {
		
		String responseMap = getResponse(); 
		getExecution().setVariable("iapresponse", new StringBuffer(responseMap));
		
		
		
		Map<String, Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		
		 
		
		
		if (responseMap != null && !responseMap.equals("")) {
			
			Document xmlDocument = JAXBUtil.getXMLDocument(responseMap);
			
			String billingMarket="";
			if (xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
					"billingMarket")!=null && null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
							"billingMarket").item(0)) {
				
				billingMarket = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
						"billingMarket").item(0).getTextContent();
			}

			

			String billingSubMarket="";
			if (xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
					"billingSubMarket")!=null && null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
							"billingSubMarket").item(0)) {
				
				billingSubMarket = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
						"billingSubMarket").item(0).getTextContent();
			}

		

			String billingAccountNumber = "";
			//http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberProfileResponse.xsd
			if (xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd", 
					"billingAccountNumber")!=null && null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd", 
							"billingAccountNumber").item(0)) {
				billingAccountNumber = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd","billingAccountNumber").item(0).getTextContent().trim();
				UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_AUTH_TYPE, CommonConstants.BAN_CODE,billingAccountNumber);
			}

		

			String accountType="";
			if (xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
					"accountType")!=null && null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
							"accountType").item(0)) {
				
				accountType = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
						"accountType").item(0).getTextContent();
			}

		

			String accountSubType = "";
			if (xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
					"accountSubType")!=null && null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
							"accountSubType").item(0)) {
				
				accountSubType = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
						"accountSubType").item(0).getTextContent();
			}
			
			

			String createdDateStr ="";
			Date createdDate = null;
			if (xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
					"effectiveDate")!=null && null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
							"effectiveDate").item(0)) {
				
				createdDateStr = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
						"effectiveDate").item(0).getTextContent();
				createdDate = format.parse(createdDateStr);
			}
			
			
			String billingAccountPassword = "";
			if (xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd", 
					"billingAccountPassword")!=null && null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd", 
							"billingAccountPassword").item(0)) {
				billingAccountPassword = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd", 
						"billingAccountPassword").item(0).getTextContent().trim();
			}
			
			String lastNameRes = "";
			NodeList customerNodelist = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd","Customer");
			if(customerNodelist!=null && customerNodelist.getLength()>0 ){
				Element customerNode = (Element) customerNodelist.item(0);
				if(customerNode.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
						"lastName")!=null && customerNode.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
						"lastName").item(0)!=null ){
					lastNameRes=	customerNode.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
							"lastName").item(0).getTextContent();
			//	System.out.println("lastname1 : "+lastNameRes);
				}
			}
			
			
			String socialSecurityNumber = "";
			
			if (xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd", 
					"socialSecurityNumber").item(0) !=null && !xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd", 
							"socialSecurityNumber").item(0).getTextContent().equals("")) {
				socialSecurityNumber = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd", 
						"socialSecurityNumber").item(0).getTextContent().trim();
				
			} 
			
			String pastDue = "";
			if (xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
					"totalAmountPastDue")!=null && null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
							"totalAmountPastDue").item(0)) {
				
				pastDue = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
						"totalAmountPastDue").item(0).getTextContent();
			}
			
			
			
			String deviceEligibility = "";
			if (unlockContext.get("eligibilityStatus") != null && !unlockContext.get("eligibilityStatus").toString().equals("")) {
				deviceEligibility = unlockContext.get("eligibilityStatus").trim().toString();
			}

			

			String deviceType = "";
			if (unlockContext.get(CommonConstants.PREPAIED_INDICATOR) != null && !unlockContext.get(CommonConstants.PREPAIED_INDICATOR).toString().equals("")) {
				deviceType = unlockContext.get(CommonConstants.PREPAIED_INDICATOR).trim().toString();
			}

			String encryptedPasscode="";
			if(getExecution().getVariable("encryptedPasscode")!=null && getExecution().getVariable("encryptedPasscode")!="" 
					&& billingAccountPassword!=null && !billingAccountPassword.equals(""))
			{
			String encryJson = (String) getExecution().getVariable("encryptedPasscode");
			Map<String, Object> mapRes = VelocityHelper.jsonToMap(encryJson);
			if(mapRes.get("OceVoltageResponse")!=null && ((Map<?,?>)mapRes.get("OceVoltageResponse")).get("pciFields")!=null 
					&& ((Map<?,?>)((Map<?,?>)mapRes.get("OceVoltageResponse")).get("pciFields")).get("passcode")!=null){
			
						 encryptedPasscode = (String) ((Map<?,?>)((Map<?,?>)mapRes.get("OceVoltageResponse")).get("pciFields")).get("passcode");
			}
			
			}else{
				getExecution().setVariable("encryptedPasscode", "\"\"");
			}

			if ((billingMarket==null || billingMarket.equalsIgnoreCase("")) && (billingSubMarket ==null || billingSubMarket.equalsIgnoreCase(""))) {
				
				order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_DENIED,
						CommonConstants.LOSG_SUB_STATUS_DATA_NOT_FOUND));
				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCELLED_REASON_MARKET_MISMATCH);
				logger.info("Billing Market or sub market not found");
				
				
			} else  if(billingAccountNumber == null || billingAccountNumber.equals("")){
				
				order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_DENIED,
						CommonConstants.LOSG_SUB_STATUS_DATA_NOT_FOUND));
				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCELLED_REASON_BAN_NOT_FOUND);

				UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_AUTH_TYPE, CommonConstants.BAN_CODE, CommonConstants.VALUE_FAILED);
				logger.info("Billing Account Number not found");
				
				

				
			} else if (pastDue != null && !pastDue.equals("") &&  !(pastDue.equals("0") || pastDue.equals("0.0"))) {
				
					if (accountType.equalsIgnoreCase("B") || accountType.equalsIgnoreCase("G")) {
						
						order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"iap")));
						unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
						if(unlockContext.get("Make")!=null)
						UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.CANCELLED_REASON_PAST_DUE);

						getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"iap"),"Past Dues"));
						getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));

						logger.info("Past due on account");
						
					} else {
						
						order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_DENIED,
								CommonConstants.LOSG_SUB_STATUS_PAST_DUE));
						unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
						if(unlockContext.get("Make")!=null)
						UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCELLED_REASON_PAST_DUE);

						logger.info("Past due on account");
					}
				
					UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_VALIDATION_TYPE, CommonConstants.PASTDUE_CODE, CommonConstants.VALUE_FAILED);
			} else if (deviceEligibility!=null && !deviceEligibility.equals("") && deviceEligibility.equalsIgnoreCase(CommonConstants.ELIGIBLE)) {
				
				Date currentDate = new Date();
				currentDate = format.parse(format.format(currentDate));
				int diffInDays =0;
				if (createdDate!=null) {
					diffInDays = (int) ((currentDate.getTime() - createdDate.getTime()) / (1000 * 60 * 60 * 24));
				}
				
				if (diffInDays < 60) {
					
					order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_DENIED,
							CommonConstants.LOSG_SUB_STATUS_ACCOUNT_ACTIVE_60_DAYS));
					unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
					if(unlockContext.get("Make")!=null)
					UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCELLED_REASON_ACCOUNT_ACTIVE_60_DAYS);
					UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_VALIDATION_TYPE, CommonConstants.PASTDUE_CODE, CommonConstants.VALUE_PASSED);
					UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_VALIDATION_TYPE, CommonConstants.ACC_CREATE_60, CommonConstants.VALUE_FAILED);
					//todo: addnote context
					logger.info("Account active less than 60");
				} else {
					UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_VALIDATION_TYPE, CommonConstants.PASTDUE_CODE, CommonConstants.VALUE_PASSED);
					UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_VALIDATION_TYPE, CommonConstants.ACC_CREATE_60, CommonConstants.VALUE_PASSED);
					validatePassCode(billingAccountPassword,order, unlockContext, accountType,accountSubType, deviceType, billingAccountNumber,encryptedPasscode, lastNameRes, socialSecurityNumber);
					
				}
				
			} else {
				UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_VALIDATION_TYPE, CommonConstants.PASTDUE_CODE, CommonConstants.VALUE_PASSED);
				validatePassCode(billingAccountPassword,order, unlockContext, accountType,accountSubType, deviceType, billingAccountNumber,encryptedPasscode, lastNameRes, socialSecurityNumber);

			}
			
			Map<String, Object>  accounts =  (Map<String, Object>)order.get("Accounts");
			Map<String, Object>  account =   (Map<String, Object>) ( (List<Object>)accounts.get("Account")).get(0);
			String enterpriseType ="";
		
			if(account.get("EnterpriseType")!=null)
			 enterpriseType = account.get("EnterpriseType").toString();
			
			
			if(enterpriseType!=null && !enterpriseType.equals("") && enterpriseType.equalsIgnoreCase(CommonConstants.ENTERPRISE_CRU)){
				
				if (xmlDocument.getElementsByTagName("fan").item(0) != null && !xmlDocument.getElementsByTagName("fan").item(0).getTextContent().equals("")) {
					String fan = xmlDocument.getElementsByTagName("fan").item(0).getTextContent().trim();
					Map<String, Object>  b2Bs =  (Map<String, Object>)order.get("B2Bs");
					if(b2Bs!=null){
						List<Object> b2Blist =(List<Object>)b2Bs.get("B2B");
						
						Map<String, Object>  b2B =   (Map<String, Object>) ( (List<Object>)b2Bs.get("B2B")).get(0);
						b2B.put("B2BFAN", fan);
						b2Blist.set(0, b2B);
						b2Bs.put("B2B", b2Blist);
						order.put("B2Bs", b2Bs);
					}else{
						b2Bs = new HashMap<String, Object>();
						List<Object> b2Blist = new ArrayList<Object>();
						Map<String, Object> b2B = new HashMap<String, Object>();
						b2B.put("Id", "B2B_01");
						b2B.put("B2BFAN", fan);
						b2Blist.add(b2B);
						b2Bs.put("B2B", b2Blist);
					
						order.put("B2Bs", b2Bs);
						
					}
					
					
					
					
				}
				
			}
			if(unlockContext.get("LOSGSTATUS").equalsIgnoreCase(CommonConstants.LOSG_STATUS_SYS_PROCESSING)){
				
				String banFromOrder =(String) account.get("BillingAccountNumber");
				if(banFromOrder==null || banFromOrder.equals("")){
					account.put("BillingAccountNumber", billingAccountNumber)	;	
					List<Object> accountlist =(List<Object>)accounts.get("Account");
					accountlist.set(0, account);
					accounts.put("Account", accountlist);
					order.put("Accounts", accounts);
				}
			}
			getExecution().setVariableLocal(CommonConstants.ORDER, Variables.objectValue(order).
			serializationDataFormat(Variables.SerializationDataFormats.JSON).create());
			
		}
	}

	private void validatePassCode(String billingAccountPassword, Map<String, Object> order, Map<String, String> unlockContext, String accountType, String accountSubType, String deviceType, String billingAccountNumber, String decryptedPasscode,	String lastNameRes, String socialSecurityNumber) {
	
		boolean isGoPhone= isGoPhoneCustomer(accountType,accountSubType, deviceType) ;
		
		Map<String, Object>  accounts =  (Map<String, Object>)order.get("Accounts");
		List<Object> accountlist = (List<Object>)accounts.get("Account");
		Map<String, Object>  account =   (Map<String, Object>) ( (List<Object>)accounts.get("Account")).get(0);
		String passCode =(String) account.get("PassCode");
				
				
		if ((billingAccountPassword!=null && !billingAccountPassword.equalsIgnoreCase("")) && !isGoPhone
				&& decryptedPasscode!=null && !decryptedPasscode.equalsIgnoreCase("")) {
			if(passCode!=null && !passCode.equals("")){
				if(passCode.equalsIgnoreCase(decryptedPasscode)){
					accountTypeCheck(order, unlockContext, accountType,
							accountSubType, deviceType,
							billingAccountNumber, lastNameRes,
							socialSecurityNumber, 
							decryptedPasscode,passCode);
					UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_AUTH_TYPE, CommonConstants.PASSCODE_CODE, CommonConstants.VALUE_PASSED);
				}else{
					order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_UNABLE_TO_VERIFY));
					unlockContext.put("LOSGSTATUS",CommonConstants.LOSG_STATUS_DENIED);
					if(unlockContext.get("Make")!=null)
					UnlockUtils.createAutomationSummary(order,null,CommonConstants.PHONE_TYPE,UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_REASON,CommonConstants.CANCELLED_REASON_PASSCODE_MISMATCH);
					UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_AUTH_TYPE, CommonConstants.PASSCODE_CODE, CommonConstants.VALUE_FAILED);
					//todo: addnote context
					noteText = "Device Unlock request is denied. Passcode entered did not match. Please refer myCSP for a complete list of eligibility requirements.";
					unlockContext.put(CommonConstants.ADDNOTE_TEXT,
							noteText);
				}
			}else{
				order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_UNABLE_TO_VERIFY));
				unlockContext.put("LOSGSTATUS",CommonConstants.LOSG_STATUS_DENIED);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order,null,CommonConstants.PHONE_TYPE,UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_REASON,CommonConstants.CANCELLED_REASON_PASSCODE_MISMATCH);
				UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_AUTH_TYPE, CommonConstants.PASSCODE_CODE, CommonConstants.VALUE_FAILED);
				//todo: addnote context
				noteText = "Device Unlock request is denied. Passcode entered did not match. Please refer myCSP for a complete list of eligibility requirements.";
				unlockContext.put(CommonConstants.ADDNOTE_TEXT,
						noteText);
			}
			
		} else {
			UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_AUTH_TYPE, CommonConstants.PASSCODE_CODE, CommonConstants.VALUE_SKIPPED);
			accountTypeCheck(order,unlockContext, accountType,accountSubType, deviceType, billingAccountNumber, lastNameRes, socialSecurityNumber, decryptedPasscode,passCode);
			
		}
		
	}

	@SuppressWarnings("null")
	private void accountTypeCheck(Map<String, Object> order, Map<String, String> unlockContext, String accountType,	String accountSubType, String deviceType, String billingAccountNumber, String lastNameRes, String socialSecurityNumber, String billingAccountPassword, String decryptedPasscode) {
		
		if (accountType.equalsIgnoreCase("S") && accountSubType.equalsIgnoreCase("R")) {
			
			//todo: addnote context
			
			
		} else if (!accountType.equalsIgnoreCase("I")) {
			
			if (accountType.contains("B") || accountType.equalsIgnoreCase("G")) {
				
				if (accountType.equalsIgnoreCase("B") && accountSubType.equalsIgnoreCase("G") ) {
					
					order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"iap")));
					unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
					if(unlockContext.get("Make")!=null)
					UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.CRU_FALLOUT_REASON);

					getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"iap"),CommonConstants.CRU_FALLOUT_REASON));
					getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));

					//todo: addnote context				
					
				} else if (validateAccNameNoSIMNo(order,billingAccountNumber)) {
					
				UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_AUTH_TYPE, CommonConstants.CODE_LAST4OFSIM_NUMBER_AND_LAST4OFBAN, CommonConstants.VALUE_PASSED);
					//todo: addnote context
				} else {
					
					order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_DENIED,
							CommonConstants.LOSG_SUB_STATUS_UNABLE_TO_VERIFY));
					unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
					if(unlockContext.get("Make")!=null)
					UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCELLED_REASON_LAST4BAN_MISMATCH);
					UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_AUTH_TYPE, CommonConstants.CODE_LAST4OFSIM_NUMBER_AND_LAST4OFBAN, CommonConstants.VALUE_FAILED);
					//todo: addnote context
					noteText = "Device Unlock request is denied. LAST4BAN didnot match. Please refer myCSP for a complete list of eligibility requirements.";
		    		unlockContext.put(CommonConstants.ADDNOTE_TEXT, noteText);
		    		logger.info("last 4 BAN mismatch");
				}
				
			} else {
				
				order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_DENIED,
						CommonConstants.LOSG_SUB_STATUS_DATA_NOT_FOUND));
				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCELLED_REASON_ACCOUNT_NOT_FOUND);

				//todo: addnote context
				
				
			}
			
		} else if (accountSubType.equalsIgnoreCase("R")) {
			
			if (deviceType!=null && !deviceType.isEmpty()) {
				

				//todo: addnote context
			} else {
				
				if (vidCheck(billingAccountPassword, unlockContext, decryptedPasscode, lastNameRes, socialSecurityNumber, order)) {
					
	
					UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_AUTH_TYPE, CommonConstants.CODE_LASTNAME_AND_LAST4OFSSN, CommonConstants.VALUE_PASSED);
					//todo: addnote context
				} else {
					
					order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_DENIED,
							CommonConstants.LOSG_SUB_STATUS_UNABLE_TO_VERIFY));
					unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
					if(unlockContext.get("Make")!=null)
					UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
					UnlockUtils.createAutomationSummary(order, CommonConstants.ACC_AUTH_TYPE, CommonConstants.CODE_LASTNAME_AND_LAST4OFSSN, CommonConstants.VALUE_FAILED);
					logger.info("VID check mismatch");
				}

			}
			
		} else if (accountSubType.equalsIgnoreCase("G") || accountSubType.equalsIgnoreCase("H")) {
			

		} else {
			
			order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_DENIED,
					CommonConstants.LOSG_SUB_STATUS_DATA_NOT_FOUND));
			unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
			if(unlockContext.get("Make")!=null)
			UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCELLED_REASON_ACCOUNT_NOT_FOUND);

			//todo: addnote context		
		}
		
	}

	@SuppressWarnings({ "unchecked", "null" })
	private boolean vidCheck(String billingAccountPassword,	Map<String, String> unlockContext, String decryptedPasscode, String lastNameRes, String socialSecurityNumber, Map<String, Object> order) {
		boolean valid = false;
		String lastNameReq = "", last4SSNReq ="",last4SSNRes = "";
		Map<String, Object>  accounts =  (Map<String, Object>)order.get("Accounts");
		Map<String, Object>  account =   (Map<String, Object>) ( (List<Object>)accounts.get("Account")).get(0);
		
		String langId ="";
		if(account.get("LangId")!=null)
			langId= account.get("LangId").toString();
		
		Map<String, Object> names = (Map<String, Object>) order.get("Names");
		Map<String, Object> name = null;
		if (names != null) {
			name = (Map<String, Object>) ((List<Object>) names.get("Name"))
					.get(0);
		}
		
		
		if (name != null && name.get("LastName") != null && !name.get("LastName").toString().equals("")) {
			lastNameReq = name.get("LastName").toString();
		}

		if (socialSecurityNumber!=null && !socialSecurityNumber.equalsIgnoreCase("")) {
			last4SSNRes = socialSecurityNumber.substring(socialSecurityNumber.length() - 4);
		}
		
		List<Object> billingInfos = (List<Object>) account.get("BillingInfo");
		Map<String, Object> billingInfo =null;
		if(billingInfos!=null &&  billingInfos.get(0)!=null){
			billingInfo = (Map<String, Object>) billingInfos.get(0);
		}
		
		Map<String, Object> authentication = null;
		if (billingInfo != null ) {
			if(billingInfo.get("Authentication")!=null)
			authentication = (Map<String, Object>) billingInfo.get("Authentication");
		}
		
		
		
		
		
		if (authentication != null && authentication.get("LastFourOfSSN") != null && !authentication.get("LastFourOfSSN").toString().equals("")) {
			last4SSNReq = authentication.get("LastFourOfSSN").toString();
		}
		if(langId!=null && !langId.equals("")&& langId.equalsIgnoreCase("spanish")){
			Collator collator = Collator.getInstance(Locale.FRENCH);
			collator.setStrength(Collator.PRIMARY);
			int result = collator.compare(lastNameReq, lastNameRes);
			if (result==0) {	
				
				if ((decryptedPasscode!=null && !decryptedPasscode.equalsIgnoreCase("")) && (billingAccountPassword!=null && !billingAccountPassword.equalsIgnoreCase("")) && decryptedPasscode.equalsIgnoreCase(billingAccountPassword)) {

					valid = true;

				} else {
					if ((last4SSNRes!=null && !last4SSNRes.equalsIgnoreCase("")) && (last4SSNReq!=null && !last4SSNReq.equalsIgnoreCase("")) &&  last4SSNRes.equalsIgnoreCase(last4SSNReq)){				
					
						valid = true;
					
					} else {
					valid = false;
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCELLED_REASON_LAST4SSN_MISMATCH);
				}					
			
				}				
		} else {
			valid = false;
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCELLED_REASON_LASTNAME_MISMATCH);
			
			String noteText = "Device Unlock request is denied. Lastname entered did not match. Please refer myCSP for a complete list of eligibility requirements.";
    		unlockContext.put(CommonConstants.ADDNOTE_TEXT, noteText);
		}
		}else{
			if (lastNameRes.trim().equalsIgnoreCase(lastNameReq.trim())) {	
				
				if ((decryptedPasscode!=null && !decryptedPasscode.equalsIgnoreCase("")) && (billingAccountPassword!=null && !billingAccountPassword.equalsIgnoreCase("")) && decryptedPasscode.equalsIgnoreCase(billingAccountPassword)) {

					valid = true;

				} else {
					if ((last4SSNRes!=null && !last4SSNRes.equalsIgnoreCase("")) && (last4SSNReq!=null && !last4SSNReq.equalsIgnoreCase("")) &&  last4SSNRes.equalsIgnoreCase(last4SSNReq)){				
					
						valid = true;
					
					} else {
					valid = false;
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCELLED_REASON_LAST4SSN_MISMATCH);
				}					
			
				}				
		} else {
			valid = false;
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCELLED_REASON_LASTNAME_MISMATCH);
			
			String noteText = "Device Unlock request is denied. Lastname entered did not match. Please refer myCSP for a complete list of eligibility requirements.";
    		unlockContext.put(CommonConstants.ADDNOTE_TEXT, noteText);
		}
		}
		
		
		return valid;
	}

	@SuppressWarnings("unchecked")
	private boolean validateAccNameNoSIMNo(Map<String, Object> order, String billingAccountNumber) {
		boolean valid = false;
		String last4Digits = billingAccountNumber.substring(billingAccountNumber.length()-4).trim();

		String  digits="";
		Map<String, Object> accounts = (Map<String, Object>) order.get("Accounts");
		Map<String, Object> account = (Map<String, Object>) ((List<Object>) accounts.get("Account")).get(0);
		String banFromOrderPayload = account.get("BillingAccountNumber").toString();
		
		if (banFromOrderPayload != null && !banFromOrderPayload.toString().equals("")) {
			digits = banFromOrderPayload.substring(banFromOrderPayload.length()-4).trim();
			
			if((last4Digits.equalsIgnoreCase(digits)) )
				valid = true;
			else 
				valid = false;
		}
		return valid;
	}

	private boolean isGoPhoneCustomer(String accountType, String accountSubType, String deviceType) {
		
		if ( (deviceType!=null && !deviceType.isEmpty()) ||  (accountType.equalsIgnoreCase("I") && (accountSubType.equalsIgnoreCase("G") || accountSubType.equalsIgnoreCase("H"))) || (accountType.equalsIgnoreCase("S") && accountSubType.equalsIgnoreCase("R"))) {
			
			return true;
			
		} else {

			return false;
			
		}		
	}


	
}