package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.variable.Variables;
import org.json.JSONObject;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;

public class UnlockInstructionsValidator implements JavaDelegate {

	static final Logger logger = Logger.getLogger(UnlockInstructionsValidator.class.getName());
	@SuppressWarnings("unchecked")
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		Map<String, Object> responseWrapper  =null;
		try{
		if(execution.getVariable("getUnlockResponse")!=null)
		responseWrapper  = (Map<String, Object>) execution.getVariable("getUnlockResponse");
		if(responseWrapper!=null && responseWrapper.get(CommonConstants.IS_FAULT_RESPONSE)!=null){
		boolean isFault = (boolean) responseWrapper.get(CommonConstants.IS_FAULT_RESPONSE);

		if(isFault) {
			logger.info("Fault Respsne for GetUnlockInstructions API : " + responseWrapper.get("payload"));
			
		} else {
			// TODO Auto-generated method stub
			
			String response = (String) responseWrapper.get("payload");
			
			if(!CommonConstants.isNull(response)){


				
				Map<String,Object> order = (Map<String, Object>) execution.getVariable(CommonConstants.ORDER);
				
				if (!response.equals("") && response!=null && !response.isEmpty()) {
					JSONObject jsonObject = new JSONObject(response);


					Map<String, Object> accounts = (Map<String, Object>)order.get("Accounts");
					List<Object> accountlist =(List<Object>)accounts.get("Account");
					Map<String, Object> account =(Map<String, Object>) accountlist.get(0);
					String langId = (String) account.get("LangId");

					String UnlockInstruction = "";

					if(langId!=null && langId.equalsIgnoreCase("spanish"))
					{
						UnlockInstruction = jsonObject.getString("instructionspanish");
						
					}
					else
					{
						UnlockInstruction = jsonObject.getString("instructionenglish");
						
					}


					Map<String, Object>  lineitems =  (Map<String, Object>)order.get("LineItems");
					List<Object> lineitemlist =(List<Object>)lineitems.get("LineItem");
					Map<String, Object>  lineitem =   (Map<String, Object>) ( (List<Object>)lineitems.get("LineItem")).get(0);
					Map<String, Object> additionalDetails = ((Map<String, Object>)lineitem.get("AdditionalDetails"));
					if(null!=additionalDetails){
						List<Object> additionalDetaillist =(List<Object>)additionalDetails.get("AdditionalDetail");
						Map<String, Object> additionalDetail = new HashMap<String, Object>();
						additionalDetail.put("Code", "UnlockInstruction");
						additionalDetail.put("Value", UnlockInstruction);
						additionalDetaillist.add(additionalDetail);
						additionalDetails.put("AdditionalDetail", additionalDetaillist);
						lineitem.put("AdditionalDetails", additionalDetails);
						lineitemlist.set(0, lineitem);
						lineitems.put("LineItem", lineitemlist);
						order.put("LineItems", lineitems);
					}else
					{
						additionalDetails = new HashMap<String, Object>();
						List<Object> additionalDetaillist = new ArrayList<Object>();
						Map<String, Object> additionalDetail = new HashMap<String, Object>();
						additionalDetail.put("Code", "UnlockInstruction");
						additionalDetail.put("Value", UnlockInstruction);
						additionalDetaillist.add(additionalDetail);
						additionalDetails.put("AdditionalDetail", additionalDetaillist);
						lineitem.put("AdditionalDetails", additionalDetails);
						lineitemlist.set(0, lineitem);
						lineitems.put("LineItem", lineitemlist);
						order.put("LineItems", lineitems);

					}
				}else{
					execution.setVariableLocal("getUnlockResponse","204");
				}
				execution.setVariableLocal(CommonConstants.ORDER, Variables.objectValue(order).
						serializationDataFormat(Variables.SerializationDataFormats.JSON).create());
			}
			else{

				execution.setVariableLocal("getUnlockResponse","204");
			}
		}
		}else{
			execution.setVariableLocal("getUnlockResponse","204");
		}
	}catch(NullPointerException e){
		execution.setVariableLocal("getUnlockResponse","204");
	}
	}
}


