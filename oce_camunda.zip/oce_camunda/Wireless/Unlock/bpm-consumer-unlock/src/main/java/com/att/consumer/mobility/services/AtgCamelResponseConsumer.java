package com.att.consumer.mobility.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.camel.custom.AbstractCamelConsumer;

public class AtgCamelResponseConsumer extends AbstractCamelConsumer {

	@Override
	public void execute(Exchange e) {
		System.out.println("ATG Response handler started..");
		System.out.println("Inside CheckResponseStatus");
		Message msg = e.getIn();
		String inMessageStr = null;
		Map<String, Object> responseWrapper  = new LinkedHashMap<>();
		boolean isFaultResponse;
		
		try {
			inMessageStr = readExchangeMessage(e);
			
			String responseCode =  String.valueOf(msg.getHeaders().get("CamelHttpResponseCode"));
			String camelException = String.valueOf(e.getProperties().get("CamelExceptionCaught") );
			
			if(!"200".equals(responseCode) || !CommonConstants.isEmpty(camelException) ) {
				isFaultResponse = true;
				if(!CommonConstants.isEmpty(camelException)) {
					Map<String, Object> payload  = new LinkedHashMap<>();
					payload.put("Errors", new LinkedHashMap<String, Object>());
					
					ArrayList error = new ArrayList<>();
					LinkedHashMap<String, Object> errorMap = new LinkedHashMap<>();
					errorMap.put("ErrorCode", "404");
					errorMap.put("ErrorDescription", camelException);
					error.add(errorMap);
					
					((LinkedHashMap<String, Object>)payload.get("Errors")).put("Error", error);
					
					responseWrapper.put("payload", payload);
					e.getProperties().put(CommonConstants.ERROR_CODE, "404");
				} else {
					e.getProperties().put(CommonConstants.ERROR_CODE, responseCode);
					responseWrapper.put("payload", inMessageStr);
				}
					
			} else {
				isFaultResponse = false;
			}
			e.setProperty(CommonConstants.IS_FAULT_RESPONSE, isFaultResponse);
			responseWrapper.put(CommonConstants.INTERFACE_NAME, (String) e.getProperties().get(CommonConstants.INTERFACE_NAME));
			responseWrapper.put(CommonConstants.IS_FAULT_RESPONSE, (Boolean) e.getProperties().get(CommonConstants.IS_FAULT_RESPONSE));
			if(isFaultResponse) {
				responseWrapper.put(CommonConstants.ERROR_CODE, (String) e.getProperties().get(CommonConstants.ERROR_CODE));
			} else {
				responseWrapper.put(CommonConstants.ERROR_CODE, responseCode);
				responseWrapper.put("payload", inMessageStr);
			}
		} catch (IOException e1) {
			e1.printStackTrace();
			isFaultResponse = true;
			Map<String, Object> payload  = new LinkedHashMap<>();
			payload.put("Errors", new LinkedHashMap<String, Object>());
			
			ArrayList error = new ArrayList<>();
			LinkedHashMap<String, Object> errorMap = new LinkedHashMap<>();
			errorMap.put("ErrorCode", "404");
			errorMap.put("ErrorDescription", "Request failed");
			error.add(errorMap);
			responseWrapper.put(CommonConstants.INTERFACE_NAME, (String) e.getProperties().get(CommonConstants.INTERFACE_NAME));
			((LinkedHashMap<String, Object>)payload.get("Errors")).put("Error", error);
			responseWrapper.put(CommonConstants.IS_FAULT_RESPONSE, isFaultResponse);
			responseWrapper.put("payload", payload);
			responseWrapper.put(CommonConstants.ERROR_CODE, "404");
		}
		
		msg.setBody(responseWrapper);
		e.setOut(msg);
		System.out.println("ATG Response ::" + inMessageStr);
		
	}

}
