package com.att.consumer.mobility.services;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.engine.variable.VariableMap;
import org.camunda.bpm.engine.variable.Variables;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.ServicePropertiesMapBean;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.bpm.common.VelocityHelper;

public class NotifyPostFalloutService {

	
static final Logger logger = Logger.getLogger(NotifyPostFalloutService.class.getName());
	
	@Autowired
	private RuntimeService runtimeService;
	
	public void notify(Exchange e){
		Message msg = e.getIn();
//		JSONObject response = new JSONObject();
		Map<String, Object> response = new HashMap<>();
		try {
			
			
			logger.info("NotifyPostFalloutService :: Request HTTP Path : " + msg.getHeaders().get(Exchange.HTTP_PATH));
			
			String oceOrderNumber = (String) msg.getHeaders().get(Exchange.HTTP_PATH);
			
			if (oceOrderNumber != null && !"".equals(oceOrderNumber.trim())) {
				oceOrderNumber = oceOrderNumber.substring(oceOrderNumber.indexOf("/")+1, oceOrderNumber.length());
				
				if("".equals(oceOrderNumber.trim()))
					throw new Exception("Invalid HTTP GET Request. \n" + "HTTP path must ends with valid OCE Order Number.\n"
							+ "Ex: http://<host>:<port>/services/bpm-consumer-unlock/v1/notifyPostFallout/<oce_order_no>");
				
				Map<String,String> globalConfig =  new HashMap<>();
				globalConfig.put("commonCsiServicesUsername", ServicePropertiesMapBean.getProperty(CommonConstants.URN_MAPPING_PROPS , CommonConstants.OCE_USER_NAME_PROPERTY));
				globalConfig.put("commonCsiServicesPassword",ServicePropertiesMapBean.getProperty(CommonConstants.URN_MAPPING_PROPS, CommonConstants.OCE_PASSWORD_PROPERTY));
				globalConfig.put("CSIVersion", ServicePropertiesMapBean.getProperty(CommonConstants.URN_MAPPING_PROPS, CommonConstants.OCE_CSI_VERSION_PROPERTY));
				globalConfig.put("ttl", ServicePropertiesMapBean.getProperty(CommonConstants.URN_MAPPING_PROPS, CommonConstants.OCE_CSI_TTL_PROPERTY));
				
				Map<String,String> unlockContext =  new HashMap<>();
				
				VariableMap variables = Variables.createVariables();
				variables.put(CommonConstants.OCE_ORDER_NO, oceOrderNumber);
				variables.put("vtlHelp", VelocityHelper.class);
				variables.put("unlockUtils", UnlockUtils.class);
				variables.put("globalConfig", globalConfig);
				variables.put("unlockContext", unlockContext);

				ProcessInstance instance = runtimeService.startProcessInstanceByKey(
						"oce.unlock.notifyPostUnlockParent",
						oceOrderNumber, variables);

				
				response.put("code", "0");
				response.put("description", "Success");
				
				response.put("processData", new HashMap<String, Object>());
				((HashMap)response.get("processData")).put("id", instance.getProcessInstanceId());
				((HashMap)response.get("processData")).put("status", instance.isEnded() ? "ended" : (instance.isSuspended() ? "suspended" : "running"));
				
			} else {
				throw new Exception("Invalid HTTP GET Request. \n" + "HTTP path must ends with OCE Order Number.\n"
						+ "Ex: http://<host>:<port>/services/bpm-consumer-unlock/v1/notifyPostFallout/<oce_order_no>");
			} 
		} catch (Exception e2) {
			e2.printStackTrace();
			response.put("code", "400");
			response.put("description","Bad Request : " + e2.getMessage());
		}
		
		msg.setBody(VelocityHelper.toJsonString(response));
		e.setOut(msg);
		
	}
}
