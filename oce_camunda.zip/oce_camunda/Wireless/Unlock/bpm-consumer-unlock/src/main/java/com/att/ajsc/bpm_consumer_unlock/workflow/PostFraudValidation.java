package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.variable.Variables;
import org.w3c.dom.Document;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;

public class PostFraudValidation implements JavaDelegate {

	static final Logger logger = Logger.getLogger(PostFraudValidation.class.getName());
	@SuppressWarnings("unchecked")
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		Map<String,Object> order = (Map<String, Object>) execution.getVariable("order");
		Map<String,String> unlockContext = (Map<String, String>) execution.getVariable("unlockContext");
		
		try{
			Map<String, Object> responseWrapper  = (Map<String, Object>) execution.getVariable("getExecuteFraudResponse");
			boolean isFault =false;
			if(responseWrapper!=null){
				 isFault = (boolean) responseWrapper.get(CommonConstants.IS_FAULT_RESPONSE);
			}
			else{
				isFault=true;
			}
			
		//	String response = execution.getVariable("getExecuteFraudResponse").toString();
			//UnlockUtils unlockUtils = new UnlockUtils();
			if(isFault) {
				logger.info("Error while validating BRMS response:");
				order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"brms")));
				 unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
				 UnlockUtils.createAutomationSummary(order, CommonConstants.SECTION_ELIGIBILITY_CHECK, CommonConstants.CODE_FRAUD_CHECK, CommonConstants.VALUE_FAILED);
				 if(unlockContext.get("Make")!=null)
				 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_FRAUD_SERVICE_UNAVAILABLE);
					execution.setVariable(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"brms"),CommonConstants.FALLOUT_INFO_FRAUD_SERVICE_UNAVAILABLE));
					execution.setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
					
			}else{
				
			String response = (String) responseWrapper.get("payload");
			if(response!=null && !response.equals("")){
				
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = null;
				try {
				    builder = factory.newDocumentBuilder();
				} catch (ParserConfigurationException e) {
				    e.printStackTrace();  
				}
				Document xmlDocument = builder.parse(new ByteArrayInputStream(response.getBytes()));
				//XPath xPath =  XPathFactory.newInstance().newXPath();
				String responeStatus="";
				if (xmlDocument.getElementsByTagName("Status")!=null && !xmlDocument.getElementsByTagName("Status").item(0).getTextContent().equals("")) {
					responeStatus = xmlDocument.getElementsByTagName("Status")
							.item(0).getTextContent();
				}

		      
				String responeSubStatus="";
				if (xmlDocument.getElementsByTagName("SubStatus")!=null && !xmlDocument.getElementsByTagName("SubStatus").item(0).getTextContent().equals("")) {
					responeSubStatus = xmlDocument
							.getElementsByTagName("SubStatus").item(0)
							.getTextContent();
				}		
		       
		        logger.info("respone SubStatus :"+responeSubStatus);
		        
				//Update LoSGStatus to order
				 if(responeStatus.equalsIgnoreCase(CommonConstants.LOSG_STATUS_IN_QUEUE)){
					//UnlockUtils.setLOSGStatusSubStatus(order, responeStatus, UnlockUtils.getSubStatusForFallout(unlockContext,"brms"));
					order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"brms")));
					 unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
				}
				else if(responeStatus.equalsIgnoreCase(CommonConstants.LOSG_STATUS_DENIED)){
					String subString = responeSubStatus.substring(responeSubStatus.lastIndexOf('-')+1 ,responeSubStatus.length());
					subString=subString.replace("\n","");
					 order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,subString));
					/*if(responeSubStatus!=null && !responeSubStatus.equals("")){
						order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,responeSubStatus));
					}
					*/
					unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
				}
				else{
					 order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_SYS_PROCESSING,CommonConstants.LOSG_STATUS_FRAUD_PASS));
		    		   unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_SYS_PROCESSING);
					
				}
				
				//Update AdditionalDetail to LineItems
				if(responeStatus.equalsIgnoreCase(CommonConstants.LOSG_STATUS_IN_QUEUE) || responeStatus.equalsIgnoreCase(CommonConstants.LOSG_STATUS_DENIED)
						){
					UnlockUtils.createAutomationSummary(order, CommonConstants.SECTION_ELIGIBILITY_CHECK, CommonConstants.CODE_FRAUD_CHECK, CommonConstants.VALUE_FAILED);

					UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				}
				else{
					UnlockUtils.createAutomationSummary(order, CommonConstants.SECTION_ELIGIBILITY_CHECK, CommonConstants.CODE_FRAUD_CHECK, CommonConstants.VALUE_PASSED);
				}
				
				//Update AdditionalDetail to Groups
				if(responeStatus.equalsIgnoreCase(CommonConstants.LOSG_STATUS_DENIED)){
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.FRAUD_VALIDATION_FAILED_BRMS);
				}
				
				//Update AdditionalDetail to Groups
				if(responeStatus.equalsIgnoreCase(CommonConstants.LOSG_STATUS_IN_QUEUE)){
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
					UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, responeSubStatus);
					execution.setVariable(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"brms"),responeSubStatus));
					execution.setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
				}
			}
		}
		}catch(Exception ne){
			logger.info("Error while validating BRMS response:"+ne.getMessage());
			order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"brms")));
			 unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
			 UnlockUtils.createAutomationSummary(order, CommonConstants.SECTION_ELIGIBILITY_CHECK, CommonConstants.CODE_FRAUD_CHECK, CommonConstants.VALUE_FAILED);
			 if(unlockContext.get("Make")!=null)
			 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_FRAUD_SERVICE_UNAVAILABLE);
				execution.setVariable(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"brms"),CommonConstants.FALLOUT_INFO_FRAUD_SERVICE_UNAVAILABLE));
				execution.setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
				
			 
		}
		
		execution.setVariableLocal(CommonConstants.ORDER, Variables.objectValue(order).
				serializationDataFormat(Variables.SerializationDataFormats.JSON).create());
			unlockContext.remove("orderXml");
	}

}
