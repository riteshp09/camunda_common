package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.camunda.bpm.engine.variable.Variables;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.api.response.handler.AbstractCsiApiResponseHandler;

public class DeviceUnlockEligibilityCheck extends AbstractCsiApiResponseHandler {

	static final Logger logger = Logger.getLogger(DeviceUnlockEligibilityCheck.class.getName());
	
	@Override
	public void handleFaultResponse() throws Exception {
		Map<?,?> response = (Map<?, ?>) getException().get("response");
		String errorCode = (String) response.get("code");
		
		Map<?,?> svcProviderEntity = (Map<?, ?>) ((ArrayList)getException().get("serviceProviderEntity")).get(0);
		Map<?,?> svcProviderRawErr = (Map<?, ?>) svcProviderEntity.get("serviceProviderRawError");
		
		String svcProviderRawErrorCode = (String) svcProviderRawErr.get("code");
		String desc = (String) svcProviderRawErr.get("description");
		
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		if("300".equals(errorCode) && "-20003".equals(svcProviderRawErrorCode)) {
			
			unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_SYS_PROCESSING);
			getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
			getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
			unlockContext.put(CommonConstants.UNLOCK_CODE, "0");
			unlockContext.put("eligibilityStatus", CommonConstants.LOSG_SUB_STATUS_DATA_NOT_FOUND);
			UnlockUtils.createAutomationSummary(order, null, CommonConstants.UNLOCK_CODE, "0");
			UnlockUtils.createAutomationSummary(order, CommonConstants.ELIGIBILITY_CHECK_TYPE , CommonConstants.ELIGIBILITY_CHECK_CODE , CommonConstants.VALUE_DATA_NOT_FOUND);
			
		} else {
			order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idue")));
			unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
			 if(unlockContext.get("Make")!=null)
			 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_B4_IDUE);
			 getExecution().setVariable(CommonConstants.ERRORS, UnlockUtils.getErrors(errorCode,CommonConstants.FALLOUT_INFO_B4_IDUE));
				getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
				unlockContext.put(CommonConstants.UNLOCK_CODE, "0");
				UnlockUtils.createAutomationSummary(order, null, CommonConstants.UNLOCK_CODE, "0");
				logger.info("CSIEXception in IDUE call "+desc);
		}
		getExecution().setVariableLocal("isIAPRequired", false);
	}
	
	@Override
	public void handleSuccessResponse() throws Exception {
		// TODO Auto-generated method stub
		String response = getResponse();
		getExecution().setVariable("idueresponse", new StringBuffer(response));
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		Map<String, Object>  accounts =  (Map<String, Object>)order.get("Accounts");
	//	List<Object> accountlist = (List<Object>)accounts.get("Account");
		Map<String, Object>  account =   (Map<String, Object>) ( (List<Object>)accounts.get("Account")).get(0);
		String enterpriseType = account.get("EnterpriseType").toString();
		String eligibilityStatus ="";
		String unlockCode ="0";
		boolean isIAPRequired =false;
	if(response!=null && !response.equals("")){
			
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = null;
			try {
			    builder = factory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
			    logger.info("Error creating xmlDoc from soap response in DeviceAlreadyUnlockValidator "+e.getMessage());  
			}
			Document xmlDocument = builder.parse(new ByteArrayInputStream(response.getBytes()));
			
			
			if (xmlDocument.getElementsByTagName("DeviceUnlockStatusData")!=null){
				
				 NodeList deviceUnlockStatusDataList = xmlDocument.getElementsByTagName("DeviceUnlockStatusData");
				 Node deviceUnlockStatusData = deviceUnlockStatusDataList.item(0);
		            if (deviceUnlockStatusData.getNodeType() == Node.ELEMENT_NODE) {
		            	
		            	Element deviceUnlockStatusDataElement = (Element) deviceUnlockStatusData;
		            	//System.out.println(deviceUnlockStatusDataElement.getElementsByTagName("imei").item(0).getTextContent());
		            //	System.out.println(deviceUnlockStatusDataElement.getElementsByTagName("deviceUnlockEligibilityStatus").item(0).getTextContent());
		            	eligibilityStatus = deviceUnlockStatusDataElement.getElementsByTagName("deviceUnlockEligibilityStatus").item(0).getTextContent();
		            	
		            	unlockContext.put("eligibilityStatus", eligibilityStatus);
		            	
							
		          		if(deviceUnlockStatusDataElement.getElementsByTagName("prepaidIndicator")!=null && deviceUnlockStatusDataElement.getElementsByTagName("prepaidIndicator").item(0)!=null)
		          		{
		          			String prepareInd = deviceUnlockStatusDataElement.getElementsByTagName("prepaidIndicator").item(0).getTextContent();
		          			if(prepareInd!=null && unlockContext.get(CommonConstants.PREPAIED_INDICATOR)==null)
	            			unlockContext.put(CommonConstants.PREPAIED_INDICATOR, prepareInd);
	            		}
		          		
		            	if(eligibilityStatus!=null && ( eligibilityStatus.equalsIgnoreCase(CommonConstants.ELIGIBLE) ||  eligibilityStatus.equalsIgnoreCase(CommonConstants.ELIGIBILITY_UNKNOWN)) ){
		            		if(deviceUnlockStatusDataElement.getElementsByTagName("unlockCode")!=null && deviceUnlockStatusDataElement.getElementsByTagName("unlockCode").item(0)!=null){
		            		 unlockCode = deviceUnlockStatusDataElement.getElementsByTagName("unlockCode").item(0).getTextContent();
		            		}
		            		
		            		 if(deviceUnlockStatusDataElement.getElementsByTagName("subscriberNumber")!=null && deviceUnlockStatusDataElement.getElementsByTagName("subscriberNumber").item(0)!=null){
		            			 String CTN = deviceUnlockStatusDataElement.getElementsByTagName("subscriberNumber").item(0).getTextContent();
				            	 isIAPRequired = (CTN != null && !("").equals(CTN) && eligibilityStatus.equalsIgnoreCase(CommonConstants.ELIGIBILITY_UNKNOWN));
				            	 getExecution().setVariableLocal("IDUEResponse_CTN", CTN);
		            		 }
		            		 
		            		 UnlockUtils.createAutomationSummary(order, CommonConstants.ELIGIBILITY_CHECK_TYPE , CommonConstants.ELIGIBILITY_CHECK_CODE , eligibilityStatus);
		            		 unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_SYS_PROCESSING);
		            	}
		            	if(eligibilityStatus!=null && eligibilityStatus.equalsIgnoreCase(CommonConstants.INELIGIBLE)){
		  
		            		if(deviceUnlockStatusDataElement.getElementsByTagName("InEligibleReasonDetails")!=null){
		            			if(deviceUnlockStatusDataElement.getElementsByTagName("ineligibleReasonCode").getLength()==1){
		            				String reasonCode =deviceUnlockStatusDataElement.getElementsByTagName("ineligibleReasonCode").item(0).getTextContent();
		            				logger.info("Device Ineligibile with reason code : "+reasonCode);
		            				if(reasonCode.equals("1")){
		            					order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idue")));
				           				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
				           			
				           			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
				       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
				       				if(unlockContext.get("Make")!=null)
				       				 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.INELIGIBLE_REASON_CODE_1_FALLOUT_INFO);
				       				 getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idue"),CommonConstants.INELIGIBLE_REASON_CODE_1_FALLOUT_INFO));
				     				getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
				     				UnlockUtils.createAutomationSummary(order, CommonConstants.ELIGIBILITY_CHECK_TYPE , CommonConstants.ELIGIBILITY_CHECK_CODE , CommonConstants.ELIGIBILITY_UNKNOWN);
				     				
		            				}else if (reasonCode.equals("2") || reasonCode.equals("3")){
		            					 order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_LOST_STOLEN));
		            						unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
		            			   			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
						       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
						       				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_LOST_STOLEN);
						       				if(unlockContext.get("Make")!=null)
						       				 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
						       				getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
											getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
											 UnlockUtils.createAutomationSummary(order, CommonConstants.ELIGIBILITY_CHECK_TYPE , CommonConstants.ELIGIBILITY_CHECK_CODE , eligibilityStatus);
		            				}else if (reasonCode.equals("6") || reasonCode.equals("8")){
		            					 UnlockUtils.createAutomationSummary(order, CommonConstants.ELIGIBILITY_CHECK_TYPE , CommonConstants.ELIGIBILITY_CHECK_CODE , eligibilityStatus);
		            					if(enterpriseType.equalsIgnoreCase(CommonConstants.ENTERPRISE_CRU)){
		            						order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idue")));
					           				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
					           				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
					       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
					       				if(unlockContext.get("Make")!=null)
					       				 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_CRU_IN_BRE_PERIOD);
				       				 getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idue"),CommonConstants.FALLOUT_INFO_CRU_IN_BRE_PERIOD));
					     				getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
					     				
		            					}else{
		            						 order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_IN_BRE_PERIOD));
			            						unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
			            			 			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
							       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
							       				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_IN_BRE_PERIOD);
							       				if(unlockContext.get("Make")!=null)
							       				 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
							       				getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
												getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
												
		            					}
		            					
		            				}else if(reasonCode.equals("4") || reasonCode.equals("5")){
		            					UnlockUtils.createAutomationSummary(order, CommonConstants.ELIGIBILITY_CHECK_TYPE , CommonConstants.ELIGIBILITY_CHECK_CODE , eligibilityStatus);
		            					if(UnlockUtils.isActiveMilitary(account)){
		            						order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,CommonConstants.LOSG_SUB_STATUS_MILITARY_VERIFICATION));
					           				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
											UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
					       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
					       				if(unlockContext.get("Make")!=null)
					       				 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_MILITARY_VERIFICATION);
				       				 getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(CommonConstants.LOSG_SUB_STATUS_MILITARY_VERIFICATION,CommonConstants.FALLOUT_INFO_MILITARY_VERIFICATION));
					     				getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
					     				 
			            			
		            					}else{
		            						if(enterpriseType.equalsIgnoreCase(CommonConstants.ENTERPRISE_CRU)){
		            							order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idue")));
						           				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
						           				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
						       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
						       				if(unlockContext.get("Make")!=null)
						       				 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
						       				 
						       				 if(reasonCode.equals("4")){
						       					 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_CRU_SUBSIDY_COMMITMENT);
							       				 getExecution().setVariable(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idue"),CommonConstants.FALLOUT_INFO_CRU_SUBSIDY_COMMITMENT));
						       				 }else{
						       					 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_CRU_ATT_NEXT_COMMITMENT);
							       				 getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idue"),CommonConstants.FALLOUT_INFO_CRU_ATT_NEXT_COMMITMENT));
						       				 }
						       				
							     				getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
				            					
						       				 
		            						}else{
		            							if(reasonCode.equals("4")){
		            								order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_SUBSIDY_SERVICE_COMMITMENT_NOT_MET));
				            						unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
				            			 			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
								       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
								       				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_SUBSIDY_SERVICE_COMMITMENT_NOT_MET);
								       				if(unlockContext.get("Make")!=null) 
								       				UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
								       				getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
													getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
		            							}else{
		            								order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_ATT_NEXT_SERVICE_COMMITMENT_NOT_MET));
				            						unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
				            			 			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
								       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
								       				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_ATT_NEXT_SERVICE_COMMITMENT_NOT_MET);
								       				if(unlockContext.get("Make")!=null)
								       				UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
								       				getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
													getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
		            							}
		            						}
		            					}
		            				}
		            				else{
		            					order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idue")));
				           				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
				           				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
				       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
				       				if(unlockContext.get("Make")!=null)
				       				 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_B4_IDUE);
				       				 getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idue"),CommonConstants.FALLOUT_INFO_B4_IDUE));
				     				getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
				     				 UnlockUtils.createAutomationSummary(order, CommonConstants.ELIGIBILITY_CHECK_TYPE , CommonConstants.ELIGIBILITY_CHECK_CODE , eligibilityStatus);
		            				
		            				}
		            			}
		            			if(deviceUnlockStatusDataElement.getElementsByTagName("ineligibleReasonCode").getLength()!=1){
		            				order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idue")));
		           				 unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
		           				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
		       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
		       				if(unlockContext.get("Make")!=null)
		       				 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
		       				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_B4_IDUE);
		       				 getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idue"),CommonConstants.FALLOUT_INFO_B4_IDUE));
		     				getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
		     				UnlockUtils.createAutomationSummary(order, CommonConstants.ELIGIBILITY_CHECK_TYPE , CommonConstants.ELIGIBILITY_CHECK_CODE , eligibilityStatus);
		           				
		            			}
		            		}
		            		
		            	}
		           }
		            logger.info("statusDescription :"+eligibilityStatus); 	       
			        logger.info("UnlockCode :"+unlockCode);
			}
			

	       
	      
		}
	getExecution().setVariableLocal("isIAPRequired", isIAPRequired);
	UnlockUtils.createAutomationSummary(order, null, CommonConstants.UNLOCK_CODE, unlockCode);
	unlockContext.put(CommonConstants.UNLOCK_CODE, unlockCode);
	getExecution().setVariableLocal(CommonConstants.ORDER, Variables.objectValue(order).
				serializationDataFormat(Variables.SerializationDataFormats.JSON).create());
		
	}

}
