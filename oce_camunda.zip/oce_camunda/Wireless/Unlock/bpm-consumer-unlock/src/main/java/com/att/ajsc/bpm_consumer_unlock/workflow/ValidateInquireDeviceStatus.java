package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.variable.Variables;
import org.w3c.dom.Document;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.api.response.handler.AbstractCsiApiResponseHandler;

public class ValidateInquireDeviceStatus extends AbstractCsiApiResponseHandler /*implements JavaDelegate*/ {

	
	static final Logger logger = Logger.getLogger(ValidateInquireDeviceStatus.class.getName());
	@Override
	public void handleSuccessResponse() throws Exception {
		// TODO Auto-generated method stub
		String response = getResponse();
		getExecution().setVariable("idsresponse",new StringBuffer(response));
		//UnlockUtils unlockUtils = new UnlockUtils();
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable("order");
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		if(response!=null && !response.equals("")){
			
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = null;
			try {
			    builder = factory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
			    logger.info("Error creating xmlDoc from soap response in DeviceAlreadyUnlockValidator "+e.getMessage());  
			}
			Document xmlDocument = builder.parse(new ByteArrayInputStream(response.getBytes()));
			//XPath xPath =  XPathFactory.newInstance().newXPath();
			String statusDescription = "";
			String statusDescriptionlowercase = "";
			if(xmlDocument.getElementsByTagName("statusDescription")!=null && xmlDocument.getElementsByTagName("statusDescription").item(0)!=null && 
					xmlDocument.getElementsByTagName("statusDescription").item(0).getTextContent()!=null){
				 statusDescription = xmlDocument.getElementsByTagName("statusDescription").item(0).getTextContent();
				 statusDescriptionlowercase = xmlDocument.getElementsByTagName("statusDescription").item(0).getTextContent();
				 statusDescriptionlowercase=statusDescriptionlowercase.toLowerCase();
			}
			
			
	       
	        String message ="";
	        String status ="";
	        if(xmlDocument.getElementsByTagName("message")!=null && xmlDocument.getElementsByTagName("message").item(0)!=null){
	        	 message = xmlDocument.getElementsByTagName("message").item(0).getTextContent();
	        }
			if(xmlDocument.getElementsByTagName("status")!=null && xmlDocument.getElementsByTagName("status").item(0)!=null){
				status = xmlDocument.getElementsByTagName("status").item(0).getTextContent();
			}
			 
			
	        logger.info("IDS response message :"+message);
	        if(status.equalsIgnoreCase("") || status.equalsIgnoreCase(CommonConstants.SUCCESS) || (statusDescription!=null && !statusDescription.equals("") && statusDescription.equalsIgnoreCase(CommonConstants.DEVICE_UNLOCKED)) 
	        		|| (statusDescriptionlowercase!=null && !statusDescriptionlowercase.equals("") && statusDescriptionlowercase.contains("unlocked"))
	        		||(message!=null && !message.equals("") && message.equalsIgnoreCase(CommonConstants.AL_PENDING_UNLOCK))){
	        	
	        	 order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_APPROVED,CommonConstants.LOSG_SUBSTATUS_TORCH_APPLE_COMPLETED));
	    		   unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_APPROVED);
	    		   UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
					 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
					 if(unlockContext.get("Make")!=null)
					 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
	        }
	        else if(message!=null && !message.equals("") && message.equalsIgnoreCase(CommonConstants.AL_BAD_REQUEST)){
	        	order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUBSTATUS_NON_ATT_IMEI));
	        	 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.CANCEL_REASON_NON_ATT_IMEI);
				if(unlockContext.get("Make")!=null)
				 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
				
	        }
	        else{
	        	if(unlockContext.get("isBulkUnlockOrder")!=null && unlockContext.get("isBulkUnlockOrder").toString().equalsIgnoreCase("true")){
	        		order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,CommonConstants.LOSG_SUB_STATUS_BULK));
	        	}else{
	        		order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,CommonConstants.LOSG_SUBSTATUS_TORCH_APPLE_FAILED));
	        	}
	        	
				unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
				 if(unlockContext.get("Make")!=null)
				 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));

				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_TORCH_APPLE_FAILED);

				 getExecution().setVariable(CommonConstants.ERRORS, UnlockUtils.getErrors(CommonConstants.LOSG_SUBSTATUS_TORCH_APPLE_FAILED,CommonConstants.FALLOUT_INFO_TORCH_APPLE_FAILED));
				 getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
	        }
		}
		
		getExecution().setVariableLocal(CommonConstants.ORDER, Variables.objectValue(order).
				serializationDataFormat(Variables.SerializationDataFormats.JSON).create());
	}

}
