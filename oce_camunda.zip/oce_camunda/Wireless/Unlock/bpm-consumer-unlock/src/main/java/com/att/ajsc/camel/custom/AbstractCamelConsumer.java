package com.att.ajsc.camel.custom;

import java.io.IOException;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.converter.stream.FileInputStreamCache;
import org.apache.camel.converter.stream.InputStreamCache;

import com.att.consumer.mobility.services.CamelBean;

public abstract class AbstractCamelConsumer implements CamelBean {

	@Override
	abstract public void execute(Exchange e);
	
	public static String readExchangeMessage(Exchange e) throws IOException {
		String inMessageStr = null;
		Message msg = e.getIn();
		if (msg.getBody() instanceof String) {
			inMessageStr = (String) msg.getBody();
		} else {
			try{
			InputStreamCache msgCache = (InputStreamCache) msg.getBody();
			byte[] content = new byte[msgCache.available()];
			msgCache.read(content);
			inMessageStr = new String(content);
			}catch(ClassCastException c){
				FileInputStreamCache msgCache = (FileInputStreamCache) msg.getBody();
				byte[] content = new byte[msgCache.available()];
				msgCache.read(content);
				inMessageStr = new String(content);
			}
		}
		return inMessageStr;
	}

}
