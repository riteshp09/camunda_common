package com.att.consumer.mobility.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.converter.stream.InputStreamCache;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.oce.bpm.common.VelocityHelper;

import org.camunda.bpm.engine.variable.VariableMap;
import org.camunda.bpm.engine.variable.Variables;
import org.camunda.bpm.engine.variable.value.ObjectValue;
import org.json.JSONObject;
import org.json.JSONException;

//import com.att.oce.oce.namespaces.types._private.ocedatamodel.Order;
import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.ServicePropertiesMapBean;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;

public class DispatchService {
	
	static final Logger logger = Logger.getLogger(DispatchService.class.getName());
	
	@Autowired
	private RuntimeService runtimeService;
	
	public void dispatch(Exchange e){
		
		Message msg = e.getIn();
		
		JSONObject response = new JSONObject();
		try {
			String messageStr = null;
			
			if(msg.getBody() instanceof String) {
				messageStr = (String) msg.getBody();
			} else {
				InputStreamCache msgCache = (InputStreamCache) msg.getBody();
				byte[] content = new byte[msgCache.available()];
				msgCache.read(content);
				messageStr = new String(content);
			}
			String jsonOrder = UnlockUtils.xmlToJson(messageStr);
		
			Map<String,Object> order = VelocityHelper.jsonToMap(new String(jsonOrder));
			String OrderType = order.get("OrderType").toString();
		
			String businessKey = new StringBuffer( ( (Map<?,?>)order.get("OrderSource")).get("Channel").toString() )
					.append(":")
					.append(order.get("CustomerOrderNumber"))
					.append(":")
					.append(OrderType).toString();
			
			Map<String,String> globalConfig =  new HashMap<>();
			globalConfig.put("commonCsiServicesUsername", ServicePropertiesMapBean.getProperty(CommonConstants.URN_MAPPING_PROPS , CommonConstants.OCE_USER_NAME_PROPERTY));
			globalConfig.put("commonCsiServicesPassword",ServicePropertiesMapBean.getProperty(CommonConstants.URN_MAPPING_PROPS, CommonConstants.OCE_PASSWORD_PROPERTY));
			globalConfig.put("CSIVersion", ServicePropertiesMapBean.getProperty(CommonConstants.URN_MAPPING_PROPS, CommonConstants.OCE_CSI_VERSION_PROPERTY));
			globalConfig.put("ttl", ServicePropertiesMapBean.getProperty(CommonConstants.URN_MAPPING_PROPS, CommonConstants.OCE_CSI_TTL_PROPERTY));
			if(order.get("CustomerOrderNumber")!=null)
			e.setProperty("customerOrderNumber", order.get("CustomerOrderNumber"));
			
			if(order.get("RequestId")!=null)
				e.setProperty("RequestId", order.get("RequestId"));
			Map<String,String> unlockContext =  new HashMap<>();
			unlockContext.put("orderAction", OrderType);
		
			unlockContext.put("CustomerType", UnlockUtils.getCustomerType(order));
			String paymentArrangement = UnlockUtils.getPaymentArrangement(order);
			
			if(paymentArrangement !=null && !paymentArrangement.equals("") && !paymentArrangement.equalsIgnoreCase("POSTPAID")){
				unlockContext.put(CommonConstants.PREPAIED_INDICATOR, "true");
			}
			
			unlockContext.put("requestedIMEI", UnlockUtils.getReqestedIMEI(order));
			unlockContext.put("isBulkUnlockOrder",String.valueOf(UnlockUtils.isBulkUnlockOrder(order)) );
			if(!UnlockUtils.isBulkUnlockOrder(order)){
				List<Object>  lineitemarray = (List<Object>) ( (Map<?,?>)order.get("LineItems")).get("LineItem");
				String make = ( (Map <?,?>)((Map<?,?>)lineitemarray.get(0)).get("HardGood")).get("Make").toString();
				String model = ( (Map <?,?>)((Map<?,?>)lineitemarray.get(0)).get("HardGood")).get("Model").toString();
				unlockContext.put("Make", make);
				unlockContext.put("Model", model);
				//logger.info("Model: "+ model + ", Make: "+ make);
				String paramString = "model=" + model + "&make=" + make;
				unlockContext.put("paramString", paramString);
				
			}
			if(!UnlockUtils.isBulkUnlockOrder(order)){
			String fraudOrderValidationRequest ="";
			try{
				// fraudOrderValidationRequest =VelocityHelper.jsonToXML(new String(jsonOrder)).toString();
				 int from = messageStr.indexOf("<Order>", 0);
			        int to = messageStr.indexOf("</Order>", 0);
			        fraudOrderValidationRequest = messageStr.substring(from, to+8);
			        fraudOrderValidationRequest=fraudOrderValidationRequest.replaceAll("\\r\\n", "").replaceAll("  ", "");			        
			        fraudOrderValidationRequest = fraudOrderValidationRequest.replaceFirst("<Order>", "<Order xmlns=\"http://oce.att.com/OCE/Namespaces/Types/Private/OCEDataModel.xsd\">");
			        unlockContext.put("orderXml", fraudOrderValidationRequest);
			}
			catch(JSONException j){
				logger.info("Exception while converting json to xml order payload"+j.getMessage());
			}
			}
			//Param string for decryption passcode unmask API call
			unlockContext.put("unmaskingParam", UnlockUtils.getDecryptedPasscodeParams(order));
			unlockContext.put(CommonConstants.IS_ROBOTICS_AUTOMATION, ServicePropertiesMapBean.getProperty(CommonConstants.URN_MAPPING_PROPS,CommonConstants.IS_ROBOTICS_AUTOMATION));
			UnlockUtils.setIntializations(order, CommonConstants.ORDERSTATUS_RECEIVED);
			
			VariableMap variables = Variables.createVariables();
			
			ObjectValue value = Variables.objectValue(order).
								serializationDataFormat(Variables.SerializationDataFormats.JSON).create();
			
			variables.put(CommonConstants.ORDER, value );
			variables.put("vtlHelp", VelocityHelper.class);
			variables.put("unlockUtils", UnlockUtils.class);
			variables.put("globalConfig", globalConfig);
			variables.put("unlockContext", unlockContext);
			variables.put("eContext",new HashMap<String,Object>());
			variables.put("beforeIDUE", true);
			
			ProcessInstance instance =  runtimeService.startProcessInstanceByKey("oce.unlock.parentorderprocess",businessKey , variables);
			
			//Calling IDUE Process Directly
			//ProcessInstance instance =  runtimeService.startProcessInstanceByKey("IDUEProcess",businessKey , variables);
			
			response.append("response", new JSONObject().append("code", 0)
					                                    .append("description", "success")
					                                    .append("processData", new JSONObject().append("id", instance.getProcessInstanceId())
					                                    		                               .append("id", instance.isEnded()?"ended":(instance.isSuspended()?"suspended":"running"))
					                                    		));
		} catch (Exception e2) {
			e2.printStackTrace();
			response.append("response", new JSONObject().append("code", 900)
                    .append("description",e2.getMessage()));
		} 
		
		msg.setBody(response.toString());
		e.setOut(msg);
		
	}
 

}
