package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.util.List;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;

public class NonCRUValidator implements JavaDelegate{

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		
		Map<String,String> unlockContext = (Map<String, String>) execution.getVariable("unlockContext");
		Map<String,Object> order = (Map<String, Object>) execution.getVariable("order");
		Map<String, Object>  accounts =  (Map<String, Object>)order.get("Accounts");
		Map<String, Object>  account =   (Map<String, Object>) ( (List<Object>)accounts.get("Account")).get(0);
		String enterpriseType = account.get("EnterpriseType").toString();
		Map<String, String> losgStatus=UnlockUtils.getLOSGStatusSubStatus(order);
		String isRobiticsAutomation ="false";
		if(unlockContext.get(CommonConstants.IS_ROBOTICS_AUTOMATION)!=null)
		 isRobiticsAutomation = unlockContext.get(CommonConstants.IS_ROBOTICS_AUTOMATION).toString();
		String fallout= UnlockUtils.getAdditionalDetailValue(order,CommonConstants.FALLOUT_INFO);
		if(!enterpriseType.equalsIgnoreCase(CommonConstants.ENTERPRISE_CRU) && fallout!=null && fallout.equals(CommonConstants.NO_UNLOCK_CODE_FALLOUT_REASON) && isRobiticsAutomation.equalsIgnoreCase("true") ){
			order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_IN_QUEUE, CommonConstants.ROBOTICS_PROCESS_AUTOMATION));
		
		}
	
		if(unlockContext.get("LOSGSTATUS")!=null && unlockContext.get("LOSGSTATUS").toString().equalsIgnoreCase(CommonConstants.LOSG_STATUS_IN_QUEUE) && execution.getVariable(CommonConstants.ERRORS)!=null && ((Map<String,Object>)execution.getVariable(CommonConstants.ERRORS)).size()==0){
			execution.setVariable(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.FALLOUT_INFO_CATCH_ALL));
			
		}
		if(unlockContext.get("LOSGSTATUS")!=null && unlockContext.get("LOSGSTATUS").toString().equalsIgnoreCase(CommonConstants.LOSG_STATUS_IN_QUEUE) && execution.getVariable(CommonConstants.ORDERTASKS)!=null && ((Map<String,Object>)execution.getVariable(CommonConstants.ORDERTASKS)).size()==0){
			execution.setVariable(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
		}

	}
}