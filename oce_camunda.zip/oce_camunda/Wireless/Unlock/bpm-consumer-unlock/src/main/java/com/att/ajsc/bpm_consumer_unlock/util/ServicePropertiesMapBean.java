package com.att.ajsc.bpm_consumer_unlock.util;

import com.att.ajsc.bpm_consumer_unlock.filemonitor.ServicePropertiesMap;

public class ServicePropertiesMapBean {

	public static String getProperty(String propFileName, String propertyKey) {
		return ServicePropertiesMap.getProperty(propFileName, propertyKey);
	}
}
