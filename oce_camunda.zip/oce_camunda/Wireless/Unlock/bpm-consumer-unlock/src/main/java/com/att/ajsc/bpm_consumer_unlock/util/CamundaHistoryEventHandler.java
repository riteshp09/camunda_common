package com.att.ajsc.bpm_consumer_unlock.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.camunda.bpm.engine.impl.history.event.HistoricActivityInstanceEventEntity;
import org.camunda.bpm.engine.impl.history.event.HistoryEvent;
import org.camunda.bpm.engine.impl.history.handler.DbHistoryEventHandler;
import org.camunda.bpm.engine.impl.history.handler.HistoryEventHandler;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.att.ajsc.bpm_consumer_unlock.AttCamundaService;

import com.att.ajsc.csi.logging.PerformanceTracking;
import com.att.ajsc.csi.logging.PerformanceTrackingBean;


public class CamundaHistoryEventHandler extends DbHistoryEventHandler implements HistoryEventHandler {


	List<HistoricActivityInstanceEventEntity> historyEventList = Collections.synchronizedList(new ArrayList<HistoricActivityInstanceEventEntity>());

	@Override
	public void handleEvent(HistoryEvent historyEvent) 
	{
		// create db entry
		super.handleEvent(historyEvent);	    

		// Create log Entry
		HistoricActivityInstanceEventEntity activityEvent = null;

		Date startDate = null;
		Date endDate = null;
		if(historyEvent != null && historyEvent instanceof HistoricActivityInstanceEventEntity )
		{
			activityEvent = (HistoricActivityInstanceEventEntity) historyEvent;
			if(activityEvent != null)
			{
				startDate = activityEvent.getStartTime();
				endDate = activityEvent.getEndTime();
				
				synchronized (historyEventList) {
					if(activityEvent.getActivityType() != null && (activityEvent.getActivityType().equalsIgnoreCase("manualTask")
							|| activityEvent.getActivityType().equalsIgnoreCase("userTask")))
					{
						historyEventList.clear();
					}
					if(startDate != null && endDate != null)
					{
						System.out.println(activityEvent + ":" + activityEvent.getProcessInstanceId()+ ":" +  activityEvent.getActivityType() );
						if(activityEvent != null && activityEvent.getProcessInstanceId() != null)
						{
							historyEventList.add(activityEvent);
							if( activityEvent.getActivityType() != null && activityEvent.getActivityType().equalsIgnoreCase("noneEndEvent"))
							{
								if(AttCamundaService.getHttpRequest() != null)
								{
									for(HistoricActivityInstanceEventEntity actiEvent : historyEventList)
									{
										int activityInstanceState = actiEvent.getActivityInstanceState();
										String activityState = getActivityInstanceState(activityInstanceState);
										//  resolve null pointer exception if actiEvent.getActivityName()
										String serviceName = actiEvent.getActivityName();
										if ( serviceName == null ) {
											serviceName = "UNKNOWN";
										}
										PerformanceTracking.addInvokeServiceTrack((PerformanceTrackingBean)AttCamundaService.getHttpRequest().getAttribute("PERFORMANCE_TRACKER_BEAN"),
												serviceName, Long.valueOf(actiEvent.getStartTime().getTime()), Long.valueOf(actiEvent.getEndTime().getTime()),activityState,
												500, 1000) ;
									}
									System.out.println("Call performacne is success");
								}
								else
								{
									RestTemplate restTemplate = new RestTemplate();
									String histEvents = "";
									for(HistoricActivityInstanceEventEntity actiEvent : historyEventList)
									{
										int activityInstanceState = actiEvent.getActivityInstanceState();
										String activityState = getActivityInstanceState(activityInstanceState);
										histEvents = histEvents + actiEvent.getActivityName() + ":" + String.valueOf(actiEvent.getStartTime().getTime() )+ ":" 
												+ String.valueOf(actiEvent.getEndTime().getTime()) + ":" + activityState + "," ;
										System.out.println(actiEvent);
									}
									Map<String,String> restValues = new HashMap<String,String>();
									restValues.put("procInstId", activityEvent.getProcessInstanceId());
									restValues.put("histEventList",histEvents);
									// TODO: this should be fixed - put in temporary solution with existing sysprop and vars - why are we calling our own service? (cb3786)
									String port = System.getProperty("server.port");
									String url = "http://localhost:" + port + "/services/bpm-consumer-unlock/v1/jaxrsExample/log/createLogHist/" + activityEvent.getProcessInstanceId() + "/" + histEvents;
									System.out.println("History REST URL : " + url);
									//			 	    			ResponseEntity<String> resp = restTemplate.getForEntity("http://localhost:" + port + "/services/bpm-consumer-unlock/v1/jaxrsExample/log/createLogHist/{procInstId}/{histEventList}", String.class, restValues);
								}
								historyEventList.clear();
							}
						}
					}
				}
			}
		}
	}


	private String getActivityInstanceState(int activityInstanceState)
	{
		String activityState = "Default";
		if(activityInstanceState == 1)
		{
			activityState = "Complete";
		}
		else if(activityInstanceState == 2)
		{
			activityState = "Cancelled";
		}
		return activityState;
	}

}