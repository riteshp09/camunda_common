package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.variable.Variables;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;

public class UpdateUnlockInsturction implements JavaDelegate {
	
	@SuppressWarnings("unchecked")
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		LinkedHashMap<?, ?> inquireOrderResponse = (LinkedHashMap<?, ?>) execution.getVariable("inquireOrderResponse");
		
		List<?> orderDetails = (List<?>) inquireOrderResponse.get("OrderDetails");
		Map<?,?> order =  (Map<?, ?>) ((Map<?,?>)orderDetails.get(0)).get("Order");
		
		Map<String, Object>  lineitems =  (Map<String, Object>)order.get("LineItems");
		Map<String, Object>  lineitem =   (Map<String, Object>) ( (List<Object>)lineitems.get("LineItem")).get(0);
		Map<String, Object> additionalDetails = ((Map<String, Object>)lineitem.get("AdditionalDetails"));
		
		Map<?,?> unlockInstructionMap = null;
		
		if(null!=additionalDetails){
			List<Map<String, Object>> additionalDetaillist =(List<Map<String, Object>>)additionalDetails.get("AdditionalDetail");
			
			for (Map<String, Object> additionalDetailsMap : additionalDetaillist) {
				
				if(additionalDetailsMap.get("Code").toString().equalsIgnoreCase("UnlockInstruction")) {
					unlockInstructionMap = additionalDetailsMap;
					break;
				}
			}
		}
		
		Map<String, Object> orderMap = (Map<String, Object>) execution.getVariable("order");
		
		UnlockUtils.setOceOrderNumber((String) order.get("OCEOrderNumber"), orderMap);
		if(unlockInstructionMap != null && !unlockInstructionMap.isEmpty())
			UnlockUtils.setUnlockInstructions(unlockInstructionMap, orderMap);
		
		execution.setVariableLocal(CommonConstants.ORDER, Variables.objectValue(orderMap).
				serializationDataFormat(Variables.SerializationDataFormats.JSON).create());
	}

}
