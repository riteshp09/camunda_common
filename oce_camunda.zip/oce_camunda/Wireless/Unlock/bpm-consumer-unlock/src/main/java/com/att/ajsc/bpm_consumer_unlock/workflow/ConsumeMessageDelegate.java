package com.att.ajsc.bpm_consumer_unlock.workflow;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.runtime.ProcessInstance;

import com.att.ajsc.bpm_consumer_unlock.util.DMaapConsumer;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Log message.
 * Invoked by the log-message-wf example Camunda workflow/bpmn. 
 * 
 * @author cb3786
 *
 */
public class ConsumeMessageDelegate implements JavaDelegate {
	// currently uses the java.util.logging.Logger like the Camunda engine
	private final Logger LOGGER = Logger.getLogger(ConsumeMessageDelegate.class.getName());

	/**
	 * Perform activity.  Log message from running process and set a variable in the running process.
	 * 
	 * @param execution
	 */
	public void execute(DelegateExecution execution) throws Exception {
	
		DMaapConsumer consumer = new DMaapConsumer();
		String consumedMsg = "";
	    consumedMsg= consumer.consume();
	    System.out.println("Consumed Messages are:" + consumedMsg);
		LOGGER.info("Invoked from processDefinitionId=" + execution.getProcessDefinitionId() +  ", processInstanceId=" + execution.getProcessInstanceId() +  ", activityInstanceId=" + execution.getActivityInstanceId());
		RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		// input variables to example camunda process
    	Map<String, Object> variables = new HashMap<String,Object>();
		variables.put("MessageFromTopic", consumedMsg);
		// execute example camunda process, log-message-wf
		ProcessInstance pi = runtimeService.startProcessInstanceByKey("log-message-wf",variables);
		execution.setVariable("isMessageLogComplete", true);
		execution.setVariable("LogMessageStarted", pi.getProcessDefinitionId());
	}
}
