package com.att.ajsc.bpm_consumer_unlock.workflow;


import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.api.response.handler.AbstractCsiApiResponseHandler;

public class LatestCTNDeviceDetailsValidation extends AbstractCsiApiResponseHandler{
	static final Logger logger = Logger.getLogger(LatestCTNDeviceDetailsValidation.class.getName());
	@Override
	public void handleFaultResponse() throws Exception {
		Map<?,?> response = (Map<?, ?>) getException().get("response");
		String errorCode = (String) response.get("code");
		
		Map<?,?> svcProviderEntity = (Map<?, ?>) ((ArrayList)getException().get("serviceProviderEntity")).get(0);
		Map<?,?> svcProviderRawErr = (Map<?, ?>) svcProviderEntity.get("serviceProviderRawError");
		
		String svcProviderRawErrorCode = (String) svcProviderRawErr.get("code");
		String desc = (String) svcProviderRawErr.get("description");		
		Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		getExecution().setVariableLocal("isIAPForLatestCTNRequired", false);
		logger.info("CSI Exception in IDD call for latest CTN ");
		if("300".equals(errorCode)){
			order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_DATA_NOT_FOUND));
			unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_DENIED);
   			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_TRUE);
			 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_TRUE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON, CommonConstants.FALLOUT_INFO_IMEI_ACTIVE_OTHER);
			if(unlockContext.get("Make")!=null)
			 UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			 getExecution().setVariableLocal(CommonConstants.ERRORS, new HashMap<>());
				getExecution().setVariableLocal(CommonConstants.ORDERTASKS, new HashMap<>());
		}else{
			order.put("Groups",UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"idd")));
			unlockContext.put("LOSGSTATUS", CommonConstants.LOSG_STATUS_IN_QUEUE);
			if(unlockContext.get("Make")!=null)
			UnlockUtils.createAutomationSummary(order, null, CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG, CommonConstants.VALUE_FALSE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_BY_AUTOMATION, CommonConstants.VALUE_FALSE);
			UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_IMEI_ACTIVE_OTHER);

			getExecution().setVariableLocal(CommonConstants.ERRORS, UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"idd"),CommonConstants.FALLOUT_INFO_IMEI_ACTIVE_OTHER));
			getExecution().setVariableLocal(CommonConstants.ORDERTASKS, UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
		}
		
		
	}

	@Override
	public void handleSuccessResponse() throws Exception {
		// TODO Auto-generated method stub
		
		String response = getResponse();
		getExecution().setVariableLocal("getLatestCTNIddResponse", new StringBuffer(response));
		//Map<String,Object> order = (Map<String, Object>) getExecution().getVariable(CommonConstants.ORDER);
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		boolean isIAPForLatestCTNRequired =false;
		 List<String> sortedIMEIs=new ArrayList();
		String requestedIMEI= unlockContext.get("requestedIMEI").toString();
		
		if(response!=null && !response.equals("")){
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = null;
			try {
			    builder = factory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
			    logger.info("Error creating xmlDoc from soap response in LatestCTNDeviceDetailsValidation "+e.getMessage());  
			}
			Document xmlDocument = builder.parse(new ByteArrayInputStream(response.getBytes()));
			if(null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireDeviceDetailsResponse.xsd", 
					"Device")){
				NodeList DeviceList = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireDeviceDetailsResponse.xsd", 
						"Device");
				 Element[] sortedDeviceList = UnlockUtils.sortNodes(DeviceList, "firstUseDate","http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd" ,false, Date.class);
			       // List<String> sortedCTNs=new ArrayList();
			        for(Element n: sortedDeviceList)
			        {
			        	sortedIMEIs.add(n.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","IMEI").item(0).getTextContent().toString());
			            //System.out.println(n.getElementsByTagName("cng:subscriberNumber").item(0).getTextContent()+" : "+n.getElementsByTagName("cng:activityDate").item(0).getTextContent());
			        	
			        }
			        if(requestedIMEI.equals(sortedIMEIs.get(0))){
			        	isIAPForLatestCTNRequired=true;
			        }
			}
			
		}
		getExecution().setVariableLocal("isIAPForLatestCTNRequired", isIAPForLatestCTNRequired);
	}
	
	
}
