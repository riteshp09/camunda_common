package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.util.LinkedHashMap;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.w3c.dom.Document;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.oce.bpm.common.JAXBUtil;

public class PasscodeMaskRequest implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LinkedHashMap<String, Object>  responseWrapper = null;
		boolean isFault = false;
		if(execution.getVariable("response")!=null){
			responseWrapper = (LinkedHashMap<String, Object>) execution.getVariable("response");
		}
		
		
		 isFault = (boolean) responseWrapper.get(CommonConstants.IS_FAULT_RESPONSE);
		if (isFault) {
			/*exception = (LinkedHashMap<String, Object>) responseWrapper.get("payload");
			getExecution().setVariable(
					(String) responseWrapper.get(CommonConstants.INTERFACE_NAME) + "_FaultResponse", exception);
			handleFaultResponse();*/
		} else {
			String response="";
			String billingAccountPassword = "";
			if(responseWrapper.get("payload")!=null){
				response = (String) responseWrapper.get("payload");
			}
			
			if(response!=null && !response.equals("")){
				Document xmlDocument = JAXBUtil.getXMLDocument(response);
				
				//http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberProfileResponse.xsd
				if (xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd", 
						"billingAccountPassword")!=null && null!=xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd", 
								"billingAccountPassword").item(0)) {
					billingAccountPassword = xmlDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd", 
							"billingAccountPassword").item(0).getTextContent().trim();
				}
			}
			
			String req = "{\"OceVoltageRequest\": {\"passcode\": " +"\"" +billingAccountPassword+"\"" + "}}";
			execution.setVariable("maskPasscodereq", req);
			
		} 
		
	}

/*	@Override
	public void handleSuccessResponse() throws Exception {
		// TODO Auto-generated method stub
		String response=getResponse();
		Map<String,String> unlockContext = (Map<String, String>) getExecution().getVariable("unlockContext");
		if(response!=null && response.equals(""))
		{
			Document xmlDoc = JAXBUtil.getXMLDocument(response);
			String passcode = null;
			if (xmlDoc.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
					"PassCode")!=null && null!=xmlDoc.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
							"PassCode").item(0))
			{
				passcode=xmlDoc.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
						"PassCode").item(0).getTextContent();
			}
			unlockContext.put("PassCode", passcode);
			
		}
	}*/

	
	
	
}
