package com.att.ajsc.bpm_consumer_unlock.workflow;

import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.RandomAccess;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.variable.Variables;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.att.ajsc.bpm_consumer_unlock.util.CommonConstants;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;
import com.att.oce.bpm.common.JAXBUtil;


public class SubscriberContractInfoValidation implements JavaDelegate{
	
	static final Logger logger = Logger.getLogger(SubscriberContractInfoValidation.class.getName());
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	
	@SuppressWarnings("unchecked")
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		Map<String, Object> order = (Map<String, Object>) execution.getVariable(CommonConstants.ORDER);
		Map<String, String> unlockContext = (Map<String, String>) execution.getVariable("unlockContext");
		
		if(execution.getVariable("iapresponse")!=null && !execution.getVariable("iapresponse").toString().equals("")){
			String iapResponse = execution.getVariable("iapresponse").toString();
			
			Document xmlIAPDocument = JAXBUtil.getXMLDocument(iapResponse);
			
			if(execution.getVariable("getIddResponse")!=null && !execution.getVariable("getIddResponse").toString().equals("")){
				String iddResponse = execution.getVariable("getIddResponse").toString();
				
				Document xmlIDDDocument = JAXBUtil.getXMLDocument(iddResponse);
				
				
		
				Map<String, Object> groups = (Map<String, Object>) order.get("Groups");
				Map<String, Object> group = (Map<String, Object>) ((List<Object>) groups.get("Group")).get(0);
		
				String requestCTN = UnlockUtils.getRequestCTN(group);
				String requestIMEI = UnlockUtils.getReqestedIMEI(order);
		
				Map<String, Object> accounts = (Map<String, Object>) order.get("Accounts");
				Map<String, Object> account = (Map<String, Object>) ((List<Object>) accounts.get("Account")).get(0);
				String enterpriseType = account.get("EnterpriseType").toString();
				
				String accountType="";
				if (xmlIAPDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
						"accountType")!=null && null!=xmlIAPDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
								"accountType").item(0)) {
					
					accountType = xmlIAPDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
							"accountType").item(0).getTextContent();
				}


				String accountSubType = "";
				if (xmlIAPDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
						"accountSubType")!=null && null!=xmlIAPDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
								"accountSubType").item(0)) {
					
					accountSubType = xmlIAPDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd", 
							"accountSubType").item(0).getTextContent();
				}
		
				String deviceEligibility = "";
				if (unlockContext.get("eligibilityStatus") != null && !unlockContext.get("eligibilityStatus").toString().equals("")) {
					deviceEligibility = unlockContext.get("eligibilityStatus").trim().toString();
				}
		
				
		
				String deviceType = "";
				if (unlockContext.get(CommonConstants.PREPAIED_INDICATOR) != null && !unlockContext.get(CommonConstants.PREPAIED_INDICATOR).toString().equals("")) {
					deviceType = unlockContext.get(CommonConstants.PREPAIED_INDICATOR).trim().toString();
				}
		
				NodeList nwActivityList = null;
				if (xmlIDDDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireDeviceDetailsResponse.xsd", "NetworkActivity") != null) {
					nwActivityList = xmlIDDDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireDeviceDetailsResponse.xsd","NetworkActivity");
				}
				String firstUsageDate = "";
				Element[] sortedNWActivity = UnlockUtils.sortNodes(nwActivityList,"activityDate","http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd",true, Date.class);
				List<String> sortedDates = new ArrayList<String>();
				List<String> sortedCTNs = new ArrayList();
				for (Element element : sortedNWActivity) {
					String subscriberNumber = element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","subscriberNumber").item(0).getTextContent().toString();
					String activityDate = element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","activityDate").item(0).getTextContent().toString();
					if ((subscriberNumber != null && !subscriberNumber.isEmpty()) && subscriberNumber.equalsIgnoreCase(requestCTN)) {
						if (activityDate != null && !activityDate.isEmpty()) {
							firstUsageDate = activityDate;
						}
						} 
					sortedDates.add(activityDate);
					sortedCTNs.add(subscriberNumber);
		
				}
				
				
				List<String> subscriberNumberList = new ArrayList();
				String subscriberEqforCTnStatus = "",subscriberNumber="",responseIMEI="";
				String startDate = "";
				long startDateLong = 0;
				String statusDate = "";
				String term = "";
				String contractEndDate = "";
				String attNextSubscriber ="";		
				String contract = "";
				String subscriberStatus = "";
				NodeList subscriberList = null;
				if (xmlIAPDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberProfileResponse.xsd", "Subscriber") != null) {
					subscriberList = xmlIAPDocument.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberProfileResponse.xsd","Subscriber");
				}
				
				Element[] sortedSubscriberList = UnlockUtils.sortNodes(subscriberList,"subscriberNumber","http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberProfileResponse.xsd",true, String.class);
				
				for (Element element : sortedSubscriberList) {
					String subscriberNum = element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberProfileResponse.xsd","subscriberNumber").item(0).getTextContent().toString();
					
					if (subscriberNum.equalsIgnoreCase(requestCTN)) {
						if (element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","subscriberStatus")!=null
								&& null!=(element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","subscriberStatus").item(0))){
						subscriberEqforCTnStatus = element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","subscriberStatus").item(0).getTextContent().toString();
						}
						if (element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","statusDate")!=null
								&& null!=(element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","statusDate").item(0))){
						statusDate = element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","statusDate").item(0).getTextContent().toString();
						}
						if (element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","startDate")!=null
								&& null!=(element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","startDate").item(0))){
						startDate = element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","startDate").item(0).getTextContent().toString();
						startDateLong = format.parse(startDate).getTime();
						}
						if (element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","term")!=null
								&& null!=(element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","term").item(0))){
						term = element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","term").item(0).getTextContent().toString();
						}
						if (element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberProfileResponse.xsd","commitmentReasonCode")!=null
								&& null!=(element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberProfileResponse.xsd","commitmentReasonCode").item(0))){
						attNextSubscriber = element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberProfileResponse.xsd","commitmentReasonCode").item(0).getTextContent().toString();
						}
						if (element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberProfileResponse.xsd","contractEndDate")!=null
								&& null!=(element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberProfileResponse.xsd","contractEndDate").item(0))){
						contractEndDate = element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireSubscriberProfileResponse.xsd","contractEndDate").item(0).getTextContent().toString();
						}
					} 
				}
				
				for (Element element : sortedSubscriberList) {
					if (element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","IMEI")!=null
							&& null!=(element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","IMEI").item(0))){
							responseIMEI = element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","IMEI").item(0).getTextContent().toString();
					}
					if (responseIMEI.equalsIgnoreCase(requestIMEI)){
						if (element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","subscriberStatus")!=null
								&& null!=(element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","subscriberStatus").item(0))){
						subscriberStatus = element.getElementsByTagNameNS("http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd","subscriberStatus").item(0).getTextContent().toString();
						}
					}

				}
			
				
				//-----------------------------------------------------------------------------------------
		
				if (!UnlockUtils.isGoPhone(accountType, accountSubType, deviceType)) {
					 UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_DEVICE_LINKED_DLC , CommonConstants.VALUE_YES);
					Date currentDate = new Date();
					int diffInDays = 0;
		
					if (startDateLong != 0) {
						diffInDays = (int) ((currentDate.getTime() - startDateLong) / (1000 * 60 * 60 * 24));
					}
		
					
					if (deviceEligibility.equalsIgnoreCase(CommonConstants.ELIGIBILITY_UNKNOWN)	&& diffInDays < 14) {
						order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_IN_QUEUE, UnlockUtils.getSubStatusForFallout(unlockContext, "iap")));
						unlockContext.put("LOSGSTATUS",	CommonConstants.LOSG_STATUS_IN_QUEUE);
						if(unlockContext.get("Make")!=null)
						UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_FALSE);
						UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_FALSE);
						UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_BRE_UNKNW);
						unlockContext.put("noteText",  CommonConstants.FALLOUT_INFO_BRE_UNKNW);
						 UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_BRE_PERIOD , CommonConstants.VALUE_UNKNOWN);
						execution.setVariableLocal(CommonConstants.ERRORS,UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext, "iap"), CommonConstants.FALLOUT_INFO_BRE_UNKNW));
						execution.setVariableLocal(CommonConstants.ORDERTASKS,	UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
						logger.info("Eligibility is unknown and user is in bre period");
					} else {
		
						if (deviceEligibility.equalsIgnoreCase(CommonConstants.ELIGIBLE)) {
		
							order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(	order, CommonConstants.LOSG_STATUS_APPROVED,CommonConstants.LOSG_SUB_STATUS_COMPLETED));
							unlockContext.put("LOSGSTATUS",	CommonConstants.LOSG_STATUS_APPROVED);
		
						/*	UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
							UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
							UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_FALSE);*/
		
							if (subscriberStatus.equalsIgnoreCase("A")) {
								
								 UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_DEVICE_LINKED_TO_ACCOUNT , CommonConstants.VALUE_YES);
							} else {
								
								 UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_DEVICE_LINKED_TO_ACCOUNT , CommonConstants.VALUE_NO);
							}
							
						} else if (deviceEligibility.equalsIgnoreCase(CommonConstants.ELIGIBILITY_UNKNOWN)	&& subscriberStatus.equalsIgnoreCase("A")) {
							
							 UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_DEVICE_LINKED_TO_ACCOUNT , CommonConstants.VALUE_YES);
							validateSubscribersContract(order, unlockContext,subscriberNumberList, firstUsageDate, contractEndDate, startDate, term, subscriberEqforCTnStatus,contract, enterpriseType, attNextSubscriber, execution);
		
						} else {
							order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(	order, CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"iap")));
							unlockContext.put("LOSGSTATUS",	CommonConstants.LOSG_STATUS_IN_QUEUE);
							if(unlockContext.get("Make")!=null)
							UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
							UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,	CommonConstants.VALUE_FALSE);
							UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_FALSE);
							UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_AFTER_IDUE);
							 UnlockUtils.createAutomationSummary(order, CommonConstants.SUBSCRIBER_VALIDATION_TYPE, CommonConstants.CODE_SERVICE_COMMITMENT_MET , CommonConstants.VALUE_UNKNOWN);
							execution.setVariableLocal(CommonConstants.ERRORS,	UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,	"iap"),CommonConstants.FALLOUT_INFO_AFTER_IDUE));
							execution.setVariableLocal(CommonConstants.ORDERTASKS,	UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
							logger.info("Service commintment unknown");
						}
					}
		
				} else {
		
					String newDate = sortedDates.get(sortedDates.size() - 1);
					String oldDate = sortedDates.get(0);
		
					String ctn = sortedCTNs.get(sortedDates.size() - 1);
		
					customerTypesIDDbyIMEI(order, unlockContext,requestCTN, subscriberEqforCTnStatus, statusDate, ctn, deviceEligibility, oldDate, newDate,execution);
				}
			}
		}

		execution.setVariableLocal(CommonConstants.ORDER, Variables.objectValue(order).
				serializationDataFormat(Variables.SerializationDataFormats.JSON).create());
	}

	@SuppressWarnings({ "null" })
	private void validateSubscribersContract(Map<String, Object> order,	Map<String, String> unlockContext, List<String> subscriberNumberList,String firstUsageDate, String contractEndDate,
			String contractStartdate, String term, String subscriberStatus,String contract, String enterpriseType, String attNextSubscriber, DelegateExecution execution) throws Exception {

		Date calculatedContractEndDate = new Date();
		Date currentDate = new Date();
		currentDate = format.parse(format.format(currentDate));

		int month = (int)  Math.round(Double.parseDouble(term));
		if (contractEndDate != null && !contractEndDate.isEmpty()) {
			Calendar calender = Calendar.getInstance();			
				calender.setTime(format.parse(contractEndDate));
				calender.add(Calendar.MONTH, month); // number of months to add contractEndDate
				contractEndDate = format.format(calender.getTime());
				calculatedContractEndDate = format.parse(contractEndDate);
		
		}

		long firstUsageDateLong =0 ;
		if (firstUsageDate != null && !firstUsageDate.isEmpty()) {
			firstUsageDateLong = format.parse(firstUsageDate).getTime();
		}

		int diffInDays = (int) ((currentDate.getTime() - firstUsageDateLong) / (1000 * 60 * 60 * 24));

		int floorEpr =0;
		if (CommonConstants.ConvertToMonth > month) {
			floorEpr = (diffInDays / (CommonConstants.ConvertToMonth) - CommonConstants.TermDiff);
		} else {
			floorEpr = (diffInDays / (month) - CommonConstants.TermDiff);
		}

		if (contract == null || contract.isEmpty()) {
			order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_APPROVED,CommonConstants.LOSG_SUB_STATUS_COMPLETED));
			unlockContext.put("LOSGSTATUS",	CommonConstants.LOSG_STATUS_APPROVED);
			/*if(unlockContext.get("Make")!=null)
			UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
			UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_FALSE);*/
			 UnlockUtils.createAutomationSummary(order, CommonConstants.SUBSCRIBER_VALIDATION_TYPE, CommonConstants.CODE_SERVICE_COMMITMENT_MET , CommonConstants.VALUE_YES);
		} else if (calculatedContractEndDate.compareTo(currentDate) < 0) {
			UnlockUtils.createAutomationSummary(order, CommonConstants.SUBSCRIBER_VALIDATION_TYPE, CommonConstants.CODE_SERVICE_COMMITMENT_MET , CommonConstants.VALUE_YES);
			if (subscriberNumberList.size() > 1) {

				// floor epr
				if (floorEpr > 0) {
					order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_APPROVED,	CommonConstants.LOSG_SUB_STATUS_COMPLETED));
					unlockContext.put("LOSGSTATUS",	CommonConstants.LOSG_STATUS_APPROVED);
					/*if(unlockContext.get("Make")!=null)
					UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_FALSE);*/
					 
				} else {
					order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"iap")));
					unlockContext.put("LOSGSTATUS",	CommonConstants.LOSG_STATUS_IN_QUEUE);
					if(unlockContext.get("Make")!=null)
					UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_FALSE);
					UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_FALSE);
					 UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_FIRST_USE_DATE);

					execution.setVariableLocal(CommonConstants.ERRORS,	UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"iap"), CommonConstants.FALLOUT_INFO_FIRST_USE_DATE));
					execution.setVariableLocal(CommonConstants.ORDERTASKS,UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));

				}
			} else {
				order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_APPROVED,CommonConstants.LOSG_SUB_STATUS_COMPLETED));
				unlockContext.put("LOSGSTATUS",	CommonConstants.LOSG_STATUS_APPROVED);
				/*if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_FALSE);*/
			}

		} else if (subscriberStatus.equalsIgnoreCase("A")) {
			UnlockUtils.createAutomationSummary(order, CommonConstants.SUBSCRIBER_VALIDATION_TYPE, CommonConstants.CODE_SERVICE_COMMITMENT_MET , CommonConstants.VALUE_NO);
			if (subscriberNumberList.size() > 1) {

				if (floorEpr > 0) {
					order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_APPROVED,	CommonConstants.LOSG_SUB_STATUS_COMPLETED));
					unlockContext.put("LOSGSTATUS",CommonConstants.LOSG_STATUS_APPROVED);
				/*	if(unlockContext.get("Make")!=null)
					UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
					UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_FALSE);*/
				} else {
					order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order, CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext,"iap")));
					unlockContext.put("LOSGSTATUS",CommonConstants.LOSG_STATUS_IN_QUEUE);
					if(unlockContext.get("Make")!=null)
					UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
					UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_FALSE);
					UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_FALSE);
					 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_FIRST_USE_DATE);

					execution.setVariableLocal(CommonConstants.ERRORS,	UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext,"iap"), CommonConstants.FALLOUT_INFO_FIRST_USE_DATE));
					execution.setVariableLocal(CommonConstants.ORDERTASKS,	UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));

				}
			} else
				contractDateCheck(order, unlockContext, subscriberNumberList,
						firstUsageDate, contractStartdate, enterpriseType, attNextSubscriber,execution);
		} else {
			order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext, "iap")));
			unlockContext.put("LOSGSTATUS",	CommonConstants.LOSG_STATUS_IN_QUEUE);
			UnlockUtils.createAutomationSummary(order, CommonConstants.SUBSCRIBER_VALIDATION_TYPE, CommonConstants.CODE_SERVICE_COMMITMENT_MET , CommonConstants.VALUE_NO);
			if(unlockContext.get("Make")!=null)
			UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_FALSE);
			UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_FALSE);
			UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_SUBSCRIBER_INACTIVE);
			
			execution.setVariableLocal(CommonConstants.ERRORS,UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext, "iap"), CommonConstants.FALLOUT_INFO_SUBSCRIBER_INACTIVE));
			execution.setVariableLocal(CommonConstants.ORDERTASKS,	UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));

		}

	}

	private void contractDateCheck(Map<String, Object> order,Map<String, String> unlockContext, List<String> subscriberNumberList,String firstUsageDate, String contractStartdate,
			String enterpriseType,String attNextSubscriber,DelegateExecution execution) throws Exception {

		long contractStartDateLong = format.parse(contractStartdate).getTime();

		long firstUsageDateLong = format.parse(firstUsageDate).getTime();

		int diffInDays = (int) ((contractStartDateLong - firstUsageDateLong) / (1000 * 60 * 60 * 24));
		
		if (diffInDays > CommonConstants.DiffContractStartFirstUseDate) {

			order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_APPROVED,CommonConstants.LOSG_SUB_STATUS_COMPLETED));
			unlockContext.put("LOSGSTATUS",	CommonConstants.LOSG_STATUS_APPROVED);
			/*if(unlockContext.get("Make")!=null)
			UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
			UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_FALSE);*/

		} else if (enterpriseType.equals("CRU")) {
			order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,UnlockUtils.getSubStatusForFallout(unlockContext, "iap")));
			unlockContext.put("LOSGSTATUS",	CommonConstants.LOSG_STATUS_IN_QUEUE);
			if(unlockContext.get("Make")!=null)
			UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
			UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_FALSE);
			UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_FALSE);
			UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_AFTER_IDUE);

			execution.setVariableLocal(CommonConstants.ERRORS,UnlockUtils.getErrors(UnlockUtils.getSubStatusForFallout(unlockContext, "iap"), CommonConstants.FALLOUT_INFO_AFTER_IDUE));
			execution.setVariableLocal(CommonConstants.ORDERTASKS,UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));

		} else {

			if (attNextSubscriber.equalsIgnoreCase(CommonConstants.COMMITMENT_REASONCODE)) {

				order.put("Groups",	UnlockUtils.setLOSGStatusSubStatus(	order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_ATT_NEXT_SERVICE_COMMITMENT_NOT_MET));
				unlockContext.put("LOSGSTATUS",CommonConstants.LOSG_STATUS_DENIED);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_REASON,CommonConstants.CANCEL_REASON_ATT_NEXT_SERVICE_COMMITMENT_NOT_MET);

			} else {
				order.put("Groups",	UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_SUBSIDY_SERVICE_COMMITMENT_NOT_MET));
				unlockContext.put("LOSGSTATUS",	CommonConstants.LOSG_STATUS_DENIED);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_REASON,CommonConstants.CANCEL_REASON_SUBSIDY_SERVICE_COMMITMENT_NOT_MET);

			}
		}

	}

	private void customerTypesIDDbyIMEI(Map<String, Object> order,Map<String, String> unlockContext, String requestCTN, String subscriberStatus, String subscriberStatusDate,
			String ctn, String eligibilityStatus, String oldDate, String newDate,DelegateExecution execution) {
		
		try {
			Calendar calender = Calendar.getInstance();
			calender.setTime(format.parse(subscriberStatusDate));
			calender.add(Calendar.MONTH, 6); // number of months to add
												// subscriberStatusDate
			subscriberStatusDate = format.format(calender.getTime());
			Date subscriberDate = format.parse(subscriberStatusDate);

			calender.setTime(format.parse(oldDate));
			calender.add(Calendar.MONTH, 6); // number of months to add to
												// oldestDate
			oldDate = format.format(calender.getTime());
			Date old = format.parse(oldDate);

			Date currentDate = new Date();
			currentDate = format.parse(format.format(currentDate));

			if (eligibilityStatus.equalsIgnoreCase(CommonConstants.ELIGIBLE) && subscriberStatus.equalsIgnoreCase("A") && (subscriberDate.compareTo(currentDate) < 0)
					&& (old.compareTo(currentDate) < 0) && ctn.equalsIgnoreCase(requestCTN)) {

				order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_APPROVED,CommonConstants.LOSG_SUB_STATUS_COMPLETED));
				unlockContext.put("LOSGSTATUS",CommonConstants.LOSG_STATUS_APPROVED);
				/*if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_FALSE);*/
				 UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_DEVICE_LINKED_DLC , CommonConstants.VALUE_YES);
				 UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_NETWORK_ACTIVITY , CommonConstants.VALUE_YES);
				 UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_GOPHONE_ACTIVE , CommonConstants.VALUE_YES);
			} else if (eligibilityStatus
					.equalsIgnoreCase(CommonConstants.ELIGIBILITY_UNKNOWN)	&& subscriberStatus.equalsIgnoreCase("A")
					&& (subscriberDate.compareTo(currentDate) < 0)
					&& (old.compareTo(currentDate) < 0) && ctn.equalsIgnoreCase(requestCTN)) {

				// set IN_QUEUE/GOPHONE_VERIFIED

				order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_IN_QUEUE,CommonConstants.LOSG_SUBSTATUS_GOPHONE_VERIFIED));
				unlockContext.put("LOSGSTATUS",CommonConstants.LOSG_STATUS_IN_QUEUE);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_FALSE);
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_FALSE);
				UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.FALLOUT_INFO, CommonConstants.FALLOUT_INFO_GOPHONE_6MONTHS_UNKN);
				execution.setVariableLocal(CommonConstants.ERRORS,	UnlockUtils.getErrors(CommonConstants.LOSG_SUBSTATUS_GOPHONE_VERIFIED,CommonConstants.FALLOUT_INFO_GOPHONE_6MONTHS_UNKN));
				execution.setVariableLocal(CommonConstants.ORDERTASKS,	UnlockUtils.getOrderTasks(order,CommonConstants.APPLICATION_NAME_ORDERTASK));
				 UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_DEVICE_LINKED_DLC , CommonConstants.VALUE_YES);
				 UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_NETWORK_ACTIVITY , CommonConstants.VALUE_YES);
				 UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_GOPHONE_ACTIVE , CommonConstants.VALUE_YES);
			} else if (!ctn.equalsIgnoreCase(requestCTN)) {

				// set DENIED/DATA_NOT_FOUND
				order.put("Groups", UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_DATA_NOT_FOUND));
				unlockContext.put("LOSGSTATUS",	CommonConstants.LOSG_STATUS_DENIED);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_TRUE);
				 UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_DEVICE_LINKED_DLC , CommonConstants.VALUE_NO);
				 UnlockUtils.updatedditionalDetailsForGroup(order, CommonConstants.CANCELED_REASON,CommonConstants.CANCEL_REASON_DATA_NOT_FOUND);

			} else if (old.compareTo(currentDate) > 0) {

				// set DENIED/GOPHONE_COMMITMENT_6_MONTHS

				order.put("Groups",	UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_GOPHONE_COMMITMENT_6_MONTHS));
				unlockContext.put("LOSGSTATUS",	CommonConstants.LOSG_STATUS_DENIED);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(	order,CommonConstants.CANCELED_REASON,	CommonConstants.CANCEL_REASON_GOPHONE_6MONTHS_COMMITMENT);
				UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_DEVICE_LINKED_DLC , CommonConstants.VALUE_YES);
				UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_NETWORK_ACTIVITY , CommonConstants.VALUE_NO);
			} else if ((!subscriberStatus.equalsIgnoreCase("A")
					|| (subscriberDate.compareTo(currentDate) > 0) || (subscriberStatus == null || subscriberStatus.isEmpty()))) {

				// set DENIED/GOPHONE_COMMITMENT_6_MONTHS

				order.put("Groups",	UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_GOPHONE_COMMITMENT_6_MONTHS));
				unlockContext.put("LOSGSTATUS",CommonConstants.LOSG_STATUS_DENIED);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(	order,	CommonConstants.CANCELED_REASON,CommonConstants.CANCEL_REASON_GOPHONE_6MONTHS_COMMITMENT);
				UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_DEVICE_LINKED_DLC , CommonConstants.VALUE_YES);
				UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_NETWORK_ACTIVITY , CommonConstants.VALUE_YES);
				UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_GOPHONE_ACTIVE , CommonConstants.VALUE_NO);

			} else {
				

				order.put("Groups",	UnlockUtils.setLOSGStatusSubStatus(order,CommonConstants.LOSG_STATUS_DENIED,CommonConstants.LOSG_SUB_STATUS_GOPHONE_COMMITMENT_6_MONTHS));
				unlockContext.put("LOSGSTATUS",CommonConstants.LOSG_STATUS_DENIED);
				if(unlockContext.get("Make")!=null)
				UnlockUtils.createAutomationSummary(order, null,CommonConstants.PHONE_TYPE, UnlockUtils.getPhoneType(unlockContext.get("Make").toString()));
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.AUTOMATION_FLAG,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(order,CommonConstants.CANCELED_BY_AUTOMATION,CommonConstants.VALUE_TRUE);
				UnlockUtils.updatedditionalDetailsForGroup(	order,	CommonConstants.CANCELED_REASON,CommonConstants.CANCEL_REASON_GOPHONE_6MONTHS_COMMITMENT);
				UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_DEVICE_LINKED_DLC , CommonConstants.VALUE_YES);
				UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_NETWORK_ACTIVITY , CommonConstants.VALUE_YES);
				UnlockUtils.createAutomationSummary(order, CommonConstants.DEVICE_VALIDATION_TYPE, CommonConstants.CODE_GOPHONE_ACTIVE , CommonConstants.VALUE_NO);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private Document xmlParsing(String response) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = null;
		try {
			builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new ByteArrayInputStream(response.getBytes()));
			   return doc;
        } catch (Exception e) {  
            e.printStackTrace();  
        } 
        return null;  
	}
	
	
	  public static List<Node> asList(NodeList n) {
		    return n.getLength()==0?
		      Collections.<Node>emptyList(): new NodeListWrapper(n);
		  }
		  static final class NodeListWrapper extends AbstractList<Node>
		  implements RandomAccess {
		    private final NodeList list;
		    NodeListWrapper(NodeList l) {
		      list=l;
		    }
		    public Node get(int index) {
		      return list.item(index);
		    }
		    public int size() {
		      return list.getLength();
		    }
		  }
	
}
