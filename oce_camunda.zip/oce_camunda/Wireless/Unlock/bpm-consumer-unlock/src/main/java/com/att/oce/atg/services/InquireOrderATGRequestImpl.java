package com.att.oce.atg.services;

import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

import com.att.ajsc.beans.PropertiesMapBean;
import com.att.ajsc.bpm_consumer_unlock.util.UnlockUtils;

public class InquireOrderATGRequestImpl implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		
		Map<String,Object> order = (Map<String, Object>) execution.getVariable("order");
		String searchString =  UnlockUtils.getSearchString(
					((Map<?,?>)order.get("OrderSource")).get("Channel").toString(), 
					((Map<?,?>)order.get("OrderSource")).get("Application").toString(), 
					order.get("CustomerOrderNumber").toString(), 
					order.get("RequestId").toString(), 
					Integer.parseInt(PropertiesMapBean.getProperty("consumer-unlock-app.properties", "inquireorder.search.duration")));
		
		String fields = "{\"orderDetails\":[\"order\"],\"order\":[\"customerOrderNumber\",\"acceptedDate\",\"orderStatus\",\"lineItems\",\"groups\"], \"lineItems\":[\"additionalDetails\"], \"groups\":[\"groupCharItem\"], \"groupCharItem\":[\"wirelessLOSChar\",\"losGStatus\"]}";

		String paramString = "searchString=" + searchString + "&fields=" + fields;
		System.out.println("Final Param String : " + paramString);
		execution.setVariable("paramString", paramString);
		
	}
}
