package com.att.route.test;

import java.net.InetSocketAddress;
import java.net.Proxy;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

public class RestUtil {
	
	private static SimpleClientHttpRequestFactory clientHttpRequestFactory;
	private static Proxy proxy;
	private static RestTemplate restTemplate;

	static {
		clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
		restTemplate = new RestTemplate(clientHttpRequestFactory);
		proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("one.proxy.att.com", 8080));
	}
	
	public static String callRestService(String paylaod, String url, boolean useProxy) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<String>(paylaod, headers);
		
		if(useProxy) {
			clientHttpRequestFactory.setProxy(proxy);
		}

		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);

		return response.getBody();
	}

}
