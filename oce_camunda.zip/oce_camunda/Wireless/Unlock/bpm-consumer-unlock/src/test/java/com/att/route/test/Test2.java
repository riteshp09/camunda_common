package com.att.route.test;

public class Test2 {
	
	public static void main(String s[]) {
		String clue = "some";
		
		char[] ch = clue.toCharArray();
		System.out.println(ch);
		
		int[] c = new int[]{83,85,66,87,65,89};
		
		
		for(int i =0; i<c.length; i++)
        {
            System.out.println( i + ". " + c[i]);
        }

	}

}
