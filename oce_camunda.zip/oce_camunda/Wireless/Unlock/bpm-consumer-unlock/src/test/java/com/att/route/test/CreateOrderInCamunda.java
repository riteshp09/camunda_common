package com.att.route.test;

import java.io.IOException;
import java.util.GregorianCalendar;

import com.att.oce.bpm.common.FileUtility;

public class CreateOrderInCamunda {
	
	private static String PRE_PROD = "zlt07889";
	private static String D4B = "zld01123";
	private static String T1 = "zltv9992";
	private static String S2 = "zlp03564";
	private static String T4B = "zlt10401";
	private static String T2 = "zlt10399";
	
	boolean isLocal = true;
	
	public String createOrder() throws IOException {
		String result = "";
		String orderPayload = "";
		synchronized (this) {
			final String idRef = String.valueOf(GregorianCalendar.getInstance().getTimeInMillis());
			orderPayload = FileUtility.getInstance().getFileContent("order.xml").replace("order_id", "PT"+idRef);
		}
		
		String baseUrl = (isLocal) ? "http://localhost:8085" : "http://" + T4B + ".vci.att.com:8080";
		String suffixUrl = "/services/identity/UnlockParentProcess";
		
		//call camunda web service to create order.
		RestUtil.callRestService(orderPayload, baseUrl + suffixUrl, false);
		
		return result;
		
	}

}
