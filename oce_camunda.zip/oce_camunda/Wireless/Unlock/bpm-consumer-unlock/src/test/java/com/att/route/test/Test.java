package com.att.route.test;

import java.io.IOException;

import javax.xml.bind.JAXBException;
import javax.xml.transform.dom.DOMSource;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.att.oce.bpm.common.FileUtility;
import com.att.oce.bpm.common.JAXBUtil;
import com.csi.v112.container.inquireAccountProfileResponse.InquireAccountProfileResponseInfo;

public class Test {

	
	public void te() throws SAXException, IOException, JAXBException
	{

		Document iapresponseDocument = JAXBUtil.getXMLDocument(FileUtility.getInstance().getFileContent("iap_response.xml"));
		Node iapReqNode = JAXBUtil.getDocumentElement(iapresponseDocument, "http://csi.cingular.com/CSI/Namespaces/Container/Public/InquireAccountProfileResponse.xsd", "InquireAccountProfileResponse");
		
		InquireAccountProfileResponseInfo iapRespponseInfo = JAXBUtil.unmarshalObj(new DOMSource(iapReqNode), InquireAccountProfileResponseInfo.class);
		
		
		String pastDue  = String.valueOf(iapRespponseInfo.getAccount().getAccountBilling().getBalance().getTotalAmountPastDue()); 
		System.out.println(iapRespponseInfo.getAccount().getBillingMarket().getBillingMarket());
		System.out.println(pastDue);
	
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Test t=new Test();
//		try {
//			t.te();
			
			String clue = "some";
			
			char[] ch = clue.toCharArray();
			System.out.println(ch);
			
		/*} catch (SAXException | IOException | JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

}
