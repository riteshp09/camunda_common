### About

This is a copy of https://github.com/camunda/camunda-bpm-camel/tree/master/camunda-bpm-camel-spring and https://github.com/camunda/camunda-bpm-camel/tree/master/camunda-bpm-camel-common
It is customized to for use with camunda

## camunda BPM --> Apache Camel

### Calling a Camel Endpoint (Service)

Use the following expression in a ServiceTask to send all the process instance variables as a map to Camel endpoint:

```
${camel.sendTo('<camel endpoint>')}
```

Alternatively you can specify which process instance variables you want to send to Camel with:

```
${camel.sendTo('<camel endpoint>', '<list of process variables>')}
```

Also you can include additional header to be included in the camel context to indicate api name, endpoint to use etc
It follows simple json string.

```
${camel.sendTo('<camel endpoint>', '<list of process variables>','{key:value,key:value}')}
```

Additionally you can specify a correlationKey to send to Camel. It can be used to correlate a response message. The route for the response must contain a parameter correlationKeyName with the name of the process variable which is used for correlation:

```
${camel.sendTo('<camel endpoint>', '<list of process variables>', 'correlationKey')}
```

The properties `CamundaBpmProcessInstanceId`, `CamundaBpmBusinessKey` (if available) and `CamundaBpmCorrelationKey` (if set) will be available to any downstream processesors in the Camel route.



## Apache Camel --> camunda BPM
The following use cases are supported by the camunda BPM Camel component (see [Camel Components](http://camel.apache.org/components.html)).

### `camunda-bpm://start` Start a process instance

A direct consumer to start process instances.

The following URI parameters are supported:

Parameter | Description
--- | ---
`processDefinitionKey` | the [process definition key](http://docs.camunda.org/api-references/java/org/camunda/bpm/engine/RuntimeService.html) of the process to start an instance of
`copyBodyAsVariable` | name of the process variable to which the body of the Camel should be copied. Default is `camelBody`

If the Camel message body is a map, then all the keys will be copied as process variables of the started instance.
Additionally all headers will be copied in to the executionContext for the process. In case, correlating a message, it will merge with existing execution context.
This will ignore any header starting with 'Camel'.
All properties will be copied as process variables.
This will ignore any property starting with 'Camel'.

If the property `CamundaBpmBusinessKey` is available on the incoming message then it will be associated with the started process instance and can be later followed to look it up.

The properties `CamundaBpmProcessInstanceId`, `CamundaBpmProcessDefinitionId` and `CamundaBpmBusinessKey` are available to the downstream processors in the Camel route as Camel exchange properties.

Example: `camunda-bpm://start?processDefinitionKey=startProcessFromRoute&copyBodyAsVariable=var1`

Starts a process instance of the process definition `startProcessFromRoute` with the body of the message as a map with process variable `var1` as a key.
This will return the process instance Id as output.

### `camunda-bpm://task` Send a task related action to the process engine

A direct consumer to send a task related action to the process engine.

The following URI parameters are supported:

Parameter | Description
--- | ---
`action`| the name of action. For now only complete is supported
`copyBodyAsVariable` | name of the process variable to which the body of the Camel should be copied. 
`taskId`| the Id of the task on which the action needs to be applied

If there is a header with the name `CamundaTaskId` then the value is the header overrides the value in the URI. Similarly for the action also if there is a header `CamundaTaskAction` it will override the action.

if `copyBodyAsVariable` is provided then the body will be copied onto the process variable.
The scope of the variable will always be the process.

### `camunda-bpm://message` Send a message to the process engine

A direct consumer to send a message to the process engine. This can either:
* trigger the start of a new process instance, see [Start Message Event](http://docs.camunda.org/latest/api-references/bpmn20/#events-message-events)
* send a message to a waiting process instances. The process instance might either wait in a [ReceiveTask](http://docs.camunda.org/latest/api-references/bpmn20/#tasks-receive-task) or an [Intermediate Message Event](http://docs.camunda.org/latest/api-references/bpmn20/#events-message-events).

The following URI parameters are supported:

Parameter | Description
--- | ---
`messageName`| the name of the message in the BPMN 2.0 XML (mandatory if you correlate to a Intermediate Message Event or a ReceiveTask with a message reference)
`activityId`| the id of the ReceiveTask in the BPMN 2.0 XML (mandatory if the process instance waits in a ReceiveTask without a message reference - considered as deprecated)
`correlationKeyName`| the name of a process variable to which the property `CamundaBpmCorrelationKey` will be correlated
`copyBodyAsVariable` | name of the process variable to which the body of the Camel should be copied. Default is `camelBody`.
`processDefinitionKey` | the [process definition key](http://docs.camunda.org/api-references/java/org/camunda/bpm/engine/RuntimeService.html) of the process definition this operation is related to. In case of working without a message this can help to make correlation unique, it is always an optional parameter.

Note that either one of the properties `CamundaBpmProcessInstanceId`, `CamundaBpmBusinessKey` or `CamundaBpmCorrelationKey` need to be present in the message if it is correlated to a waiting process instance. Usage of `CamundaBpmCorrelationKey` and / or `CamundaBpmBusinessKey` is preferred.

## Apache Camel --> Apache Velocity

ONLY DEMOSTRATION PURPOSE

Check the Unit test case VelocityTemplateTest, to see the usage of how to call velocity from apache camel.


# Examples
Check the existing unit tests for guidance on how to use the current supported features in your projects
