package com.att.oce.bpm.beans.services;

import static com.att.oce.bpm.camel.component.CamundaBpmConstants.CAMUNDA_BPM_BUSINESS_KEY;
import static com.att.oce.bpm.camel.component.CamundaBpmConstants.CAMUNDA_BPM_CORRELATION_KEY;
import static com.att.oce.bpm.camel.component.CamundaBpmConstants.CAMUNDA_BPM_PROCESS_INSTANCE_ID;
import static com.att.oce.bpm.camel.component.CamundaBpmConstants.CAMUNDA_PROCESS_EXECUTION_CONTEXT;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.RoutesBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.impl.context.Context;
import org.camunda.bpm.engine.impl.pvm.delegate.ActivityExecution;
import org.camunda.bpm.engine.runtime.Job;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.att.oce.bpm.camel.common.CamelService;
import com.att.oce.bpm.error.APIFailedException;
import com.att.oce.bpm.error.OceErrorHandler;
import com.att.oce.bpm.error.RetryException;

@Service("camel")
public class CamelServiceImpl implements CamelService {
	
	final Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	OceErrorHandler errorhandler;

	@Autowired
	ProcessEngine processEngine;
	
	@Autowired
	CamelContext camelContext;
	
	@PostConstruct
	public void initRoutes(){
		log.debug("initRoutes");
 		Map<String,RoutesBuilder> rb = camelContext.getRegistry().findByTypeWithName(RoutesBuilder.class);
 		if (rb != null){
 			for (String k : rb.keySet()){
 				try {
 					log.debug(""+rb.get(k).getClass());
 					rb.get(k).addRoutesToCamelContext(camelContext);
				} catch (Exception e) {
					e.printStackTrace();
				}
 			}
 		}
	}

	public Object sendTo(String endpointUri) throws Exception {
		log.debug("sendTo(String endpointUri)");
		return sendTo(endpointUri, null, null);
	}

	public Object sendTo(String endpointUri, String processVariables) throws Exception {
		log.debug("sendTo(String endpointUri, String processVariables)");
		return sendTo(endpointUri, processVariables, null);
	}

	public Object sendTo(String endpointUri, String processVariables, String correlationId) throws Exception {
		Collection<String> vars;
		if (processVariables == null) {
			ActivityExecution execution = Context.getBpmnExecutionContext().getExecution();
			vars = execution.getVariableNames();
		} else if ("".equals(processVariables)) {
			vars = Collections.emptyList();
		} else {
			vars = Arrays.asList(processVariables.split("\\s*,\\s*"));
		}
		return sendToInternal(endpointUri, vars, correlationId);
	}

	private Object sendToInternal(String endpointUri, Collection<String> variables, String correlationKey) throws Exception
			 {
		try {
		log.debug("Calling "+endpointUri);
		
		ArrayList<String> headers = new ArrayList<String>();

		ActivityExecution execution = (ActivityExecution) Context.getBpmnExecutionContext().getExecution();
		Map<String, Object> variablesToSend = new HashMap<String, Object>();
		for (String var : variables) {
			if (execution.hasVariable(var)) {
				variablesToSend.put(var, execution.getVariable(var));
			} else {
				headers.add(var);
			}
		}
		
		log.debug("Sending process variables '{}' as a map to Camel endpoint '{}'", variablesToSend, endpointUri);
		ProducerTemplate producerTemplate = camelContext.createProducerTemplate();
		String businessKey = execution.getBusinessKey();

		Exchange exchange = new DefaultExchange(camelContext);
		if (execution.hasVariable(CAMUNDA_PROCESS_EXECUTION_CONTEXT)){
			exchange.setProperty(CAMUNDA_PROCESS_EXECUTION_CONTEXT, execution.getVariable(CAMUNDA_PROCESS_EXECUTION_CONTEXT));
		}
		exchange.setProperty(CAMUNDA_BPM_PROCESS_INSTANCE_ID, execution.getProcessInstanceId());
		if (businessKey != null) {
			exchange.setProperty(CAMUNDA_BPM_BUSINESS_KEY, businessKey);
		}
		if (correlationKey != null) {
			exchange.setProperty(CAMUNDA_BPM_CORRELATION_KEY, correlationKey);
		}
		exchange.getIn().setBody(variablesToSend);

		int i = 1;
		for (String header : headers) {
			exchange.getIn().getHeaders().put("param" + i, header);
			i++;
		}

		exchange.setPattern(ExchangePattern.InOut);
		Exchange send = producerTemplate.send(endpointUri, exchange);
		log.debug("List of Activity Id in PID : " + processEngine.getManagementService().createJobQuery().processInstanceId(execution.getProcessInstanceId()).active().list());
		log.debug("Execution of Current Activity Id : " + execution.getCurrentActivityId());
		Job j = processEngine.getManagementService().createJobQuery().processInstanceId(execution.getProcessInstanceId()).activityId(execution.getCurrentActivityId()).active().singleResult();
		
		if (j != null){
			log.debug("JOB ID: "+j.getId()+" , Retries: "+j.getRetries());
		} else {
			log.debug("JOB IS NULL. Query: "+ execution.getProcessInstanceId()+","+Context.getBpmnExecutionContext().getExecution().getId());
		}
		
		if (exchange.getException() != null){
			log.error(""+exchange.getException());
			if (exchange.getException() instanceof APIFailedException ){
				APIFailedException apie = (APIFailedException)exchange.getException();
				Map<String,Object> errorContext = errorhandler.handleError(apie);
				log.debug("ErrorContext : " + errorContext);
				
				if (errorContext != null && ((errorContext.containsKey("numOfRetries") 
						&& ((Integer) errorContext.get("numOfRetries")) == 0 || errorContext.get("numOfRetries") == null)) 
						&& ((errorContext.get("interval") == null) || (errorContext.get("interval").toString().equals("0")))) {
					errorContext.put("retry", false);
				}
				
				log.debug("ErrorContext : " + errorContext);
				if (errorContext != null){
					if (((Boolean)errorContext.get("retry")) && ((j == null) || (j.getRetries() > 1 ))){
						log.debug("ERROR RetryException");
						String interval_value = errorContext.get("interval").toString();
						
						if(interval_value.contains(",") || errorContext.get("numOfRetries") == null){
							errorContext.put("config_retry",true);
							Integer interval = 0;
							String[] config_retry_interval = null;
							config_retry_interval = interval_value.split(",");
							errorContext.put("config_retry_interval", config_retry_interval);
							log.debug("config_retry_interval : " + errorContext.get("config_retry_interval"));
							
							if(j.getExceptionMessage() == null){
								interval=Integer.valueOf(config_retry_interval[0]);
							}else{
								if(config_retry_interval.length >= j.getRetries()){
									interval=Integer.valueOf(config_retry_interval[config_retry_interval.length - j.getRetries() + 1]);
								}
							}
							errorContext.put("numOfRetries", config_retry_interval.length);
							errorContext.put("interval", interval);
						}else{
							if (errorContext.get("interval") instanceof String ){
								errorContext.put("interval", Integer.parseInt((String) errorContext.get("interval")));
							}else{
								errorContext.put("interval", errorContext.get("interval"));	
							}
							
						}
						throw new RetryException((Integer)errorContext.get("numOfRetries"),(Integer)errorContext.get("interval"),errorContext);
					} 
					else {
						log.debug("ERROR BpmnError");
						throw new BpmnError(apie.getCode(),apie.getCodeDescription());
					}
				} 
				else { 
					throw new BpmnError(apie.getCode(),apie.getCodeDescription());
				}
			} 
			else {
				throw exchange.getException();
			}
			
		}
			
		Object r = send.getOut().getBody();
		if (r instanceof String) {
			r = new StringBuilder().append(r);
		}
		
		if (exchange.getProperties().containsKey(CAMUNDA_PROCESS_EXECUTION_CONTEXT)){
			execution.setVariable(CAMUNDA_PROCESS_EXECUTION_CONTEXT, exchange.getProperty(CAMUNDA_PROCESS_EXECUTION_CONTEXT));
		}

		return r;
		} catch(Exception e){
			log.debug("ERROR IN CAMEL ROUTE "+endpointUri+ ", Exception: ["+e.getClass()+"] "+e.getMessage());
			throw e;
		}
	}
	
}
