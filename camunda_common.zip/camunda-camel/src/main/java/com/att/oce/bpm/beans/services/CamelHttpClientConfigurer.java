package com.att.oce.bpm.beans.services;

import org.apache.camel.component.http4.HttpClientConfigurer;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.stereotype.Component;

@Component
public class CamelHttpClientConfigurer implements HttpClientConfigurer {

@Override
public void configureHttpClient(HttpClientBuilder client) {
client.setMaxConnTotal(500);
}

}
