package com.att.oce.bpm.nf.transformations.test;

import java.util.ArrayList;
import java.util.Map;

import org.json.JSONException;
import org.junit.Test;

import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.bpm.nf.transformations.ATGCreateOrderTransformation;

public class ATGCreateOrderTransformationTest {

	
	@Test
	public void test_validateCancelledLosg()throws Exception{
		ATGCreateOrderTransformation atgCreate = new ATGCreateOrderTransformation();
		Map<String, Object> Order = null;
		try {
			Order = TestOrderBuilder.build("AddAccPreConditionFailure.json").getMapofMaps();
		} catch (JSONException e) {
			e.printStackTrace();
		}	
		ArrayList<String> groupIds = new ArrayList<String>();
		groupIds.add("GROUP_01");
		groupIds.add("GROUP_02");
		Object result = atgCreate.validateCancelledLosg(Order,groupIds);
		
		System.out.println("**************************result*************************"+result);
	}
}
