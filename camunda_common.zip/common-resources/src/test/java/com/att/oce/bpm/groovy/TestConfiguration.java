package com.att.oce.bpm.groovy;

import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.att.oce.beans.config.OceConfig;

@Configuration
public class TestConfiguration {
	
	@Bean
	public static DmnEngine dmnEngine() {
		// create default DMN engine configuration
		DmnEngineConfiguration configuration = DmnEngineConfiguration
		  .createDefaultDmnEngineConfiguration();

		// build a new DMN engine
		DmnEngine dmnEngine = configuration.buildEngine();
		return dmnEngine;
	}
	
	@Bean
	public static OceConfig oceConfig(){
		OceConfig oceConfig = new OceConfig();
		return oceConfig;
	}
}
