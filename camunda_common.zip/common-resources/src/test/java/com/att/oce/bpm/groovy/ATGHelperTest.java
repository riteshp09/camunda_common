package com.att.oce.bpm.groovy;

import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.json.XML;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.beans.config.APIResultConfig;
import com.att.oce.beans.config.OceConfig;
import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.bpm.common.TransformationService;
import com.att.oce.bpm.transformations.ATGHelper;
import com.att.oce.config.components.GlobalProperties;
import com.att.oce.config.components.URNResolver;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {OceConfig.class, GlobalProperties.class, 
								URNResolver.class,
								ATGHelper.class,
								TestConfiguration.class, APIResultConfig.class})
public class ATGHelperTest {

	static Logger log = LoggerFactory.getLogger(ATGHelperTest.class);
	@Autowired
	ATGHelper atgHelper;
	
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "./../../oce_framework/oce-resources/src/main/resources/");
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireless");
	} 
	
	@Test
	public void testConvertFtoNF() throws Exception{
		Map<String,Object> order = (Map<String,Object>)TestOrderBuilder.build("orderWithPGWithoutLOSG").getMapofMaps();
		String result = atgHelper.convertFToNF(order).toString();
		log.debug("After conversion >>>>>>>>>>>>>> :"+result);
		String oceXmlOrder = XML.toString(new JSONObject(result));
		log.debug("XML format >>>>>>>>>>>>>> :"+oceXmlOrder);
	}
	
	@Test
	public void testConvertFtoNFWithMap() throws Exception{
		Map<String,Object> order = (Map<String,Object>)TestOrderBuilder.build("SMB_HSIA_VOIP_OCERT").getMapofMaps();
		String result = atgHelper.convertFToNF(order).toString();
		log.debug("After conversion >>>>>>>>>>>>>> :"+result);
		String oceXmlOrder = XML.toString(new JSONObject(result));
		log.debug("XML format >>>>>>>>>>>>>> :"+oceXmlOrder);
	}
	
	@Test
	public void testConvertFtoNFWithAllElements() throws Exception{
		Map<String,Object> order = (Map<String,Object>)TestOrderBuilder.build("OrderWithAllElements").getMapofMaps();
		String result = atgHelper.convertFToNF(order).toString();
		log.debug("After conversion >>>>>>>>>>>>>> :"+result);
		String oceXmlOrder = XML.toString(new JSONObject(result));
		log.debug("XML format >>>>>>>>>>>>>> :"+oceXmlOrder);
	}
	
	@Test
	public void testLookUpForNF_uucpStatus() throws Exception{
		String result = atgHelper.getMapFandNF("uucpStatus",false).toString();
		log.debug("After conversion fro testLookUpForNF_uucpStatus>>>>>>>>>>>>>> :"+result);
		assertTrue(result.equals("UUCPStatus"));
	}
	
	@Test
	public void testLookUpForNF_salesChannelType() throws Exception{
		String result = atgHelper.getMapFandNF("salesChannelType",false).toString();
		log.debug("After conversion fro testLookUpForNF_salesChannelType>>>>>>>>>>>>>> :"+result);
		assertTrue(result.equals("salesChannelType"));
	}
	
	@Test
	public void testLookUpForNF_shipmentInfoUpdatedIndicator() throws Exception{
		String result = atgHelper.getMapFandNF("shipmentInfoUpdatedIndicator",false).toString();
		log.debug("After conversion fro testLookUpForNF_shipmentInfoUpdatedIndicator>>>>>>>>>>>>>> :"+result);
		assertTrue(result.equals("IsShipmentInfoUpdated"));
	}
	
	@Test
	public void testConvertFtoNFWithEncodedKeys() throws Exception{
		Map<String,Object> order = (Map<String,Object>)TestOrderBuilder.build("OrderWithQuotesInDOB").getMapofMaps();
		String result = atgHelper.convertFToNF(order).toString();
		log.debug("After conversion >>>>>>>>>>>>>> :"+result);
		String oceXmlOrder = XML.toString(new JSONObject(result));
		log.debug("XML format >>>>>>>>>>>>>> :"+oceXmlOrder);
	}
	
	@Test
	public void testLookUp() throws Exception{
		String result = atgHelper.getMapFandNF("realTimeCalendarIndicator",false).toString();
		log.debug("After conversion >>>>>>>>>>>>>> :"+result);
		assertTrue(result.equals("IsRealTimeCalendar"));
		
	}
	@Test
	public void testLookUp_sequence() throws Exception{
		String result = atgHelper.getMapFandNF("order/shippingDetails/shippingDetail/sequence",false).toString();
		log.debug("After conversion >>>>>>>>>>>>>> :"+result);
		assertTrue(result.equals("ShippingInfoSequence"));
		
	}
	@Test
	public void testEscapeUtil() throws Exception{
		String result = TransformationService.escapeHtml("49+1I\"9n");
		log.debug("After conversion >>>>>>>>>>>>>> :"+result);
	}
	
	@Test
	public void testConvertNFtoF() throws Exception{
		Map<String,Object> order = (Map<String,Object>)TestOrderBuilder.build("WUPG-Order").getMapofMaps();
		String result = atgHelper.convertNFToF(order).toString();
		log.debug("After conversion - NF-F >>>>>>>>>>>>>> :"+result);
	}
	@Test
	public void testLookUpForNF_sequence() throws Exception{
		String result = atgHelper.getMapFandNF("PaymentSequence",true).toString();
		log.debug("After conversion fro testLookUpForNF_sequence>>>>>>>>>>>>>> :"+result);
		assertTrue(result.equals("sequence"));
	}
	@Test
	public void testLookUpForNF_notinAXml() throws Exception{
		String result = (String) atgHelper.getMapFandNF("PaymentOrder",true);
		log.debug("After conversion >>>>>>>>>>>>>> :"+result);
		assertTrue(result==null);
	}
	@Test
	public void testLookUpForNF() throws Exception{
		String result = atgHelper.getMapFandNF("CAPMConfig",true).toString();
		log.debug("After conversion for testLookUpForNF >>>>>>>>>>>>>> :"+result);
		assertTrue(result.equals("capmConfig"));
	}
	
	@Test
	public void testConvertNFtoF_UUCPStatus() throws Exception{
		Map<String,Object> order = (Map<String,Object>)TestOrderBuilder.build("WUPG-Order").getMapofMaps();
		String result = atgHelper.convertNFToF(order).toString();
		log.debug("After conversion - NF-F >>>>>>>>>>>>>> :"+result);
		assertTrue(result.contains("uucpStatus"));
	}
	
	@Test
	public void testConvertNFtoF_salesChannelType() throws Exception{
		Map<String,Object> order = (Map<String,Object>)TestOrderBuilder.build("WUPG-Order").getMapofMaps();
		String result = atgHelper.convertNFToF(order).toString();
		log.debug("After conversion - NF-F >>>>>>>>>>>>>> :"+result);
		assertTrue(result.contains("salesChannelType"));
	}
	
	@Test
	public void testConvertNFtoF_IsShipmentInfoUpdated() throws Exception{
		Map<String,Object> order = (Map<String,Object>)TestOrderBuilder.build("WUPG-Order").getMapofMaps();
		String result = atgHelper.convertNFToF(order).toString();
		log.debug("After conversion - NF-F >>>>>>>>>>>>>> :"+result);
		assertTrue(result.contains("shipmentInfoUpdatedIndicator"));
	}
	
}

