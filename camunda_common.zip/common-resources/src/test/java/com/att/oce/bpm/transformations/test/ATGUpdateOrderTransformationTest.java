package com.att.oce.bpm.transformations.test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import org.json.JSONException;
import org.junit.Test;

import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.bpm.transformations.ATGUpdateOrderTransformation;

public class ATGUpdateOrderTransformationTest {

	protected static SimpleDateFormat xmlDateformat = new SimpleDateFormat("yyyy-MM-dd'Z'");
	protected static SimpleDateFormat dateTimeformat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	protected static String getXmlDate(){
		dateTimeformat.setTimeZone(TimeZone.getTimeZone("GMT"));
		return xmlDateformat.format(new Date());
	}
	
	@Test
	public void testCreateTransactionLogs_Fed() throws Exception
	{
		ATGUpdateOrderTransformation atgUpdateTransform =  new ATGUpdateOrderTransformation();
		Map<String, Object> Order= null;
		try {
			Order = TestOrderBuilder.build("Order_ATGUpdateOrder_TL.json").getMapofMaps();
		} catch (JSONException e) {
			e.printStackTrace();
		}	
		
		ArrayList<Map<String,Object>> transactionHistory = new ArrayList<Map<String,Object>>();
		Map<String,Object> transHist = new HashMap<String,Object>();
		transHist.put("StartTime", getXmlDate());
		transHist.put("EndTime", getXmlDate());
		transHist.put("api", "ReserveContractIdentifier");
		transHist.put("status", "SYS_PROCESSING");
		transHist.put("subStatus", "RETRIEVE_CONTRACT_IDENTIFIER_SKIPPED");
		transHist.put("ReferenceId", "GROUP_01");
		Map<String,Object> transHist2 = new HashMap<String,Object>();
		transHist2.put("StartTime", getXmlDate());
		transHist2.put("EndTime", getXmlDate());
		transHist2.put("api", "InquireIncompatibleOffering");
		transHist2.put("status", "SYS_PROCESSING");
		transHist2.put("subStatus", "INQUIRE_INCOMPATIBLE_OFFERING_PASS");
		transHist2.put("ReferenceId", "21-108100003001091");
		/*Map<String,Object> transHist3 = new HashMap<String,Object>();
		transHist3.put("StartTime", getXmlDate());
		transHist3.put("EndTime", getXmlDate());
		transHist3.put("api", "UpdateSubscriberProfile");
		transHist3.put("status", "COMPLETED");
		transHist3.put("subStatus", "UPDATE_SUBSCRIBER_PROFILE_SKIPPED");
		transHist3.put("ReferenceId", "GROUP_01");
		Map<String,Object> transHist4 = new HashMap<String,Object>();
		transHist4.put("StartTime", getXmlDate());
		transHist4.put("EndTime", getXmlDate());
		transHist4.put("api", "UpdateSubscriberProfile");
		transHist4.put("status", "COMPLETED");
		transHist4.put("subStatus", "UPDATE_SUBSCRIBER_PROFILE_SKIPPED");
		transHist4.put("ReferenceId", "GROUP_02");*/
		
		transactionHistory.add(transHist);
		transactionHistory.add(transHist2);
/*		transactionHistory.add(transHist3);
		transactionHistory.add(transHist4);*/
		
		Map<String,Object> executionContext = new HashMap<String,Object>();
		executionContext.put("transactionHistory",transactionHistory);
		
		Object result = atgUpdateTransform.createTransactionLogs(Order,executionContext);
		System.out.println("*********************TransactionLogs****************************");
		System.out.println(result);
		System.out.println("*************************************************************");
		
	}
}
