package com.att.oce.routes.test;

import static org.junit.Assert.assertEquals;

import com.att.oce.beans.config.APIResultConfig;
import com.att.oce.beans.config.OceConfig;
import com.att.oce.bpm.common.MapBuilder;
import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.bpm.routes.ValidateAddressRouteBuilder;
import com.att.oce.config.components.GlobalProperties;
import com.att.oce.config.components.URNResolver;
import java.io.File;
import java.io.FileInputStream;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.ExchangeBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpClientConfigurer;
import org.apache.camel.model.ModelCamelContext;
import org.apache.camel.spring.javaconfig.SingleRouteCamelConfiguration;
import org.apache.camel.test.spring.CamelSpringDelegatingTestContextLoader;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.apache.http.impl.client.HttpClientBuilder;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;

@RunWith(CamelSpringJUnit4ClassRunner.class)
@ContextConfiguration(
  classes = {
    ValUnparsedAddress_SuccessResponseTest.TestConfig.class,
    OceConfig.class,
    GlobalProperties.class,
    APIResultConfig.class,
    URNResolver.class
  },
  loader = CamelSpringDelegatingTestContextLoader.class
)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ValUnparsedAddress_SuccessResponseTest {

  @Configuration
  public static class TestConfig extends SingleRouteCamelConfiguration {

    @Bean
    public HttpClientConfigurer oceHttpClientConfigurer() {
      return new HttpClientConfigurer() {
        @Override
        public void configureHttpClient(HttpClientBuilder arg0) {}
      };
    }

    @Bean
    public ExecutorService wiretapThreadPool() {
      return Executors.newFixedThreadPool(2);
    }

    @Bean
    @Override
    public RouteBuilder route() {
      return new ValidateAddressRouteBuilder();
    }

    @Bean
    public static DmnEngine dmnEngine() {
      // create default DMN engine configuration
      DmnEngineConfiguration configuration =
          DmnEngineConfiguration.createDefaultDmnEngineConfiguration();

      // build a new DMN engine
      DmnEngine dmnEngine = configuration.buildEngine();
      return dmnEngine;
    }
  }

  @Produce(uri = "direct:csi:val:add")
  protected ProducerTemplate testProducer;

  @BeforeClass
  public static void init() {
    System.setProperty(
        "OCE_RESOURCES_HOME", "./../../oce_framework/oce-resources/src/main/resources/");
    System.setProperty("OCE_ENV", "dev");
    System.setProperty("OCE_DOMAIN", "wireless");
  }

  @DirtiesContext
  @Test
  public void testRoute() throws Exception {

    testProducer
        .getCamelContext()
        .getRouteDefinitions()
        .get(0)
        .adviceWith(
            testProducer.getCamelContext().adapt(ModelCamelContext.class),
            new RouteBuilder() {
              File file =
                  new File("./src/test/resources/apiResponses/ValidateAddress_SuccessResponse.xml");
              FileInputStream fis = new FileInputStream(file);

              @Override
              public void configure() throws Exception {
                interceptSendToEndpoint("http4://ValidateAddress?throwExceptionOnFailure=false&httpClientConfigurer=oceHttpClientConfigurer")
                    .skipSendToOriginalEndpoint()
                    .setBody(constant(fis));
              }
            });
    Exchange e =
        ExchangeBuilder.anExchange(testProducer.getCamelContext())
            .withBody(
                MapBuilder.build()
                    .add("addressId", "ADDRESS_01")
                    .add("order", TestOrderBuilder.build("unparsedAddress").getMapofMaps())
                    .get())
            .withProperty("executionContext", MapBuilder.build().add("test", "testvalue").get())
            .withPattern(ExchangePattern.InOut)
            .build();

    testProducer.send(e);
    assertEquals("SUCCESS", ((Map) e.getProperty("executionContext")).get("ValidateAddress.pass"));
    System.out.println("Response from Camel to BPMN:" + e.getOut().getBody());
    System.out.println("ExecutionContext:" + e.getProperty("executionContext"));
    // assertTrue((boolean)iapXfrm.preCondition(e.getOut().getBody()));

  }
}
