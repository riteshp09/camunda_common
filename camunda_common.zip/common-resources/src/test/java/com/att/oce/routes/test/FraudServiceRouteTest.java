package com.att.oce.routes.test;

import com.att.oce.beans.config.APIResultConfig;
import com.att.oce.beans.config.OceConfig;
import com.att.oce.bpm.common.MapBuilder;
import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.bpm.nf.transformations.FraudValidationTransformation;
import com.att.oce.bpm.routes.FraudServiceRouteBuilder;
import com.att.oce.config.components.GlobalProperties;
import com.att.oce.config.components.URNResolver;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.apache.camel.Exchange;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.ExchangeBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpClientConfigurer;
import org.apache.camel.model.ModelCamelContext;
import org.apache.camel.spring.javaconfig.SingleRouteCamelConfiguration;
import org.apache.camel.test.spring.CamelSpringDelegatingTestContextLoader;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.apache.http.impl.client.HttpClientBuilder;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;

@RunWith(CamelSpringJUnit4ClassRunner.class)
@ContextConfiguration(
  classes = {
    FraudServiceRouteTest.TestConfig.class,
    OceConfig.class,
    APIResultConfig.class,
    FraudValidationTransformation.class,
    GlobalProperties.class,
    URNResolver.class
  },
  loader = CamelSpringDelegatingTestContextLoader.class
)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class FraudServiceRouteTest {

  @Configuration
  public static class TestConfig extends SingleRouteCamelConfiguration {

    @Bean
    public HttpClientConfigurer oceHttpClientConfigurer() {
      return new HttpClientConfigurer() {
        @Override
        public void configureHttpClient(HttpClientBuilder arg0) {}
      };
    }

    @Bean
    public ExecutorService wiretapThreadPool() {
      return Executors.newFixedThreadPool(2);
    }

    @Bean
    @Override
    public RouteBuilder route() {
      return new FraudServiceRouteBuilder();
    }

    @Bean
    public static DmnEngine dmnEngine() {
      // create default DMN engine configuration
      DmnEngineConfiguration configuration =
          DmnEngineConfiguration.createDefaultDmnEngineConfiguration();

      // build a new DMN engine
      DmnEngine dmnEngine = configuration.buildEngine();
      return dmnEngine;
    }
  }

  @Produce(uri = "direct:fraud")
  protected ProducerTemplate prodTemplate;

  @BeforeClass
  public static void init() {
    System.setProperty("OCE_ENV", "dev");
    System.setProperty("OCE_DOMAIN", "wireless");
    System.setProperty(
        "OCE_RESOURCES_HOME", "../../oce_framework/oce-resources/src/main/resources/");
  }

  @DirtiesContext
  @Test
  public void testFraud_SuccessScenario() throws Exception {

    prodTemplate
        .getCamelContext()
        .getRouteDefinitions()
        .get(0)
        .adviceWith(
            prodTemplate.getCamelContext().adapt(ModelCamelContext.class),
            new RouteBuilder() {
              @Override
              public void configure() throws Exception {
                interceptSendToEndpoint("http://headeruri?throwExceptionOnFailure=false")
                    .skipSendToOriginalEndpoint()
                    .setBody(
                        constant(
                            TestOrderBuilder.build("executeFraudChecksResponse.xml").toString()));
              }
            });

    Exchange e =
        prodTemplate.send(
            "direct:fraud",
            ExchangeBuilder.anExchange(prodTemplate.getCamelContext())
                .withBody(
                    MapBuilder.build()
                        .add("order", TestOrderBuilder.build("order_d5.json").getMapofMaps())
                        .get())
                .withProperty("executionContext", MapBuilder.build().add("test", "testvalue").get())
                .build());

    System.out.println("Response from Camel to BPMN:" + e.getProperty("executionContext"));
  }

  @DirtiesContext
  @Test
  public void testFraud_FailureScenario() throws Exception {

    prodTemplate
        .getCamelContext()
        .getRouteDefinitions()
        .get(0)
        .adviceWith(
            prodTemplate.getCamelContext().adapt(ModelCamelContext.class),
            new RouteBuilder() {
              @Override
              public void configure() throws Exception {
                interceptSendToEndpoint("http4://FraudService?throwExceptionOnFailure=false&httpClientConfigurer=oceHttpClientConfigurer")
                    .skipSendToOriginalEndpoint()
                    .setBody(
                        constant(
                            TestOrderBuilder.build("executeFraudChecksResponse_Inqueue.xml")
                                .toString()));
              }
            });

    Exchange e =
        prodTemplate.send(
            "direct:fraud",
            ExchangeBuilder.anExchange(prodTemplate.getCamelContext())
                .withBody(
                    MapBuilder.build()
                        .add("order", TestOrderBuilder.build("order_d5.json").getMapofMaps())
                        .get())
                .withProperty("executionContext", MapBuilder.build().add("test", "testvalue").get())
                .build());

    System.out.println("Response from Camel to BPMN:" + e.getProperty("executionContext"));
  }

  @DirtiesContext
  @Test
  public void testFraud_FaultScenario() throws Exception {

    prodTemplate
        .getCamelContext()
        .getRouteDefinitions()
        .get(0)
        .adviceWith(
            prodTemplate.getCamelContext().adapt(ModelCamelContext.class),
            new RouteBuilder() {
              @Override
              public void configure() throws Exception {
                interceptSendToEndpoint("http://headeruri?throwExceptionOnFailure=false")
                    .skipSendToOriginalEndpoint()
                    .setBody(
                        constant(
                            TestOrderBuilder.build("executeFraudChecksResponse_fault.xml")
                                .toString()));
              }
            });

    Exchange e =
        prodTemplate.send(
            "direct:fraud",
            ExchangeBuilder.anExchange(prodTemplate.getCamelContext())
                .withBody(
                    MapBuilder.build()
                        .add("order", TestOrderBuilder.build("order_d5.json").getMapofMaps())
                        .get())
                .withProperty("executionContext", MapBuilder.build().add("test", "testvalue").get())
                .build());

    System.out.println("Response from Camel to BPMN:" + e.getProperty("executionContext"));
  }
}
