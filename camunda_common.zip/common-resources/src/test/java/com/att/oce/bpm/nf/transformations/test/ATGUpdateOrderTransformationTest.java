package com.att.oce.bpm.nf.transformations.test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import org.apache.camel.test.spring.CamelSpringDelegatingTestContextLoader;
import org.apache.camel.test.spring.CamelSpringJUnit4ClassRunner;
import org.camunda.bpm.engine.test.ProcessEngineTestCase;
import org.json.JSONException;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;

import com.att.oce.beans.config.APIResultConfig;
import com.att.oce.beans.config.OceConfig;
import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.bpm.nf.transformations.ATGUpdateOrderTransformation;
import com.att.oce.config.components.GlobalProperties;
import com.att.oce.config.components.URNResolver;

	
	public class ATGUpdateOrderTransformationTest {

	
		
		protected static SimpleDateFormat xmlDateformat = new SimpleDateFormat("yyyy-MM-dd'Z'");
		protected static SimpleDateFormat dateTimeformat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		// @author:sk598g - Changed TimeZone to GMT
		protected static String getXmlDate(){
			dateTimeformat.setTimeZone(TimeZone.getTimeZone("GMT"));
			return xmlDateformat.format(new Date());
		}
	   

		@Test
		public void test_createTransactionLogs()throws Exception{
			ATGUpdateOrderTransformation atgUpdateTransform =  new ATGUpdateOrderTransformation();
			Map<String, Object> Order = null;
			try {
				Order = TestOrderBuilder.build("AddAccPreConditionFailure.json").getMapofMaps();
			} catch (JSONException e) {
				e.printStackTrace();
			}	
			
			ArrayList<Map<String,Object>> transList = new ArrayList<Map<String,Object>>();
			Map<String,Object> transMap1 = new HashMap<String,Object>();
			transMap1.put("StartTime", getXmlDate());
			transMap1.put("EndTime", getXmlDate());
			transMap1.put("api", "BusinessRulesValidation");
			transMap1.put("status", "SYS_PROCESSING");
			transMap1.put("subStatus", "FRAUD_APPROVED");
			transMap1.put("ReferenceId", "GROUP_01");
			Map<String,Object> transMap = new HashMap<String,Object>();
			transMap.put("StartTime", getXmlDate());
			transMap.put("EndTime", getXmlDate());
			transMap.put("api", "BusinessRulesValidation");
			transMap.put("status", "IN_QUEUE");
			transMap.put("subStatus", "BUSINESS_RULE_VALIDATION_FAIL");
			transMap.put("ReferenceId", "GROUP_01");
			
			transList.add(transMap1);
			transList.add(transMap);
			
			Map<String,Object> executionContext = new HashMap<String,Object>();
			executionContext.put("transactionHistory",transList);
			
			Object result = atgUpdateTransform.createTransactionLogs(Order,executionContext);
			System.out.println("*********************TransactionLogs*************************");
			System.out.println(result);
			System.out.println("*************************************************************");
		}

		
		@Test
		public void test_updateLoSGStatus()throws Exception{
			ATGUpdateOrderTransformation atgUpdateTransform =  new ATGUpdateOrderTransformation();
			Map<String, Object> Order= null;
			try {
				Order = TestOrderBuilder.build("AddAccPreConditionFailure.json").getMapofMaps();
			} catch (JSONException e) {
				e.printStackTrace();
			}	
			
			ArrayList<Map<String,Object>> transList = new ArrayList<Map<String,Object>>();
			Map<String,Object> transMap1 = new HashMap<String,Object>();
			transMap1.put("StartTime", getXmlDate());
			transMap1.put("EndTime", getXmlDate());
			transMap1.put("api", "BusinessRulesValidation");
			transMap1.put("status", "SYS_PROCESSING");
			transMap1.put("subStatus", "FRAUD_APPROVED");
			transMap1.put("ReferenceId", "GROUP_01");
			Map<String,Object> transMap = new HashMap<String,Object>();
			transMap.put("StartTime", getXmlDate());
			transMap.put("EndTime", getXmlDate());
			transMap.put("api", "BusinessRulesValidation");
			transMap.put("status", "IN_QUEUE");
			transMap.put("subStatus", "BUSINESS_RULE_VALIDATION_FAIL");
			transMap.put("ReferenceId", "T1473830709711");
			
			transList.add(transMap1);
			transList.add(transMap);
			
			Map<String,Object> executionContext = new HashMap<String,Object>();
			executionContext.put("transactionHistory",transList);
			
			Map<String,Object> result = (Map<String, Object>) atgUpdateTransform.updateLoSGStatus(Order,executionContext);
			System.out.println("*********************UpdatedOrder****************************");
			System.out.println(result);
			System.out.println("*************************************************************");
		}
		
		@Test
		public void testUpdateLoSGStatusForEnrollment_USPSkip()throws Exception{
			ATGUpdateOrderTransformation atgUpdateTransform =  new ATGUpdateOrderTransformation();
			Map<String, Object> Order= null;
			try {
				Order = TestOrderBuilder.build("OrderUSPSkip.json").getMapofMaps();
			} catch (JSONException e) {
				e.printStackTrace();
			}	
			
			ArrayList<Map<String,Object>> transactionHistory = new ArrayList<Map<String,Object>>();
			Map<String,Object> transHist = new HashMap<String,Object>();
			transHist.put("StartTime", getXmlDate());
			transHist.put("EndTime", getXmlDate());
			transHist.put("api", "MoveMobileSubscriber");
			transHist.put("status", "SYS_PROCESSING");
			transHist.put("subStatus", "MOVE_MOBILE_SUBSCRIBER_PASS");
			transHist.put("ReferenceId", "GROUP_01");
			Map<String,Object> transHist2 = new HashMap<String,Object>();
			transHist2.put("StartTime", getXmlDate());
			transHist2.put("EndTime", getXmlDate());
			transHist2.put("api", "MoveMobileSubscriber");
			transHist2.put("status", "SYS_PROCESSING");
			transHist2.put("subStatus", "MOVE_MOBILE_SUBSCRIBER_PASS");
			transHist2.put("ReferenceId", "GROUP_02");
			Map<String,Object> transHist3 = new HashMap<String,Object>();
			transHist3.put("StartTime", getXmlDate());
			transHist3.put("EndTime", getXmlDate());
			transHist3.put("api", "UpdateSubscriberProfile");
			transHist3.put("status", "COMPLETED");
			transHist3.put("subStatus", "UPDATE_SUBSCRIBER_PROFILE_SKIPPED");
			transHist3.put("ReferenceId", "GROUP_01");
			Map<String,Object> transHist4 = new HashMap<String,Object>();
			transHist4.put("StartTime", getXmlDate());
			transHist4.put("EndTime", getXmlDate());
			transHist4.put("api", "UpdateSubscriberProfile");
			transHist4.put("status", "COMPLETED");
			transHist4.put("subStatus", "UPDATE_SUBSCRIBER_PROFILE_SKIPPED");
			transHist4.put("ReferenceId", "GROUP_02");
			
			transactionHistory.add(transHist);
			transactionHistory.add(transHist2);
			transactionHistory.add(transHist3);
			transactionHistory.add(transHist4);
			
			Map<String,Object> executionContext = new HashMap<String,Object>();
			executionContext.put("transactionHistory",transactionHistory);
			
			Map<String,Object> result = (Map<String, Object>) atgUpdateTransform.updateLoSGStatus(Order,executionContext);
			System.out.println("*********************UpdatedOrder****************************");
			System.out.println(result);
			System.out.println("*************************************************************");
		}


	}

