package com.att.oce.bpm.groovy;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.beans.config.APIResultConfig;
import com.att.oce.beans.config.OceConfig;
import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.bpm.transformations.ValidateAddressTransformation;
import com.att.oce.config.components.GlobalProperties;
import com.att.oce.config.components.URNResolver;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {OceConfig.class, GlobalProperties.class, 
								URNResolver.class,
								ValidateAddressTransformation.class,
								TestConfiguration.class, APIResultConfig.class})
public class ValidateAddressTransformationTest {

	@Autowired
	ValidateAddressTransformation valTransform;
	
	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "./../../oce_framework/oce-resources/src/main/resources/");
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireless");
	} 
	
	@Test
	public void testPreCondition_Success() throws Exception{
		Map<String,Object> order = (Map<String,Object>)TestOrderBuilder.build("parsedAddress_true").getMapofMaps();
		Map<String,Object> executionContext = new HashMap<String, Object>();
		executionContext.put("transactionHistory", new ArrayList<Map<String,Object>>());
		List<String> addressList = new ArrayList<>();
		addressList.add("ADDRESS_01");
		addressList.add("ADDRESS_02");
		for (String addressId : addressList) {
			DelegateExecution execution = mock(DelegateExecution.class);
			when(execution.getVariable("order")).thenReturn(order);
			when(execution.getVariable("addressId")).thenReturn(addressId);
			when(execution.getVariable("executionContext")).thenReturn(executionContext);
			Boolean result = (Boolean) valTransform.preCondition(execution);
			System.out.println("Result>>>: "+result);
			assertTrue(result);
		}
	}
	
	@Test
	public void testPreCondition_Failure() throws Exception{
		Map<String,Object> order = (Map<String,Object>)TestOrderBuilder.build("parsedAddress").getMapofMaps();
		Map<String,Object> executionContext = new HashMap<String, Object>();
		executionContext.put("transactionHistory", new ArrayList<Map<String,Object>>());
		DelegateExecution execution = mock(DelegateExecution.class);
		when(execution.getVariable("order")).thenReturn(order);
		when(execution.getVariable("addressId")).thenReturn("ADDRESS_01");
		when(execution.getVariable("executionContext")).thenReturn(executionContext);
		Boolean result = (Boolean) valTransform.preCondition(execution);
		assertFalse(result);
	}
	
	@Test
	public void testGetCollection() throws Exception{
		Map<String,Object> order = (Map<String,Object>)TestOrderBuilder.build("parsedAddress").getMapofMaps();
		List<Object> result = (List) valTransform.getLoopCollection(order);
		assertTrue(result.size()>0);
	}
	
	@Test
	public void testGetCollectionCount_GtThanZero() throws Exception{
		Map<String,Object> order = (Map<String,Object>)TestOrderBuilder.build("parsedAddress").getMapofMaps();
		int result = valTransform.getLoopCount(order);
		assertTrue(result > 0);
	}
	
	@Test
	public void testGetCollectionCount_LtOrEqualToZero() throws Exception{
		Map<String,Object> order = (Map<String,Object>)TestOrderBuilder.build("ValAdd_Sample1_woAddress").getMapofMaps();
		int result = valTransform.getLoopCount(order);
		assertTrue(result <= 0);
	}
}
