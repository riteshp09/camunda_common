package com.att.oce.bpm.nf.transformations.test;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.json.JSONException;
import org.junit.Test;

import com.att.oce.bpm.common.TestOrderBuilder;
import com.att.oce.bpm.nf.transformations.ATGTaskCreateTransformation;

public class ATGTaskCreateTransformationTest extends ATGTaskCreateTransformation {

	protected static SimpleDateFormat dateTimeformat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

	protected static String getXmlDateTime(){
		return dateTimeformat.format(new Date());
	}
	
	@Test
	public void testValidateOrderForFalloutManagement() throws JSONException, Exception {
		List<String> apiNames = new ArrayList<String>();
		apiNames.add("BusinessRulesValidation");
		apiNames.add("ICDS");
		
		Map<String,Object> executionContext = new HashMap<String,Object>();
		
		List<Map<String, Object>> transactionHistory = new ArrayList<Map<String, Object>>();
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(),"api","BusinessRulesValidation","success",true,"status","SYS_PROCESSING","subStatus","BRVP","ReferenceId","123456"));
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(),"api","ICDS","success",false,"status","IN_QUEUE","subStatus","BRVP","ReferenceId","2122120405"));
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(),"api","IMSP","success",false,"status","IN_QUEUE","subStatus","BRVP","ReferenceId","2122120406"));
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(),"api","FALLOUT","success",true,"status","IN_QUEUE","subStatus","WAITING_FOR_ORDER_UPDATE","ReferenceId","31-338100003326180","recordType","Internal"));
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(),"api","VMA","success",true,"status","SYS_PROCESSING","subStatus","BRVP","ReferenceId","2122120406"));
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(),"api","VMA","success",true,"status","SYS_PROCESSING","subStatus","BRVP","ReferenceId","2122120406"));
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(),"api","ADDACC","success",true,"status","SYS_PROCESSING","subStatus","BRVP","ReferenceId","2122120406"));
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(),"api","ADDACC","success",true,"status","SYS_PROCESSING","subStatus","BRVP","ReferenceId","2122120406"));

		executionContext.put("transactionHistory", transactionHistory);
		CamelContext ctx = new DefaultCamelContext(); 
		Exchange ex = new DefaultExchange(ctx);
		ex.setProperty("order", TestOrderBuilder.build("order_d5").getMapofMaps());
		ex.setProperty("executionContext",executionContext);
//		addTransactionHistory(ex);
		
		
		executionContext = (Map<String, Object>) ex.getProperty("executionContext");
		List<Map<String,Object>> th = (List<Map<String,Object>>) executionContext.get("transactionHistory");
		List<Map<String,Object>> updatedList = getUpdatedTransactionHistory(th);
		assertEquals(updatedList.size(), 4);
	}

}
