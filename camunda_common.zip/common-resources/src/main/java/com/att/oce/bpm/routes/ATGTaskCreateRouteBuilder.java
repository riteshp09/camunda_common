package com.att.oce.bpm.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component("atgTaskCreateRouteBuilder")
public class ATGTaskCreateRouteBuilder extends RouteBuilder {

  @Override
  public void configure() throws Exception {
    from("direct:atgcreatetask")
        .beanRef("atgTaskCreateTransformation", "transform")
        .wireTap("direct:auditlog:request").executorServiceRef("wiretapThreadPool")
        .to("http4://ATGTaskCreate?throwExceptionOnFailure=false&httpClientConfigurer=oceHttpClientConfigurer").id("ATGTaskCreate-http")
        .convertBodyTo(String.class).id("ATGTaskCreate-http-readstr")
        .wireTap("direct:auditlog:response").executorServiceRef("wiretapThreadPool")
        .beanRef("atgTaskCreateTransformation", "processResponse")
        .routeId("ATGTaskCreate");
  }
}