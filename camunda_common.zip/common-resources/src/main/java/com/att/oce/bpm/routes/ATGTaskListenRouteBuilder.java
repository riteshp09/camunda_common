package com.att.oce.bpm.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/**
 * Modified by jt316g on 3/29/2017 1) camunda-bpm:task?action=complete&amp;copyBodyAsVariable=order
 * changed to camunda-bpm:task?action=complete&copyBodyAsVariable=order XML DSL follows &amp; to
 * denote & (special character handling), but Java DSL should use & - otherwise everything after &
 * shall be considered as an option, which makes "amp;copyBodyAsVariable" as an option in place of
 * "copyBodyAsVariable"
 */
@Component("atgTaskListenRouteBuilder")
public class ATGTaskListenRouteBuilder extends RouteBuilder {

  @Override
  public void configure() throws Exception {
    from("atgtask-activemq:" + System.getProperty("ATG_TASK_NOTIFY_AMQ_NAME"))
        .beanRef("atgGetOrderTransformation", "transform")
        .wireTap("direct:auditlog:request").executorServiceRef("wiretapThreadPool")
        .to("http4://ATGTaskListen?throwExceptionOnFailure=false&httpClientConfigurer=oceHttpClientConfigurer").id("ATGTaskListen-http")
        .convertBodyTo(String.class).id("ATGTaskListen-http-readstr")
        .wireTap("direct:auditlog:response").executorServiceRef("wiretapThreadPool")
        .beanRef("atgGetOrderTransformation", "processResponse")
        .to("camunda-bpm:task?action=complete&copyBodyAsVariable=order")
        .routeId("ATGTaskListen");
  }
}