package com.att.oce.bpm.routes;

import com.att.oce.config.components.GlobalProperties;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("atgUpdateOrderRouteBuilder")
public class ATGUpdateOrderRouteBuilder extends RouteBuilder {

  @Autowired GlobalProperties global;

  @Override
  public void configure() throws Exception {
    from("direct:atg:update")
        .beanRef("atgUpdateOrderTransformation", "transform")
        .wireTap("direct:auditlog:request").executorServiceRef("wiretapThreadPool")
        .choice()
        .when(constant(global.isATGEndPointAMQ).isEqualTo("false"))
        .to("http4://ATGUpdateOrder?throwExceptionOnFailure=false&httpClientConfigurer=oceHttpClientConfigurer").id("ATGUpdateOrder-http")
        .convertBodyTo(String.class).id("ATGUpdateOrder-http-readstr")
        .wireTap("direct:auditlog:response").executorServiceRef("wiretapThreadPool")
        .beanRef("atgUpdateOrderTransformation", "processResponse")
        .end()
        .otherwise()
        .to("atg-activemq:" + global.atgQueueName)
        .end()
        .routeId("ATGUpdateOrder");
  }
}