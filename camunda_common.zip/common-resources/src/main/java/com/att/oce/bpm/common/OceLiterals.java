package com.att.oce.bpm.common;

public class OceLiterals {
	
	
	public static String KEY_HEADER_PASCAL_CASE = "header";
	public static String KEY_BODY_PASCAL_CASE = "body";

	public static String KEY_FIRSTNAME_CAMEL_CASE = "firstName";
	public static String KEY_LASTNAME_CAMEL_CASE = "lastName";
	public static String KEY_CAN_BE_REACHED_PHONE_CAMEL_CASE = "canBeReachedPhone";
	public static String KEY_EMAIL_ADDRESS_CAMEL_CASE = "emailAddress";
	public static String KEY_ACCOUNT_TYPE_CAMEL_CASE = "accountType";
	public static String KEY_ACCOUNT_SUB_TYPE_CAMEL_CASE = "accountSubType";
	public static String KEY_SUBSCRIBER_NUMBER_CAMEL_CASE = "subscriberNumber";
	public static String KEY_CODE_CAMEL_CASE = "code";
	public static String KEY_DEALER_CAMEL_CASE = "dealer";
	public static String KEY_FIELD_INDICATOR_CAMEL_CASE = "fieldIndicator";
	public static String KEY_ZIP_CODE_CAMEL_CASE = "zipCode";
	public static String KEY_SINGLE_USER_CODE_CAMEL_CASE = "singleUserCode";
	public static String KEY_EFFECTIVE_DATE_CAMEL_CASE = "effectiveDate";
	public static String KEY_LOCATION_CAMEL_CASE = "location";
	public static String KEY_SALES_REPRESENTATIVE_CAMEL_CASE = "salesRepresentative";
	public static String KEY_SUBSCRIPTION_CLASS_CAMEL_CASE = "subscriptionClass";
	public static String KEY_VIN_CAMEL_CASE = "vin";
	public static String KEY_USER_NAME_CAMEL_CASE = "userName";
	public static String KEY_USER_PASSWORD_CAMEL_CASE = "userPassword";
	public static String KEY_DATE_TIME_STAMP_CAMEL_CASE = "dateTimeStamp";	
	public static String KEY_TIME_TO_LIVE_CAMEL_CASE = "timeToLive";
	public static String KEY_RETURN_URL_CAMEL_CASE = "returnURL";
	public static String KEY_VERSION_CAMEL_CASE = "version";
	public static String KEY_MESSAGE_ID_CAMEL_CASE = "messageId";
	public static String KEY_ORIGINATOR_ID_CAMEL_CASE = "originatorId";

	public static String KEY_PPU_ADDRESS_PASCAL_CASE = "PPUAddress";
	public static String KEY_BILLING_ADDRESS_PASCAL_CASE = "BillingAddress";
	public static String KEY_CODE_PASCAL_CASE = "Code";
	public static String KEY_PRICE_PLAN_PASCAL_CASE = "PricePlan";
	public static String KEY_ADDRESS_LINE1_PASCAL_CASE = "AddressLine1";
	public static String KEY_ADDRESS_LINE2_PASCAL_CASE = "AddressLine2";
	public static String KEY_CITY_PASCAL_CASE = "City";
	public static String KEY_STATE_PASCAL_CASE = "State";
	public static String KEY_ZIP_PASCAL_CASE = "Zip";
	public static String KEY_COUNTRY_PASCAL_CASE = "Country";
	public static String KEY_COMMISSION_PASCAL_CASE = "Commission";
	public static String KEY_ACCOUNT_PASCAL_CASE = "Account";
	public static String KEY_BILLING_ACCOUNT_NUMBER_PASCAL_CASE = "BillingAccountNumber";
	public static String KEY_ORDER_PASCAL_CASE = "Order";
	public static String KEY_GROUP_PASCAL_CASE = "Group";
	public static String KEY_TRANSACTION_LOGS_PASCAL_CASE = "TransactionLogs";
	public static String KEY_ERRORS_PASCAL_CASE = "Errors";
	public static String KEY_ORDER_TASKS_PASCAL_CASE = "OrderTasks";
	public static String KEY_MOBILE_NUMBER_PASCAL_CASE = "MobileNumber";
	public static String KEY_MAKE_PASCAL_CASE = "Make";
	public static String KEY_TRIM_PASCAL_CASE = "Trim";
	public static String KEY_MODEL_PASCAL_CASE = "Model";
	public static String KEY_YEAR_PASCAL_CASE ="Year";
	public static String KEY_CONNECTED_CAR_LOS_CHARS_PASCAL_CASE = "ConnectedCarLOSChars";	
	public static String KEY_PRICE_PLAN_OFFERINGS_PASCAL_CASE = "PricePlanOfferings";
	public static String KEY_CHILD_ORDER_NUMBER_PASCAL_CASE = "ChildOrderNumber";
	public static String KEY_ORDER_NUMBER_PASCAL_CASE = "OrderNumber";
	public static String KEY_APPLICATION_NAME_PASCAL_CASE = "ApplicationName";
	
	public static String KEY_START_TIME = "StartTime";
	public static String KEY_END_TIME = "EndTime";
	public static String KEY_STATUS = "Status";
	public static String KEY_SUB_STATUS = "SubStatus";
	public static String KEY_ORDER_ID = "OrderId";
	public static String KEY_SERVICE_TYPE = "ServiceType";
	public static String KEY_SERVICE = "Service";
	public static String KEY_NUMBER = "Number";
	public static String KEY_LOSG_REFERENCE_ID = "LosgReferenceId";
	public static String KEY_CHANGED_LOSG_REFERENCE_ID ="ChangedLosgReferenceId";
	public static String KEY_MARKER_KEY = "MarkerKey";
	public static String KEY_MARKER_TYPE1 = "MarkerType1";

}
