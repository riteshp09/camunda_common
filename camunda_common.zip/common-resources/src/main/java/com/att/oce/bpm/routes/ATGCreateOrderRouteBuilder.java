package com.att.oce.bpm.routes;

import com.att.oce.config.components.GlobalProperties;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("atgCreateOrderRouteBuilder")
public class ATGCreateOrderRouteBuilder extends RouteBuilder {

  @Autowired GlobalProperties global;

  @Override
  public void configure() throws Exception {
    from("direct:atg")
        .beanRef("atgCreateOrderTransformation", "transform")
        .wireTap("direct:auditlog:request").executorServiceRef("wiretapThreadPool")
        .choice()
        .when(constant(global.isATGEndPointAMQ).isEqualTo("false"))
        .to("http4://ATGCreateOrder?throwExceptionOnFailure=false&httpClientConfigurer=oceHttpClientConfigurer").id("ATGCreateOrder-http")
        .convertBodyTo(String.class).id("ATGCreateOrder-http-readstr")
        .wireTap("direct:auditlog:response").executorServiceRef("wiretapThreadPool")
        .beanRef("atgCreateOrderTransformation", "processResponse")
        .end()
        .otherwise()
        .to("atg-activemq:" + global.atgQueueName)
        .end()
        .routeId("ATGCreateOrder");
  }
}