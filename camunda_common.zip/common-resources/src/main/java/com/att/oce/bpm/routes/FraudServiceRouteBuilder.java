package com.att.oce.bpm.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;


@Component("fraudServiceRouteBuilder")
public class FraudServiceRouteBuilder extends RouteBuilder {

  @Override
  public void configure() throws Exception {
    from("direct:brms:fraud")
        .beanRef("fraudTransformation", "transform")
        .to("velocity:vm/fraudvalidation.vm").id("FraudService-velocity")
        .wireTap("direct:auditlog:request").executorServiceRef("wiretapThreadPool")
        .to("http4://FraudService?throwExceptionOnFailure=false&httpClientConfigurer=oceHttpClientConfigurer").id("FraudService-http")
        .convertBodyTo(String.class).id("FraudService-http-readstr")
        .wireTap("direct:auditlog:response").executorServiceRef("wiretapThreadPool")
        .beanRef("fraudTransformation", "processResponse")
        .routeId("FraudService");
  }
}
