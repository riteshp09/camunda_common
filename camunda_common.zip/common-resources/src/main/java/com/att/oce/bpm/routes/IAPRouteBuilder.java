package com.att.oce.bpm.routes;

import com.att.oce.bpm.transformations.InquireAccountProfileTransformation;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component("iapRouteBuilder")
public class IAPRouteBuilder extends RouteBuilder {

  @Override
  public void configure() throws Exception {
    from("direct:csi:iap")
        .bean(InquireAccountProfileTransformation.class, "transform").id("IAP-transform")
        .to("velocity://vm/IAP.vm").id("IAP-velocity")
        .wireTap("direct:auditlog:request").executorServiceRef("wiretapThreadPool")
        .to("http4://IAP?throwExceptionOnFailure=false&httpClientConfigurer=oceHttpClientConfigurer").id("IAP-http")
        .convertBodyTo(String.class).id("IAP-http-readstr")
        .wireTap("direct:auditlog:response").executorServiceRef("wiretapThreadPool")
        .bean(InquireAccountProfileTransformation.class, "processResponse").id("IAP-processResponse")
        .routeId("IAP");
  }
}
