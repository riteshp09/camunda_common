package com.att.oce.bpm.routes;

import com.att.oce.bpm.transformations.ValidateAddressTransformation;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component("validateAddressRouteBuilder")
public class ValidateAddressRouteBuilder extends RouteBuilder {

  @Override
  public void configure() throws Exception {
    from("direct:csi:val:add")
        .bean(ValidateAddressTransformation.class, "transform").id("ValidateAddress-transform")
        .to("velocity://vm/ValidateAddress.vm").id("ValidateAddress-velocity")
        .wireTap("direct:auditlog:request").executorServiceRef("wiretapThreadPool")
        .to("http4://ValidateAddress?throwExceptionOnFailure=false&httpClientConfigurer=oceHttpClientConfigurer").id("ValidateAddress-http")
        .convertBodyTo(String.class).id("ValidateAddress-http-readstr")
        .wireTap("direct:auditlog:response").executorServiceRef("wiretapThreadPool")
        .bean(ValidateAddressTransformation.class, "processResponse").id("ValidateAddress-processResponse")
        .routeId("ValidateAddress");
  }
}
