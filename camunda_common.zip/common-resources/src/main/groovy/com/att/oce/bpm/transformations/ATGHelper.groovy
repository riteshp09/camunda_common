package com.att.oce.bpm.transformations

import groovy.json.JsonSlurper
import groovy.json.StringEscapeUtils;

import java.io.File
import java.io.InputStream;
import java.net.URL
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.att.oce.bpm.common.TransformationService
import org.camunda.bpm.engine.impl.util.json.JSONObject;
import org.camunda.bpm.engine.impl.util.json.XML
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;


class ATGHelper {
	static Logger log = LoggerFactory.getLogger(ATGHelper.class);

	static def FtoNFMap = [:];
	static def NFtoFMap =[:];
	
	/**
	 * To convert Fed Map to Non Fed JSON
	 * @param mOrder
	 * @return
	 */
	static def convertFToNF(mOrder) {
		log.info('ATGHelper.convertFToNF <-- Entering');
		log.debug('ATGHelper.convertFToNF: Fed map Before conversion:'+mOrder);
		/*if(!mOrder.customerOrderNumber && mOrder.order.customerOrderNumber){
			mOrder = mOrder.order
		}*/
		def jOrder = StringBuilder.newInstance();
		List<String> keyPath = new ArrayList<String>();

		keyPath.add('order');
		jOrder << '{ "Order" : ';

		convertMapToJson(mOrder, jOrder,true,keyPath);

		jOrder << '}';
		keyPath.remove('order');

		log.debug('ATGHelper.convertFToNF: KeyPath:'+keyPath);
		log.debug('ATGHelper.convertFToNF: Non Fed JSON after conversion:'+jOrder);
		log.info('ATGHelper.convertFToNF <-- Exiting');
		
		return jOrder;
	}

	/**
	 * To convert Non Fed Map to Fed JSON
	 * @param mOrder
	 * @return
	 */
	static def convertNFToF(mOrder) {

		def jOrder = StringBuilder.newInstance();
		List<String> keyPath = new ArrayList<String>();
		convertMapToJson(mOrder, jOrder,false,keyPath);
		log.info( 'Order in JSON Format >>>>> : ' + jOrder );
		return jOrder;
	}

	/**
	 * To convert Fed Map to Fed JSON or Non Fed Map to Non Fed JSON
	 * @param mOrder
	 * @return
	 */
	static def convertXToX(mOrder) {
		def jOrder = new JSONObject(mOrder).toString()
		log.info( 'Order in JSON Format >>>>> : ' + jOrder);
		return jOrder;
	}

	/**
	 * Method to lookup the FedTransforamtion Key file 
	 * @param key
	 * @return
	 */
	static def getMapFandNF(String key,Boolean fedIndicator){
		log.debug('ATGHelper.getMapNFFromF <-- Entering');
		if(!FtoNFMap || !NFtoFMap){
			FtoNFMap = new LinkedHashMap<String,Object>()
			NFtoFMap  = new LinkedHashMap<String,Object>()
			InputStream configStream = ATGHelper.class.getResourceAsStream("/config/FedToNonFed.xml");
			def config = IOUtils.toString(configStream, StandardCharsets.UTF_8.name());
			def jsonObj = XML.toJSONObject(config)
			log.debug('ATGHelper.getMapNFFromF: Response from jsonObj:'+jsonObj);
			def jsonStrng=new JsonSlurper().parseText(jsonObj.toString());
			log.debug('ATGHelper.getMapNFFromF: Response from jsonStrng:'+jsonStrng);
			jsonStrng.ajscConfig?.elementNameChanges?.entry.each{e ->
				FtoNFMap.put(e.key,e.value)
				NFtoFMap.put(e.value,e.key);
			}
			log.debug('ATGHelper.getMapNFFromF: configMap-->\n'+FtoNFMap);
		}
		def keyValue = !fedIndicator?FtoNFMap.get(key):NFtoFMap.get(key)
		if(keyValue!=null){
			if(keyValue.contains("/")){
				String[] bits = keyValue.split("/");
				keyValue = bits[bits.length-1];
			}
		}
		log.debug('ATGHelper.getMapNFFromF <--'+ key + '=='+keyValue)
		return keyValue
	}


	/**
	 * Method to convert given Map into a JSON String
	 * @param map
	 * @param json
	 * @param fedIndicator
	 * @param keyPath
	 * @return
	 */
	static def convertMapToJson(Map map,json,boolean fedIndicator,List keyPath){
		keyPath = (keyPath == null) ? [] : keyPath
		if(map.keySet().size()== 0){
			json <<= '{}';
		}else{
			json <<= '{';
			map.each { k,v ->
				keyPath.add(k);
				String tempKey = keyPath.join("/");
				if(tempKey!="order/shippingDetails/shippingDetail/shipmentCommitDate")
				{ 
				json <<= '"';
				def key = (fedIndicator)? translateFtoNFKey(k,json,keyPath) : translateNFtoFKey(k,json,keyPath)
				json <<= key;
				json <<= '" : ';
				if (v instanceof List){
					convertListToJson(v,json,fedIndicator,keyPath)
					json <<= ',';
				} else if (v instanceof Map){
					convertMapToJson(v,json,fedIndicator,keyPath)
					json <<= ','
				} else {
					if(key == 'priceType' && v == 'DueToday'){
						json <<= '"';
						json <<= 'DUE_TODAY';
						json <<= '",';
					}
					else if(key == 'PriceType' && v == 'DUE_TODAY'){
						json <<= '"';
						json <<= 'DueToday';
						json <<= '",';
					}
					else if(key == 'SecurityAnswer' || key == 'DOB' || key == 'PassCode'){
						json <<= '"';
						json <<= v;
						json <<= '",';
					}
					else if((v instanceof String) && !v.contains("&")){
						json <<= '"';
						json <<= TransformationService.escapeHtml(v?.toString())?.replaceAll("\\s+", " ")
						json <<= '",';
					}
					else if(v instanceof Long || v instanceof Double || v instanceof Integer || v instanceof Boolean){
						json <<= v;
						json <<= ",";
					}
					else{
						json <<= '"';
						json <<= StringEscapeUtils.escapeJava(v?.toString())?.replaceAll("\\s+", " ")
						json <<= '",';
					}
				}
				}
				keyPath.remove(k);
			}
			if(json.toString().endsWith(','))
				json.setLength(json.length() - 1)

			json <<= '}';
		}
	}
	/**
	 * Method to convert given List into a JSON String
	 * @param list
	 * @param json
	 * @param fedIndicator
	 * @param keyPath
	 * @return
	 */
	static def convertListToJson(List list,json,boolean fedIndicator,List keyPath){
		
		if(list.size() == 0){
			json <<= '[]';
		}
		else{
			json <<= '['
			list.each { l ->
				if (l instanceof List){
					convertListToJson(l,json,fedIndicator,keyPath);
					json <<= ','
				} else if (l instanceof Map){
					convertMapToJson(l,json,fedIndicator,keyPath);
					json <<= ','
				} else {
					json <<= '"'
					json <<= l?.toString()?.replaceAll("\\s+", " ")
					json <<= '"'
					json <<= ','
				}
			}

			if(json.toString().endsWith(','))
				json.setLength(json.length() - 1);

			json <<= ']';
		}
	}

	/**
	 * Method to translate the Fed JSON keys into Non Fed JSON keys
	 * @param k
	 * @param json
	 * @param keyPath
	 * @return
	 */
	static def translateFtoNFKey(k,json,List keyPath){

		String tempKey = keyPath.join("/");
		log.debug('ATGHelper.translateFtoNFKey: tempKey:'+tempKey);
		def isKey
		isKey=getMapFandNF(tempKey,false)

		log.debug('ATGHelper.translateFtoNFKey: Key['+tempKey+']'+isKey);
		if(isKey == null){
			isKey=getMapFandNF(k,false)
			log.debug('ATGHelper.translateFtoNFKey: Key['+k+']'+isKey);
			if(isKey==null){
				log.debug('ATGHelper.translateFtoNFKey: Not able to locate the key from Transformation lookup');
			}
			else{
				k=isKey
				return k;
			}
		}
		else{
			k=isKey
			return k;
		}

		log.debug('ATGHelper.translateFtoNFKey: Proceeding to default strategy to transalate key');

		if(k == 'order/shippingDetails/shippingDetail/sequence'){k = 'ShippingInfoSequence'}
		else if(k == 'order/paymentOptions/paymentOption/sequence'){k = 'PaymentSequence'}
		else if(k == 'order/accounts/account/sequence'){k = 'AccountSequenceNumber'}
		else if(k == 'order/uDLs/uDL/sequence'){k = 'SequenceNumber'}
		else if(k == 'order/promotions/promotion/sequence'){k = 'DisplaySequence'}
		else if(k == 'order/productGroups/group/characteristics/losgCharacteristics/sequence'){k = 'LoSGSequenceNumber'}
		else if(k == 'order/productGroups/group/sequence'){k = 'Sequence'}
		else if(k == 'order/lineItems/lineItem/sequence'){k = 'LineItemSequence'}
		else if(k == 'order/orderSource/sequence'){k = 'SequenceNumber'}
		else if(k== 'order/productGroups/group/characteristics'){k = 'GroupCharacteristics'}
		else if (k == 'productGroups'){k = 'Groups'}
		else if (k == 'id'){k = 'Id'}
		else if(k== 'tradeInDetail'){k='TradeInInfo'}
		else if(k== 'supplyChainDetail'){k='SupplyChainInfo'}
		else if (k == 'safeScanPassIndicator'){k='SafeScanPassIndicator'}
		else if (k == 'saveProfileIndicator'){k='SaveProfileIndicator'}
		else if (k == 'consentUpdatedInCAPMIndicator'){k='IsConsentUpdatedInCAPM'}
		else if (k == 'planAndFeatureUpdatedIndicator'){k='IsPlanAndFeatureUpdated'}
		else if (k == 'paperlessBillingUpdatedIndicator'){k='IsPaperlessBillingUpdated'}
		else if (k == 'safeScanAlertIndicator'){k='SafeScanAlertIndicator'}
		else if (k == 'singleCreditQueryWirelessIndicator'){k='SingleCreditQueryWirelessIndicator'}
		else if(k== 'creditCardHolderName'){ k = 'creditCardHolderName'}
		else if(k== 'employerDetail'){ k = 'EmployerInfo'}
		else if(k == 'newAEUCheckerIndicator'){k='NewAEUChecker'}
		else if (k == 'byodIndicator'){k='BYOD'}
		else if (k == 'productSKU')
			k = 'ProductSku';
		else if (k == 'taxDetail')
			k = 'TaxInfo';
		else if (k == 'lineItemTaxes')
			k = 'LineItemTax';
		else if (k == 'taxLineId')
			k = 'TaxLineID';
		else if (k == 'skuSpecific')
			k = 'SKUSpecificIndicator';
		else if (k == 'taxable')
			k = 'TaxableIndicator';
		else if (k.endsWith('TaxAreaId'))
			k = k.replace('TaxAreaId','TaxAreaID').capitalize();
		else if (k.startsWith('capm'))
			k = k.replace('capm','CAPM');
		else if (k == 'upgradeQualificationDetails')
			k = 'UpgradeQualificationInfo'
		else if (k == 'termsAndConditions')
			k = 'TCs'
		else if (k == 'termsAndConditionAccepted')
			k = 'TCAccepted'
		else if (k == 'orderLevelIndicator')
			k = 'IsOrderLevel'
		else if (k == 'termsAndConditionReferences')
			k = 'TCRefs'
		else if (k == 'termsAndConditionReference')
			k = 'TCRef'
		else if (k == 'additionalContactPhones')
			k = 'AdditionalContactPhone'
		else if (k == 'locationId')
			k = 'LocationID'
		else if (k == 'taxExemptIndicator')
			k = 'TaxExemptInd'
		else if (k == 'nciEligibleIndicator')
			k = 'isNCIEligible'
		else if (k == 'ssnRefusedIndicator')
			k = 'SSNRefusedIndicator'
		else if (k == 'defaultPacketDataProtocolIndicator')
			k = 'IsDefaultPDP'
		else if (k == 'shippedHotIndicator')
			k = 'IsShippedHot'
		else if (k == 'primaryContactPhones')
			k = 'PrimaryContactPhone'
		else if (k == 'billingDetail')
			k = 'BillingInfo'
		else if (k == 'msrp')
			k = 'MSRP'
		else if (k == 'btm')
			k = 'BTM'
		else if (k == 'wirelessLOSCharacteristics')
			k = 'WirelessLOSChars'
		else if (k == 'numberOfInstallment')
			k = 'NoOfInstallment'
		else if (k == 'systemOrderReferenceType')
			k = 'SystemOrderRefType'
		else if (k == 'employerPhoneNumber')
			k = 'EmployerPhoneNum'
		else if (k == 'creditCheckManagementTransactionId')
			k = 'CCMTransactionID'
		else if (k == 'expressPayDetailHeld')
			k = 'ExpressPayInfoHeld'
		else if (k == 'conflictingServiceDetailReferences')
			k = 'ConflictingServiceInfoRef'
		else if (k == 'usoc')
			k = 'USOC'
		else if (k == 'zodiacSequenceNumber')
			k = 'ZodSequenceNo'
		else if (k == 'schedulingDetailReference')
			k = 'SchedulingInfoRef'
		else if (k == 'siteAddressId')
			k = 'SiteAddrId'
		else if (k == 'groupReferencesCode')
			k = 'GroupReferenceCode'
		else if (k == 'e911DetailReference')
			k = 'E911InfoRef'
		else if (k == 'shippingDetailReference')
			k = 'ShippingInfoRef'
		else if (k == 'tcreferences')
			k = 'TCRefs'
		else if (k == 'ssn')
			k = 'SSN'
		else if (k == 'localExchangeRoutingGuideLocalRoutingNumber')
			k = 'LERGLRN'
		else if (k == 'e911ServiceRoutingNumber')
			k = 'ESRN'
		else if (k == 'lightspeedLocalRoutingNumber')
			k = 'LSLRN'
		else if (k == 'ospAccountNumber')
			k = 'OSPAccountNumber'
		else if (k == 'voipLOSCharacteristics')
			k = 'VOIPLOSChars'
		else if (k == 'iptvLOSCharacteristics')
			k = 'IPTVLOSChars'
		else if (k == 'userDefinedLabels')
			k = 'UDLs'
		else if (k == 'userDefinedLabel')
			k = 'UDL'
		else if (k == 'voipLineItemCharacteristics')
			k = 'VOIPLineItemChars'
		else if (k == 'uverseMessaging')
			k = 'UVerseMessaging'
		else if (k == 'iptvLineItemCharacteristics')
			k = 'IPTVLineItemChars'
		else if (k == 'packetDataProtocolType')
			k = 'PDPType'
		else if (k == 'ipversionType')
			k = 'IPVersionType'
		else if (k == 'ipv6Address')
			k = 'IPv6Address'
		else if (k == 'ipAddress')
			k = 'IPAddress'
		else if (k == 'attDynamicTrafficManager')
			k = 'ADTM'
		else if (k == 'cardSerialNumber')
			k = 'CSN'
		else if (k == 'iccId')
			k = 'ICCID'
		else if (k == 'primaryContactPhones')
			k = 'PrimaryContactPhone'
		else if (k == 'additionalContactPhones')
			k = 'AdditionalContactPhone'
		else if (k == 'dob')
			k = 'DOB'
		else if (k == 'ssnRefusedIndicator')
			k = 'SSNRefusedIndicator'
		else if (k == 'addressLines')
			k = 'AddressLine'
		else if (k == 'electronicIdNumber')
			k = 'EIDNumber'
		else if (k == 'electronicIdVerifierRequired')
			k = 'EIDVerifierRequired'
		else if (k == 'electronicIdVerifierLaunched')
			k = 'EIDVerifierLaunched'
		else if (k == 'electronicIdVerifierResults')
			k = 'EIDVerifierResults'
		else if (k == 'customerApprovalSystemTransactionId')
			k = 'CASTransactionId'
		else if (k == 'debtAccounts')
			k = 'DebtAccount'
		else if (k == 'finalBillAccounts')
			k = 'FinalBillAccount'
		else if (k == 'electronicLetterOfAuthorization')
			k = 'ELOA'
		else if (k == 'ebillReason'){k='EBillReason'}
		else if (k == 'accountsReceivable'){k='AR'}
		else if (k == 'accountsReceivableIndicator'){k='ARIndicator'}
		else if (k == 'purchaseOrderNumber'){k='PONumber'}
		else if (k == 'btn'){k='BTN'}
		else if (k == 'tn'){k='TN'}
		else if (k == 'btm'){k='BTM'}
		else if (k == 'ach'){k='ACH'}
		else if (k == 'capm'){k='CAPM'}
		else if (k == 'addressVerificationSystemCode'){k='AVScode'}
		else if (k == 'capmlast4Digits'){k='CAPMLast4Digits'}
		else if (k == 'lpmReferenceNumber'){k='LPMReferenceNumber'}
		else if (k == 'lpmPaymentType'){k='LPMPaymentType'}
		else if (k == 'lpmPaymentTypeName'){k='LPMPaymentTypeName'}
		else if (k == 'lpmLast4Digits'){k='LPMLast4Digits'}
		else if (k == 'componentConfigurations'){k='ComponentConfiguration'}
		else if (k == 'connecTechInstallationOptions'){k='ConnectechInstallationOption'}
		else if (k == 'validations'){k='Validation'}
		else if (k == 'potsAvailableIndicator'){k='IsPOTSAvailable'}
		else if (k == 'dslAvailableIndicator'){k='IsDSLAvailable'}
		else if (k == 'productDetails'){k='ProductDetail'}
		else if (k == 'dslmemberDetail'){k='DSLMemberInfo'}
		else if (k == 'termsAndCondition911'){k='TC911'}
		else if (k == 'referralEmployeeUId'){k='ReferralEmpUId'}
		else if (k == 'termsAndConditions'){k='TCs'}
		else if (k == 'premierResourceCenterTicketNumber'){k='PRCTicketNumber'}
		else if (k == 'falloutDescription'){k='FalloutDesc'}
		else if (k == 'packetDataProtocol'){k='PDP'}
		else if (k == 'usoc'){k='USOC'}
		else if (k == 'orderDocumentDetail'){k='OrderDocumentInfo'}
		else if (k == 'currentServiceProviderId'){k='CurrentSPID'}
		else if (k == 'upgradeQualificationDetails'){k='UpgradeQualificationDetail'}
		else if (k == 'termsAndConditionAccepted'){k='TCAccepted'}
		else if (k == 'termsAndConditionReferences'){k='TCRefs'}
		else if (k == 'termsAndConditionReference'){k='TCRef'}
		else if (k == 'upgradeQualificationDetails'){k='UpgradeQualificationInfo'}
		else if (k == 'operationNames'){k='OperationName'}
		else if (k == 'usoc'){k='Usoc'}
		else if (k == 'addAccountGUId'){k='AddAccountGUID'}
		else if (k == 'skuSpecific'){k='SKUSpecificIndicator'}
		else if (k == 'autoBill'){k='AutoBillIndicator'}
		else if (k == 'FixedAmount'){k='IsFixedAmount'}
		else if (k == 'taxable'){k='TaxableIndicator'}
		else if (k == 'gigaPower'){k='GigaPowerIndicator'}
		else if (k == 'thirdPartyCombinedBill'){k='ThirdPartyCombinedBillIndicator'}
		else if (k == 'unifiedAccountPending'){k='UnifiedAccountPendingIndicator'}
		else if (k == 'unifiedAccountExisting'){k='UnifiedAccountExistingIndicator'}
		else if (k == 'convergedBilling'){k='ConvergedBillingIndicator'}
		else if (k == 'previousAddress'){k='PreviousAddressIndicator'}
		else if (k == 'homeAlarmSystem'){k='HomeAlarmSystemIndicator'}
		else if (k == 'proprietarySegment'){k='ProprietarySegmentIndicator'}
		else if (k == 'equipmentUpgrade'){k='EquipmentUpgradeIndicator'}
		else if (k == 'orderChange'){k='OrderChangeIndicator'}
		else if (k == 'internetProtocolDigitalSubscriberLineAccess'){k='IPDSLAIndicator'}
		else if (k == 'callerId'){k='CallerIdIndicator'}
		else if (k == 'ctnValidatedIndicator'){k='CTNValidated'}
		else if (k == 'cardNotValidatedIndicator'){k='CardNotValidated'}
		else if (k == 'delinquentAccountIndicator'){k='DelinquentAccount'}
		else if (k == 'consentToCCIndicator'){k='ConsentToCC'}
		else if (k == 'convergeOrderIndicator'){k='ConvergeOrder'}
		else if (k == 'convergeValidationIndicator'){k='ConvergeValidation'}
		else if (k == 'newAEUCheckerIndicator'){k='NewAEUChecker'}
		else if (k == 'asyncResponseIndicator'){k='AsyncResponse'}
		else if (k == 'creditCheckRanIndicator'){k='CCRan'}
		else if (k == 'orderConfirmationByEmailPermissionIndicator'){k='OrderConfirmationByEmailPermission'}
		else if (k == 'productUpdatesByEmailPermissionIndicator'){k='ProductUpdatesByEmailPermission'}
		else if (k == 'unpublishedContactByPhonePermissionIndicator'){k='UnpublishedContactByPhonePermission'}
		else if (k == 'permissionForOutboundCallIndicator'){k='PermissionForOutboundCall'}
		else if (k == 'referallOfCallsIndicator'){k='ReferallOfCalls'}
		else if (k == 'authenticatedIndicator'){k='Authenticated'}
		else if (k == 'reuseDSLMemberIdIndicator'){k='Reuse_DSLMemberId'}
		else if (k == 'ltePacketDataProtocolIndicator'){k='IsLTEPDP'}
		else if (k == 'byodIndicator'){k='BYOD'}
		else if (k == 'preOrderIndicator'){k='PreOrder'}
		else if (k == 'scheduleAsSoonAsPossibleIndicator'){k='ScheduleAsSoonAsPossible'}
		else if (k == 'billingInstallmentsIndicator'){k='BillingInstallments'}
		else if (k == 'omitAddressIndicator'){k='OmitAddress'}
		else if (k == 'releaseDetailForBillingIndicator'){k='ReleaseInfoForBilling'}
		else if (k == 'rsagValidationIndicator'){k='RsagValidation'}
		else if (k == 'b2bSkipUpgradeEligibilityIndicator'){k='B2BskipUpgradeEligibility'}
		else if (k == 'b2bIgnoreDepositRequiredIndicator'){k='B2BIgnoreDepositRequired'}
		else if (k == 'b2bMIRIneligibleIndicator'){k='B2BMIRIneligible'}
		else if (k == 'taxExemptIndicator'){k='TaxExemptInd'}
		else if (k == 'equipmentInstallmentPlanIndicator'){k='IsEIP'}
		else if (k == 'componentMapRequiredIndicator'){k='ComponentMapRequired'}
		else if (k == 'direcTVLOSCharacteristics'){k='DirecTVLOSChars'}
		else if (k == 'internetLOSCharacteristics'){k='InternetLOSChars'}
		else if (k == 'wirelessLOSCharacteristics'){k='WirelessLOSChars'}
		else if (k == 'direcTVLineItemCharacteristics'){k='DirecTVLineItemChars'}
		else if (k == 'internetLineItemCharacteristics'){k='InternetLineItemChars'}
		else if (k == 'wirelessLineItemCharacteristics'){k='WirelessLineItemChars'}
		else if (k == 'wirelessHardGoodCharacteristics'){k='WirelessHardGoodChars'}
		else if (k == 'numberLinesRequired'){k='NumberLinesReq'}
		else if (k == 'losgCharacteristics'){k='LoSGCharacteristics'}
		else if (k == 'losgReferenceId'){k='LoSGReferenceId'}
		else if (k == 'losgType'){k='LoSGType'}
		else if (k == 'losgStatus'){k='LoSGStatus'}
		else if (k == 'shadowLocalRoutingNumber'){k='ShadowLRN'}
		else if (k == 'installmentPlanDefinition'){k='InstallmentPlanDef'}
		else if (k == 'fieldId'){k='Fid'}
		else if (k == 'losgReferenceId'){k='LoSGReferenceId'}
		else if (k == 'internationalMobileSubscriberIdentity'){k='Imsi'}
		else if (k == 'primaryNPANXX'){k='PrimaryNpaNxx'}
		else if (k == 'lastNetworkAccessDeviceType'){k='LastNADType'}
		else if (k == 'codingAccuracySupportSystemAddress'){k='CassAddress'}
		else if (k == 'numberApprovedLines'){k='NumberApprLines'}
		else if (k == 'letterOfAuthorizationURL'){k='LoaURL'}
		else if (k == 'connecTechServiceDate'){k='ConnectechServiceDate'}
		else if (k == 'b2bs'){k='B2Bs'}
		else if (k == 'b2b'){k='B2B'}
		else if (k == 'b2bContractProvider'){k='B2BContractProvider'}
		else if (k == 'b2bContractType'){k='B2BContractType'}
		else if (k == 'b2bSalesRepCode'){k='B2BSalesRepCode'}
		else if (k == 'b2bFAN'){k='B2BFAN'}
		else if (k == 'b2bSIBEnrollment'){k='B2BsibEnrollment'}
		else if (k == 'b2bFANBusinessName'){k='B2BFANBusinessName'}
		else if (k == 'centralizedEmployeeTableId'){k='CenetId'}
		else if (k == 'crsmOnFlag'){k='CRSMOnFlag'}		
		else if (k == 'ctn'){k='CTN'}
		else if (k == 'vin'){k='VIN'}
		else if (k == 'cpni'){k='CPNI'}
		else if (k == 'eid'){k='EID'}
		else if (k == 'employerPhoneNumber'){k='EmployerPhoneNum'}
		else if (k == 'structureNumber'){k='StructureNum'}
		else if (k == 'levelNumber'){k='LevelNum'}
		else if (k == 'apartmentUnitNumber'){k='ApartmentUnitNum'}
		else if (k == 'schedulingDetails'){k='SchedulingInfos'}
		else if (k == 'schedulingDetail'){k='SchedulingInfo'}
		else if (k == 'shippingDetails'){k='ShippingInfos'}
		else if (k == 'shippingDetail'){k='ShippingInfo'}
		else if (k == 'agentUId'){k='AgentUID'}
		else if (k == 'referralEmployeeUId'){k='ReferralEmpUID'}
		else if (k == 'selectedOptionId'){k='SelectedOptionID'}
		else if (k == 'merchantId'){k='MerchantID'}
		else if (k == 'orderTaxAreaId'){k='OrderTaxAreaID'}
		else if (k == 'shipFromTaxAreaId'){k='ShipFromTaxAreaID'}
		else if (k == 'shipToTaxAreaId'){k='ShipToTaxAreaID'}
		else if (k == 'exemptionId'){k='ExemptionID'}
		else if (k == 'taxLineId'){k='TaxLineID'}
		else if (k == 'customerId'){k='CustomerID'}
		else if (k == 'installmentPlanId'){k='InstallmentPlanID'}
		else if (k == 'creditCheckManagementTransactionId'){k='CCMTransactionID'}
		else if (k == 'enterpriseId'){k='EnterpriseID'}
		else if (k == 'siteAddressId'){k='SiteAddrId'}
		else if (k == 'browserId'){k='BrowserID'}
		else if (k == 'selectedOptionId'){k='SelectedOptionID'}
		else if (k == 'repId'){k='RepID'}
		else if (k == 'storeId'){k='StoreID'}
		else if (k == 'dealerId'){k='DealerID'}
		else if (k == 'newSalesChannelId'){k='NewSalesChannelID'}
		else if (k == 'installmentPlanId'){k='InstallmentPlanID'}
		else if (k == 'locationId'){k='LocationID'}
		else if (k == 'iccId'){k='ICCID'}
		else if (k == 'addAccountGUId'){k='AddAccountGUID'}
		else if (k == 'callerId'){k='CallerIdIndicator'}
		else if (k == 'losgReferenceId'){k='LoSGReferenceId'}
		else if (k == 'fieldId'){k='Fid'}
		else if (k == 'losgReferenceId'){k='LoSGReferenceId'}
		else if (k.startsWith('submitted'))
			k = k.replace('submitted','Submited')
		else if (k == 'b2bReference'){
			k = 'B2BRef'
		} else if (k.startsWith('losg'))
			k = k.replace('losg','LoSG')
		else if (k.startsWith('b2b'))
			k = k.replace('b2b','B2B')
		else
			k = k.capitalize()
		return k
	}


	/**
	 * Method to translate the Non Fed JSON keys into Fed JSON keys
	 * @param k
	 * @param json
	 * @param keyPath
	 * @return
	 */
	static def translateNFtoFKey(k,json,v){
		def isKey
		isKey=getMapFandNF(k,true)
		log.debug('ATGHelper.translateNFtoFKey: Key['+k+']'+isKey);
		if(isKey==null){
			log.debug('ATGHelper.translateNFtoFKey: Not able to locate the key from Transformation lookup');
		}
		else{
			k=isKey
			return k;
		}
		if (k == 'Groups')
			k = 'productGroups'
		else if (k == 'Sequence' || k == 'LoSGSequenceNumber' || k == 'LineItemSequence' || k == 'AccountSequenceNumber' || k == 'PaymentSequence' || k == 'SequenceNumber')
			k = 'sequence'
		else if (k == 'Id')
			k = 'id'
		else if (k == 'OCEOrderNumber')
			k = 'oceOrderNumber'
		else if (k == 'UpgradeQualificationInfo')
			k = 'upgradeQualificationDetails'
		else if (k == 'TCs')
			k = 'termsAndConditions'
		else if (k == 'TCAccepted')
			k = 'termsAndConditionAccepted'
		else if (k == 'TCRefs')
			k = 'termsAndConditionReferences'
		else if (k == 'TCRef')
			k = 'termsAndConditionReference'
		else if (k == 'AdditionalContactPhone')
			k = 'additionalContactPhones'
		else if (k == 'LocationID')
			k = 'locationId'
		else if (k == 'TaxExemptInd')
			k = 'taxExemptIndicator'
		else if (k == 'PrimaryContactPhone')
			k = 'primaryContactPhones'
		else if (k == 'LineItemTax')
			k = 'lineItemTaxes'
		else if (k == 'isNCIEligible')
			k = 'nciEligibleIndicator'
		else if (k == 'AVScode')
			k = 'addressVerificationSystemCode'
		else if (k == 'MSRP')
			k = 'msrp'
		else if (k == 'BTM')
			k = 'btm'
		else if (k == 'ProductSku')
			k = 'productSKU'
		else if (k == 'NoOfInstallment'){
			k = 'numberOfInstallment'
		}
		else if (k == 'SystemOrderRefType'){
			k = 'systemOrderReferenceType'
		}
		else if(k == 'NewAEUChecker'){
			k='newAEUCheckerIndicator'
		}
		else if (k == 'EmployerPhoneNum'){
			k = 'employerPhoneNumber'
		}
		else if (k == 'CCMTransactionID'){
			k = 'creditCheckManagementTransactionId'
		}
		else if (k == 'ExpressPayInfoHeld'){
			k = 'expressPayDetailHeld'
		}
		else if (k == 'ConflictingServiceInfoRef'){
			k = 'conflictingServiceDetailReference'
		}
		else if (k == 'IsDefaultPDP'){
			k = 'defaultPacketDataProtocolIndicator'
		}
		else if (k == 'IsShippedHot'){
			k = 'shippedHotIndicator'
		}
		else if (k == 'SiteAddrId'){
			k = 'siteAddressId'
		}
		else if (k == 'GroupReferenceCode'){
			k = 'groupReferencesCode'
		}
		else if (k == 'E911InfoRef'){
			k = 'e911DetailReference'
		}
		else if (k == 'ShippingInfoRef'){
			k = 'shippingDetailReference'
		}
		else if (k == 'TCRefs'){
			k = 'tcreferences'
		}
		else if (k == 'SSN'){
			k = 'ssn'
		}
		else if (k == 'LERGLRN'){
			k = 'localExchangeRoutingGuideLocalRoutingNumber'
		}
		else if (k == 'LSLRN'){
			k = 'lightspeedLocalRoutingNumber'
		}
		else if (k == 'OSPAccountNumber'){
			k = 'ospAccountNumber'
		}
		else if (k == 'VOIPLOSChars'){
			k = 'voipLOSCharacteristics'
		}
		else if (k == 'IPTVLOSChars'){
			k = 'iptvLOSCharacteristics'
		}
		else if (k == 'UDLs'){
			k = 'userDefinedLabels'
		}
		else if (k == 'UDL'){
			k = 'userDefinedLabel'
		}
		else if (k == 'SOCForPreviousDevice'){
			k = 'socForPreviousDevice'
		}
		else if (k == 'VOIPLineItemChars'){
			k = 'voipLineItemCharacteristics'
		}
		else if (k == 'UVerseMessaging'){
			k = 'uverseMessaging'
		}
		else if (k == 'ZodSequenceNo'){
			k = 'zodiacSequenceNumber'
		}
		else if (k == 'IsPreAuthReleased'){k='preAuthReleasedIndicator'}
		else if (k == 'ASSuccessFlag'){k='asSuccessFlag'}
		else if (k == 'SafeScanPassIndicator'){k='safeScanPassIndicator'}
		else if(k == 'SaveProfileIndicator'){k= 'saveProfileIndicator'}
		else if (k == 'IsConsentUpdatedInCAPM'){k='consentUpdatedInCAPMIndicator'}
		else if (k == 'IsPlanAndFeatureUpdated'){k='planAndFeatureUpdatedIndicator'}
		else if (k == 'IsPaperlessBillingUpdated'){k='paperlessBillingUpdatedIndicator'}
		else if (k == 'SafeScanAlertIndicator'){k='safeScanAlertIndicator'}
		else if (k == 'SingleCreditQueryWirelessIndicator'){k='singleCreditQueryWirelessIndicator'}
		else if (k  ==  'IPTVLineItemChars'){k=  'iptvLineItemCharacteristics'}
		else if (k  ==  'isNCIEligible'){k=  'nciEligibleIndicator'}
		else if (k  ==  'PDPType'){k=  'packetDataProtocolType'}
		else if (k  ==  'IPVersionType'){k=  'ipversionType'}
		else if (k  ==  'IPv6Address'){k=  'ipv6Address'}
		else if (k  ==  'IPAddress'){k=  'ipAddress'}
		else if (k  ==  'ADTM'){k=  'attDynamicTrafficManager'}
		else if (k  ==  'CSN'){k=  'cardSerialNumber'}
		else if (k  ==  'ICCID'){k=  'iccId'}
		else if (k  ==  'PrimaryContactPhone'){k=  'primaryContactPhones'}
		else if (k  ==  'AdditionalContactPhone'){k=  'additionalContactPhones'}
		else if (k  ==  'DOB'){k=  'dob'}
		else if (k  ==  'SSNRefusedIndicator'){k=  'ssnRefusedIndicator'}
		else if (k  ==  'AddressLine'){k=  'addressLines'}
		else if (k  ==  'EIDNumber'){k=  'electronicIdNumber'}
		else if (k  ==  'EIDVerifierRequired'){k=  'electronicIdVerifierRequired'}
		else if (k  ==  'EIDVerifierLaunched'){k=  'electronicIdVerifierLaunched'}
		else if (k  ==  'EIDVerifierResults'){k=  'electronicIdVerifierResults'}
		else if (k  ==  'CASTransactionId'){k=  'customerApprovalSystemTransactionId'}
		else if (k  ==  'DebtAccount'){k=  'debtAccounts'}
		else if (k  ==  'FinalBillAccount'){k=  'finalBillAccounts'}
		else if (k  ==  'ELOA'){k=  'electronicLetterOfAuthorization'}
		else if (k  ==  'EBillReason'){k=  'ebillReason'}
		else if (k  ==  'AR'){k=  'accountsReceivable'}
		else if (k  ==  'ARIndicator'){k=  'accountsReceivableIndicator'}
		else if (k  ==  'PONumber'){k=  'purchaseOrderNumber'}
		else if (k  ==  'BTN'){k=  'btn'}
		else if (k  ==  'TN'){k=  'tn'}
		else if (k  ==  'BTM'){k=  'btm'}
		else if (k  ==  'ACH'){k=  'ach'}
		else if (k  ==  'CAPM'){k=  'capm'}
		else if (k  ==  'AVScode'){k=  'addressVerificationSystemCode'}
		else if (k  ==  'CAPMLast4Digits'){k=  'capmlast4Digits'}
		else if (k  ==  'LPMReferenceNumber'){k=  'lpmReferenceNumber'}
		else if (k  ==  'LPMPaymentType'){k=  'lpmPaymentType'}
		else if (k  ==  'LPMPaymentTypeName'){k=  'lpmPaymentTypeName'}
		else if (k  ==  'LPMLast4Digits'){k=  'lpmLast4Digits'}
		else if (k  ==  'ComponentConfiguration'){k=  'componentConfigurations'}
		else if (k  ==  'ConnectechInstallationOption'){k=  'connecTechInstallationOptions'}
		else if (k  ==  'Validation'){k=  'validations'}
		else if (k  ==  'IsPOTSAvailable'){k=  'potsAvailableIndicator'}
		else if (k  ==  'IsDSLAvailable'){k=  'dslAvailableIndicator'}
		else if (k  ==  'ProductDetail'){k=  'productDetails'}
		else if (k  ==  'DSLMemberInfo'){k=  'dslmemberDetail'}
		else if (k  ==  'TC911'){k=  'termsAndCondition911'}
		else if (k  ==  'ReferralEmpUId'){k=  'referralEmployeeUId'}
		else if (k  ==  'TCs'){k=  'termsAndConditions'}
		else if (k  ==  'PRCTicketNumber'){k=  'premierResourceCenterTicketNumber'}
		else if (k  ==  'FalloutDesc'){k=  'falloutDescription'}
		else if (k  ==  'PDP'){k=  'packetDataProtocol'}
		else if (k  ==  'USOC'){k=  'usoc'}
		else if (k  ==  'OrderDocumentInfo'){k=  'orderDocumentDetail'}
		else if (k  ==  'CurrentSPID'){k=  'currentServiceProviderId'}
		else if (k  ==  'UpgradeQualificationDetail'){k=  'upgradeQualificationDetails'}
		else if (k  ==  'TCAccepted'){k=  'termsAndConditionAccepted'}
		else if (k  ==  'TCRefs'){k=  'termsAndConditionReferences'}
		else if (k  ==  'TCRef'){k=  'termsAndConditionReference'}
		else if (k  ==  'UpgradeQualificationInfo'){k=  'upgradeQualificationDetails'}
		else if (k  ==  'OperationName'){k=  'operationNames'}
		else if (k  ==  'Usoc'){k=  'usoc'}
		else if (k  ==  'AddAccountGUID'){k=  'addAccountGUId'}
		else if (k  ==  'SKUSpecificIndicator'){k=  'skuSpecific'}
		else if (k  ==  'AutoBillIndicator'){k=  'autoBill'}
		else if (k  ==  'IsFixedAmount'){k=  'FixedAmount'}
		else if (k  ==  'TaxableIndicator'){k=  'taxable'}
		else if (k  ==  'GigaPowerIndicator'){k=  'gigaPower'}
		else if (k  ==  'ThirdPartyCombinedBillIndicator'){k=  'thirdPartyCombinedBill'}
		else if (k  ==  'UnifiedAccountPendingIndicator'){k=  'unifiedAccountPending'}
		else if (k  ==  'UnifiedAccountExistingIndicator'){k=  'unifiedAccountExisting'}
		else if (k  ==  'ConvergedBillingIndicator'){k=  'convergedBilling'}
		else if (k  ==  'PreviousAddressIndicator'){k=  'previousAddress'}
		else if (k  ==  'HomeAlarmSystemIndicator'){k=  'homeAlarmSystem'}
		else if (k  ==  'ProprietarySegmentIndicator'){k=  'proprietarySegment'}
		else if (k  ==  'EquipmentUpgradeIndicator'){k=  'equipmentUpgrade'}
		else if (k  ==  'OrderChangeIndicator'){k=  'orderChange'}
		else if (k  ==  'IPDSLAIndicator'){k=  'internetProtocolDigitalSubscriberLineAccess'}
		else if (k  ==  'CallerIdIndicator'){k=  'callerId'}
		else if (k  ==  'CTNValidated'){k=  'ctnValidatedIndicator'}
		else if (k  ==  'CardNotValidated'){k=  'cardNotValidatedIndicator'}
		else if (k  ==  'DelinquentAccount'){k=  'delinquentAccountIndicator'}
		else if (k  ==  'ConsentToCC'){k=  'consentToCCIndicator'}
		else if (k  ==  'ConvergeOrder'){k=  'convergeOrderIndicator'}
		else if (k  ==  'ConvergeValidation'){k=  'convergeValidationIndicator'}
		else if (k  ==  'NewAEUChecker'){k=  'newAEUCheckerIndicator'}
		else if (k  ==  'AsyncResponse'){k=  'asyncResponseIndicator'}
		else if (k  ==  'CCRan'){k=  'creditCheckRanIndicator'}
		else if (k  ==  'OrderConfirmationByEmailPermission'){k=  'orderConfirmationByEmailPermissionIndicator'}
		else if (k  ==  'ProductUpdatesByEmailPermission'){k=  'productUpdatesByEmailPermissionIndicator'}
		else if (k  ==  'UnpublishedContactByPhonePermission'){k=  'unpublishedContactByPhonePermissionIndicator'}
		else if (k  ==  'PermissionForOutboundCall'){k=  'permissionForOutboundCallIndicator'}
		else if (k  ==  'ReferallOfCalls'){k=  'referallOfCallsIndicator'}
		else if (k  ==  'Authenticated'){k=  'authenticatedIndicator'}
		else if (k  ==  'Reuse_DSLMemberId'){k=  'reuseDSLMemberIdIndicator'}
		else if (k  ==  'IsLTEPDP'){k=  'ltePacketDataProtocolIndicator'}
		else if (k  ==  'BYOD'){k=  'byodIndicator'}
		else if (k  ==  'PreOrder'){k=  'preOrderIndicator'}
		else if (k  ==  'ScheduleAsSoonAsPossible'){k=  'scheduleAsSoonAsPossibleIndicator'}
		else if (k  ==  'BillingInstallments'){k=  'billingInstallmentsIndicator'}
		else if (k  ==  'OmitAddress'){k=  'omitAddressIndicator'}
		else if (k  ==  'ReleaseInfoForBilling'){k=  'releaseDetailForBillingIndicator'}
		else if (k  ==  'RsagValidation'){k=  'rsagValidationIndicator'}
		else if (k  ==  'B2BskipUpgradeEligibility'){k=  'b2bSkipUpgradeEligibilityIndicator'}
		else if (k  ==  'B2BIgnoreDepositRequired'){k=  'b2bIgnoreDepositRequiredIndicator'}
		else if (k  ==  'B2BMIRIneligible'){k=  'b2bMIRIneligibleIndicator'}
		else if (k  ==  'TaxExemptInd'){k=  'taxExemptIndicator'}
		else if (k  ==  'IsEIP'){k=  'equipmentInstallmentPlanIndicator'}
		else if (k  ==  'ComponentMapRequired'){k=  'componentMapRequiredIndicator'}
		else if (k  ==  'DirecTVLOSChars'){k=  'direcTVLOSCharacteristics'}
		else if (k  ==  'InternetLOSChars'){k=  'internetLOSCharacteristics'}
		else if (k  ==  'WirelessLOSChars'){k=  'wirelessLOSCharacteristics'}
		else if (k  ==  'DirecTVLineItemChars'){k=  'direcTVLineItemCharacteristics'}
		else if (k  ==  'InternetLineItemChars'){k=  'internetLineItemCharacteristics'}
		else if (k  ==  'WirelessLineItemChars'){k=  'wirelessLineItemCharacteristics'}
		else if (k  ==  'WirelessHardGoodChars'){k=  'wirelessHardGoodCharacteristics'}
		else if (k  ==  'NumberLinesReq'){k=  'numberLinesRequired'}
		else if (k  ==  'LoSGCharacteristics'){k=  'losgCharacteristics'}
		else if (k  ==  'LoSGReferenceId'){k=  'losgReferenceId'}
		else if (k  ==  'LoSGType'){k=  'losgType'}
		else if (k  ==  'LoSGStatus'){k=  'losgStatus'}
		else if (k  ==  'ShadowLRN'){k=  'shadowLocalRoutingNumber'}
		else if (k  ==  'InstallmentPlanDef'){k=  'installmentPlanDefinition'}
		else if (k  ==  'Fid'){k=  'fieldId'}
		else if (k  ==  'LoSGReferenceId'){k=  'losgReferenceId'}
		else if (k  ==  'Imsi'){k=  'internationalMobileSubscriberIdentity'}
		else if (k  ==  'PrimaryNpaNxx'){k=  'primaryNPANXX'}
		else if (k  ==  'LastNADType'){k=  'lastNetworkAccessDeviceType'}
		else if (k  ==  'CassAddress'){k=  'codingAccuracySupportSystemAddress'}
		else if (k  ==  'NumberApprLines'){k=  'numberApprovedLines'}
		else if (k  ==  'LoaURL'){k=  'letterOfAuthorizationURL'}
		else if (k  ==  'ConnectechServiceDate'){k=  'connecTechServiceDate'}
		else if (k  ==  'B2Bs'){k=  'b2bs'}
		else if (k  ==  'B2B'){k=  'b2b'}
		else if (k  ==  'B2BContractProvider'){k=  'b2bContractProvider'}
		else if (k  ==  'B2BContractType'){k=  'b2bContractType'}
		else if (k  ==  'B2BSalesRepCode'){k=  'b2bSalesRepCode'}
		else if (k  ==  'B2BFAN'){k=  'b2bFAN'}
		else if (k  ==  'B2BsibEnrollment'){k=  'b2bSIBEnrollment'}
		else if (k  ==  'B2BFANBusinessName'){k=  'b2bFANBusinessName'}
		else if (k  ==  'CenetId'){k=  'centralizedEmployeeTableId'}
		else if (k  ==  'CRSMOnFlag'){k=  'crsmOnFlag'}
		else if (k  ==  'UUCPStatus'){k=  'uucpStatus'}	
		else if (k == 'IsShipmentInfoUpdated')	{k='shipmentInfoUpdatedIndicator'}
		else if (k == 'salesChannelType'){k = 'salesChannelType'}
		else if (k  ==  'CTN'){k= 'ctn'}
		else if (k  ==  'VIN'){k= 'vin'}
		else if (k  ==  'CPNI'){k= 'cpni'}
		else if (k  ==  'EID'){k=  'eid'}
		else if (k == 'SchedulingInfoRef'){
			k = 'schedulingDetailReference'
		}
		else if (k == 'IPTVLineItemChars'){
			k = 'iptvLineItemCharacteristics'
		}
		else if (k == 'PDPType'){
			k = 'packetDataProtocolType'
		}
		else if (k == 'usoc'){
			k = 'USOC'
		}
		else if (k == 'AgentUID'){k='agentUId'}
		else if (k == 'ReferralEmpUID'){k='referralEmployeeUId'}
		else if (k == 'SelectedOptionID'){k='selectedOptionId'}
		else if (k == 'MerchantID'){k='merchantId'}
		else if (k == 'OrderTaxAreaID'){k='orderTaxAreaId'}
		else if (k == 'ShipFromTaxAreaID'){k='shipFromTaxAreaId'}
		else if (k == 'ShipToTaxAreaID'){k='shipToTaxAreaId'}
		else if (k == 'ExemptionID'){k='exemptionId'}
		else if (k == 'TaxLineID'){k='taxLineId'}
		else if (k == 'CustomerID'){k='customerId'}
		else if (k == 'InstallmentPlanID'){k='installmentPlanId'}
		else if (k == 'CCMTransactionID'){k='creditCheckManagementTransactionId'}
		else if (k == 'EnterpriseID'){k='enterpriseId'}
		else if (k == 'SiteAddrId'){k='siteAddressId'}
		else if (k == 'BrowserID'){k='browserId'}
		else if (k == 'SelectedOptionID'){k='selectedOptionId'}
		else if (k == 'RepID'){k='repId'}
		else if (k == 'StoreID'){k='storeId'}
		else if (k == 'DealerID'){k='dealerId'}
		else if (k == 'NewSalesChannelID'){k='newSalesChannelId'}
		else if (k == 'InstallmentPlanID'){k='installmentPlanId'}
		else if (k == 'LocationID'){k='locationId'}
		else if (k == 'ICCID'){k='iccId'}
		else if (k == 'AddAccountGUID'){k='addAccountGUId'}
		else if (k == 'CallerIdIndicator'){k='callerId'}
		else if (k == 'LoSGReferenceId'){k='losgReferenceId'}
		else if (k == 'Fid'){k='fieldId'}
		else if (k == 'LoSGReferenceId'){k='losgReferenceId'}
		else if (k == 'EmployerPhoneNum'){k='employerPhoneNumber'}
		else if (k == 'StructureNum'){k='structureNumber'}
		else if (k == 'LevelNum'){k='levelNumber'}
		else if (k == 'ApartmentUnitNum'){k='apartmentUnitNumber'}
		else if (k == 'SchedulingInfos'){k='schedulingDetails'}
		else if (k == 'SchedulingInfo'){k='schedulingDetail'}
		else if (k == 'ShippingInfos'){k='shippingDetails'}
		else if (k == 'ShippingInfo'){k='shippingDetail'}
		else if (k == 'SKUSpecificIndicator')
			k == 'skuSpecific'
		else if (k == 'GroupCharacteristics' || k == 'Characteristics')
			k = 'characteristics'
		else if (k.startsWith('Submited'))
			k = k.replace('Submited','submitted')
		else if (k == 'B2BRef')
			k = 'b2bReference'
		else if (k.startsWith('LoSG'))
			k = k.replace('LoSG','losg')
		else if (k.startsWith('B2B'))
			k = k.replace('B2B','b2b')
		else if (k.startsWith('CAPM'))
			k = k.replace('CAPM','capm');
		else if (k.endsWith('Chars')){
			k == StringUtils.chomp(k,'Chars')+'Characteristics';
			k = StringUtils.uncapitalize(k);
		}
		else if (k.endsWith('Info')){
			k = StringUtils.chomp(k,'Info')+'Detail';
			k = StringUtils.uncapitalize(k);
		}
		else if (k.endsWith('Infos')){
			k = StringUtils.chomp(k,'Infos')+'Details';
			k = StringUtils.uncapitalize(k);
		}
		else if (k.startsWith('Is')){
			k = k.substring(2)+'Indicator';
			k = StringUtils.uncapitalize(k);
		}
		else if (k.endsWith('Refs')){
			k = k.replace('Refs','References');
			k = StringUtils.uncapitalize(k);
		}
		else if (k.endsWith('Ref')){
			k = k.replace('Ref','Reference')
			k = StringUtils.uncapitalize(k);
		}
		else
			k = StringUtils.uncapitalize(k);

		//		lastKey = k
		return k
	}
}
