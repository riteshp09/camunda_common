package com.att.oce.bpm.nf.transformations

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.error.APIFailedException
import org.apache.camel.Exchange
import org.springframework.stereotype.Component
import com.att.oce.bpm.common.OceConstants
import org.camunda.bpm.engine.impl.util.json.JSONObject
import org.camunda.bpm.engine.impl.util.json.XML
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.apache.commons.lang.StringEscapeUtils

@Component('fraudTransformation')
class FraudValidationTransformation extends TransformationService {

	static Logger log = LoggerFactory.getLogger(FraudValidationTransformation.class)
	
	String url;

	@Override
	String getApiName(){
		return OceConstants.API_NAME_FRAUD_VALIDATION_SERVICE
	}


	/*
	 * This function will do the transformation for Fraud Service
	 * @param exchange of type Camel Exchange
	 * */
	public def transform(Exchange exchange){
		log.info('FraudValidationTransformation.transform <-- Entering')
		
		def order = exchange.in.body.order;
		exchange.properties.put('order',order);
		exchange.properties.put("referenceId",order.CustomerOrderNumber);
		exchange.properties.put('apiURN','urn:brmsService');
		exchange.properties.fedIndicator = false
		setAuditLogProperties(exchange,false)
		super.setCSIHttpHeaders(exchange)
		exchange.in.headers.put("CamelHttpUri",resolveURN('urn:brms:services',url))
		exchange.properties.put("OceCSIApiName", OceConstants.API_NAME_FRAUD_VALIDATION_SERVICE )
		log.debug('FraudValidationTransformation.transform: order --> :' + order);
		
		def oceJsonMap = exchange.in.body.order
		
		oceJsonMap = escapeSoapRequest(oceJsonMap)
		
		def oceXmlOrder = XML.toString(new JSONObject(oceJsonMap))
		def fraudRequest = ['fraudDetectionRequest' : oceXmlOrder]
		
		log.debug('FraudValidationTransformation.transform: Body:' + fraudRequest)
		log.info('FraudValidationTransformation.transform --> Exiting')
		
		return fraudRequest
	}


	/*
	 * This function will take the Fraud response  and do necessary processing
	 * Will update order payload during success or return the APIFailedException object in case of Soap Fault
	 * @param exchange - Camel Exchange
	 * */
	def processResponse(Exchange exchange) throws APIFailedException {
		def response = new XmlSlurper().parseText(exchange.in.body)
		def orderMap = exchange.properties.order
		def fraudResponse = response.Body.executeFraudChecksResponse
			
		/*Adding additionalDetail from response to existing order*/
		def existingDetails
		if(orderMap.AdditionalDetails?.AdditionalDetail) {
			existingDetails = orderMap.AdditionalDetails.AdditionalDetail;
		}
		def detailsFromResponse = fraudResponse.return.StatusDetails.AdditionalDetails.AdditionalDetail.asList()
		if(detailsFromResponse){
			def details = new ArrayList<Map>();
			detailsFromResponse.each { it ->
				def additionaldetail = new HashMap();
				additionaldetail = ['Type': it.Type.text(), 'Code': it.Code.text(),'Value': it.Value.text()]
				details.add(additionaldetail)
			}
			if(existingDetails){
				existingDetails.addAll(details)
				orderMap.put('AdditionalDetails',['AdditionalDetail' : existingDetails])
			}else{
				orderMap.put('AdditionalDetails',['AdditionalDetail' : details])
			}
		}
		
		/*Determining LosgStatus from Fraud response*/
		def loSGStatus
		if( fraudResponse.return.StatusDetails && fraudResponse.return.StatusDetails.Status.text().length() > 0)
		{
			loSGStatus = [Status:fraudResponse.return.StatusDetails.Status.text(), SubStatus:fraudResponse.return.StatusDetails.SubStatus.text()]
		}
		else if(fraudResponse.return.size()>0)
		{
			loSGStatus = [Status:OceConstants.LOSGSTATUS_SYS_PROCESSING, SubStatus:OceConstants.LOSGSUBSTATUS_FRAUD_APPROVED]
		}else
		{
			loSGStatus = [Status:OceConstants.LOSGSTATUS_IN_QUEUE, SubStatus:OceConstants.LOSGSUBSTATUS_FRAUD_REVIEW_MED]
		}

		addTransactionHistory(exchange,loSGStatus)
		log.info('Order: ' + orderMap)
		
		if(loSGStatus?.Status == OceConstants.LOSGSTATUS_IN_QUEUE){
			def e = new APIFailedException();
			e.api = getApiName();
			e.code = 200
			e.codeDescription = "Fraud Validation Failed"
			exchange.out.body = orderMap;
			throw e;
		}
		else{
			exchange.out.body = orderMap;
			return orderMap
		}
	}
	
	public void addTransactionHistory(Exchange exchange,def losgStatus){
		def order = exchange.properties.order;
		Map<String,Object> executionContext = (Map<String,Object>)exchange.getProperties().get("executionContext");
		if (!executionContext.containsKey("transactionHistory")){
			executionContext.put("transactionHistory",new ArrayList<Map<String,Object>>());
		}
		List<Map<String,Object>> transactionHistory = (List<Map<String,Object>>) executionContext.get("transactionHistory");
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(),"api",exchange.getProperties().get("OceCSIApiName"),"success",(losgStatus.Status == OceConstants.LOSGSTATUS_SYS_PROCESSING),"status",losgStatus.Status,"subStatus",losgStatus.SubStatus,'ReferenceId',order.CustomerOrderNumber));
	}
}