package com.att.oce.bpm.transformations

import java.nio.charset.Charset

import javax.xml.soap.*

import org.apache.camel.Exchange
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import org.w3c.dom.NodeList

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.common.util.JsonConverters
import com.att.oce.bpm.error.APIFailedException

@Component('atgGetOrderTransformation')
class ATGGetOrderTransformation extends TransformationService {

	String url

	static Logger log = LoggerFactory.getLogger(ATGGetOrderTransformation.class)

	@Override
	String getApiName() {
		return 'GetOrder'
	}

	/**
	 * This function will do the transformation for ATGGetOrder
	 * @param exchange
	 * @return
	 */
	public def transform(Exchange exchange) {

		String reqMessage = (String) exchange.getIn().getBody()
		String taskID = ""
		String oceOrdNo = ""

		try {
			SOAPMessage soapMessage = getSoapMessageFromString(reqMessage)
			log.info(":: soapMessage.toString() ::" + soapMessage.toString())

			SOAPPart soapPart = soapMessage.getSOAPPart()
			SOAPEnvelope soapEnv = soapPart.getEnvelope()
			SOAPBody soapBody = soapEnv.getBody()

			log.info("soapBody.getTextContent() : " + soapBody.getTextContent())

			String ns = "http://oce.att.com/OCE/Namespaces/Messages/Private/NotifyTaskUpdateServiceMessagesV1.0.xsd"
			NodeList notifyRequest = soapBody.getElementsByTagNameNS(ns, "NotifyTaskUpdateRequest")

			// Retrieves the task id from request
			for (int k = 0; k < notifyRequest.getLength(); k++) {
				NodeList notifyOrderTask = notifyRequest.item(k).getChildNodes()

				for (int l = 0; l < notifyOrderTask.getLength(); l++) {
					NodeList orderTaskItems = notifyOrderTask.item(l).getChildNodes()

					for (int m = 0; m < orderTaskItems.getLength(); m++) {

						if (orderTaskItems.item(m).getNodeName().endsWith(":OrderNumber")) {
							log.info("orderTaskItems.item(m).getNodeName() OrderNumber is : " + orderTaskItems.item(m).getNodeName())
							oceOrdNo = orderTaskItems.item(m).getTextContent().trim()
						} else if (orderTaskItems.item(m).getNodeName().endsWith(":TaskId")) {
							log.info("orderTaskItems.item(m).getNodeName() is TaskId : " + orderTaskItems.item(m).getNodeName())
							taskID = orderTaskItems.item(m).getTextContent().trim();
						}
					}
				}
			}

			log.info("taskID : " + taskID);
			log.info("OrderNumber : " + oceOrdNo);

		} catch (Exception e) {
			e.printStackTrace();
		} catch (SOAPException se) {
			se.printStackTrace();
		} catch (IOException io) {
			io.printStackTrace();
		}

		setATGHttpHeaders(exchange)
		exchange.in.headers.put("CamelHttpUri", resolveURN('urn:atg:getorder:' + oceOrdNo, url))
		exchange.in.headers.put("CamelHttpMethod", "GET")
		exchange.getIn().getHeaders().put("Accept", "application/json")
		exchange.getIn().getHeaders().put("Content-Type", "application/json")
		exchange.in.headers.put("CamundaTaskId", taskID)
		/* Adding Reference Id for transactionHistory */
		exchange.properties.put("referenceId", taskID)

		exchange.properties.put('apiURN', 'urn:atgGetOrder')
		exchange.properties.put("OceCSIApiName", "ATGGetOrder")
		exchange.properties.put("fedIndicator", true)
		setAuditLogProperties(exchange, true)
	}

	/**
	 *
	 * @param xml
	 * @return
	 * @throws SOAPException
	 * @throws IOException
	 */
	private SOAPMessage getSoapMessageFromString(String xml) throws SOAPException, IOException {
		MessageFactory factory = MessageFactory.newInstance()
		InputStream stream = new ByteArrayInputStream(xml.getBytes(Charset.forName("UTF-8")))
		SOAPMessage message = factory.createMessage(new MimeHeaders(), stream)
		return message;
	}

	/**
	 * Method to get the latest Order information from ATG
	 * and convert it into Fed Format
	 * @param exchange
	 * @throws APIFailedException
	 */
	def processResponse(Exchange exchange) throws APIFailedException {
		log.info("ATGGetOrderTransformation processResponse Entering");
		String contentType = exchange.in.getHeader("Content-Type")
		def updatedOrder = exchange.in.body
		if(contentType?.contains("json") && updatedOrder?.contains("CustomerOrderNumber")){
			log.info("ATGGetOrderTransformation success response");
			HashMap atgResponseJson = JsonConverters.toMapofMaps(exchange.in.body)
			if(exchange.in.headers.CamelHttpResponseCode == 200){
				HashMap orderDetailsMap = atgResponseJson.get("OrderDetails")
				HashMap orderMap = orderDetailsMap.get("Order")
				def fedJsonOrder = ATGHelper.convertNFToF(orderMap)
				log.info("ATGGetOrderTransformation success response " + orderMap);
				updatedOrder = JsonConverters.toMapofMaps((String) fedJsonOrder)
				log.info("ATGGetOrderTransformation success response ConvertedOrderMap" + updatedOrder);
			} else { /* Unsuccessful HTTP Response */
				APIFailedException apiException = new APIFailedException()
				apiException.api = getApiName()
				apiException.code = exchange.in.headers.CamelHttpResponseCode.toString()
				apiException.subCode = (atgResponseJson?.Errors?.Error?.get(0)?.ErrorCode)?: "NA"
				apiException.codeDescription = (atgResponseJson?.Errors?.Error?.get(0)?.ErrorDescription)?: "NA"
				exchange.setException(apiException)
				throw apiException
			}
		}
		/*Invalid response payload hence creating incident*/
		else {
			APIFailedException e = new APIFailedException();
			e.api = getApiName();
			e.code = exchange.in.headers.CamelHttpResponseCode.toString();
			e.subCode = "NA";
			e.codeDescription = "NA";
			exchange.setException(e);
			throw e;
		}
		return updatedOrder
	}
}