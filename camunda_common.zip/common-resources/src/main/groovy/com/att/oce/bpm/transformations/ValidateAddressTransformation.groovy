package com.att.oce.bpm.transformations

import org.apache.camel.Exchange
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component

import com.att.oce.bpm.common.OceConstants;
import com.att.oce.bpm.error.APIFailedException;
import com.att.oce.bpm.common.TransformationService;

@Component('validateAddressTransformation')
class ValidateAddressTransformation extends CommonTransformationService 
{
	static Logger log = LoggerFactory.getLogger(ValidateAddressTransformation.class)
	
	String url;
	
	@Override String getApiName()
	{
		return 'ValidateAddress';
	}
	/**
	 * Method to gather data to frame the outbound request for a given API 
	 * @param uri
	 * @param exchange
	 * @return
	 */
	public def transform(Exchange exchange){
		log.info('ValidateAddressTransformation.transform <-- Entering')
		/*Setting values for Camel Header*/
		setCSIHttpHeaders(exchange)
		exchange.in.headers.put("CamelHttpUri",resolveURN('urn:csi:services:compass:ValidateAddress.jws',url))
		exchange.properties.put("OceCSIApiName","ValidateAddress");
		exchange.properties.put('apiURN','urn:csi:services:compass:ValidateAddress.jws');
		def order = exchange.in.body.order;
		exchange.properties.put('order',order);
		exchange.properties.put("fedIndicator",true);
		setAuditLogProperties(exchange,true);
		
		def addressId = exchange.in.body.addressId
		
		log.debug('ValidateAddressTransformation.transform: order --> :' + order);
		log.debug('ValidateAddressTransformation.transform: addressId -->:' + addressId);
		
		/*to retain the original arguments */
		exchange.properties.put('addressId',addressId);
		def address = order.addresses.address.find{ad -> ad.id == addressId};
		exchange.properties.put('address',address);
		
		/* Adding Reference Id for transactionHistory */
		exchange.properties.put("referenceId",order.customerOrderNumber);
		
		/*Setting Values required for SOAP Body*/
		def Address;
		if(address?.parsedAddress){
			def PostalCode = ['zipCode' : address?.parsedAddress?.zip]

			def addressLines;
			addressLines = address?.parsedAddress?.assignedStreetNumber?:''+' '+address?.parsedAddress?.streetName?:''+' '+address?.parsedAddress?.streetType?:'';

			def AddressUnfielded = ['addressLines' : addressLines,
				'city' : address?.parsedAddress?.city,
				'state' : address?.parsedAddress?.state,
				'postalCode' : PostalCode]

			def AddressData = ['addressUnfielded': AddressUnfielded]

			Address = ['addressData' : AddressData,
				'county' : address?.parsedAddress?.county,
				'country' : address?.parsedAddress?.country,
				'addressId' : address?.parsedAddress?.addressId,
				'linkKey' : address?.parsedAddress?.linkKey]
		}
		else{
			def Structure = ['type' : address?.unparsedAddress?.structure?.type,
				'value' : address?.unparsedAddress?.structure?.value]

			def Elevation = ['type' : address?.unparsedAddress?.elevation?.type,
				'value' : address?.unparsedAddress?.elevation?.value]

			def Unit = ['type' : address?.unparsedAddress?.unit?.type,
				'value' : address?.unparsedAddress.unit?.value]

			def PostalCode = ['zipCode' : address?.unparsedAddress?.zip]

			def AddressUnfielded = ['addressLine1' : address?.unparsedAddress?.addressLine1,
				'addressLine2' : address?.unparsedAddress?.addressLine2,
				'addressLine3' : address?.unparsedAddress?.addressLine3,
				'structure' : Structure,
				'elevation' : Elevation,
				'unit' : Unit,
				'city' : address?.unparsedAddress?.city,
				'state' : address?.unparsedAddress?.state,
				'postalCode' : PostalCode]

			def AddressData = ['addressUnfielded': AddressUnfielded]

			Address = ['addressData' : AddressData,
				'county' : address?.unparsedAddress?.county,
				'country' : address?.unparsedAddress?.country,
				'attention' : address?.unparsedAddress?.attention,
				'urbanizationCode' : address?.unparsedAddress?.urbanizationCode]
		}

		def validateAddressRequest = ['address' : Address, 'mode' : 'U']
		def soapRequest = ['messageHeader' : createMessageHeader(order),
			'validateAddressRequest' : validateAddressRequest]

		soapRequest = removeKeysWithoutValues(soapRequest);
		
		escapeSoapRequest(soapRequest)
		
		log.debug('ValidateAddressTransformation.transform: Body:' + soapRequest)
		log.info('ValidateAddressTransformation.transform --> Exiting')
		
		return soapRequest
	}

	/**
	 * Method to Process the response back from the API
	 * @param exchange
	 * @return
	 */
	public void processResponse(Exchange exchange){
		log.info('ValidateAddressTransformation.processResponse <-- Entering')
		
		/* Initialize */
		def executionContext = exchange.properties.executionContext;
		def sValidateAddressResponse = exchange.in.body;
		def order = exchange.properties.order;
		def addressId = exchange.properties.addressId;
		def address = order.addresses.address.find{ad -> ad.id == addressId};
		log.debug('ValidateAddressTransformation.processResponse: Response XML :' + sValidateAddressResponse);
		
		/* Parse the response as an XML*/
		def validateAddressResponse = new XmlSlurper().parseText(sValidateAddressResponse)
		if (validateAddressResponse.Body.Fault.size()>0){
			def e = new APIFailedException();
			e.api = getApiName()
			e.code = validateAddressResponse.Body.Fault.detail.CSIApplicationException.Response.code
			e.codeDescription = validateAddressResponse.Body.Fault.detail.CSIApplicationException.Response.description
			e.subCode = validateAddressResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code
			e.subCodeDescription = validateAddressResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
			addTransactionHistory(exchange,e)
			exchange.out.body = order
			throw e
		}
		
		/* Updating the execution context */
		executionContext.put('ValidateAddress.pass', 'SUCCESS')
		exchange.properties.put('executionContext',executionContext)
		
		def confidenceLevel = globalConfig.validateAddressConfidence
		def body = validateAddressResponse.Body.ValidateAddressResponse
		
		/* Matching the confidence and getting the best available match*/
		def matchedAddress = body.MatchedAddressResult?.AddressMatchResult.findAll{ ma -> Integer.parseInt(ma.confidence.toString()) > confidenceLevel}.collect{it.Address}.sort{it.confidence}[0]
		def parsedAddress = address?.parsedAddress
		def addressType = globalConfig.mAddressTypes.get('AddressType.'+matchedAddress?.addressType?.text())
		HashMap modParsedAddress;

		def matchedAddressFields = new HashMap<>()
		if(matchedAddress?.addressLine1?.text())			
			matchedAddressFields.addressStreetLine = matchedAddress?.addressLine1?.text()		
		if(matchedAddress?.Street?.streetNumberPrefix?.text())
			matchedAddressFields.houseNumberPrefix = matchedAddress?.Street?.streetNumberPrefix?.text()
		if(matchedAddress?.Street?.streetNumber?.text())
			matchedAddressFields.houseNumber = matchedAddress?.Street?.streetNumber?.text()	
		if(matchedAddress?.Street?.streetNumberPrefix?.text())
			matchedAddressFields.houseNumberSuffix = matchedAddress?.Street?.streetNumberPrefix?.text()
		if(matchedAddress?.Street?.streetDirection?.text())
			matchedAddressFields.direction = matchedAddress?.Street?.streetDirection?.text()
		if(matchedAddress?.Street?.assignedStreetNumber?.text())
			matchedAddressFields.assignedStreetNumber = matchedAddress?.Street?.assignedStreetNumber?.text()
		if(matchedAddress?.Street?.streetName?.text())
			matchedAddressFields.streetName = matchedAddress?.Street?.streetName.text()
		if(matchedAddress?.Street?.streetType?.text())
			matchedAddressFields.streetType = matchedAddress?.Street?.streetType?.text()
		if(matchedAddress?.postOfficeBox?.text())
			matchedAddressFields.streetType = matchedAddress?.postOfficeBox?.text()
		if(matchedAddress?.postOfficeBox?.text())
			matchedAddressFields.postOfficeBox = matchedAddress?.postOfficeBox?.text()
		if(matchedAddress?.city?.text())
			matchedAddressFields.city = matchedAddress?.city?.text()
		if(matchedAddress?.state?.text())
			matchedAddressFields.state = matchedAddress?.state?.text()
		if(matchedAddress?.Zip?.zipCode?.text())
			matchedAddressFields.zip = matchedAddress?.Zip?.zipCode?.text()
		if(matchedAddress?.internationalZip?.text())
			matchedAddressFields.internationalZip = matchedAddress?.internationalZip?.text()
		if(matchedAddress?.Zip?.zipGeoCode?.text())
			matchedAddressFields.zipGeoCode = matchedAddress?.Zip?.zipGeoCode?.text()
		if(matchedAddress?.Zip?.zipCodeExtension?.text())
			matchedAddressFields.zipCodeExtension = matchedAddress?.Zip?.zipCodeExtension?.text()
		if(matchedAddress?.county?.text())
			matchedAddressFields.county = matchedAddress?.county?.text()
		if(matchedAddress?.country?.text())
			matchedAddressFields.country = matchedAddress?.country?.text()
		if(addressType)
			matchedAddressFields.addressType = addressType 
			
		if(parsedAddress){
			def tempParsedAddress = parsedAddress.putAll(matchedAddressFields)
			modParsedAddress = (HashMap) tempParsedAddress
		}
		else{
			modParsedAddress = (HashMap) matchedAddressFields
		}
		
		/* Replacing the contents in the existing order */
		order.addresses?.address.each{ ad ->
			if(ad.id == address.id){
				ad.put('parsedAddress',modParsedAddress)
			}
		}
		
		removeKeysWithoutValues(order)
		addTransactionHistory(exchange,null)
		exchange.out.body = order
		log.debug('ValidateAddressTransformation.processResponse: Body:' + order)
		log.info('ValidateAddressTransformation.processResponse --> Exiting')
	}
	
	/*void addTransactionHistory(Exchange exchange, APIFailedException exception){
		//Add transactionHistory Logic here if you want to override Transformation service
	}*/
	
	/**
	 * Method to evaluate the precondition before calling API
	 * @param order
	 * @return
	 */
	 public boolean preCondition(execution) {
		log.info('ValidateAddressTransformation.preCondition <-- Entering')
		def order = (HashMap<String, Object>) execution.getVariable("order");
		def executionContext = (HashMap<String, Object>) execution.getVariable("executionContext");
		def addressId = execution.getVariable("addressId");
		
		log.debug('ValidateAddressTransformation.preCondition: Validating preCondition for Address ID: ' + addressId)
		
		boolean result = false;
		def validateAddressIgnore = OceConstants.API_NAME_VALIDATE_ADDRESS + '_IGNORE'
		boolean isValidateAddressIgnore = order.productGroups?.group.any { g -> g.characteristics?.losgCharacteristics?.losgStatus?.subStatus == validateAddressIgnore}
		
		if(!isValidateAddressIgnore){
			boolean isAddressValidated = order.addresses.address.any { ad-> ad.id == addressId && ad.additionalDetails?.additionalDetail?.any {adt -> adt.code == 'ValidatedAddress' && adt.value == 'true'}}
			log.debug('ValidateAddressTransformation.preCondition: isValidateAddress: ' + isAddressValidated)
			boolean isChannelDEMobility = (order.orderSource.channel == OceConstants.DEMOBILITY)? true : false;
			log.debug('ValidateAddressTransformation.preCondition: isChannelDEMobility: ' + isChannelDEMobility)
			if(!(isAddressValidated && isChannelDEMobility)){ result = true}
		}
		
		if(!result){
			addSkipTransactionHistory(execution, order.customerOrderNumber);
		}
		
		log.debug('ValidateAddressTransformation.preCondition:' + result);
		log.info('ValidateAddressTransformation.preCondition --> Exiting');
		return result;
	}
	
	public def getLoopCollection(order){
		def addressIdList = order.addresses?.address?.id;
		return addressIdList;
	}
	
	public int getLoopCount(order){
		def addressList = order.addresses?.address;
		def defaultLoopCount = 0;
		return (addressList?.size()>0)?addressList?.size(): defaultLoopCount;
	}
}