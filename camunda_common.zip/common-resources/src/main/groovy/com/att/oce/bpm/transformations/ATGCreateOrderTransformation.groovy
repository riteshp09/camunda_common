package com.att.oce.bpm.transformations

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.error.APIFailedException
import groovy.json.JsonSlurper
import org.apache.camel.Exchange
import org.json.JSONObject
import org.springframework.stereotype.Component
import com.att.oce.bpm.common.OceConstants
import org.slf4j.LoggerFactory
import org.slf4j.Logger

@Component('atgCreateOrderTransformation')
class ATGCreateOrderTransformation extends CommonTransformationService 
{
	static Logger log = LoggerFactory.getLogger(ATGCreateOrderTransformation.class);
	String url;
	
	@Override String getApiName()
	{
		return 'CreateOrder';
	}
		
	/**
	 * Method to gather data to frame the outbound request for a given API 
	 * @param uri
	 * @param exchange
	 * @return
	 */
	public def transform(Exchange exchange){
		log.info("ATGCreateOrderTransformation.transform --> Enter");
		/*Setting values for Camel Header*/
		def order = exchange.in.body.order;
		exchange.properties.put('order',order);
		exchange.properties.put('apiURN','urn:atgOrderCreate');
		setATGHttpHeaders(exchange);
		exchange.in.headers.put("CamelHttpUri",resolveURN('urn:atg:api',url));
		exchange.in.headers.put("isATGEndPointAMQ",globalConfig.isATGEndPointAMQ);
		exchange.properties.fedIndicator = true;
		setAuditLogProperties(exchange,true);
		
		exchange.properties.put("OceCSIApiName","CreateOrder");
		
		def atgRequest = ATGHelper.convertFToNF(order).toString();
		log.debug("ATG Request " + atgRequest);
		log.info("ATGCreateOrderTransformation.transform <-- Exit");
		return atgRequest;
	}

	/**
	 * Method to Process the response back from the API
	 * @param exchange
	 * @return
	 */
	public void processResponse(Exchange exchange){

		log.info("ATGCreateOrderTransformation.processResponse --> Enter");
		def order = exchange.properties.order;
		String contentType = exchange.in.getHeader("Content-Type");
		log.debug("Camel HTTP Response Code " + exchange.in.headers.CamelHttpResponseCode);
		def atgResponse = exchange.in.body;
		if(contentType?.contains("json") && atgResponse?.contains("OrderNumber")){
			def atgResponseJson = new JsonSlurper().parseText(atgResponse);
			log.debug("ATG Response " + atgResponseJson);
			if(exchange.in.headers.CamelHttpResponseCode == 200){
				order.put('oceOrderNumber',atgResponseJson.OrderNumber);
				exchange.out.body = order;
			}else{
				APIFailedException e = new APIFailedException();
				e.api = getApiName();
				e.code = exchange.in.headers.CamelHttpResponseCode.toString();
				e.subCode = (atgResponseJson?.Errors?.Error?.get(0)?.ErrorCode)?: "NA"
				e.codeDescription = (atgResponseJson?.Errors?.Error?.get(0)?.ErrorDescription)?: "NA"
				exchange.out.body = order;
				exchange.setException(e);
				throw e;
			}
		}
		else{
			APIFailedException e = new APIFailedException();
			e.api = getApiName();
			e.code = exchange.in.headers.CamelHttpResponseCode.toString();
			e.subCode = "NA";
			e.codeDescription = "NA";
			exchange.out.body = order;
			exchange.setException(e);
			throw e;
		}
		log.info("ATGCreateOrderTransformation.processResponse <-- Exit");
	}
	
	public def atgSwitch(){
		
		if(globalConfig.atgSwitch == "ON"){
			 return true
		}
		else{
			return false
		}
	}
	
}