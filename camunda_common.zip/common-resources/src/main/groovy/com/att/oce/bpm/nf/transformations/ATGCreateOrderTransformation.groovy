package com.att.oce.bpm.nf.transformations

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.error.APIFailedException
import groovy.json.JsonSlurper
import org.apache.camel.Exchange
import org.json.JSONObject
import org.springframework.stereotype.Component
import com.att.oce.bpm.common.OceConstants

@Component('atgCreateOrderTransformation')
class ATGCreateOrderTransformation extends TransformationService {

	String url;

	/*
	 * This function will do the transformation for ATG Create Order service
	 * @param exchange of type Camel Exchange
	 * */
	public def transform(Exchange exchange){

		exchange.properties.order = exchange.in.body.order
		exchange.properties.apiURN = "urn:atgOrderCreate"
		exchange.properties.fedIndicator = false
		setAuditLogProperties(exchange,false)
		exchange.in.headers.put("isATGEndPointAMQ",globalConfig.isATGEndPointAMQ);
		
		def oceJsonMap = exchange.in.body.order
		def atgOrderMap = [Order:oceJsonMap]
		def order = new JSONObject(atgOrderMap).toString()
		super.setATGHttpHeaders(exchange)
		exchange.in.headers.put("CamelHttpUri",super.resolveURN('urn:atg:api',url))
		return order
	}


	/*
	 * This function will take the ATG create order response  and do necessary processing
	 * Will update order payload during success or return the APIFailedException object in case of Soap Fault
	 * @param exchange - Camel Exchange
	 * */
	def processResponse(Exchange exchange) throws Exception {

		/* Initialize */
		def order = exchange.properties.order;
		String contentType = exchange.in.getHeader("Content-Type");

		def atgResponse = exchange.in.body;
		if(contentType?.contains("json") && atgResponse?.contains("OrderNumber")){
			def atgResponseJson = new JsonSlurper().parseText(atgResponse);
			if(exchange.in.headers.CamelHttpResponseCode.toString() == "200")
			{
				order.put('OCEOrderNumber',atgResponseJson.OrderNumber);
				exchange.out.body = order;
			}
			else
			{
				APIFailedException e = new APIFailedException();
				e.api = "CreateOrder";
				e.code = exchange.in.headers.CamelHttpResponseCode.toString();
				e.subCode = (atgResponseJson?.Errors?.Error?.get(0)?.ErrorCode)?: "NA"
				e.codeDescription = (atgResponseJson?.Errors?.Error?.get(0)?.ErrorDescription)?: "NA"
				exchange.out.body = order;
				exchange.setException(e);
				throw e;
			}
		}else{
			APIFailedException e = new APIFailedException();
			e.api = "CreateOrder";
			e.code = exchange.in.headers.CamelHttpResponseCode.toString();
			e.subCode = "NA";
			e.codeDescription = "NA";
			exchange.out.body = order;
			exchange.setException(e);
			throw e;
		}
	}

	def validateOrderForFalloutManagement(def apiName, def executionContext) {
		def result = false
		def transactionHistory = executionContext.transactionHistory
		def updatedTransactionHistory = getUpdatedTransactionHistory(transactionHistory)
		def statusList = updatedTransactionHistory.findAll {t -> apiName.contains(t.api)}.collect{it.status}

		if(statusList.contains(OceConstants.LOSG_STATUS_IN_QUEUE))
			result = true
		
		return result
	}

	def validateCancelledOrder(def Order) {
		def result

		List<String> Status = new ArrayList<String>();
		Status.add("CANCELED");

		def groupList = Order.Groups.Group.findAll  {g -> g.Type == OceConstants.GROUP_TYPE}.collect{it}

		List<String> cancelLoSGList = new ArrayList<String>();

		for(def group in groupList) {
			if(group.Type.equals(OceConstants.GROUP_TYPE) &&
			group.GroupCharacteristics && group.GroupCharacteristics.LoSGCharacteristics &&
			group.GroupCharacteristics.LoSGCharacteristics.LoSGType.equals(OceConstants.LOSGTYPE_CHANGE) &&
			(Status.contains(group.GroupCharacteristics.LoSGCharacteristics.LoSGStatus.Status))) {
				cancelLoSGList.add(group);
			}
		}

		if(groupList.size() == cancelLoSGList.size())
			result = true
		else
			result = false

		return result
	}
	
	
	def validateCancelledLosg(def Order,def GroupIds) {
		def result

		List<String> Status = new ArrayList<String>();
		Status.add("CANCELED");
		
		def statusList = Order.Groups.Group.findAll  {g -> GroupIds.contains(g.Id)}.collect{it.GroupCharacteristics.LoSGCharacteristics.LoSGStatus.Status}

		List<String> cancelLoSGList = new ArrayList<String>();

		for(def losgStatus in statusList) {
			if(Status.contains(losgStatus)) {
				cancelLoSGList.add(losgStatus);
			}
		}

		if(statusList.size() == cancelLoSGList.size())
			result = true
		else
			result = false

		return result
	}


}
