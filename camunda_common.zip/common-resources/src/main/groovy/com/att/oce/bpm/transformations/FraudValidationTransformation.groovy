package com.att.oce.bpm.transformations

import java.util.ArrayList
import java.util.Date
import java.util.List
import java.util.Map

import org.apache.camel.Exchange
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import com.att.oce.bpm.common.OceConstants
import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.error.APIFailedException
import org.camunda.bpm.engine.impl.util.json.XML;
import org.camunda.bpm.engine.impl.util.json.JSONObject;

@Component('fraudTransformation')
class FraudValidationTransformation extends CommonTransformationService {
	static Logger log = LoggerFactory.getLogger(FraudValidationTransformation.class)

	String url;

	@Override String getApiName()
	{
		return OceConstants.API_NAME_FRAUD_VALIDATION_SERVICE;
	}
	/**
	 * Method to gather data to frame the outbound request for a given API 
	 * @param uri
	 * @param exchange
	 * @return
	 */
	public def transform(Exchange exchange){
		log.info('FraudValidationTransformation.transform <-- Entering')
		/*Setting values for Camel Header*/
		def order = exchange.in.body.order;
		exchange.properties.put('order',order);

		/* Adding Reference Id for transactionHistory */
		exchange.properties.put("referenceId",order.customerOrderNumber);

		exchange.properties.put('apiURN','urn:brmsService');
		setCSIHttpHeaders(exchange);
		exchange.in.headers.put("CamelHttpUri",resolveURN('urn:brms:services',url));
		exchange.properties.put("OceCSIApiName","FraudValidation");
		exchange.properties.put("fedIndicator",true);
		setAuditLogProperties(exchange,true);
		
		order = escapeSoapRequest(order)
		
		log.debug('FraudValidationTransformation.transform: order --> :' + order);
		
		String nfOrder = ATGHelper.convertFToNF(order).toString();
		/*To remove \'Order\' from Json since that will be added in VM with proper namespace */
		nfOrder = nfOrder.substring(12, nfOrder.length()-1);
		log.debug('FraudValidationTransformation.transform: After Conversion Non Fed Order --> :' + nfOrder);
		println 'FraudValidationTransformation.transform: After Conversion Non Fed Order --> :' + nfOrder;
		
		def oceXmlOrder = XML.toString(new JSONObject(nfOrder));
		def soapRequest = ['fraudDetectionRequest' : oceXmlOrder];

		println 'FraudValidationTransformation.transform: Body:' + soapRequest
		
		log.debug('FraudValidationTransformation.transform: Body:' + soapRequest)
		log.info('FraudValidationTransformation.transform --> Exiting')
		
		return soapRequest;
	}

	/**
	 * Method to Process the response back from the API
	 * @param exchange
	 * @return
	 */
	public void processResponse(Exchange exchange){
		log.info('FraudValidationTransformation.processResponse <-- Entering');
		/* Initialize */
		def order = exchange.properties.order
		def executeFraudChecksResponse = exchange.in.body
		def httpResponseCode = exchange.in.headers.CamelHttpResponseCode;
		def losgStatus=[:];
		//		if(httpResponseCode == '200'){
		/* Parse the response as an XML*/
		def fraudResponse = new XmlSlurper().parseText(executeFraudChecksResponse)
		log.debug('FraudValidationTransformation.processResponse: Response XML :' + executeFraudChecksResponse);

		def body = fraudResponse.Body.executeFraudChecksResponse;

		/*Updating the losgStatus based on the response*/

		if( body.return.StatusDetails.Status.text().length() > 0 ){
			log.debug('FraudValidationTransformation.processResponse: Updating losgStatus based on status from BRMS');
			losgStatus = ['status': body.return.StatusDetails.Status.text() , 'subStatus': body.return.StatusDetails.SubStatus.text()];
		}
		else if (body.return.size()>0 ){
			log.debug('FraudValidationTransformation.processResponse: Updating losgStatus as default SUCESS');
			losgStatus = [status:OceConstants.LOSGSTATUS_SYS_PROCESSING, subStatus:OceConstants.LOSGSUBSTATUS_FRAUD_APPROVED];
		}
		else{
			log.debug('FraudValidationTransformation.processResponse: Updating losgStatus as default FAILURE');
			losgStatus = [status:OceConstants.LOSGSTATUS_IN_QUEUE, subStatus:OceConstants.LOSGSUBSTATUS_FRAUD_REVIEW_MED];
		}
				
		/*Adding additionalDetail from response to existing order*/
		def existingDetails
		if(order.additionalDetails?.additionalDetail) {
			existingDetails = order.additionalDetails.additionalDetail;
		}
		def detailsFromResponse = body.return.StatusDetails.AdditionalDetails.AdditionalDetail.asList()
		if(detailsFromResponse){
			def details = new ArrayList<Map>();
			detailsFromResponse.each { it ->
				def additionaldetail = new HashMap();
				additionaldetail = ['type': it.Type.text(), 'code': it.Code.text(),'value': it.Value.text()]
				details.add(additionaldetail)
			}
			if(existingDetails){
				existingDetails.addAll(details)
				order.put('additionalDetails',['additionalDetail' : existingDetails])
			}else{
				order.put('additionalDetails',['additionalDetail' : details])
			}
		}

		//		}
		//		else{
		//			println 'Not able to determine the HTTP RESPONSE CODE :(:(:(:(:(:(:(:(:(:(:(:(:(:(:(:(:(';
		//			losgStatus = [status:OceConstants.LOSGSTATUS_IN_QUEUE, subStatus:OceConstants.LOSGSUBSTATUS_FRAUD_REVIEW_MED];
		//		}
		
		addTransactionHistory(exchange,losgStatus);
		log.info('Order: ' + order)
		
		if(losgStatus?.status == OceConstants.LOSGSTATUS_IN_QUEUE){
			def e = new APIFailedException();
			e.api = getApiName();
			e.code = 200
			e.codeDescription = "Fraud Validation Failed"
			exchange.out.body = order;
			throw e;
		}else{
			exchange.out.body = order;
		}
		log.debug('FraudValidationTransformation.processResponse: Body:' + order)
		log.info('FraudValidationTransformation.processResponse --> Exiting')
	}

	public void addTransactionHistory(Exchange exchange,def losgStatus){
		def order = exchange.properties.order;
		Map<String,Object> executionContext = (Map<String,Object>)exchange.getProperties().get("executionContext");
		if (!executionContext.containsKey("transactionHistory")){
			executionContext.put("transactionHistory",new ArrayList<Map<String,Object>>());
		}
		List<Map<String,Object>> transactionHistory = (List<Map<String,Object>>) executionContext.get("transactionHistory");
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(),"api",exchange.getProperties().get("OceCSIApiName"),"success",(losgStatus.status == OceConstants.LOSGSTATUS_SYS_PROCESSING),"status",losgStatus.status,"subStatus",losgStatus.subStatus,'ReferenceId',order.customerOrderNumber));
	}
}