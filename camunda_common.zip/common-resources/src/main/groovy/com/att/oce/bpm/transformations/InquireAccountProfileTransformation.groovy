package com.att.oce.bpm.transformations

import org.apache.camel.Exchange
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import org.slf4j.LoggerFactory
import org.slf4j.Logger

import com.att.oce.bpm.common.OceConstants
import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.error.APIFailedException;

@Component('iapTransformation')
class InquireAccountProfileTransformation extends CommonTransformationService 
{
	static Logger log = LoggerFactory.getLogger(InquireAccountProfileTransformation.class)
	
	String url;
	
	@Override String getApiName()
	{
		return 'InquireAccountProfile';
	}
	/**
	 * Method to gather data to frame the outbound request for a given API
	 * @param uri
	 * @param exchange
	 * @return
	 */
	public def transform(uri,Exchange exchange){
		log.info('InquireAccountProfileTransformation.transform <-- Entering')
		
		/*Setting values for Camel Header*/
		setCSIHttpHeaders(exchange);
		exchange.in.headers.put("CamelHttpUri",resolveURN('urn:csi:services:cam:InquireAccountProfile.jws',url));
		exchange.properties.put("OceCSIApiName","InquireAccountProfile");
		exchange.properties.put('apiURN','urn:InquireAccountProfile.jws');
		def order = exchange.in.body.order;
		exchange.properties.put('order',order);
		/* Adding Reference Id for transactionHistory */
		exchange.properties.put("referenceId",order.customerOrderNumber);
		
		exchange.properties.put("fedIndicator",true);
		setAuditLogProperties(exchange,true);
		
		/*Setting Values required for SOAP Body*/
		def mobilityAccount = getMobilityAccount(order);
		def zipCode = getZip(order);
		
		log.debug('InquireAccountProfileTransformation.transform: order --> :' + order);
		log.debug('InquireAccountProfileTransformation.transform: mobilityAccount -->:' + mobilityAccount);
		
		def MarketServiceInfo;
		def AccountSelector;
		if(mobilityAccount.billingAccountNumber){
			if(mobilityAccount.market && mobilityAccount.subMarket){

				def billingMarket = ['billingMarket': mobilityAccount.market,
					'billingSubMarket' : mobilityAccount.subMarket]
				MarketServiceInfo = ['billingMarket' : billingMarket]
			}
			else{
				MarketServiceInfo = ['serviceZipCode' : zipCode]
			}
			AccountSelector = ['marketServiceInfo' : MarketServiceInfo,
				'billingAccountNumber' :	mobilityAccount.billingAccountNumber]
		}
		else{			
			AccountSelector = ['subscriberNumber' : order.productGroups.group[0].characteristics.losgCharacteristics.wirelessLOSCharacteristics.mobileNumber]
		}
		
		def AccountOrSubscriptionIDSelector = ['accountSelector' : AccountSelector]
		def InquireAccountProfileRequest = ['accountOrSubscriptionIDSelector' : AccountOrSubscriptionIDSelector]
		
		def soapRequest = ['messageHeader' : createMessageHeader(order), 
					'inquireAccountProfileRequest' : InquireAccountProfileRequest]
		
		escapeSoapRequest(soapRequest)
		
		log.debug('InquireAccountProfileTransformation.transform: Body:' + soapRequest)
		log.info('InquireAccountProfileTransformation.transform --> Exiting')
		
		return soapRequest		
	}

	
	/**
	 * Method to filter the Mobility Account
	 * @param order
	 * @return
	 */
	public def getMobilityAccount (order){
		return order.accounts.account.find{ n -> n.accountCategory == 'MOBILITY_ACCOUNT'}
	}
	
	/**
	 * Method to get Zip code from either Parsed or Unparsed Address corresponding to the Mobility Account
	 * @param order
	 * @return
	 */
	public def getZip(order){
		log.info('InquireAccountProfileTransformation.getZip <-- Entering');
		def addressRef = getMobilityAccount(order).billingDetail[0].addressReference;
		log.debug('InquireAccountProfileTransformation.getZip: Reference Address ID :' + addressRef);
		def address = order.addresses.address.find{ ad -> ad.id == addressRef };
		log.debug('InquireAccountProfileTransformation.getZip: Address :' + address);
		def zip;
		if(address.parsedAddress)
			zip = address.parsedAddress.zip;
		else
			zip = address.unparsedAddress.zip;
			
		log.debug('InquireAccountProfileTransformation.getZip: Zip :' + zip);
		log.info('InquireAccountProfileTransformation.getZip --> Exiting');
	}
	
	/**
	 * Method to Process the response back from the API
	 * @param exchange
	 * @return
	 */
	public void processResponse(Exchange exchange){
		log.info('InquireAccountProfileTransformation.processResponse <-- Entering')
		/* Initialize */
		def sIAPResponse = exchange.in.body
		def order = exchange.properties.order
		
		/* Parse the response as an XML*/
		def iapResponse = new XmlSlurper().parseText(sIAPResponse)
		log.debug('InquireAccountProfileTransformation.processResponse: Response XML :' + sIAPResponse)
		
		if (iapResponse.Body.Fault.size()>0){
			def e = new APIFailedException();
			e.api = getApiName()
			e.code = iapResponse.Body.Fault.detail.CSIApplicationException.Response.code
			e.codeDescription = iapResponse.Body.Fault.detail.CSIApplicationException.Response.description
			e.subCode = iapResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.code
			e.subCodeDescription = iapResponse.Body.Fault.detail.CSIApplicationException.ServiceProviderEntity.ServiceProviderRawError.description
			addTransactionHistory(exchange,e)
			exchange.out.body = order
			throw e
		}
		
		def body = iapResponse.Body.InquireAccountProfileResponse
		String slastUpdated = body.Account.Customer?.Address?.lastUpdate?.text()
		def lastUpdatedDate = formatDate(slastUpdated,'yyyy-MM-dd\'T\'HH:mm:ss\'Z\'','yyyy-MM-dd\'Z\'')
		
		log.debug('InquireAccountProfileTransformation.processResponse: lastUpdatedDate - Before Format :' + slastUpdated)
		log.debug('InquireAccountProfileTransformation.processResponse: lastUpdatedDate - After Format :' + lastUpdatedDate)
		
		/* Updating order */
		order.accounts.account.each { ac -> 
			if(ac.accountCategory == OceConstants.ACCOUNTCATEGORY_MOBILITY_ACCOUNT){
				if(lastUpdatedDate != null){
					ac.billingDetail[0].put('lastUpdated',lastUpdatedDate)
				}
				ac.put('effectiveDate', body.Account?.AccountCreationDate?.effectiveDate?.text())
			}
		}
		
		addTransactionHistory(exchange,null);
		exchange.out.body = order
		log.debug('InquireAccountProfileTransformation.processResponse: Body:' + order)
		log.info('InquireAccountProfileTransformation.processResponse --> Exiting')
	}
	
	/*void addTransactionHistory(Exchange exchange, APIFailedException exception){
	//Add transactionHistory Logic here
	}*/
	
	def ignore(order){
		def effectiveDate = order.accounts.account.find{ n -> n.accountCategory == 'MOBILITY_ACCOUNT'}?.effectiveDate;
		if (!effectiveDate)
			return false
		return true
	}
	
	public def preCondition(order){
		
		def account = order.accounts.account.find{ acc -> acc.accountCategory == 'MOBILITY_ACCOUNT' && acc.billingAccountNumber}
		def group = order.productGroups.group.find{ grp -> grp.characteristics?.losgCharacteristics?.wirelessLOSCharacteristics?.mobileNumber}.collect{it}
		log.info("IAP PreCondition check ....>>>>Account: "+account)
		log.info("IAP PreCondition check ....>>>>Group: "+group)
		def invokeIAP=false
		if(account || group){
			invokeIAP= true
		}
		log.debug("IAP PreCondition >>>>Result: "+invokeIAP)
		return invokeIAP
	}
}