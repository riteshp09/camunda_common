package com.att.oce.bpm.transformations

import java.text.SimpleDateFormat

import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.util.json.JSONObject
import org.springframework.stereotype.Component
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.error.APIFailedException
import groovy.json.JsonSlurper


@Component('atgTaskCreateTransformation')
class ATGTaskCreateTransformation extends ATGUpdateOrderTransformation{
	static Logger log = LoggerFactory.getLogger(ValidateAddressTransformation.class)
	String url;
	String HTTP_CONTENT_TYPE_JSON = "application/json";
	private static SimpleDateFormat xmlDateTimeformat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	/*
	 * This function will do the transformation for ATGTaskCreate
	 * @param exchange of type Camel Exchange
	 * */
	public def transform(Exchange exchange){
		exchange.properties.order = exchange.in.body.order
		def oceJsonMap = exchange.in.body.order;
		def oceErrorMap;
		def atgRequest;
		if(oceJsonMap.Errors != null){
			oceErrorMap = oceJsonMap.remove("Errors");
		}
		def executionContext = exchange.properties.executionContext;
		def oceUpdatedOrder = updateLoSGStatus(oceJsonMap,executionContext);
		def transactionLogsList = createTransactionLogs(oceJsonMap,executionContext);
		def orderTaskMap = updateOrderTask(oceJsonMap,exchange);
		def atgTaskRequestWithoutOrder;
		def atgreq;
		if(oceErrorMap != null){
			atgreq = [Errors:oceErrorMap,OrderTasks:orderTaskMap,TransactionLogs:transactionLogsList]
			atgTaskRequestWithoutOrder = new JSONObject(atgreq);
		}
		else{
			atgreq = [OrderTasks:orderTaskMap,TransactionLogs:transactionLogsList]
			atgTaskRequestWithoutOrder = new JSONObject(atgreq);
		}
		
		log.debug('ATGRequestWithoutOrder:>>>>>>>>>>> '+atgTaskRequestWithoutOrder.toString());

		def jOrder = ATGHelper.convertFToNF(oceUpdatedOrder);
		jOrder.setLength(jOrder.length() - 1);
		log.debug('Order after conversion:############ '+ jOrder);
		
		if(atgreq.Errors){
			atgRequest = jOrder+','+'\"Errors\":'+atgTaskRequestWithoutOrder.get('Errors').toString()+','+'\"OrderTasks\":'+atgTaskRequestWithoutOrder.get('OrderTasks').toString()+','+'\"TransactionLogs\":'+atgTaskRequestWithoutOrder.get('TransactionLogs').toString()+'}';
			log.debug('ATG Task Create Request with Errors :$$$$$$$$$$ '+ atgRequest);
		}
		else{
			atgRequest = jOrder+','+'\"OrderTasks\":'+atgTaskRequestWithoutOrder.get('OrderTasks').toString()+','+'\"TransactionLogs\":'+atgTaskRequestWithoutOrder.get('TransactionLogs').toString()+'}';
			log.debug('ATG Task Create Request :$$$$$$$$$$ '+ atgRequest);
		}
		setATGHttpHeaders(exchange);
		exchange.in.headers.put("CamelHttpUri",resolveURN('urn:atg:api',url));
		exchange.in.headers.put("Accept",HTTP_CONTENT_TYPE_JSON);
		exchange.in.headers.put("Content-Type",HTTP_CONTENT_TYPE_JSON);

		/* Adding Reference Id for transactionHistory */
		exchange.properties.put("referenceId",oceJsonMap.customerOrderNumber);

		exchange.properties.put('apiURN','urn:atgCreateFalloutTask');
		exchange.properties.put("OceCSIApiName","ATGCreateFalloutTask");
		exchange.properties.put("fedIndicator",true);
		setAuditLogProperties(exchange,true);
		return atgRequest;
	}

	/**
	 * This function will take the ATG response and will set it into Exchange body
	 * during success or return the APIFailedException object in case of Fault
	 * @param exchange
	 * @return
	 */
	def processResponse(Exchange exchange) {

		/* Initialize */
		def order = exchange.properties.order;
		String contentType = exchange.in.getHeader("Content-Type");

		def atgResponse = exchange.in.body;
		if(contentType?.contains("json") && atgResponse?.contains("OrderNumber")){
			def atgResponseJson = new JsonSlurper().parseText(atgResponse);
			if(exchange.in.headers.CamelHttpResponseCode == 200){
				addTransactionHistory(exchange)
				log.debug("ATGTaskCreateTransformation ExecutionContext : " + exchange.properties.executionContext)
				order.oceOrderNumber = atgResponseJson?.OrderNumber
				exchange.out.body = order;
			}else{
				APIFailedException e = new APIFailedException();
				e.api = getApiName();
				e.code = exchange.in.headers.CamelHttpResponseCode.toString();
				e.subCode = (atgResponseJson?.Errors?.Error?.get(0)?.ErrorCode)?: "NA"
				e.codeDescription = (atgResponseJson?.Errors?.Error?.get(0)?.ErrorDescription)?: "NA"
				exchange.out.body = order;
				exchange.setException(e);
				throw e;
			}
		}
	}

	/**
	 * 
	 * @param order
	 * @param exchange
	 * @return
	 */
	def updateOrderTask(order,exchange){
		List orderTaskList = new ArrayList();
		def orderNumber = order.parentOrderNumber ? order.parentOrderNumber : order.oceOrderNumber;
		orderTaskList.add([CamundaTaskId : exchange.in.headers.CamundaTaskId,
			"ApplicationName" : System.getProperty("ATG_TASK_NOTIFY_MODULE_APPLICATION_NAME"),
			"CustomerOrderNumber" : order.customerOrderNumber,
			"ChildOrderNumber" : order.oceOrderNumber,
			"OrderNumber" : orderNumber]);
		def orderTaskMap = ["OrderTask":orderTaskList];
		return orderTaskMap;

	}
	
	public void addTransactionHistory(Exchange exchange){
		def order = exchange.properties.order;
		Map<String,Object> executionContext = (Map<String,Object>)exchange.getProperties().get("executionContext");
		if (!executionContext.containsKey("transactionHistory")){
			executionContext.put("transactionHistory",new ArrayList<Map<String,Object>>());
		}
		List<Map<String,Object>> transactionHistory = (List<Map<String,Object>>) executionContext.get("transactionHistory");
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(),"api","FALLOUT","success",true,
									  "status","IN_QUEUE","subStatus","WAITING_FOR_ORDER_UPDATE",'ReferenceId',order.customerOrderNumber,
									  "recordType","Internal"));
	}
}