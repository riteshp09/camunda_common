package com.att.oce.bpm.transformations

import java.text.SimpleDateFormat
import java.util.Date

import com.att.oce.bpm.common.TransformationService;

public abstract class CommonTransformationService extends TransformationService {
	
	protected static String convertLongToDate(String input,String targetFormat){
		long dateInLong = Long.parseLong(input);
		Date dateAsIs = new Date(dateInLong);
		SimpleDateFormat targetFormatter = new SimpleDateFormat(targetFormat);
		return targetFormatter.format(dateAsIs);
	}
	
	protected static String convertLongToDate(long input,String targetFormat){
		Date dateAsIs = new Date(input);
		SimpleDateFormat targetFormatter = new SimpleDateFormat(targetFormat);
		return targetFormatter.format(dateAsIs);
	}
	
}
