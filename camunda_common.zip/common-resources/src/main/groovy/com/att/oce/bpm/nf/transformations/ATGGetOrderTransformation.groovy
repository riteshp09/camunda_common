package com.att.oce.bpm.nf.transformations;

import java.nio.charset.Charset
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import javax.xml.soap.MessageFactory
import javax.xml.soap.MimeHeaders
import javax.xml.soap.SOAPBody
import javax.xml.soap.SOAPEnvelope
import javax.xml.soap.SOAPException
import javax.xml.soap.SOAPMessage
import javax.xml.soap.SOAPPart

import org.apache.camel.Exchange
import org.springframework.stereotype.Component
import org.w3c.dom.NodeList

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.common.util.JsonConverters
import com.att.oce.bpm.error.APIFailedException

@Component('atgGetOrderTransformation')
class ATGGetOrderTransformation extends TransformationService{

	String url;

	static Logger log = LoggerFactory.getLogger(ATGGetOrderTransformation.class)

	/*
	 * This function will do the transformation for Fraud Service
	 * @param exchange of type Camel Exchange
	 * */
	public def transform(Exchange exchange){
		String reqMessage = (String) exchange.getIn().getBody();
		SOAPMessage soapMessage = null;
		String taskID = "";
		String oceOrdNo = "";

		try{
			soapMessage = getSoapMessageFromString(reqMessage);
			log.info(":: soapMessage.toString() ::"+soapMessage.toString());

			SOAPPart soapPart = soapMessage.getSOAPPart();
			SOAPEnvelope soapEnv = soapPart.getEnvelope();
			SOAPBody soapBody = soapEnv.getBody();

			log.info("soapBody.getTextContent() : " + soapBody.getTextContent());

			String ns = "http://oce.att.com/OCE/Namespaces/Messages/Private/NotifyTaskUpdateServiceMessagesV1.0.xsd";
			NodeList notifyRequest = soapBody.getElementsByTagNameNS(ns, "NotifyTaskUpdateRequest");

			// Retrieves the task id from request
			for (int k = 0; k < notifyRequest.getLength(); k++) {
				NodeList notifyOrderTask = notifyRequest.item(k).getChildNodes();

				for (int l = 0; l < notifyOrderTask.getLength(); l++) {
					NodeList orderTaskItems = notifyOrderTask.item(l).getChildNodes();

					for (int m = 0; m < orderTaskItems.getLength(); m++) {

						if (orderTaskItems.item(m).getNodeName().endsWith(":OrderNumber")) {
							log.info("orderTaskItems.item(m).getNodeName() OrderNumber is : " + orderTaskItems.item(m).getNodeName());
							oceOrdNo = orderTaskItems.item(m).getTextContent().trim();
						}
						else if (orderTaskItems.item(m).getNodeName().endsWith(":TaskId")) {
							log.info("orderTaskItems.item(m).getNodeName() is TaskId : " + orderTaskItems.item(m).getNodeName());
							taskID = orderTaskItems.item(m).getTextContent().trim();
						}
					}
				}
			}

			log.info("taskID : " + taskID);
			log.info("OrderNumber : " + oceOrdNo);

		} catch (Exception e) {
			e.printStackTrace();
		} catch (SOAPException se) {
			se.printStackTrace();
		}catch (IOException io) {
			io.printStackTrace();
		}

		setATGHttpHeaders(exchange)
		exchange.in.headers.put("CamelHttpUri",resolveURN('urn:atg:getorder:'+oceOrdNo,url))
		exchange.in.headers.put("CamelHttpMethod","GET");
		exchange.getIn().getHeaders().put("Accept","application/json");
		exchange.getIn().getHeaders().put("Content-Type","application/json");
		exchange.in.headers.put("CamundaTaskId", taskID);
		/* Adding Reference Id for transactionHistory */
		exchange.properties.put("referenceId",taskID);

		exchange.properties.put('apiURN','urn:atgGetOrder');
		exchange.properties.put("OceCSIApiName","ATGGetOrder");
		exchange.properties.put("fedIndicator",false);
		setAuditLogProperties(exchange,false);
	}

	private SOAPMessage getSoapMessageFromString(String xml) throws SOAPException, IOException {
		MessageFactory factory = MessageFactory.newInstance();
		InputStream stream = new ByteArrayInputStream(xml.getBytes(Charset.forName("UTF-8")));
		SOAPMessage message = factory.createMessage(new MimeHeaders(), stream);
		return message;
	}

	public def processResponse(Exchange exchange) throws APIFailedException{

		log.info("ATGGetOrderTransformation processResponse Entering");
		String contentType = exchange.in.getHeader("Content-Type");
		def updatedOrder = exchange.in.body
		if(contentType?.contains("json") && updatedOrder?.contains("CustomerOrderNumber")){
			log.info("ATGGetOrderTransformation success response");
			HashMap atgResponseJson = JsonConverters.toMapofMaps(exchange.in.body)
			if(exchange.in.headers.CamelHttpResponseCode.toString() == "200"){
				HashMap orderDetailsMap = atgResponseJson.get("OrderDetails")
				HashMap orderMap = orderDetailsMap.get("Order")
				log.info("ATGGetOrderTransformation success response " + orderMap);
				updatedOrder = orderMap
			}else{/* Unsuccessful HTTP Response */
				APIFailedException e = new APIFailedException();
				e.api = getApiName();
				e.code = exchange.in.headers.CamelHttpResponseCode.toString();
				e.subCode = (atgResponseJson?.Errors?.Error?.get(0)?.ErrorCode)?: "NA"
				e.codeDescription = (atgResponseJson?.Errors?.Error?.get(0)?.ErrorDescription)?: "NA"
				exchange.setException(e);
				throw e;
			}
		}
		else{/*Invalid response payload hence creating incident*/
			APIFailedException e = new APIFailedException();
			e.api = "CreateOrder";
			e.code = exchange.in.headers.CamelHttpResponseCode.toString();
			e.subCode = "NA";
			e.codeDescription = "NA";
			exchange.setException(e);
			throw e;
		}
		log.info("ATGGetOrderTransformation response " + updatedOrder);
		return updatedOrder
	}

}