package com.att.oce.bpm.transformations

import com.att.oce.bpm.common.OceConstants
import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.transformations.ATGHelper
import com.att.oce.config.components.GlobalProperties
import groovy.json.JsonSlurper
import groovy.util.slurpersupport.GPathResult

import java.util.List
import org.slf4j.LoggerFactory
import org.slf4j.Logger
import org.apache.camel.Exchange
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator
import org.camunda.bpm.engine.impl.util.json.JSONObject
import org.camunda.bpm.engine.impl.util.json.XML
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.PropertySource
import org.springframework.core.io.Resource
import org.springframework.stereotype.Component



@Component('atgUpdateOrderTransformation')
class ATGUpdateOrderTransformation extends CommonTransformationService{
	static Logger log = LoggerFactory.getLogger(ValidateAddressTransformation.class)
	String url;

	@Override String getApiName()
	{
		return 'UpdateOrder';
	}
	
	/*
	 * This function will do the transformation for Fraud Service
	 * @param exchange of type Camel Exchange
	 * */
	public def transform(Exchange exchange){

		def order = exchange.in.body.order;
		exchange.properties.put('order',order);
		exchange.properties.put('apiURN','urn:atgOrderUpdate');
		def executionContext = exchange.properties.executionContext
		order = updateLoSGStatus(order,executionContext)
		def transactionLogsList = createTransactionLogs(order,executionContext)
		def transactionLogsMap = [TransactionLogs:transactionLogsList]
		def jTransactionLogs = new JSONObject(transactionLogsMap)
		def jOrder = ATGHelper.convertFToNF(order);
		jOrder.setLength(jOrder.length() - 1);
		log.debug('jTransactionLogs:############ '+ jTransactionLogs);
		log.debug('Order after conversion:############ '+ jOrder);
		def atgUpdateReq = jOrder+','+'\"TransactionLogs\":'+jTransactionLogs.get('TransactionLogs').toString()+'}';
		
		setATGHttpHeaders(exchange);
		exchange.in.headers.put("CamelHttpUri",super.resolveURN('urn:atg:api',url));
		exchange.in.headers.put("isATGEndPointAMQ",globalConfig.isATGEndPointAMQ);
		exchange.properties.fedIndicator = true;
		setAuditLogProperties(exchange,true);
		return atgUpdateReq;
	}


	/*
	 * This function will take the Fraud response  and do necessary processing
	 * Will update order payload during success or return the APIFailedException object in case of Soap Fault
	 * @param exchange - Camel Exchange
	 * */
	def processResponse(Exchange exchange) {

		/* Initialize */
		def order = exchange.properties.order;
		String contentType = exchange.in.getHeader("Content-Type");

		def atgResponse = exchange.in.body;
		if(contentType?.contains("json") && atgResponse?.contains("OrderNumber")){
			def atgResponseJson = new JsonSlurper().parseText(atgResponse);
			if(exchange.in.headers.CamelHttpResponseCode == 200){
				order.put('oceOrderNumber',atgResponseJson.OrderNumber);
				exchange.out.body = order;
			}else{
				APIFailedException e = new APIFailedException();
				e.api = getApiName();
				e.code = exchange.in.headers.CamelHttpResponseCode.toString();
				e.subCode = (atgResponseJson?.Errors?.Error?.get(0)?.ErrorCode)?: "NA"
				e.codeDescription = (atgResponseJson?.Errors?.Error?.get(0)?.ErrorDescription)?: "NA"
				exchange.out.body = order;
				exchange.setException(e);
				throw e;
			}
		}
		else{
			APIFailedException e = new APIFailedException();
			e.api = getApiName();
			e.code = exchange.in.headers.CamelHttpResponseCode.toString();
			e.subCode = "NA";
			e.codeDescription = "NA";
			exchange.out.body = order;
			exchange.setException(e);
			throw e;
		}
	}

	def createTransactionLogs(order,executionContext){
		
		def transactionLogsList = new ArrayList();
		
		def group 
		def orderId
		def service
		def servicetype
		def number 
		def losgRefId
		
		List<Map<String,Object>> transactionHistory = (List<Map<String,Object>>) executionContext.transactionHistory;
		List<Map<String,Object>> updatedTransactionHistory = getUpdatedTransactionHistory(transactionHistory)
		updatedTransactionHistory.each {transHis->
			Map<String,Object> transactionLogs = new HashMap<String, Object>();
			def groupId = order.productGroups?.group.findAll{g-> g.type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE}.collect{it.id}
			if(groupId.contains(transHis.ReferenceId)){
				group = order.productGroups.group.find{g-> g.type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE && g.id == transHis.ReferenceId};
				orderId = order.oceOrderNumber ? order.oceOrderNumber : order.parentOrderNumber
				service = group?group.characteristics.losgCharacteristics.productCategory : order.productGroups.group.characteristics.losgCharacteristics.productCategory.join(",")
				servicetype = group?group.characteristics.losgCharacteristics.losgType : order.productGroups.group.characteristics.losgCharacteristics.losgType.join(",")
				number = (group && group.characteristics.losgCharacteristics.wirelessLOSCharacteristics.mobileNumber ) ? group.characteristics.losgCharacteristics.wirelessLOSCharacteristics.mobileNumber : order.customerOrderNumber
				losgRefId = group?group.characteristics.losgCharacteristics.losgReferenceId : order.productGroups.group.characteristics.losgCharacteristics.losgReferenceId.join(",")
			   }
		   else{
				group = order.productGroups.group.findAll{g-> g.type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE};
				orderId = order.oceOrderNumber ? order.oceOrderNumber : order.parentOrderNumber
				service = group?group.characteristics.losgCharacteristics.productCategory.join(",") : order.productGroups.group.characteristics.losgCharacteristics.productCategory.join(",")
				servicetype = group?group.characteristics.losgCharacteristics.losgType.join(",") : order.productGroups.group.characteristics.losgCharacteristics.losgType.join(",")
				number = (group && group.characteristics.losgCharacteristics.wirelessLOSCharacteristics.mobileNumber ) ? group.characteristics.losgCharacteristics.wirelessLOSCharacteristics.mobileNumber.join(",") : order.customerOrderNumber
				losgRefId = group?group.characteristics.losgCharacteristics.losgReferenceId.join(",") : order.productGroups.group.characteristics.losgCharacteristics.losgReferenceId.join(",")
				}
			   
			   def startTime = transHis.StartTime ? transHis.StartTime : dateTimeformat.format(new Date())
			   def endTime = transHis.EndTime ? transHis.EndTime : dateTimeformat.format(new Date())
				   
		
			transactionLogs.put(OceConstants.KEY_START_TIME,startTime);
			transactionLogs.put(OceConstants.KEY_END_TIME,endTime);
			transactionLogs.put(OceConstants.KEY_STATUS, transHis.status);
			transactionLogs.put(OceConstants.KEY_SUB_STATUS,transHis.subStatus);
			if(orderId!=null){
				transactionLogs.put(OceConstants.KEY_ORDER_ID,orderId);
			}
			transactionLogs.put(OceConstants.KEY_SERVICE,service);
			transactionLogs.put(OceConstants.KEY_SERVICE_TYPE,servicetype);
			transactionLogs.put(OceConstants.KEY_NUMBER,number);
			transactionLogs.put(OceConstants.KEY_LOSG_REFERENCE_ID,losgRefId);
			transactionLogs.put(OceConstants.KEY_CHANGED_LOSG_REFERENCE_ID,losgRefId);
			transactionLogs.put(OceConstants.KEY_MARKER_KEY,"SYSTEM")
			transactionLogs.put(OceConstants.KEY_MARKER_TYPE,"Order Update")
			
			transactionLogsList.add(transactionLogs);
		}
		
		return transactionLogsList;
	}	
	
	def updateLoSGStatus(order,executionContext){
		def transactionHistory = executionContext.transactionHistory;
		def loSGStatus= [:];
		if(transactionHistory != null && transactionHistory.last().ReferenceId == order.customerOrderNumber){
			loSGStatus = [status:transactionHistory.last().status, subStatus:transactionHistory.last().subStatus];
			order.productGroups.group.each{ g ->
				if(g.characteristics.losgCharacteristics && (!isLoSGCancelled(order,g.id))){
					g.characteristics.losgCharacteristics.put("losgStatus",loSGStatus);
				}
			}
		}
		else{
			order.productGroups.group.each{ g ->
				if(g.characteristics.losgCharacteristics){
					def th = transactionHistory.findAll{th -> th.ReferenceId == g.id}?.last();
					def losgStatus = [status:th.status, subStatus:th.subStatus]
					if(!isLoSGCancelled(order,g.id)){
					g.characteristics.losgCharacteristics.put("losgStatus",losgStatus);
					}
				}
			}
		}
		return order;
	}
	
	 def isLoSGCancelled(order,groupId){
		
				log.info('atgUpdateOrderTransformation.isLoSGCancelled <-- Entering');
				log.debug('atgUpdateOrderTransformation.isLoSGCancelled: Group ID: ' + groupId);
		
				def result=false;
		
				if(order.productGroups.group.find{g-> g.id == groupId && g.characteristics.losgCharacteristics.losgStatus?.status  == 'CANCELED'}){
					result=true;
				}
		
				log.debug('atgUpdateOrderTransformation.isLoSGCancelled: Result:' + result);
				log.info('atgUpdateOrderTransformation.isLoSGCancelled --> Exiting');
			}
		
		
}