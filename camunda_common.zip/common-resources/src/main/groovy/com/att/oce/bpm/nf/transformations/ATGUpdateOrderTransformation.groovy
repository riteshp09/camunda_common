package com.att.oce.bpm.nf.transformations

import com.att.oce.bpm.common.TransformationService
import com.att.oce.bpm.error.APIFailedException
import com.att.oce.bpm.transformations.InquireAccountProfileTransformation

import groovy.json.JsonSlurper
import twitter4j.AccountSettings

import org.apache.camel.Exchange
import org.json.JSONObject
import org.springframework.stereotype.Component

import com.att.aft.dme2.internal.google.common.base.Predicates.ContainsPatternPredicate
import com.att.aft.dme2.internal.grm.v1.FindAllContainerDefinitionRequest
import com.att.oce.bpm.common.OceConstants

@Component('atgUpdateOrderTransformation')
class ATGUpdateOrderTransformation extends ATGCreateOrderTransformation {

	String url;

	/*
	 * This function will do the transformation for Fraud Service
	 * @param exchange of type Camel Exchange
	 * */
	public def transform(Exchange exchange){

		exchange.properties.order = exchange.in.body.order
		exchange.properties.apiURN = "urn:atgOrderUpdate"
		exchange.properties.fedIndicator = false
		setAuditLogProperties(exchange,false)
		exchange.in.headers.put("isATGEndPointAMQ",globalConfig.isATGEndPointAMQ);

		def oceJsonMap = exchange.in.body.order
		def executionContext = exchange.properties.executionContext
		def oceUpdatedOrder = updateLoSGStatus(oceJsonMap,executionContext)
		def transactionLogsList = createTransactionLogs(oceJsonMap,executionContext)
		def atgUpdateReqMap = [Order:oceUpdatedOrder,TransactionLogs:transactionLogsList]
		def atgUpdateReqString = new JSONObject(atgUpdateReqMap).toString()

		super.setATGHttpHeaders(exchange)
		exchange.getIn().getHeaders().put("CamelHttpMethod",HTTP_METHOD_PUT);
		exchange.in.headers.put("CamelHttpUri",super.resolveURN('urn:atg:api',url))
		return atgUpdateReqString
	}


	/*
	 * This function will take the Fraud response  and do necessary processing
	 * Will update order payload during success or return the APIFailedException object in case of Soap Fault
	 * @param exchange - Camel Exchange
	 * */
	def processResponse(Exchange exchange) {

		/* Initialize */
		def order = exchange.properties.order;
		String contentType = exchange.in.getHeader("Content-Type");

		def atgResponse = exchange.in.body;
		if(contentType?.contains("json") && atgResponse?.contains("OrderNumber")){
			def atgResponseJson = new JsonSlurper().parseText(atgResponse);
			if(exchange.in.headers.CamelHttpResponseCode == 200){
				exchange.out.body = order;
			}else{
				APIFailedException e = new APIFailedException();
				e.api = 'UpdateOrder';
				e.code = exchange.in.headers.CamelHttpResponseCode.toString();
				e.subCode = (atgResponseJson?.Errors?.Error?.get(0)?.ErrorCode)?: "NA"
				e.codeDescription = (atgResponseJson?.Errors?.Error?.get(0)?.ErrorDescription)?: "NA"
				exchange.out.body = order;
				exchange.setException(e);
				throw e;
			}
		}
	}

	def createTransactionLogs(Order,executionContext){

		def transactionLogsList = new ArrayList()

		/*def group = Order.Groups.Group.findAll{g-> g.Type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE}
		def orderId = Order.OCEOrderNumber ? Order.OCEOrderNumber : Order.ParentOrderNumber
		def service = group ? group.GroupCharacteristics.LoSGCharacteristics.ProductCategory.join(",") : Order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.ProductCategory.join(",")
		def servicetype = group ? group.GroupCharacteristics.LoSGCharacteristics.LoSGType.join(",") : Order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.LoSGType.join(",")
		def number = (group && group.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.MobileNumber ) ? group.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.MobileNumber.join(",") : Order.CustomerOrderNumber
		def losgRefId = group ? group.GroupCharacteristics.LoSGCharacteristics.LoSGReferenceId.join(",") : Order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.LoSGReferenceId.join(",")
*/
		def group
		def orderId
		def service
		def servicetype
		def number
		def losgRefId
		List<Map<String,Object>> transactionHistory = (List<Map<String,Object>>) executionContext.transactionHistory;
		List<Map<String,Object>> updatedTransactionHistory = getUpdatedTransactionHistory(transactionHistory)
		
		for (Object transHis: updatedTransactionHistory) {
			
			Map<String,Object> transactionLogs = new HashMap<String, Object>();
			def groupId = Order.Groups.Group.findAll{g-> g.Type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE}.collect{it.Id}
			def accountId = Order.Accounts?.Account?.Id 
			if(groupId.contains(transHis.ReferenceId) || accountId.contains(transHis.ReferenceId)){
			 group = Order.Groups.Group.findAll{g-> g.Type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE && (g.Id == transHis.ReferenceId || g.GroupCharacteristics.LoSGCharacteristics.AccountRef == transHis.ReferenceId)}
			 orderId = Order.OCEOrderNumber ? Order.OCEOrderNumber : Order.ParentOrderNumber
			 service = group ? group.GroupCharacteristics.LoSGCharacteristics.ProductCategory.join(",") : Order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.ProductCategory.join(",")
			 servicetype = group ? group.GroupCharacteristics.LoSGCharacteristics.LoSGType.join(",") : Order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.LoSGType.join(",")
			 number = (group && group.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.MobileNumber ) ? group.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.MobileNumber.join(",") : Order.CustomerOrderNumber
			 losgRefId = group ? group.GroupCharacteristics.LoSGCharacteristics.LoSGReferenceId.join(",") : Order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.LoSGReferenceId.join(",")
			}
			else{
				group = Order.Groups.Group.findAll{g-> g.Type == OceConstants.GROUP_TYPE_LINE_OF_SERVICE}
				orderId = Order.OCEOrderNumber ? Order.OCEOrderNumber : Order.ParentOrderNumber
				service = group ? group.GroupCharacteristics.LoSGCharacteristics.ProductCategory.join(",") : Order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.ProductCategory.join(",")
				servicetype = group ? group.GroupCharacteristics.LoSGCharacteristics.LoSGType.join(",") : Order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.LoSGType.join(",")
				number = (group && group.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.MobileNumber ) ? group.GroupCharacteristics.LoSGCharacteristics.WirelessLOSChars.MobileNumber.join(",") : Order.CustomerOrderNumber
				losgRefId = group ? group.GroupCharacteristics.LoSGCharacteristics.LoSGReferenceId.join(",") : Order.Groups.Group.GroupCharacteristics.LoSGCharacteristics.LoSGReferenceId.join(",")
				}
			
			def startTime = transHis.StartTime ? transHis.StartTime : dateTimeformat.format(new Date())
			def endTime = transHis.EndTime ? transHis.EndTime : dateTimeformat.format(new Date())
				
			transactionLogs.put(OceConstants.KEY_START_TIME,startTime)
			transactionLogs.put(OceConstants.KEY_END_TIME,endTime)
			transactionLogs.put(OceConstants.KEY_STATUS, transHis.status)
			transactionLogs.put(OceConstants.KEY_SUB_STATUS,transHis.subStatus)
			transactionLogs.put(OceConstants.KEY_ORDER_ID,orderId)
			transactionLogs.put(OceConstants.KEY_SERVICE,service)
			transactionLogs.put(OceConstants.KEY_SERVICE_TYPE,servicetype)
			transactionLogs.put(OceConstants.KEY_NUMBER,number)
			transactionLogs.put(OceConstants.KEY_LOSG_REFERENCE_ID,losgRefId)
			transactionLogs.put(OceConstants.KEY_CHANGED_LOSG_REFERENCE_ID,losgRefId)
			transactionLogs.put(OceConstants.KEY_MARKER_KEY,"SYSTEM")
			//transLogTemplate.put(OceConstants.KEY_MARKER_TYPE1,"Order Update")

			transactionLogsList.add(transactionLogs)
		}

		return transactionLogsList
	}
	
	def updateLoSGStatus(order,executionContext){
		def transactionHistory = executionContext.transactionHistory
		def loSGStatus= [:];
		def accountId = order.Accounts?.Account?.Id
		if(transactionHistory != null && transactionHistory.last().ReferenceId == order.CustomerOrderNumber){
			loSGStatus = [Status:transactionHistory.last().status, SubStatus:transactionHistory.last().subStatus]
			order.Groups.Group.each{ losg ->
			if(losg.GroupCharacteristics.LoSGCharacteristics && (!validateCancelledLosg(order,losg.Id))){
					losg.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",loSGStatus)
				}
			}
		}
		else if (transactionHistory != null && accountId.contains(transactionHistory.last().ReferenceId)){
			order.Groups.Group.each{ losg -> 
				if(losg.GroupCharacteristics.LoSGCharacteristics){
						def thAll = transactionHistory.findAll{th -> th.ReferenceId == losg.GroupCharacteristics.LoSGCharacteristics.AccountRef};
						def th = !thAll.isEmpty() ? thAll.last() : null;
						if(th){
							def losgStatus = [Status:th.status, SubStatus:th.subStatus]
							if(!validateCancelledLosg(order,losg.Id)){
							losg.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",losgStatus);
						}
						}
					}
				}
		}
		
		else{
			order.Groups.Group.each{ losg ->
			if(losg.GroupCharacteristics.LoSGCharacteristics){
					def thAll = transactionHistory.findAll{th -> th.ReferenceId == losg.Id}
					def th = !thAll.isEmpty() ? thAll.last() : null;
					if(th){
						def losgStatus = [Status:th.status, SubStatus:th.subStatus]
						if(!validateCancelledLosg(order,losg.Id)){
						losg.GroupCharacteristics.LoSGCharacteristics.put("LoSGStatus",losgStatus);
						}
					}
				}
			}
		}
		return order
	}

}