package com.att.oce.bpm.common;

import static org.junit.Assert.*;
import java.text.ParseException;
import java.util.Map;

import org.apache.commons.lang3.StringEscapeUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.beans.config.OceConfig;
import com.att.oce.config.components.GlobalProperties;
import com.att.oce.config.components.URNResolver;


public class TransformationServiceTest extends TransformationService{

	static Logger log = LoggerFactory.getLogger(TransformationServiceTest.class);

	@BeforeClass
	public static void init() {
		System.setProperty("OCE_RESOURCES_HOME", "./../../oce_framework/oce-resources/src/main/resources/");
		System.setProperty("OCE_ENV", "dev");
		System.setProperty("OCE_DOMAIN", "wireless");
	} 

	@Test
	public void testconvertLongToDate() throws ParseException
	{
		String input ="1493944687576";
		String result =  convertLongToDate(input,"yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		System.out.println(result);
		System.out.println("***************Authorization Date*****************");
		String authorizationDate = convertLongToDate("2017-05-04", "yyyy-MM-dd\'Z\'");
		System.out.println(authorizationDate);
		System.out.println("***************Authorization Expiration Date*****************");
		String authorizationExpDate = convertLongToDate("2017-06-01", "yyyy-MM-dd\'Z\'");
		System.out.println(authorizationExpDate);
		System.out.println("***************Initial Promise From/To Date*******************");
		String ipfd = convertLongToDate("1493967600000", "yyyy-MM-dd\'T\'HH:mm:ss\'Z\'");
		System.out.println(ipfd);
		System.out.println("***************Original Order Date****************");
		String ood =  convertLongToDate("1493963644567","yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		System.out.println(ood);
		assertEquals("Success", "yyyy-MM-dd", determineDateFormat("2017-05-08"));
	}

	/*@Test
	public void testEscapeSoapRequest()
	{
		String input = "<soapenv:Envelopexmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"xmlns:cin=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/CingularDataModel.xsd\"xmlns:anreq=\"http://csi.cingular.com/CSI/Namespaces/Container/Public/AddNoteRequest.xsd\"><soapenv:Headerxmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><mes:MessageHeaderxmlns:mes=\"http://csi.cingular.com/CSI/Namespaces/Types/Public/MessageHeader.xsd\"><mes:TrackingMessageHeader><cin:version>v116</cin:version><cin:messageId>REQ3-307100109142323~C3-307100109142323~2c20c7b8-ba91-4668-a68b-8d6bdac04d5a</cin:messageId><cin:originatorId>OCE</cin:originatorId><cin:timeToLive>30000</cin:timeToLive><cin:dateTimeStamp>2017-05-16T05:30:09.832Z</cin:dateTimeStamp></mes:TrackingMessageHeader><mes:SecurityMessageHeader><cin:userName>xxx</cin:userName><cin:userPassword>xxxxxxx</cin:userPassword></mes:SecurityMessageHeader><mes:SequenceMessageHeader><cin:sequenceNumber>1</cin:sequenceNumber><cin:totalInSequence>1</cin:totalInSequence></mes:SequenceMessageHeader></mes:MessageHeader></soapenv:Header><soapenv:Body><anreq:AddNoteRequest><anreq:accountType>Billing</anreq:accountType><anreq:AccountSelector><cin:AccountSubscriberSelector><cin:subscriberNumber>4154537217</cin:subscriberNumber><cin:BillingAccountInformation><cin:billingAccountNumber>545111472918</cin:billingAccountNumber><cin:billingMarket><cin:billingMarket>NCA</cin:billingMarket><cin:billingSubMarket>SFR</cin:billingSubMarket></cin:billingMarket></cin:BillingAccountInformation></cin:AccountSubscriberSelector></anreq:AccountSelector><anreq:Notes><cin:noteText>WebOrderNumber:C3-307100109142323,BAN:545111472918,OTC:64.85,CONTRACTTERMMONTH:,RatePlan:,DateofSale:2015-08-06T14:11:52,CTN:4154537217,DeviceName:AT&TCingularFlip-Black,AddOptFeature:,AddOptFeature:AccessforBasic&QuickMessagingPhone</cin:noteText><cin:noteType>CSM</cin:noteType><cin:priority>R</cin:priority></anreq:Notes></anreq:AddNoteRequest></soapenv:Body></soapenv:Envelope>";
		String result = escapeSoapRequest(input);
		assertTrue(result.contains("&amp;"));
	}*/

	@Test
	public void testDateInputasLong() throws ParseException
	{
		long input = 1493963644567L;
		String result = convertLongToDate(input,"yyyy-MM-dd\'Z\'");
		assertEquals("2017-05-05Z",result);
	}

	@Test
	public void testEscapeSoapRequestRecursively() throws Exception
	{
		Map order = TestOrderBuilder.build("orderWithEncryptedCharacters").getMapofMaps();	
		System.out.println("Before Convertion : "); 
		System.out.println(order); 
		System.out.println("After Convertion : "); 
		System.out.println(new JSONObject(escapeSoapRequest(order))); 
	}
}
