package com.att.oce.beans.config;

import org.apache.camel.component.http4.HttpClientConfigurer;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedAttribute;

import com.att.oce.config.components.GlobalProperties;

public class OceHttpClientConfigurer implements HttpClientConfigurer {
	
	PoolingHttpClientConnectionManager pool;
	
	@ManagedAttribute
	public int getAvailable(){
		return pool.getTotalStats().getAvailable();
	}

	@ManagedAttribute
	public int getLeased(){
		return pool.getTotalStats().getLeased();
	}

	@ManagedAttribute
	public int getMax(){
		return pool.getTotalStats().getMax();
	}
	
	@ManagedAttribute
	public int getPending(){
		return pool.getTotalStats().getPending();
	}
	
	public void init(GlobalProperties global){
		pool = new PoolingHttpClientConnectionManager();
		pool.setDefaultMaxPerRoute(global.CamelHttpMaxPerRoute);
		pool.setMaxTotal(global.CamelHttpMaxTotal);
	}

	@Override
	public void configureHttpClient(HttpClientBuilder builder) {
		builder.setConnectionManager(pool);
	}

}
