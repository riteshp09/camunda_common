package com.att.oce.beans.config;

import java.sql.SQLException;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.stereotype.Component;

@Component("camundaDataBaseMetrics")
public class CamundaDataBaseMetrics {

	@Autowired BasicDataSource basicDataSource;
	
	@ManagedAttribute
    public int getMaxActive() {
		return basicDataSource.getMaxActive();
	}
	
	@ManagedAttribute
    public void setMaxActive(int maxActive) {
		basicDataSource.setMaxActive(maxActive);
	}
	
	@ManagedAttribute
    public int getMaxIdle() {
		return basicDataSource.getMaxIdle();
	}
		
	@ManagedAttribute
    public int getMinIdle() {
		return basicDataSource.getMinIdle();
	}
		
	@ManagedAttribute
    public int getNumActive() {
		return basicDataSource.getNumActive();
	}
		
	@ManagedAttribute
    public int getNumIdle() {
		return basicDataSource.getNumIdle();
	}
	
	@ManagedAttribute
    public long getMaxWait() {
		return basicDataSource.getMaxWait();
	}

	@ManagedAttribute
    public void setMaxWait(long maxWait) {
		basicDataSource.setMaxWait(maxWait);
	}

	@ManagedAttribute
    public int getDefaultTransactionIsolation() {
		return basicDataSource.getDefaultTransactionIsolation();
	}
	
	@ManagedAttribute
    public int getInitialSize() {
		return basicDataSource.getInitialSize();
	}

	@ManagedAttribute
    public int getLoginTimeout() throws SQLException {
		return basicDataSource.getLoginTimeout();
	}
	
	@ManagedAttribute
    public int getMaxOpenPreparedStatements() {
		return basicDataSource.getMaxOpenPreparedStatements();
	}
	
	@ManagedAttribute
    public long getMinEvictableIdleTimeMillis() {
		return basicDataSource.getMinEvictableIdleTimeMillis();
	}
	
	@ManagedAttribute
    public long getTimeBetweenEvictionRunsMillis() {
		return basicDataSource.getTimeBetweenEvictionRunsMillis();
	}
}
