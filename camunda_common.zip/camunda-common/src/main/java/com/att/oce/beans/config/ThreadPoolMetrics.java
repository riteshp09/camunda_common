package com.att.oce.beans.config;

import org.camunda.bpm.engine.spring.components.jobexecutor.SpringJobExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

@Component("threadPoolMetrics")
public class ThreadPoolMetrics {
	
	private ThreadPoolTaskExecutor taskExecutor;

	@Autowired
	public void setJobExecutor(SpringJobExecutor jobExecutor) {
		this.taskExecutor = (ThreadPoolTaskExecutor)jobExecutor.getTaskExecutor();
	}

	@ManagedAttribute
    public int getQueueSize() {
		return taskExecutor.getThreadPoolExecutor().getQueue().size();
    }
	@ManagedAttribute
    public int getActiveCount() {
		return taskExecutor.getThreadPoolExecutor().getActiveCount();
    }
	@ManagedAttribute
    public long getCompletedTaskCount() {
		return taskExecutor.getThreadPoolExecutor().getCompletedTaskCount();
    }
	
	@ManagedAttribute
    public int getCorePoolSize() {
		return taskExecutor.getThreadPoolExecutor().getCorePoolSize();
    }
	
	@ManagedAttribute
    public void setCorePoolSize(int corePoolSize) {
		taskExecutor.getThreadPoolExecutor().setCorePoolSize(corePoolSize);
    }

	@ManagedAttribute
    public int getMaximumPoolSize() {
		return taskExecutor.getThreadPoolExecutor().getMaximumPoolSize();
    }
	
	@ManagedAttribute
    public void setMaximumPoolSize(int maximumPoolSize) {
		taskExecutor.getThreadPoolExecutor().setMaximumPoolSize(maximumPoolSize);
    }

}
