package com.att.oce.beans.config;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import org.apache.camel.CamelContext;
import org.apache.camel.NamedNode;
import org.apache.camel.Processor;
import org.apache.camel.management.DefaultManagementNamingStrategy;
import org.apache.camel.processor.*;

public class OceCamelNamingStrategy extends DefaultManagementNamingStrategy {
	
	Pattern httpPattern = Pattern.compile("http4\\:\\/\\/([a-zA-Z0-9]+)\\?");
	
	@Override
	public ObjectName getObjectNameForProcessor(CamelContext context, Processor processor, NamedNode definition) throws MalformedObjectNameException {
        StringBuilder buffer = new StringBuilder();
        buffer.append(domainName).append(":");
        buffer.append(KEY_CONTEXT + "=").append(getContextId(context)).append(",");
        buffer.append(KEY_TYPE + "=").append(TYPE_PROCESSOR).append(",");
        String id = definition.getId();
        if (definition.getId().startsWith("to") && processor instanceof SendProcessor){
        	SendProcessor p = (SendProcessor)processor;
        	Matcher m = httpPattern.matcher(p.getTraceLabel());
        	if (m.find()){
        		id = m.group(1)+"-http";
        	}
        }
        
        buffer.append(KEY_NAME + "=").append(ObjectName.quote(id));
        return createObjectName(buffer);
    }

}
