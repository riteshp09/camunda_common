package com.att.oce.bpm.common;

import java.util.ArrayList;
import java.util.List;

import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.ModelCamelContext;
import org.apache.camel.model.RouteDefinition;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.jmx.export.MBeanExportException;
import org.springframework.jmx.export.MBeanExporter;
import org.springframework.stereotype.Component;

import com.att.oce.beans.config.CamundaDataBaseMetrics;
import com.att.oce.beans.config.CamundaMetricsRegistry;
import com.att.oce.beans.config.OceHttpClientConfigurer;
import com.att.oce.beans.config.ThreadPoolMetrics;
import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.config.components.GlobalProperties;

@Component
public class AuditLogInterceptor implements ApplicationListener<ContextRefreshedEvent>{

	static Logger log = LoggerFactory.getLogger(AuditLogInterceptor.class);

	@Autowired GlobalProperties global;

	@Autowired CamelContext context;

	@Autowired MBeanExporter mbeanExporter;

	@Autowired ThreadPoolMetrics threadPoolMetrics;

	@Autowired CamundaDataBaseMetrics camundaDataBaseMetrics;
	
	@Autowired CamundaMetricsRegistry camundaMetricsRegistry;
	
	@Autowired OceHttpClientConfigurer oceHttpClientConfigurer;
	
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {

		List<RouteDefinition> RouteDefinitions = context.getRouteDefinitions();
		for(RouteDefinition r : RouteDefinitions)
		{
			log.info("Route ID " + r.getId() + " exists in context");
		}

		List<String> ignorableRoutes = new ArrayList<String>();
		ignorableRoutes.add("auditLogRouteBuilder");
		ignorableRoutes.add("auditLogResponseRouteBuilder");

		for(int i=0; i<RouteDefinitions.size(); i++)
		{
			RouteDefinition routeDef = RouteDefinitions.get(i);
			if(global.AuditLogSystemProperty.equals("OFF") && !ignorableRoutes.contains(routeDef.getId()))
			{
				try 
				{
					routeDef.adviceWith((ModelCamelContext)context, new RouteBuilder(){
						@Override
						public void configure() throws Exception {
							interceptSendToEndpoint("direct:auditlog:request").skipSendToOriginalEndpoint().bean(AuditLogHelper.class,"logRequest");
							interceptSendToEndpoint("direct:auditlog:response").skipSendToOriginalEndpoint().bean(AuditLogHelper.class,"logResponse");
						}
					});
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
				log.info("Turned off AuditLog for " + routeDef.getId());
			}
		}

		if(global.camundaMetricsFlag.equals("ON"))
		{	
			try {
				mbeanExporter.registerManagedResource(threadPoolMetrics,new ObjectName("com.att.oce.camunda", "name", "ThreadPoolMetrics"));
				mbeanExporter.registerManagedResource(camundaDataBaseMetrics,new ObjectName("com.att.oce.camunda", "name", "CamundaDataBaseMetrics"));
				mbeanExporter.registerManagedResource(camundaMetricsRegistry,new ObjectName("com.att.oce.camunda", "name", "CamundaMetricsRegistry"));
				mbeanExporter.registerManagedResource(oceHttpClientConfigurer,new ObjectName("com.att.oce.camel", "name", "CustomHttpConnectionPool"));				
			} catch (MBeanExportException e) {
				e.printStackTrace();
			} catch (MalformedObjectNameException e) {
				e.printStackTrace();
			}
		}
	}	
}
