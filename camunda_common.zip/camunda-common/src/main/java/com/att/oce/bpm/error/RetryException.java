package com.att.oce.bpm.error;

import java.util.Map;

public class RetryException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Map<String,Object> errorContext;
	
	private int maxRetryAttempts;
	public int getMaxRetryAttempts() {
		return maxRetryAttempts;
	}
	public void setMaxRetryAttempts(int maxRetryAttempts) {
		this.maxRetryAttempts = maxRetryAttempts;
	}
	public int getInterval() {
		return interval;
	}
	public void setInterval(int interval) {
		this.interval = interval;
	}
	private int interval;
	
	
	public Map<String,Object> getErrorContext() {
		return errorContext;
	}
	public void setErrorContext(Map<String,Object> errorContext) {
		this.errorContext = errorContext;
	}
	
	public RetryException(int maxRetryAttempts,int interval,Map<String,Object> errorContext){
		this.interval = interval;
		this.errorContext = errorContext;
		this.maxRetryAttempts = maxRetryAttempts;
	}
	
	@Override
	public String getMessage(){
		return "Retry to be attempted with "+maxRetryAttempts+" total attempts and interval as "+interval+" secs";
	}
	

}
