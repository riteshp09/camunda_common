package com.att.oce.bpm.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringEscapeUtils;
import org.camunda.bpm.dmn.engine.DmnDecision;
import org.camunda.bpm.dmn.engine.DmnDecisionRuleResult;
import org.camunda.bpm.dmn.engine.DmnDecisionTableResult;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.oce.bpm.error.APIFailedException;
import com.att.oce.config.components.GlobalProperties;
import com.att.oce.config.components.URNResolver;

@SuppressWarnings("unchecked")
public abstract class TransformationService {
	
	static Logger log = LoggerFactory.getLogger(TransformationService.class);
	
	public static String HTTP_METHOD_POST = "POST";
	public static String HTTP_METHOD_PUT = "PUT";
	public static String HTTP_METHOD_GET = "GET";
	
	private static String HTTP_CONTENT_TYPE_XML = "text/xml";
	private static String HTTP_CONTENT_TYPE_JSON = "application/json";
	
	private static String TILDE = "~";
	
	@Resource
	protected GlobalProperties globalConfig; 

	@Resource
	protected URNResolver urnResolver; 
	
	@Resource(name="apiResultDecisions") 
	protected DmnDecision apiResultDecisions;
	
	@Autowired 
	protected DmnEngine dmnEngine;
	
	protected String getApiName(){
		return "";
	}
	
	public Map<String,Object> getMap(Object... arguments){
		Map<String,Object> map = new HashMap<String, Object>();
		for(int i=0;i<arguments.length;i+=2){
			map.put(arguments[i].toString(), arguments[i+1]);
		}
		return map;
	}
	
	//Date routines	
	protected static SimpleDateFormat dateTimeformat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	
	
	protected static String getXmlDateTime(){
		return dateTimeformat.format(new Date());
	}

	protected static SimpleDateFormat xmlDateformat = new SimpleDateFormat("yyyy-MM-dd'Z'");
	
	// @author:sk598g - Changed TimeZone to GMT
	protected static String getXmlDate(){
		dateTimeformat.setTimeZone(TimeZone.getTimeZone("GMT"));
		return xmlDateformat.format(new Date());
	}
	
	protected static String formatDate(String input,String sourceFormat,String targetFormat){ 
		SimpleDateFormat sourceFormatter = new SimpleDateFormat(sourceFormat); 
 
		String dateInTargetedFormat = null; 
		try { 
			Date dateAsIs = sourceFormatter.parse(input); 
			SimpleDateFormat targetFormatter = new SimpleDateFormat(targetFormat); 
			dateInTargetedFormat = targetFormatter.format(dateAsIs); 
		} catch (ParseException e) { 
			e.printStackTrace(); 
		} 
 
		return dateInTargetedFormat; 
	}	
	
	protected Map<String,Object> createMessageHeader(Map<String,Object> order) {
		return getMap( "trackingMessageHeader",getMap( 
				"version" , globalConfig.csiVersion,
				"messageId" , order.get("requestId").toString()+TILDE+order.get("customerOrderNumber").toString()+TILDE+java.util.UUID.randomUUID().toString(),
				"originatorId" , globalConfig.csiOriginatorId,
				"dateTimeStamp" , getXmlDateTime()),
		 "securityMessageHeader" , getMap(
			 	"userName" , globalConfig.csiOceUserName,
				"userPassword" , globalConfig.csiOcePassword),
		 "sequenceMessageHeader" , getMap(
			  	"sequenceNumber" , 1,
			    "totalInSequence" , 1)
		);
	}
	
	protected void setAuditLogProperties(Exchange exchange, boolean fedIndicator) {

		String serviceName = "api_name";
	    String operationName = "api_operation";
	    String orderNumber = "oce_number";
	    String interfaceName = "interface_name";
	    String layer = "CAMUNDA";
	    String insertedBy = "CAMUNDA";
	    
		Map<String, Object> order = (Map<String, Object>) exchange.getProperties().get("order");
		
		String customerOrderNumber = "NA";
		String requestId = "NA";
		if (null != order) {
			customerOrderNumber = fedIndicator ? (String) order.get("customerOrderNumber") : (String) order.get("CustomerOrderNumber");
			requestId = fedIndicator ? (String) order.get("requestId") : (String) order.get("RequestId");
			if (order.containsKey("oceOrderNumber") || order.containsKey("OCEOrderNumber")) {
				orderNumber = fedIndicator ? (String) order.get("oceOrderNumber") : (String) order.get("OCEOrderNumber");
			}
		}
		String apiURN = (String) exchange.getProperties().get("apiURN");

		StringTokenizer  urn = new StringTokenizer(apiURN,":");
	    while(urn.hasMoreTokens()){
	    	serviceName = urn.nextToken();
	      }
	
	    if(serviceName.contains(".jws"))
	    {	
		 StringTokenizer  apiOperation = new StringTokenizer(serviceName,".");
	      operationName = apiOperation.nextToken();
	      interfaceName = "CSI";
	    }
	    else if(serviceName.equals("brmsService"))
	    {
	    	operationName = "executeFraudChecks";
	    	interfaceName = "BRMS";
	    	
	    }
	    else if(serviceName.equals("atgOrderCreate"))
	    {
	    	operationName = "POST";
	    	interfaceName = "ATG";
	    }
	    else if(serviceName.equals("atgCreateFalloutTask"))
	    {
	    	operationName = "POST";
	    	interfaceName = "ATG";
	    }
	    else if(serviceName.equals("atgOrderUpdate"))
	    {
	    	operationName = "POST";
	    	interfaceName = "ATG";
	    }
	    else if(serviceName.equals("atgGetOrder"))
	    {
	    	operationName = "GET";
	    	interfaceName = "ATG";
	    }
		String correlationId = UUID.randomUUID().toString();

		exchange.setProperty("AUDITLOG_REQUEST_ID", requestId);
		exchange.setProperty("AUDITLOG_CUSTOMER_ORDER_NUMBER", customerOrderNumber);
		exchange.setProperty("AUDITLOG_ORDER_NUMBER", orderNumber);
		exchange.setProperty("AUDITLOG_REQUEST_TIME", getXmlDateTime());			
		exchange.setProperty("AUDITLOG_INTERFACE_NAME", interfaceName);
		exchange.setProperty("AUDITLOG_CORRELATION_ID", correlationId);
		exchange.setProperty("AUDITLOG_OPERATION_NAME", operationName);
		exchange.setProperty("AUDITLOG_SERVICE_NAME", serviceName);
		exchange.setProperty("AUDITLOG_LAYER", layer);
		exchange.setProperty("AUDITLOG_INSERTED_BY", insertedBy);

	}
	
	/*
	 * @modifiedBy:sk598g
	 * @description: setStartTime(exchange) method is added at bottom to add start time.
     * 
     */
	protected void setCSIHttpHeaders(Exchange exchange){
		exchange.getIn().getHeaders().put("CamelHttpMethod",HTTP_METHOD_POST);
		exchange.getIn().getHeaders().put("Accept",HTTP_CONTENT_TYPE_XML);
		exchange.getIn().getHeaders().put("Content-Type",HTTP_CONTENT_TYPE_XML);
		exchange.getIn().getHeaders().put("CamelHttpMethod",HTTP_METHOD_POST);
		setStartTime(exchange);
	}

	/*
	 * @modifiedBy:sk598g
	 * @description: setStartTime(exchange) method is added at bottom to add start time.
     * 
     */
	protected void setATGHttpHeaders(Exchange exchange){
		exchange.getIn().getHeaders().put("CamelHttpMethod",HTTP_METHOD_POST);
		exchange.getIn().getHeaders().put("Accept",HTTP_CONTENT_TYPE_JSON);
		exchange.getIn().getHeaders().put("Content-Type",HTTP_CONTENT_TYPE_JSON);
		setStartTime(exchange);
	}
	
	/*
	 * @modifiedBy:sk598g
	 * @description: StartTime is set as timestamp as property in Exchange while setting up headers.
	 * @param exchange
     * 
     */
	protected void setStartTime(Exchange exchange) {
		exchange.setProperty("StartTime", getXmlDate());
	}
	
	
	protected Map<String,Object> getAPIConfig(APIFailedException e,String losgType,boolean bulkIndicator){
		DmnDecisionTableResult results = dmnEngine
				.evaluateDecisionTable(apiResultDecisions, getMap("api",getApiName(),"code",e == null?"0":e.getCode(),"subCode",e == null?"0":e.getSubCode(),"losgType",losgType!=null?losgType:"","bulkIndicator",bulkIndicator?bulkIndicator:""));
		DmnDecisionRuleResult result = results.getFirstResult();
		if (result.size() == 0){
			results = dmnEngine
					.evaluateDecisionTable(apiResultDecisions, getMap("api",getApiName(),"code",e == null?"0":e.getCode(),"subCode",e == null?"0":e.getSubCode(),"losgType",losgType!=null?losgType:"","bulkIndicator",""));
		}
		if (result.size() == 0){
			results = dmnEngine
					.evaluateDecisionTable(apiResultDecisions, getMap("api",getApiName(),"code",e == null?"0":e.getCode(),"subCode",e == null?"0":e.getSubCode(),"losgType","","bulkIndicator",""));
		}
		if (result.size() == 0){
			results = dmnEngine
					.evaluateDecisionTable(apiResultDecisions, getMap("api",getApiName(),"code",e == null?"0":e.getCode(),"subCode",null,"losgType","","bulkIndicator",""));
		}
		if (result.size() == 0){
			results = dmnEngine
					.evaluateDecisionTable(apiResultDecisions, getMap("api",getApiName(),"code",null,"subCode",null,"losgType","","bulkIndicator",""));
		}
		return result;
	}
	
	
	protected String resolveURN(String urn,String url){
		return urnResolver.resolveUrn(urn);
	}
	
	/*
	 * @modifiedBy:sk598g
	 * @description: StartTime is extracted from Exchange and EndTime is current time.
	 * @required: StartTime is set as timestamp as property in Exchange while setting up headers.
	 */
	public void addTransactionHistory(Exchange exchange, APIFailedException e){
			
		Map<String,Object> executionContext = (Map<String,Object>)exchange.getProperties().get("executionContext");
			
		if (!executionContext.containsKey("transactionHistory"))
			executionContext.put("transactionHistory",new ArrayList<Map<String,Object>>());

		String losgType = null;
		if (exchange.getProperties().get("OcelosgType") != null)
			losgType = exchange.getProperties().get("OcelosgType").toString();

		boolean bulkIndicator = false;
		if (exchange.getProperties().get("OcebulkIndicator") != null)
			bulkIndicator = (Boolean) exchange.getProperties().get("OcebulkIndicator");

		Map<String, Object> apires = getAPIConfig(e, losgType, bulkIndicator);

		List<Map<String, Object>> transactionHistory = (List<Map<String, Object>>) executionContext
				.get("transactionHistory");
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(), "api",
				exchange.getProperties().get("OceCSIApiName"), "success", (e == null), "status", apires.get("status"),
				"subStatus", apires.get("subStatus"),"ReferenceId",exchange.getProperties().get("referenceId")));

	}
	
	/* @createdBy:gm353e
	 * @description: Only used for NACK 
	 */
	
	public void addTransactionHistory(Map<String,Object> executionContext, APIFailedException e){
		if (!executionContext.containsKey("transactionHistory"))
			executionContext.put("transactionHistory",new ArrayList<Map<String,Object>>());
		Map<String,Object> apires = getAPIConfig(e, null, false);
		
		List<Map<String,Object>> transactionHistory = (List<Map<String,Object>>) executionContext.get("transactionHistory");
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(),"api",getApiName(),
				"success",(e == null),"status",apires.get("status"),"subStatus",apires.get("subStatus"),"ReferenceId",executionContext.get("referenceId")));
	}
	
	public void addSkipTransactionHistory(DelegateExecution execution, String referenceId){
		APIFailedException e = new APIFailedException();
		e.setApi(getApiName());
		e.setCode("NA");
		e.setCodeDescription(getApiName() + " is skipped");
		
		Map<String,Object> executionContext = (Map<String, Object>) execution.getVariable("executionContext");
		String losgType = null;
		if (executionContext.get("OcelosgType") != null)
			losgType = executionContext.get("OcelosgType").toString();

		boolean bulkIndicator = false;
		if (executionContext.get("OcebulkIndicator") != null)
			bulkIndicator = (Boolean) executionContext.get("OcebulkIndicator");
		
		Map<String, Object> apires = getAPIConfig(e, losgType, bulkIndicator);
		
		if (!executionContext.containsKey("transactionHistory"))
			executionContext.put("transactionHistory",new ArrayList<Map<String,Object>>());
		List<Map<String, Object>> transactionHistory = (List<Map<String, Object>>) executionContext.get("transactionHistory");
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(), "api",
				getApiName(), "success", (e == null), "status", apires.get("status"),
				"subStatus", apires.get("subStatus"),"ReferenceId",referenceId));
		executionContext.put("transactionHistory",transactionHistory);
		execution.setVariable("executionContext", executionContext);
		
	}
	
	public void addSkipTransactionHistory(DelegateExecution execution, String referenceId,String actionType){
		APIFailedException e = new APIFailedException();
		e.setApi(getApiName());
		e.setCode("NA");
		e.setCodeDescription(getApiName() + " is skipped");
		boolean bulkIndicator = false;
		
		Map<String, Object> apires = getAPIConfig(e, actionType, bulkIndicator);
		Map<String,Object> executionContext = (Map<String, Object>) execution.getVariable("executionContext");
		if (!executionContext.containsKey("transactionHistory"))
			executionContext.put("transactionHistory",new ArrayList<Map<String,Object>>());
		List<Map<String, Object>> transactionHistory = (List<Map<String, Object>>) executionContext.get("transactionHistory");
		transactionHistory.add(getMap("StartTime", getXmlDateTime(), "EndTime", getXmlDateTime(), "api",
				getApiName(), "success", (e == null), "status", apires.get("status"),
				"subStatus", apires.get("subStatus"),"ReferenceId",referenceId));
		executionContext.put("transactionHistory",transactionHistory);
		execution.setVariable("executionContext", executionContext);
		
	}
	
	protected Map<String,Object> removeKeysWithoutValues(Map<String,Object> map){ 
		Set<String> keys = new HashSet<String>(); 
		for (Entry<String,Object> entry : map.entrySet()) { 
			if (entry.getValue() == null || entry.getValue().toString() == "") { 
				keys.add(entry.getKey()); 
			} 
			else if(entry.getValue() instanceof Map){ 
				removeKeysWithoutValues((Map<String,Object>)entry.getValue()); 
				if( ((Map<String,Object>) entry.getValue()).keySet().size() == 0){ 
					keys.add(entry.getKey());
				} 
			} 
			else if(entry.getValue() instanceof List){ 
				List<Object> list = (List<Object>)entry.getValue(); 
				list = getMapFromList(list); 
			} 
		} 
 
		for(Object key : keys){ 
			map.remove(key);
		} 
		return map;
	}
	
	private List<Object> getMapFromList(List<Object> list){ 
		List<Object> returnList = new ArrayList<Object>();
		for (Object it : list){ 
			if(it instanceof Map){ 
				returnList.add(removeKeysWithoutValues((Map<String,Object>)it));
			} 
			else if(it instanceof List){ 
				returnList.add(getMapFromList((List<Object>)it));
			} 
		}
		return returnList; 
	}
	
	private static final Map<String, String> DATE_FORMAT_REGEXPS = new HashMap<String, String>() {/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

	{
	    put("^\\d{8}$", "yyyyMMdd");
	    put("^\\d{1,2}-\\d{1,2}-\\d{4}$", "dd-MM-yyyy");
	    put("^\\d{4}-\\d{1,2}-\\d{1,2}$", "yyyy-MM-dd");
	    put("^\\d{1,2}/\\d{1,2}/\\d{4}$", "MM/dd/yyyy");
	    put("^\\d{4}/\\d{1,2}/\\d{1,2}$", "yyyy/MM/dd");
	    put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}$", "dd MMM yyyy");
	    put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}$", "dd MMMM yyyy");
	    put("^\\d{12}$", "yyyyMMddHHmm");
	    put("^\\d{8}\\s\\d{4}$", "yyyyMMdd HHmm");
	    put("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}$", "dd-MM-yyyy HH:mm");
	    put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}$", "yyyy-MM-dd HH:mm");
	    put("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}$", "MM/dd/yyyy HH:mm");
	    put("^\\d{4}/\\d{1,2}/\\d{1,2}\\s\\d{1,2}:\\d{2}$", "yyyy/MM/dd HH:mm");
	    put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}\\s\\d{1,2}:\\d{2}$", "dd MMM yyyy HH:mm");
	    put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}\\s\\d{1,2}:\\d{2}$", "dd MMMM yyyy HH:mm");
	    put("^\\d{14}$", "yyyyMMddHHmmss");
	    put("^\\d{8}\\s\\d{6}$", "yyyyMMdd HHmmss");
	    put("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd-MM-yyyy HH:mm:ss");
	    put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$", "yyyy-MM-dd HH:mm:ss");
	    put("^\\d{4}-\\d{1,2}-\\d{1,2}'T'\\d{1,2}:\\d{2}:\\d{2}$", "yyyy-MM-dd'T'HH:mm:ss");
	    put("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "MM/dd/yyyy HH:mm:ss");
	    put("^\\d{4}/\\d{1,2}/\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$", "yyyy/MM/dd HH:mm:ss");
	    put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd MMM yyyy HH:mm:ss");
	    put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd MMMM yyyy HH:mm:ss");
	}};

	public static String determineDateFormat(String dateString) {
	    for (String regexp : DATE_FORMAT_REGEXPS.keySet()) {
	        if (dateString.toLowerCase().matches(regexp)) {
	            return DATE_FORMAT_REGEXPS.get(regexp);
	        }
	    }
	    return null; // Unknown format.
	}
	
	protected static String convertLongToDate(String input,String targetFormat) throws ParseException{
		SimpleDateFormat targetFormatter = new SimpleDateFormat(targetFormat);
		String formatedDate = null;
		Date dateAsIs = null;
		if(input.matches("^\\d{13}$"))
		{
			long dateInLong = Long.parseLong(input);
			dateAsIs = new Date(dateInLong);
			targetFormatter.setTimeZone(TimeZone.getTimeZone("GMT"));
		}
		else
		{	
			Calendar dateC = javax.xml.bind.DatatypeConverter.parseDateTime(input);
			if (dateC != null) dateAsIs = dateC.getTime();
			else {dateC = javax.xml.bind.DatatypeConverter.parseDate(input);if (dateC != null) dateAsIs = dateC.getTime();}
			
			if (dateC == null){
				String detectedFormat = determineDateFormat(input);
				if (detectedFormat != null){
					SimpleDateFormat formatter = new SimpleDateFormat(detectedFormat); 
					dateAsIs = (Date)formatter.parse(input);
				}			
			}
		}	
		if (dateAsIs == null)
			throw new ParseException("Cannot convert '"+input+"' to date.",0);
		
		formatedDate = targetFormatter.format(dateAsIs);
		return formatedDate;
	}
	
	protected static String convertLongToDate(long input,String targetFormat) throws ParseException{
		String targetDate = convertLongToDate(""+input, targetFormat);
		return targetDate;
	}
	
	protected static String convertLongToDateGMT(long input,String targetFormat){
		Date dateAsIs = new Date(input);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dateAsIs);
		calendar.add(Calendar.HOUR_OF_DAY, 12);
		SimpleDateFormat targetFormatter = new SimpleDateFormat(targetFormat);
		
		return targetFormatter.format(calendar.getTime());
	}

	/**
	 * Method to escape special characters during XML formation
	 * @param input
	 * @return
	 */
	public static String escapeXml(String input){
		log.debug("From 11 : "+input + " ==> To 11 : "+StringEscapeUtils.escapeXml11(input));
		return StringEscapeUtils.escapeXml11(input);
	}
	
	/**
	 * Method to escape special characters
	 * @param input
	 * @return
	 */
	public static String escapeHtml(String input){
		return StringEscapeUtils.escapeHtml4(input);
	}
	
	/**
	 * Method to escape special characters in soap-request 
	 * @param soapRequest
	 * @return
	 
	public static String escapeSoapRequest(String request)
	{
		String updatedRequest = request.replaceAll("&(?!.{2,4};)", "&amp;");
		return updatedRequest;
	}*/
	
	protected List<Map<String, Object>> getUpdatedTransactionHistory(List<Map<String,Object>> transactionHistory)
	{
		int position = 0;
		int counter =0;
		for (Map<String,Object> transHis: transactionHistory)
		{
			counter++;
			if(transHis.containsKey("recordType"))
			{	
				position =counter;
			}	
		}
		List<Map<String,Object>> updatedTransactionHistory = transactionHistory.subList(position,transactionHistory.size());
		return updatedTransactionHistory;		
	}
	
	/**
	 * Method to escape special characters in soap-request 
	 * @param soapRequest
	 * @return
	 */
	protected Map<String,Object> escapeSoapRequest(Map<String,Object> soapRequest){
		log.debug("Map Before : >>>>>>>>>>>>>>>>> " +soapRequest); 
		for (Entry entry : soapRequest.entrySet()) {
			if(entry.getValue() instanceof Map){
				escapeSoapRequest((Map)entry.getValue());
			}
			else if(entry.getValue() instanceof List){
				List<Object> list = (List<Object>)entry.getValue(); 
				list = escapeSoapRequest(list);
			}
			else if(entry.getValue() instanceof String){
				entry.setValue(escapeXml(entry.getValue().toString()));
			}
			else{
				/* Do Nothing as of now */
			}
			
		}
		log.debug("Map After : >>>>>>>>>>>>>>>>> " +soapRequest); 
		return soapRequest;
	}
	
	/**
	 * Method to escape special characters in soap-request 
	 * @param nodeElements
	 * @return
	 */
	protected List escapeSoapRequest(List<Object> nodeElements){
		List<Object> returnList = new ArrayList<Object>();
		for (Object nodeElement : nodeElements) {
			if(nodeElement instanceof Map){
				returnList.add(escapeSoapRequest((Map)nodeElement));
			}
			else if(nodeElement instanceof List){
				returnList.add(escapeSoapRequest((List)nodeElement));
			}
			else if(nodeElement instanceof String){
				returnList.add(escapeXml(nodeElement.toString()));
			}
			else{
				returnList.add(nodeElement);
			}
		}
		return returnList;
	}
}