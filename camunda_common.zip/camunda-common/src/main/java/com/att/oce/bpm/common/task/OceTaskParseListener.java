package com.att.oce.bpm.common.task;

import org.camunda.bpm.engine.delegate.TaskListener;
import org.camunda.bpm.engine.impl.bpmn.behavior.UserTaskActivityBehavior;
import org.camunda.bpm.engine.impl.bpmn.parser.AbstractBpmnParseListener;
import org.camunda.bpm.engine.impl.pvm.process.ScopeImpl;
import org.camunda.bpm.engine.impl.util.xml.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.camunda.bpm.engine.impl.pvm.delegate.ActivityBehavior;
import org.camunda.bpm.engine.impl.pvm.process.ActivityImpl;

public class OceTaskParseListener extends AbstractBpmnParseListener  {
	
	@Autowired
	OceTaskCreateListener atgTaskCreateListener;
	
	@Override
	public void parseUserTask(Element userTaskElement, ScopeImpl scope, ActivityImpl activity) {

		ActivityBehavior behaviour = activity.getActivityBehavior();
		if (behaviour instanceof UserTaskActivityBehavior) {
			UserTaskActivityBehavior userTaskBehaviour = (UserTaskActivityBehavior) behaviour;
			userTaskBehaviour.getTaskDefinition().addTaskListener(TaskListener.EVENTNAME_CREATE, atgTaskCreateListener);
		}
	}
	  
}
