package com.att.oce.bpm.error;

import org.camunda.bpm.engine.impl.incident.DefaultIncidentHandler;
import org.camunda.bpm.engine.impl.incident.IncidentContext;
import org.camunda.bpm.engine.impl.persistence.entity.IncidentEntity;
import org.camunda.bpm.engine.runtime.Incident;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OceIncidentHandler extends DefaultIncidentHandler{

	static Logger log = LoggerFactory.getLogger(OceIncidentHandler.class);

	public OceIncidentHandler(String type) {
		super(type);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Incident createIncident(IncidentContext context, String message) {
		IncidentEntity newIncident = IncidentEntity.createAndInsertIncident(type, context, message);

		if(context.getExecutionId() != null) {
			newIncident.createRecursiveIncidents();
		}
		log.error("Incident Created for : " + context.getExecutionId());
		return newIncident;
	}

}