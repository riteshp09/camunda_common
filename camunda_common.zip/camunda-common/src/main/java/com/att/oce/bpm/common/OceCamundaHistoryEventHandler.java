package com.att.oce.bpm.common;

import org.camunda.bpm.engine.impl.history.event.HistoricActivityInstanceEventEntity;
import org.camunda.bpm.engine.impl.history.event.HistoricProcessInstanceEventEntity;
import org.camunda.bpm.engine.impl.history.event.HistoricTaskInstanceEventEntity;
import org.camunda.bpm.engine.impl.history.event.HistoricVariableUpdateEventEntity;
import org.camunda.bpm.engine.impl.history.event.HistoryEvent;
import org.camunda.bpm.engine.impl.history.handler.DbHistoryEventHandler;
import org.camunda.bpm.engine.impl.persistence.entity.HistoricJobLogEventEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;




public class OceCamundaHistoryEventHandler extends DbHistoryEventHandler {
	private static final String PIPE_SEP = "|";
	private static final String DASH_SEP = " --- ";
	private static final String TASK2 = " task";
	private static final String JOB2 = " job";
	private static final String PROCESS = " process";
	private static final String ACTIVITY = " activity";
	static final Logger log = LoggerFactory.getLogger(OceCamundaHistoryEventHandler.class);
	
	@Override
	public void handleEvent(HistoryEvent historyEvent) {
		super.handleEvent(historyEvent);
	    if (historyEvent instanceof HistoricVariableUpdateEventEntity) {
	      ;
	    } else {
	    	log(historyEvent);
	    }

	  }

	private void log(HistoryEvent historyEvent) {
		StringBuilder strB = new StringBuilder(PIPE_SEP);
		
		if (historyEvent instanceof HistoricActivityInstanceEventEntity){
			HistoricActivityInstanceEventEntity act = (HistoricActivityInstanceEventEntity)historyEvent;
			strB.append(historyEvent.getEventType());
			strB.append(ACTIVITY);
			strB.append(DASH_SEP);
			strB.append(historyEvent.getProcessInstanceId());
			strB.append(DASH_SEP);
			strB.append(act.getActivityName());
			strB.append(DASH_SEP);
			strB.append(act.getActivityId());
			strB.append(DASH_SEP);
			strB.append(act.getActivityType());
			strB.append(DASH_SEP);
			strB.append(act.getActivityInstanceState());
			strB.append(DASH_SEP);
			strB.append(act.getStartTime());
			strB.append(DASH_SEP);
			strB.append(act.getEndTime());
		} else if (historyEvent instanceof HistoricProcessInstanceEventEntity){
			HistoricProcessInstanceEventEntity pr = (HistoricProcessInstanceEventEntity)historyEvent;
			strB.append(historyEvent.getEventType());
			strB.append(PROCESS);
			strB.append(DASH_SEP);
			strB.append(historyEvent.getProcessInstanceId());
			strB.append(DASH_SEP);
			strB.append(pr.getBusinessKey());
			strB.append(DASH_SEP);
			strB.append(pr.getProcessDefinitionKey());
			strB.append(DASH_SEP);
			strB.append(pr.getStartTime());
			strB.append(DASH_SEP);
			strB.append(pr.getEndTime());
		} else if (historyEvent instanceof HistoricJobLogEventEntity){
			HistoricJobLogEventEntity job = (HistoricJobLogEventEntity)historyEvent;
			strB.append(job.isCreationLog()?"create":(job.isDeletionLog()?"delete":(job.isSuccessLog()?"success":"failure")) );
			strB.append(JOB2);			
			strB.append(DASH_SEP);
			strB.append(historyEvent.getProcessInstanceId());
			strB.append(DASH_SEP);
			strB.append(job.getActivityId());
			strB.append(DASH_SEP);
			strB.append(job.getJobDefinitionConfiguration());
			strB.append(DASH_SEP);
			strB.append(job.getJobRetries());
			strB.append(DASH_SEP);
			strB.append(job.getJobDueDate());
			strB.append(DASH_SEP);
			strB.append(job.isFailureLog()?job.getJobExceptionMessage():"");
		} else if (historyEvent instanceof HistoricTaskInstanceEventEntity){
			HistoricTaskInstanceEventEntity task = (HistoricTaskInstanceEventEntity)historyEvent;
			strB.append(historyEvent.getEventType());
			strB.append(TASK2);			
			strB.append(DASH_SEP);
			strB.append(historyEvent.getProcessInstanceId());
			strB.append(DASH_SEP);
			strB.append(task.getId());
			strB.append(DASH_SEP);
			strB.append(task.getDescription());
			strB.append(DASH_SEP);
			strB.append(task.getStartTime());
			strB.append(DASH_SEP);
			strB.append(task.getEndTime());
		}
		strB.append(PIPE_SEP);
		log.info(strB.toString());
	}

}
