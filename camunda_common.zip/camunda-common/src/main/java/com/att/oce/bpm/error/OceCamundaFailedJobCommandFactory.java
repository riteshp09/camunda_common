package com.att.oce.bpm.error;



import org.camunda.bpm.engine.impl.interceptor.Command;
import org.camunda.bpm.engine.impl.jobexecutor.FailedJobCommandFactory;

import com.att.oce.bpm.error.RetryException;
import com.att.oce.bpm.error.retry.ConfigJobRetryCmd;
import com.att.oce.bpm.error.retry.NoJobRetryCmd;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class OceCamundaFailedJobCommandFactory implements FailedJobCommandFactory {
	
	final Logger log = LoggerFactory.getLogger(this.getClass());
	
	public Command<Object> getCommand(String jobId, Throwable exception) {
		
		log.debug("Failure while executing for job id '" + jobId + "'. Exception message '"+exception.getClass().toString()+"'");
		log.debug("Exception Type : "+((exception.getCause() != null && exception.getCause().getCause() != null)?exception.getCause().getCause().getClass().toString():"null"));
		if(exception.getCause() != null && exception.getCause().getCause() != null)
		{	
			if (exception.getCause().getCause() instanceof RetryException){
			log.debug("Sending retry exception");
			return new ConfigJobRetryCmd(jobId, exception.getCause().getCause());
			}
		}
		log.debug("Sending no retry exception");
		return new NoJobRetryCmd(jobId, exception);
	}

}
