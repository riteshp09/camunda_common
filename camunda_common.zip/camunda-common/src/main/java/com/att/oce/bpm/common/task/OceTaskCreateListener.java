package com.att.oce.bpm.common.task;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.builder.ExchangeBuilder;
import org.camunda.bpm.engine.delegate.DelegateTask;
import org.camunda.bpm.engine.delegate.TaskListener;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.oce.config.components.URNResolver;

public class OceTaskCreateListener  implements TaskListener  {
	
	@Autowired
	CamelContext camelOutbound;
	
	@Resource
	protected URNResolver urnResolver;
	
	public void notify(DelegateTask task) {
		System.out.println("Task created with task Id "+task.getId());
		Map<String,Object> orderMap = new HashMap<String,Object>();
		orderMap.put("order", task.getVariable("order"));
		
		//StringBuilder orderString = new StringBuilder(new JSONObject(orderMap).toString());		
		Exchange e = ExchangeBuilder.anExchange(camelOutbound)
				
				.withBody(orderMap)
				.withHeader("CamundaTaskId", task.getId())
				.withProperty("executionContext", task.getVariable("executionContext"))
				.build();
		e.getIn().getHeaders().put("CamelHttpUri",urnResolver.resolveUrn("urn:atg:api"));
		camelOutbound.createProducerTemplate().send("direct:atgcreatetask",e);
		
	}

}
