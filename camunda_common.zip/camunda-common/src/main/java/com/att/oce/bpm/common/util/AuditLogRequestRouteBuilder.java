package com.att.oce.bpm.common.util;

import com.att.oce.config.components.GlobalProperties;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("auditLogRequestRouteBuilder")
public class AuditLogRequestRouteBuilder extends RouteBuilder {

  @Autowired GlobalProperties global;

  @Override
  public void configure() throws Exception {

    from("direct:auditlog:request")
    	.bean(AuditLogHelper.class, "prepareRequest")
        .choice()
        .when(constant(global.AuditLogLevel).in(1, 3))
        .to("auditlogq:" + global.AuditLogQueueName)
        .end()
        .routeId("AuditLogRequest");
  }
}