package com.att.oce.beans.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.ThreadPoolBuilder;
import org.apache.camel.component.http4.HttpClientConfigurer;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.commons.dbcp.BasicDataSource;
import org.camunda.bpm.dmn.engine.DmnEngine;
import org.camunda.bpm.dmn.engine.DmnEngineConfiguration;
import org.camunda.bpm.engine.impl.bpmn.parser.BpmnParseListener;
import org.camunda.bpm.engine.impl.incident.IncidentHandler;
import org.camunda.bpm.engine.impl.persistence.StrongUuidGenerator;
import org.camunda.bpm.engine.runtime.Incident;
import org.camunda.bpm.engine.spring.SpringProcessEngineConfiguration;
import org.camunda.bpm.engine.spring.components.jobexecutor.SpringJobExecutor;
import org.camunda.bpm.engine.spring.container.ManagedProcessEngineFactoryBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.att.oce.bpm.common.OceCamundaHistoryEventHandler;
import com.att.oce.bpm.common.task.OceTaskCreateListener;
import com.att.oce.bpm.common.task.OceTaskParseListener;
import com.att.oce.bpm.common.util.AuditLogHelper;
import com.att.oce.bpm.error.OceCamundaFailedJobCommandFactory;
import com.att.oce.bpm.error.OceErrorHandler;
import com.att.oce.bpm.error.OceIncidentHandler;
import com.att.oce.config.components.GlobalProperties;

@Configuration
public class OceCamundaConfiguration implements ApplicationContextAware {
	static final Logger log = LoggerFactory.getLogger(OceCamundaConfiguration.class);

	@Autowired
	GlobalProperties global;

	private ApplicationContext appContext;

	@Bean
	public DmnEngine dmnEngine() {
		log.info("DmnEngine created");

		DmnEngineConfiguration configuration = DmnEngineConfiguration.createDefaultDmnEngineConfiguration();

		DmnEngine dmnEngine = configuration.buildEngine();
		return dmnEngine;
	}

	@Bean
	public OceErrorHandler oceErrorHandler() {
		log.info("OceErrorHandler created");
		return new OceErrorHandler();
	}

	@Bean
	public BasicDataSource basicDataSource() {
		log.info("basicDataSource created");
		BasicDataSource basicDataSource = new BasicDataSource();
		basicDataSource.setDriverClassName(global.CamundaDbDriverClass);
		basicDataSource.setPassword(global.CamundaDbPassword);
		basicDataSource.setUsername(global.CamundaDbUsername);
		basicDataSource.setUrl(global.CamundaDbUrl);
		basicDataSource.setInitialSize(global.CamundaDbPoolInitialSize);
		basicDataSource.setMaxWait(global.CamundaDbPoolMaxWait);
		basicDataSource.setMaxActive(global.CamundaDbPoolMaxActive);
		basicDataSource.setMaxIdle(global.CamundaDbPoolMaxActive);
		basicDataSource.setTestOnBorrow(global.CamundaDbPoolTestOnBorrow);
		basicDataSource.setValidationQuery(global.CamundaDbValidationQuery);
		basicDataSource.setValidationQueryTimeout(global.CamundaDbValidationQueryTimeout);
		return basicDataSource;
	}

	@Bean
	public DataSourceTransactionManager transactionManager() {
		log.info("transactionManager created");
		DataSourceTransactionManager o = new DataSourceTransactionManager();
		o.setDataSource(basicDataSource());
		return o;
	}

	@Bean
	public OceTaskCreateListener oceTaskCreateListener() {
		log.info("oceTaskCreateListener created");
		return new OceTaskCreateListener();
	}

	@Bean
	public OceTaskParseListener oceTaskParseListener() {
		log.info("oceTaskParseListener created");
		return new OceTaskParseListener();
	}

	@Bean
	public SpringJobExecutor springJobExecutor() {
		log.info("springJobExecutor creating");
		SpringJobExecutor jExec = new SpringJobExecutor();
		ThreadPoolTaskExecutor th = new ThreadPoolTaskExecutor();
		log.info("CAMUNDA CONFIGURATION: camunda.executor.corepoolsize = " + this.global.CamundaExecutorCorePoolSize);
		th.setCorePoolSize(this.global.CamundaExecutorCorePoolSize);
		log.info("CAMUNDA CONFIGURATION: camunda.executor.maxPoolSize = " + this.global.CamundaExecutorMaxPoolSize);
		th.setMaxPoolSize(this.global.CamundaExecutorMaxPoolSize);
		th.setWaitForTasksToCompleteOnShutdown(true);
		jExec.setTaskExecutor(th);
		th.initialize();
		log.info("springJobExecutor created");

		return jExec;
	}

	@Bean
	public ManagedProcessEngineFactoryBean processEngine() {
		ManagedProcessEngineFactoryBean processEngineFactoryBean = new ManagedProcessEngineFactoryBean();

		List<IncidentHandler> customIncidentHandlers = new ArrayList<IncidentHandler>();
	    customIncidentHandlers.add(new OceIncidentHandler(Incident.FAILED_JOB_HANDLER_TYPE));

		SpringProcessEngineConfiguration configuration = new SpringProcessEngineConfiguration();
		configuration.setTransactionManager(transactionManager());
		configuration.setJobExecutorActivate(true);
		configuration.setDataSource(basicDataSource());
		configuration.setHistory(this.global.camundaHistory);
		configuration.setHistoryEventHandler(new OceCamundaHistoryEventHandler());
		configuration.setAuthorizationEnabled(true);
		configuration.setFailedJobCommandFactory(new OceCamundaFailedJobCommandFactory());
		configuration.setIdGenerator(new StrongUuidGenerator());
		configuration
				.setCustomPostBPMNParseListeners(Arrays.asList(new BpmnParseListener[] { oceTaskParseListener() }));
		configuration.setJobExecutor(springJobExecutor());
		configuration.setCustomIncidentHandlers(customIncidentHandlers);
		processEngineFactoryBean.setProcessEngineConfiguration(configuration);
		log.info("processEngine created");
		return processEngineFactoryBean;
	}

	@Bean
	public CamelContext camelContext() {
		log.info("camelContext created");
		CamelContext camelCtx = new SpringCamelContext(this.appContext);
		camelCtx.getManagementStrategy().setManagementNamingStrategy(new OceCamelNamingStrategy());
		camelCtx.setTracing(Boolean.valueOf(true));
		return camelCtx;
	}

	@Bean
	public AuditLogHelper auditLogeHelper() {
		log.info("auditLogeHelper created");
		return new AuditLogHelper();
	}

	@Bean
	public ExecutorService wiretapThreadPool() throws Exception {
		log.info("wiretapThreadPool created");
		ThreadPoolBuilder tpBuilder = new ThreadPoolBuilder(camelContext());
		ExecutorService wiretapThreadPool = tpBuilder.poolSize(global.CamelWiretapExecutorCorePoolSize).maxPoolSize(global.CamundaExecutorMaxPoolSize).maxQueueSize(global.CamelWiretapExecutorCorePoolSize).build("WireTap");
		return wiretapThreadPool;
	}

	@Bean
	public HttpClientConfigurer oceHttpClientConfigurer() {
		log.info("oceHttpClientConfigurer created");
		OceHttpClientConfigurer oceHttpClientConfigurer = new OceHttpClientConfigurer();
		oceHttpClientConfigurer.init(global);
		return oceHttpClientConfigurer;
	}

	public void setApplicationContext(ApplicationContext appContext) throws BeansException {
		this.appContext = appContext;
	}
}
