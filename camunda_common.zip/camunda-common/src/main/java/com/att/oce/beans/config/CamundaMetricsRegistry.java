package com.att.oce.beans.config;

import org.camunda.bpm.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.camunda.bpm.engine.impl.metrics.Meter;
import org.camunda.bpm.engine.spring.container.ManagedProcessEngineFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.stereotype.Component;

@Component("camundaMetricsRegistry")
public class CamundaMetricsRegistry {

	@Autowired ManagedProcessEngineFactoryBean processEngieConfig;
	
    
    @ManagedAttribute
    public long getActivityInstanceStart() {
    	ProcessEngineConfigurationImpl  processEngieConfigImpl = processEngieConfig.getProcessEngineConfiguration();
    	Meter activityInstanceStart = processEngieConfigImpl.getMetricsRegistry().getMeterByName("activity-instance-start");
    	return activityInstanceStart.get();
    }
    
    @ManagedAttribute
    public long getJobAcquiredFailure() {
    	ProcessEngineConfigurationImpl  processEngieConfigImpl = processEngieConfig.getProcessEngineConfiguration();
    	Meter jobAcquiredFailure = processEngieConfigImpl.getMetricsRegistry().getMeterByName("job-acquired-failure");
    	return jobAcquiredFailure.get();
    }
    
    @ManagedAttribute
    public long getJobLockedExclusive() {
    	ProcessEngineConfigurationImpl  processEngieConfigImpl = processEngieConfig.getProcessEngineConfiguration();
    	Meter jobLockedExclusive = processEngieConfigImpl.getMetricsRegistry().getMeterByName("job-locked-exclusive");
    	return jobLockedExclusive.get();
    }
    
    @ManagedAttribute
    public long getJobExecutionRejected() {
    	ProcessEngineConfigurationImpl  processEngieConfigImpl = processEngieConfig.getProcessEngineConfiguration();
    	Meter jobExecutionRejected = processEngieConfigImpl.getMetricsRegistry().getMeterByName("job-execution-rejected");
    	return jobExecutionRejected.get();
    }
    
    @ManagedAttribute
    public long getExecutedDecisionElements() {
    	ProcessEngineConfigurationImpl  processEngieConfigImpl = processEngieConfig.getProcessEngineConfiguration();
    	Meter executedDecisionElements = processEngieConfigImpl.getMetricsRegistry().getMeterByName("executed-decision-elements");
    	return executedDecisionElements.get();
    }
    
    @ManagedAttribute
    public long getActivityInstanceEnd() {
    	ProcessEngineConfigurationImpl  processEngieConfigImpl = processEngieConfig.getProcessEngineConfiguration();
    	Meter activityInstanceEnd = processEngieConfigImpl.getMetricsRegistry().getMeterByName("activity-instance-end");
    	return activityInstanceEnd.get();
    }
    
    @ManagedAttribute
    public long getJobSuccessful() {
    	ProcessEngineConfigurationImpl  processEngieConfigImpl = processEngieConfig.getProcessEngineConfiguration();
    	Meter jobSuccessful = processEngieConfigImpl.getMetricsRegistry().getMeterByName("job-successful");
    	return jobSuccessful.get();
    }
    
    @ManagedAttribute
    public long getJobAcquiredSuccess() {
    	ProcessEngineConfigurationImpl  processEngieConfigImpl = processEngieConfig.getProcessEngineConfiguration();
    	Meter jobAcquiredSuccess = processEngieConfigImpl.getMetricsRegistry().getMeterByName("job-acquired-success");
    	return jobAcquiredSuccess.get();
    }
    
    @ManagedAttribute
    public long getJobAcquisitionAttempt() {
    	ProcessEngineConfigurationImpl  processEngieConfigImpl = processEngieConfig.getProcessEngineConfiguration();
    	Meter jobAcquisitionAttempt = processEngieConfigImpl.getMetricsRegistry().getMeterByName("job-acquisition-attempt");
    	return jobAcquisitionAttempt.get();
    }
    
    @ManagedAttribute
    public long getJobFailed() {
    	ProcessEngineConfigurationImpl  processEngieConfigImpl = processEngieConfig.getProcessEngineConfiguration();
    	Meter jobFailed = processEngieConfigImpl.getMetricsRegistry().getMeterByName("job-failed");
    	return jobFailed.get();
    }
	
    @ManagedAttribute
    public void clearMeters() {
    	ProcessEngineConfigurationImpl  processEngieConfigImpl = processEngieConfig.getProcessEngineConfiguration();
    	Meter activityInstanceStart = processEngieConfigImpl.getMetricsRegistry().getMeterByName("activity-instance-start");
    	activityInstanceStart.getAndClear();
    	
    	Meter jobAcquiredFailure = processEngieConfigImpl.getMetricsRegistry().getMeterByName("job-acquired-failure");
    	jobAcquiredFailure.getAndClear();
    	
    	Meter jobLockedExclusive = processEngieConfigImpl.getMetricsRegistry().getMeterByName("job-locked-exclusive");
    	jobLockedExclusive.getAndClear();
    	
    	Meter jobExecutionRejected = processEngieConfigImpl.getMetricsRegistry().getMeterByName("job-execution-rejected");
    	jobExecutionRejected.getAndClear();
    	
    	Meter executedDecisionElements = processEngieConfigImpl.getMetricsRegistry().getMeterByName("executed-decision-elements");
    	executedDecisionElements.getAndClear();
    	
    	Meter activityInstanceEnd = processEngieConfigImpl.getMetricsRegistry().getMeterByName("activity-instance-end");
    	activityInstanceEnd.getAndClear();
    	
    	Meter jobSuccessful = processEngieConfigImpl.getMetricsRegistry().getMeterByName("job-successful");
    	jobSuccessful.getAndClear();
    	
    	Meter jobAcquiredSuccess = processEngieConfigImpl.getMetricsRegistry().getMeterByName("job-acquired-success");
    	jobAcquiredSuccess.getAndClear();
    	
    	Meter jobAcquisitionAttempt = processEngieConfigImpl.getMetricsRegistry().getMeterByName("job-acquisition-attempt");
    	jobAcquisitionAttempt.getAndClear();
    	
    	Meter jobFailed = processEngieConfigImpl.getMetricsRegistry().getMeterByName("job-failed");
    	jobFailed.getAndClear();
    }
}
