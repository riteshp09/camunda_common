package com.att.oce.bpm.common;

import java.util.ArrayList;
import java.util.List;

import org.camunda.bpm.engine.impl.bpmn.parser.AbstractBpmnParseListener;
import org.camunda.bpm.engine.impl.pvm.process.ScopeImpl;
import org.camunda.bpm.engine.impl.pvm.process.TransitionImpl;
import org.camunda.bpm.engine.impl.util.xml.Element;

public class TestBpmnParseListener extends AbstractBpmnParseListener {
	
	public static List<String> linkList = new ArrayList<String>();
	
	@Override
	public void parseSequenceFlow(Element sequenceFlowElement, ScopeImpl scopeElement, TransitionImpl transition) {
		linkList.add(sequenceFlowElement.attribute("id"));
	}
	
	public List getLinkList(){
		return linkList;
	}
}
