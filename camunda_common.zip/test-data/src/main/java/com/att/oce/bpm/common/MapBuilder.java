package com.att.oce.bpm.common;

import java.util.HashMap;
import java.util.Map;

public class MapBuilder {
	
	private Map<String,Object> map;
	
	public MapBuilder(){
		map = new HashMap<String, Object>();
	}
	
	public  MapBuilder add (String key,Object value){
		map.put(key, value);
		return this;
	}
	
	public static MapBuilder  build(){
		return new MapBuilder();
	}
	
	
	public Map<String,Object> get(){
		return map;
	}
}
