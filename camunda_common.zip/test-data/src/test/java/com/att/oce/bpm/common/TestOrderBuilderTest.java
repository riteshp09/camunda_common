package com.att.oce.bpm.common;

import java.util.Map;

import org.json.JSONException;

import groovy.util.Eval;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class TestOrderBuilderTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public TestOrderBuilderTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( TestOrderBuilderTest.class );
    }

    /**
     * Rigourous Test :-)
     * @throws Exception 
     */
    public void testApp() throws Exception
    {
        try {
			assertTrue( TestOrderBuilder.build("SimpleWirelessOrder").getMapofMaps().containsKey("customerOrderNumber") );
			assertTrue( ((Map<?,?>)TestOrderBuilder.build("SimpleWirelessOrder").getMapofMaps().get("OrderStatus")).get("Status").toString().equals("IN_PROGRESS") );
			assertTrue( TestOrderBuilder.build("WirelessAccessoryOrder").getMapofMaps().containsKey("CustomerOrderNumber") );
			assertTrue( ((Map<?,?>)TestOrderBuilder.build("WirelessAccessoryOrder").getMapofMaps().get("OrderStatus")).get("Status").toString().equals("SYS_RECEIVED") );
			
			Object o = TestOrderBuilder.build("Test").getMapofMaps();
			assertEquals( "Groovy Get failed","123456789",Eval.x(o, "x.productGroups.group[0].characteristics.losgCharacteristics.additionalDetails.additionalDetail.find { item -> item.code == 'SUBSCRIPTION_ID' }.value ") );
			o = TestOrderBuilder.build("TestInsideData").getMapofMaps();
			assertEquals( "Test resource inside data failed","ABCDEFGHIJKL",Eval.x(o, "x.productGroups.group[0].characteristics.losgCharacteristics.additionalDetails.additionalDetail.find { item -> item.code == 'SUBSCRIPTION_ID' }.value ") );
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
    }
}
