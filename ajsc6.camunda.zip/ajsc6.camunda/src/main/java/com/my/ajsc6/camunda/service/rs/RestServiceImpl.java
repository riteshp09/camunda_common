package com.my.ajsc6.camunda.service.rs;


import org.apache.log4j.Logger;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.ProcessEngines;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.engine.variable.VariableMap;
import org.camunda.bpm.engine.variable.Variables;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.ajsc.common.Tracable;
import com.my.ajsc6.camunda.common.LogMessages;
import com.att.ajsc.common.AjscService;

import com.my.ajsc6.camunda.model.HelloWorld;
import com.my.ajsc6.camunda.service.SpringService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;

@AjscService
public class RestServiceImpl implements RestService {	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(RestServiceImpl.class);

	@Autowired
	private SpringService service;

	public RestServiceImpl() {
		// needed for autowiring
	}

	@Override
	@Tracable(message = "invoking quick hello")
	public HelloWorld getQuickHello(String name) {	
		log.info(LogMessages.RESTSERVICE_HELLO);
		log.debug(LogMessages.RESTSERVICE_HELLO_NAME, name);
		
		ProcessEngine pe = ProcessEngines.getDefaultProcessEngine();
		RuntimeService rs = pe.getRuntimeService();
		
		VariableMap var = Variables.createVariables();
		var.put("testVar", "testVAlue");
		
		//.createProcessInstanceByKey("sampleProcess",var);
		
		ProcessInstance instance = rs.startProcessInstanceByKey("sampleProcess", var);
		
		return service.getQuickHello(name + "ProcessInst :: " + instance.getProcessInstanceId());
	}

}
