package com.my.ajsc6.camunda.service;

import com.my.ajsc6.camunda.model.HelloWorld;

public interface SpringService {
	public HelloWorld getQuickHello(String name);
}
